package etm.main.market.map;

import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.BounceInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

/**
 * Performs a bounce animation on a {@link Marker} when it is clicked.
 */
public class MapMarkerBounce
{
    private static final String TAG = MapMarkerBounce.class.getSimpleName();

    private final Handler mHandler;
    private BounceAnimation mAnimation;
    private Marker mMarker;

    public MapMarkerBounce(final Marker marker)
    {
        mHandler = new Handler();
        mMarker = marker;
    }

    public void startBounce()
    {
        // This causes the marker at Perth to bounce into position when it is clicked.
        final long start = SystemClock.uptimeMillis();
        final long duration = 2500L;

        // Cancels the previous animation
        mHandler.removeCallbacks(mAnimation);

        // Starts the bounce animation
        mAnimation = new BounceAnimation(start, duration, mMarker, mHandler);
        mAnimation.setWorking(true);
        mHandler.post(mAnimation);
    }

    public void stopBounce()
    {
        mAnimation.setWorking(false);
    }

    /**
     * Performs a bounce animation on a {@link Marker}.
     */
    private static class BounceAnimation implements Runnable
    {
        private final long mStart, mDuration;
        private final Interpolator mInterpolator;
        private final Marker mMarker;
        private final Handler mHandler;
        private boolean mWorking;

        private BounceAnimation(long start, long duration, Marker marker, Handler handler)
        {
            mStart = start;
            mDuration = duration;
            mMarker = marker;
            mHandler = handler;
            mInterpolator = new BounceInterpolator();
            mWorking = false;
        }

        public void setWorking(boolean working)
        {
            mWorking = working;
        }

        @Override
        public void run()
        {
            if(mWorking == true)
            {
                float x_coord, y_coord, distance;
                long elapsed = SystemClock.uptimeMillis() - mStart;
                float t = Math.max(1 - mInterpolator.getInterpolation((float) elapsed / mDuration), 0f);
                mMarker.setAnchor(0.5f , 1.0f + 1.2f * t);

                //float change_percent = ((float) elapsed / mDuration);
                /*
                float change_percent = Math.min(mInterpolator.getInterpolation((float) elapsed / mDuration), 1f);
                float angle = 360*change_percent;
                double radians = Math.toRadians(angle);

                distance = 0.5f*(1f-change_percent);
                //Log.d(TAG, String.format("angle : %f, distance : %f", angle, distance));

                x_coord = distance * (float)Math.cos(radians);
                y_coord = distance * (float)Math.sin(radians);

                mMarker.setAnchor(0.5f + x_coord , 0.5f + y_coord);
                */
                //if(distance > 0)
                if (t > 0.0)
                {
                    // Post again 16ms later.
                    mHandler.postDelayed(this, 16L);
                }
            }
        }

        public void scaleView(View v, float startScale, float endScale)
        {
            Animation anim = new ScaleAnimation(
                    1f, 1f, // Start and end values for the X axis scaling
                    startScale, endScale, // Start and end values for the Y axis scaling
                    Animation.RELATIVE_TO_SELF, 0f, // Pivot point of X scaling
                    Animation.RELATIVE_TO_SELF, 1f); // Pivot point of Y scaling
            anim.setFillAfter(true); // Needed to keep the result of the animation
            v.startAnimation(anim);
        }
    }
}