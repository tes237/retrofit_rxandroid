/**
 * Copyright 2016 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package etm.main.market;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;

import etm.main.market.activities.HomeActivity;
import etm.main.market.activities.SplashActivity;

public class LocalFirebaseMessagingService extends FirebaseMessagingService implements baseDefine
{
    private static final String TAG = LocalFirebaseMessagingService.class.getSimpleName();

    protected generalApplication mGeneralApplication = null;

    private static boolean isMessageActivityResumed = false;
    private static boolean isMessageActivityDestroyed = true;
    private static String friendIdForMessageActivity = null;
    private static String mMyId = "";

    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */
    // [START receive_message]
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage)
    {
        // [START_EXCLUDE]
        // There are two types of messages data messages and notification messages. Data messages are handled
        // here in onMessageReceived whether the app is in the foreground or background. Data messages are the type
        // traditionally used with GCM. Notification messages are only received here in onMessageReceived when the app
        // is in the foreground. When the app is in the background an automatically generated notification is displayed.
        // When the user taps on the notification they are returned to the app. Messages containing both notification
        // and data payloads are treated as notification messages. The Firebase console always sends notification
        // messages. For more see: https://firebase.google.com/docs/cloud-messaging/concept-options
        // [END_EXCLUDE]

        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: " + remoteMessage.getFrom());


        mGeneralApplication = (generalApplication)getApplicationContext();

        if(mGeneralApplication == null)
        {
            //app is terminated

            //save push data into Sqlite
            //remoteMessage.getNotification().getBody()
        }

        String jsonPushStr = remoteMessage.getNotification().getBody();
        try
        {
            JSONObject jasonPushObject = new JSONObject(jsonPushStr);

            if(mGeneralApplication == null)
            {
                //when app is terminated
                if("tgm_message".equals(remoteMessage.getNotification().getTitle()) == true)
                {
                    if(mGeneralApplication.getMessageAlarmFlag() == true)
                    {
                        sendPushNotification(remoteMessage.getNotification().getBody());
                    }
                }
            }
            else
            {
                if("tgm_message".equals(remoteMessage.getNotification().getTitle()) == true)
                {
                    if(mGeneralApplication.getMessageAlarmFlag() == false)
                    {
                        //need to check app is on the front screen
                        String jsonFromName = (String)jasonPushObject.get("from_name");
                        String jsonMsg = (String)jasonPushObject.get("msg");
                        String jsonFromId = (String)jasonPushObject.get("from_id");

                        if(isMessageActivityDestroyed == true)
                        {
                            if(mGeneralApplication.getMessageAlarmFlag() == true)
                            {
                                showCustomMessageToast(jsonMsg, 0);
                            }
                        }
                        else
                        {
                            if(jsonFromId != null && friendIdForMessageActivity != null)
                            {
                                if(jsonFromId.equals(friendIdForMessageActivity) == true)
                                {
                                    //showCustomMessageToast(jsonMsg, 0);
                                    Intent intent = new Intent(GENERAL_APP_ID);
                                    intent.setAction(GENERAL_MESSAGE_ID);
                                    intent.putExtra(GENERAL_APP_ID, NEW_MESSAGE_RECEIVED);
                                    sendBroadcast(intent);
                                }
                                else
                                {
                                    if(jsonFromId.equals(mMyId) == false)
                                    {
                                        showCustomMessageToast(jsonMsg, 0);
                                    }
                                }
                            }
                            else
                            {
                                showCustomMessageToast(jsonMsg, 0);
                            }
                        }
                    }
                }
            }
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }


        /*
        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0)
        {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());

            sendPushNotification(remoteMessage.getData().get("message"));
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null)
        {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }
        */

        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated. See sendNotification method below.
    }
    // [END receive_message]

    private void sendPushNotification(String json_message)
    {
        //System.out.println("received message : " + message);
        //Intent intent = new Intent(this, HomeActivity.class);

        String message = "";
        try {
            JSONObject jasonMessageObject = new JSONObject(json_message);
            message = jasonMessageObject.getString("msg");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Intent intent = new Intent(this, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent, PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.notification).setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher) )
                .setContentTitle(getString(R.string.new_chatting_message_arrived))
                .setContentText(message)
                .setAutoCancel(true)
                .setSound(defaultSoundUri).setLights(000000255, 500, 2000)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        PowerManager pm = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakelock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "TAG");
        wakelock.acquire(5000);

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
    }

    public void showCustomMessageToast(String msg, int duration)
    {
        //Let this be the code in your n'th level thread from main UI thread
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable()
        {
            public void run()
            {
                /*
                Toast toast = Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.BOTTOM, 0, 0);
                LinearLayout toastView = (LinearLayout) toast.getView();
                ImageView imageCodeProject = new ImageView(getApplicationContext());
                imageCodeProject.setImageResource(R.drawable.notification);
                toastView.addView(imageCodeProject, 0);
                toast.show();
                */

                LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
                View wholeLayout = inflater.inflate( R.layout.custom_toast, null );
                //View toastLayout = inflater.inflate(R.layout.custom_toast, (ViewGroup) wholeLayout.findViewById(R.id.custom_toast_layout));

                TextView chatText = (TextView) wholeLayout.findViewById(R.id.custom_toast_message);
                chatText.setText(msg);

                Toast toast = new Toast(getApplicationContext());
                toast.setDuration(Toast.LENGTH_LONG);
                toast.setView(wholeLayout);
                toast.show();
            }
        });
    }

    public static void setMyId(String myId)
    {
        mMyId = myId;
    }

    public static void setMessageActivityResumed(boolean flag, String friend_id)
    {
        isMessageActivityResumed = flag;
        friendIdForMessageActivity = friend_id;
    }

    public static void setMessageActivityDestroyed(boolean flag, String friend_id)
    {
        isMessageActivityDestroyed = flag;
        friendIdForMessageActivity = friend_id;
    }
}
