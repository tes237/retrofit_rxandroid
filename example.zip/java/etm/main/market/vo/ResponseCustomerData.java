package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class ResponseCustomerData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private Customer mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public Customer getData()
    {
        return mData;
    }
}
