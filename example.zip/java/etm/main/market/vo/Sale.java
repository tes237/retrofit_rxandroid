package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class Sale
{
    @SerializedName("customer_photo_url")
    private String mCustomerPhotoUrl;

    @SerializedName("sale_date")
    private String mSale_date;

    @SerializedName("sale_title")
    private String mSale_title;

    @SerializedName("sale_customer")
    private String mSale_customer;

    @SerializedName("sale_customer_id")
    private String mSale_customer_id;

    public String getCustomerPhotoUrl()
    {
        return mCustomerPhotoUrl;
    }
    public String getSale_date()
    {
        return mSale_date;
    }

    public String getSale_title()
    {
        return mSale_title;
    }

    public String getSale_customer()
    {
        return mSale_customer;
    }

    public String getSale_customer_id()
    {
        return mSale_customer_id;
    }

    public Sale(String date, String title, String customer, String id, String photo_url)
    {
        this.mSale_date = date;
        this.mSale_title = title;
        this.mSale_customer = customer;
        this.mSale_customer_id = id;
        this.mCustomerPhotoUrl = photo_url;
    }
}