package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ServerMapResourceData
{
    HashMap<String, String> audios = new HashMap<String, String>();
    HashMap<String, String> images = new HashMap<String, String>();
    HashMap<String, String> rectangles = new HashMap<String, String>();
    HashMap<String, String> videos = new HashMap<String, String>();

    public String getAudio(String id) { return audios.get(id); }
    public String getImage(String id) { return images.get(id); }
    public String getRectangle(String id) { return rectangles.get(id); }
    public String getVideo(String id) { return videos.get(id); }

    public void addAudio(String id, String path)
    {
        audios.put(id, path);
    }
    public void addImage(String id, String path) { images.put(id, path);  }
    public void addRectangle(String id, String path)
    {
        rectangles.put(id, path);
    }
    public void addVideo(String id, String path)
    {
        videos.put(id, path);
    }
}