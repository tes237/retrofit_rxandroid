package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;


public class MessageListData
{
    @SerializedName("message_list_id")
    String mMessageListId;

    @SerializedName("image_path")
    String mImagePath;

    @SerializedName("user_name")
    String mUserName;

    @SerializedName("last_message")
    String mLastMessage;

    @SerializedName("message_date")
    String mMessageDate;

    public String getImagePath()
    {
        return this.mImagePath;
    }
    public String getUserName()
    {
        return this.mUserName;
    }
    public String getLastMessage()
    {
        return this.mLastMessage;
    }
    public String getMessageDate()
    {
        return this.mMessageDate;
    }

    public MessageListData(String id, String image_path, String userName, String lastMessage, String messageDate)
    {
        this.mMessageListId = id;
        this.mImagePath = image_path;
        this.mUserName = userName;
        this.mLastMessage = lastMessage;
        this.mMessageDate = messageDate;
    }
}