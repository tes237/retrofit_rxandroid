package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class Review
{
    @SerializedName("review_id")
    private String mReview_id;

    @SerializedName("review_rating1")
    private String mReview_rating1;

    @SerializedName("review_rating2")
    private String mReview_rating2;

    @SerializedName("review_title")
    private String mReview_title;

    @SerializedName("review_detail")
    private String mReview_detail;

    @SerializedName("review_nickname")
    private String mReview_nickname;

    @SerializedName("review_created_at")
    private String mReview_created_at;

    @SerializedName("reviewer_profile_url")
    private String mReview_profile_url;

    public String getReviewId()
    {
        return mReview_id;
    }

    public String getRating1()
    {
        return mReview_rating1;
    }

    public String getRating2()
    {
        return mReview_rating2;
    }

    public String getTitle()
    {
        return mReview_title;
    }

    public String getDetail()
    {
        return mReview_detail;
    }

    public String getNickname()
    {
        return mReview_nickname;
    }

    public String getCreatedAt()
    {
        return mReview_created_at;
    }

    public String getProfileUrl()
    {
        return mReview_profile_url;
    }

    public Review(String review_id, String rating1, String rating2, String title, String detail, String nickname, String created_at, String profileUrl)
    {
        this.mReview_id = review_id;
        this.mReview_rating1 = rating1;
        this.mReview_rating2 = rating2;
        this.mReview_title = title;
        this.mReview_detail = detail;
        this.mReview_nickname = nickname;
        this.mReview_created_at = created_at;
        this.mReview_profile_url = profileUrl;
    }
}