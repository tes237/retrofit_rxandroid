package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Stores
{
    @SerializedName("stores")
    public ArrayList<String> store_names;

    @SerializedName("urls")
    public ArrayList<String> store_urls;

    public ArrayList<String> getStores()
    {
        return store_names;
    }

    public ArrayList<String> getUrls()
    {
        return store_urls;
    }
}