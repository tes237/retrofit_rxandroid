package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseProductsData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private Products mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public Products getData()
    {
        return mData;
    }
}