package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseTestMapsData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private TestMaps mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public TestMaps getData()
    {
        return mData;
    }
}