package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseReviewsData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private Reviews mData;

    @SerializedName("purchased_by_me")
    private int mIsPurchased;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public int getIsPurchased()
    {
        return mIsPurchased;
    }

    public Reviews getData()
    {
        return mData;
    }
}