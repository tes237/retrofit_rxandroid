package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class ServerMapEventData implements Comparable<Object>
{
    public static final int NO_INDEX = 9999;

    //public static final int NODE_TYPE_NONE = 0;
    //public static final int NODE_TYPE_SINGLE = 1;
    //public static final int NODE_TYPE_MULTI = 2;
    //public static final int NODE_TYPE_INTRO = 3;

    public static final int NODE_TYPE_LOCATION_RELATED = 1;
    public static final int NODE_TYPE_NO_LOCATION_RELATED = 2;

    public static final int LOCATION_DETECTION_DISABLED = 0;
    public static final int LOCATION_DETECTION_ENABLED = 1;

    public static final int DISTANCE_FOR_LOCATION_DETECTION = 25;

    int index;
    String title;
    double lat = 0;
    double lng = 0;
    int type;
    int category;
    int nexts[];
    int prevs[];
    String time;
    ServerMapTextData text;
    String picture;
    String audio;
    //String image_id;
    int locationDetection = LOCATION_DETECTION_DISABLED;
    int distanceForLocationDetection = DISTANCE_FOR_LOCATION_DETECTION;

    //float coordinates[] = new float[4];
    //String rectangleId;
    String imageData;

    public int getIndex() { return index; }
    public String getTitle() { return title; }
    public double getLat() { return lat; }
    public double getLng() { return lng; }
    public int getType() { return type; }
    public int getCategory() { return category; }
    public int[] getNexts() { return nexts; }
    public int[] getPrevs() { return prevs; }
    public String getTime() { return time; }
    public ServerMapTextData getText() { return text; }
    public String getPicture() { return picture; }
    public String getAudio() { return audio; }
    //public String getImageId() { return image_id; }
    public int getLocationDetection() { return locationDetection; }
    public int getDistanceForLocationDetection() { return distanceForLocationDetection; }

    public void setIndex(String tmpIndex)
    {
        if ((tmpIndex == null) || (tmpIndex.equals("") == true))
        {
            index = NO_INDEX;
        }
        else
        {
            index = Integer.valueOf(tmpIndex);
        }
    }
    public void setTitle(String tmpTitle) { title = tmpTitle; }
    public void setLat(String tmpLat)
    {
        lat = Double.parseDouble(tmpLat);
    }
    public void setLng(String tmpLng)
    {
        lng = Double.parseDouble(tmpLng);
    }
    public void setType(String tmpType)
    {
        if ((tmpType == null) || (tmpType.equals("") == true))
        {
            type = NODE_TYPE_LOCATION_RELATED;
        }
        else
        {
            type = Integer.valueOf(tmpType);
        }
    }

    public void setCategory(String tmpCategory)
    {
        if ((tmpCategory == null) || (tmpCategory.equals("") == true))
        {
            category = NODE_TYPE_LOCATION_RELATED;
        }
        else
        {
            category = Integer.valueOf(tmpCategory);
        }
    }
    public void setNexts(int []tmpNext) { nexts = tmpNext; }
    public void setPrevs(int []tmpPrev) { prevs = tmpPrev; }

    public void setTime(String tmpTime) { time = tmpTime; }
    public void setText(ServerMapTextData tmpText) { text = tmpText; }
    public void setPicture(String tmpPicture) { picture = tmpPicture; }
    public void setAudio(String tmpAudio) { audio = tmpAudio; }
    //public void setImageId(String tmpImage) { image_id = tmpImage; }
    public void setLocationDetection(String tmpLocationDetection)
    {
        if ((tmpLocationDetection == null) || (tmpLocationDetection.equals("") == true))
        {
            locationDetection = LOCATION_DETECTION_DISABLED;
            distanceForLocationDetection = DISTANCE_FOR_LOCATION_DETECTION;
        }
        else
        {
            String parsedString[] = tmpLocationDetection.split(":");

            if(parsedString != null)
            {
                locationDetection = Integer.valueOf(parsedString[0]);
                distanceForLocationDetection = Integer.valueOf(parsedString[1]);
            }
            else
            {
                locationDetection = LOCATION_DETECTION_DISABLED;
                distanceForLocationDetection = DISTANCE_FOR_LOCATION_DETECTION;
            }
        }
    }

    /*
    //public String getRectangleId()
    public float[] getRectangleId()
    {
        return coordinates;
        //return rectangleId;
    }
    public void setRectangleId(String tmpRectangleId)
    {
        if((tmpRectangleId != null) && (tmpRectangleId.equals("") == false))
        {
            //rectangleId = tmpRectangleId;

            String coords[] = tmpRectangleId.split(",");

            for (int x = 0; x < 4; x++)
            {
                coordinates[x] = Float.valueOf(coords[x]);
            }

        }
    }
    */

    public void setImageData(String tmpImageData)
    {
        if((tmpImageData != null) && (tmpImageData.equals("") == false))
        {
            imageData = tmpImageData;
            //String tmpImageDataArr[] = tmpImageData.split("_");
            //this.setImageId(tmpImageDataArr[0]);
            //this.setRectangleId(tmpImageDataArr[1]);
        }
    }

    public String getImageData() { return imageData; }

    @Override
    public int compareTo(Object another)
    {
        ServerMapEventData f = (ServerMapEventData) another;
        if(index == f.index)
        {
            return 0;
        }
        else if(index > f.index)
        {
            return 1;
        }
        else //if(index < f.index)
        {
            return -1;
        }
    }
}