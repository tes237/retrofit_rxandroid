package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class MapFile
{
    @SerializedName("file_name")
    private String mFileName;

    @SerializedName("file_size")
    private long mFileSize;

    @SerializedName("file_key")
    private String mFileKey;

    public String getFileName()
    {
        return mFileName;
    }

    public long getFileSize()
    {
        return mFileSize;
    }

    public String getFileKey()
    {
        return mFileKey;
    }

    public MapFile(String name, long size, String key)
    {
        this.mFileName = name;
        this.mFileSize = size;
        this.mFileKey = key;
    }
}