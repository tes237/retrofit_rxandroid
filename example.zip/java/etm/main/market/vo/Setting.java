package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class Setting
{
    @SerializedName("message_alarm_disable")
    private String mMessageDisable;

    @SerializedName("selling_alarm_disable")
    private String mSellingDisable;

    @SerializedName("buying_alarm_disable")
    private String mBuyingDisable;

    @SerializedName("admin_question_email")
    private String mAdminMail;

    public String getMessage_disable()
    {
        return mMessageDisable;
    }

    public String getSelling_disable()
    {
        return mSellingDisable;
    }

    public String getBuying_disable()
    {
        return mBuyingDisable;
    }

    public String getAdmin_mail()
    {
        return mAdminMail;
    }

}