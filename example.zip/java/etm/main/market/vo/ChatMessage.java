package etm.main.market.vo;

public class ChatMessage
{
    public static final int MORE_DATE_TYPE = 1;
    public static final int CHAT_MESSAGE_TYPE = 2;

    private int type;
    private int previous_year;
    private int previous_month;
    private int previous_date;

    private long id;
    private boolean isMe;
    private String message;
    private Long userId;
    private String dateTime;

    public ChatMessage(long id, boolean isMe, String message, Long userId, String dateTime)
    {
        this.type = CHAT_MESSAGE_TYPE;
        this.id = id;
        this.isMe = isMe;
        this.message = message;
        this.userId = userId;
        this.dateTime = dateTime;
    }

    public long getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }

    public int getPrevious_year()
    {
        return previous_year;
    }

    public int getPrevious_month()
    {
        return previous_month;
    }

    public int getPrevious_date()
    {
        return previous_date;
    }

    public void setPreviousDate(int year, int month, int date)
    {
        previous_year = year;
        previous_month = month;
        previous_date = date;
    }


    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public boolean getIsme() {
        return isMe;
    }
    public void setMe(boolean isMe) {
        this.isMe = isMe;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getDate() {
        return dateTime;
    }

    public void setDate(String dateTime) {
        this.dateTime = dateTime;
    }
}