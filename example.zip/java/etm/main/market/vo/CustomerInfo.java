package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class CustomerInfo
{
    @SerializedName("customer_id")
    private String mCustomer_id;

    @SerializedName("terms_agree")
    private String mTerms_agree;

    @SerializedName("privacy_agree")
    private String mPrivacy_agree;

    public String getCustomer_id()
    {
        return mCustomer_id;
    }

    public String getTerms_agree()
    {
        return mTerms_agree;
    }

    public String getPrivacy_agree()
    {
        return mPrivacy_agree;
    }

}