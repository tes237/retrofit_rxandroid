package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class Route
{
    @SerializedName("title")
    private String mTitle;

    public String getTitle()
    {
        return mTitle;
    }

    public Route(String title)
    {
        this.mTitle = title;
    }
}