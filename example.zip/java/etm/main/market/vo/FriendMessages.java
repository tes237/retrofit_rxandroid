package etm.main.market.vo;

import android.os.Message;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class FriendMessages
{
    @SerializedName("sent_time_from_me")
    private String mSent_time_from_me;

    @SerializedName("recv_time_from_friend")
    private String mRecv_time_from_friend;

    public String getSent_time_from_me()
    {
        return mSent_time_from_me;
    }

    public String getRecv_time_from_friend()
    {
        return mRecv_time_from_friend;
    }

    public List<FriendMessage> messages;

    public List<FriendMessage> getMessages()
    {
        return messages;
    }
}