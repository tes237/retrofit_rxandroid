package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class SendReturn
{
    @SerializedName("from_id")
    private long mFrom_id;

    @SerializedName("recv_update_time")
    private String mRecv_update_time;

    @SerializedName("send_update_time")
    private String mSend_update_time;

    public long getFrom_id()
    {
        return mFrom_id;
    }

    public String getRecv_update_time()
    {
        return mRecv_update_time;
    }

    public String getSend_update_time()
    {
        return mSend_update_time;
    }

    public SendReturn(long from_id, String recv_update_time, String send_update_time)
    {
        this.mFrom_id = from_id;
        this.mRecv_update_time = recv_update_time;
        this.mSend_update_time = send_update_time;
    }
}