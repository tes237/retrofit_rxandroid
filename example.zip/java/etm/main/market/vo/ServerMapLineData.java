package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;


public class ServerMapLineData
{
    String lineText;
    String audioId;
    String videoId;
    String imageData;

    public String getLineText() { return lineText; }
    public void setLineText(String tmpLineText) { lineText = tmpLineText; }

    public String getAudioId() { return audioId; }
    public void setAudioId(String tmpAudioPath) { audioId = tmpAudioPath; }

    public String getVideoId() { return videoId; }
    public void setVideoId(String tmpVideoPath) { videoId = tmpVideoPath; }

    /*
    public String getImageId() { return imageId; }
    public void setImageId(String tmpImageId) { imageId = tmpImageId; }

    //public String getRectangleId()
    public float[] getRectangleId()
    {
        return coordinates;
        //return rectangleId;
    }

    public void setRectangleId(String tmpRectangleId)
    {
        if((tmpRectangleId != null) && (tmpRectangleId.equals("") == false))
        {
            //rectangleId = tmpRectangleId;
            String coords[] = tmpRectangleId.split(",");

            for (int x = 0; x < 4; x++)
            {
                coordinates[x] = Float.valueOf(coords[x]);
            }
        }
    }
    */

    public void setImageData(String tmpImageData)
    {
        if((tmpImageData != null) && (tmpImageData.equals("") == false))
        {
            imageData = tmpImageData;
            //String tmpImageDataArr[] = tmpImageData.split("_");
            //this.setImageId(tmpImageDataArr[0]);
            //this.setRectangleId(tmpImageDataArr[1]);
        }
    }

    public String getImageData() { return imageData; }
}