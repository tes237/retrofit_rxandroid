package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import etm.main.market.graphs.Graph;

public class ServerMapData
{
    List<ServerMapPreData> pre = null;
    String time = null;
    List<ServerMapRouteData> route = null;
    ServerMapResourceData resource = null;
    String title;

    public String getTime() { return time; }
    public void setTime(String tmpTime) { time = tmpTime; }
    public String getTitle() { return title; }

    public List<ServerMapPreData> getPre() { return pre; }
    public void setPre(List<ServerMapPreData> tmpPre) { pre = tmpPre; }
    public void addPre(ServerMapPreData tmpPre)
    {
        if(pre == null)
        {
            pre = new ArrayList<ServerMapPreData>();
            pre.add(tmpPre);
        }
        else
        {
            pre.add(tmpPre);
        }
    }

    public List<ServerMapRouteData> getRoute() { return route; }
    public void setRoute(List<ServerMapRouteData> tmpRoute) { route = tmpRoute; }
    public void addRoute(ServerMapRouteData tmpRoute)
    {
        if(route == null)
        {
            route = new ArrayList<ServerMapRouteData>();
            route.add(tmpRoute);
        }
        else
        {
            route.add(tmpRoute);
        }
    }

    public ServerMapResourceData getResource() { return resource; }
    public void addResource(ServerMapResourceData tmpResource)
    {
        resource = tmpResource;
    }
    public void setTitle(String tmpTitle) { title = tmpTitle; }
}