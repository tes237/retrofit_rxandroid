package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class FriendMessage
{
    @SerializedName("msg_from_id")
    private String mMsg_from_id;

    @SerializedName("msg_to_id")
    private String mMsg_to_id;

    @SerializedName("msg_body")
    private String mMsg_body;

    @SerializedName("msg_time")
    private String mMsg_time;

    public String getMsgFromId()
    {
        return mMsg_from_id;
    }

    public String getMsgToId()
    {
        return mMsg_to_id;
    }

    public String getMsgBody()
    {
        return mMsg_body;
    }

    public String getMsgTime()
    {
        return mMsg_time;
    }

    public FriendMessage(String from_id, String to_id, String body, String time)
    {
        this.mMsg_from_id = from_id;
        this.mMsg_to_id = to_id;
        this.mMsg_body = body;
        this.mMsg_time = time;
    }
}