package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Products
{
    @SerializedName("total_page_count")
    private int mTotal_page_count;

    @SerializedName("current_page_index")
    private int mCurrent_page_index;

    public int getTotal_page_count()
    {
        return mTotal_page_count;
    }

    public int getCurrent_page_index()
    {
        return mCurrent_page_index;
    }

    public List<Product> products;

    public List<Product> getProducts()
    {
        return products;
    }
}