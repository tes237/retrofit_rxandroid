package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class MapFiles
{
    @SerializedName("sku")
    private String mSku;

    public String getSku()
    {
        return mSku;
    }

    public List<MapFile> downloadable;

    public List<MapFile> getMapFiles()
    {
        return downloadable;
    }
}
