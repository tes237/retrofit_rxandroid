package etm.main.market.vo;

import com.google.android.gms.maps.model.LatLng;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ServerMapRouteData
{
    String time;
    String title;
    ArrayList<LatLng> area = null;
    List<ServerMapSpotData> spot;

    public String getTime() { return time; }
    public String getTitle() { return title; }
    public ArrayList<LatLng> getArea() { return area; }
    public List<ServerMapSpotData> getSpot() { return spot; }

    public void setTitle(String tmpTitle) { title = tmpTitle; }
    public void setTime(String tmpTime) { time = tmpTime; }
    public void setArea(String tmpArea)
    {
        if(area == null)
        {
            area = new ArrayList<LatLng>();
        }
        else
        {
            area.clear();
        }

        if((tmpArea != null) && (tmpArea.equals("") == false))
        {
            String latLngRaw[] = tmpArea.split("_");

            for(int x = 0; x < latLngRaw.length; x++)
            {
                String tmpLatLngString = latLngRaw[x];

                String LatLngArray[] = tmpLatLngString.split(" ");
                double lat = Double.parseDouble(LatLngArray[0]);
                double lng = Double.parseDouble(LatLngArray[1]);

                LatLng tmpLatLng = new LatLng(lat, lng);
                area.add(tmpLatLng);
            }
        }

    }
    public void setSpot(List<ServerMapSpotData> tmpSpotList) { spot = tmpSpotList; }
    public void addSpot(ServerMapSpotData tmpSpot)
    {
        if(spot == null)
        {
            spot = new ArrayList<ServerMapSpotData>();
            spot.add(tmpSpot);
        }
        else
        {
            spot.add(tmpSpot);
        }
    }
}