package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class CustomerStats
{
    @SerializedName("whole_sale_money")
    private long mWhole_sale_money;

    @SerializedName("total_sold_map_count")
    private long mTotal_sold_map_count;

    @SerializedName("total_earn_money")
    private long mTotal_earn_money;

    @SerializedName("unread_message_count")
    private long mUnread_message_count;

    @SerializedName("customer_name")
    private String mCustomer_name;

    @SerializedName("customer_id")
    private String mCustomer_id;

    @SerializedName("terms_agree")
    private String mIsTerms_agreed;

    @SerializedName("privacy_agree")
    private String mIsPrivacy_agreed;

    public long getWhole_sale_money()
    {
        return mWhole_sale_money;
    }

    public long getTotal_sold_map_count()
    {
        return mTotal_sold_map_count;
    }

    public long getTotal_earn_money()
    {
        return mTotal_earn_money;
    }

    public long getUnread_message_count()
    {
        return mUnread_message_count;
    }

    public String getCustomer_name()
    {
        return mCustomer_name;
    }

    public String getCustomer_id()
    {
        return mCustomer_id;
    }

    public String isTermsAgreed()
    {
        return mIsTerms_agreed;
    }

    public String isPrivacyAgreed()
    {
        return mIsPrivacy_agreed;
    }

    public CustomerStats(long map_count, long earn_money, long msg_count, String name, String id)
    {
        this.mTotal_sold_map_count = map_count;
        this.mTotal_earn_money = earn_money;
        this.mUnread_message_count = msg_count;
        this.mCustomer_name = name;
        this.mCustomer_id = id;

    }
}