package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseMapFilesData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private MapFiles mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public MapFiles getData()
    {
        return mData;
    }
}