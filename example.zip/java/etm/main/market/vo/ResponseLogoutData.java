package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class ResponseLogoutData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private String mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public String getData()
    {
        return mData;
    }
}
