package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class Product
{
    @SerializedName("map_sku")
    private String mMap_sku;

    @SerializedName("map_name")
    private String mMap_name;

    @SerializedName("map_price")
    private String mMap_price;

    @SerializedName("map_expected_expenses")
    private String mMap_expected_expenses;

    @SerializedName("map_image1")
    private String mMap_image1;

    @SerializedName("map_image2")
    private String mMap_image2;

    @SerializedName("map_image3")
    private String mMap_image3;

    @SerializedName("map_desc")
    private String mMap_desc;

    @SerializedName("map_rating1")
    private int mMap_rating1;

    //@SerializedName("map_rating2")
    //private int mMap_rating2;

    @SerializedName("map_rating_count")
    private int mMap_rating_count;

    @SerializedName("map_lat")
    private String mMap_lat;

    @SerializedName("map_lon")
    private String mMap_lon;

    @SerializedName("map_distance")
    private String mMap_distanc;

    @SerializedName("map_seller_name")
    private String mMap_seller_name;

    @SerializedName("map_seller_id")
    private String mMap_seller_id;

    @SerializedName("map_themed_type")
    private String mMap_themed_type;

    @SerializedName("map_special_food_type")
    private String mMap_special_food_type;

    @SerializedName("map_trans_type")
    private String mMap_trans_type;

    @SerializedName("map_required_duration")
    private String mMap_required_duration;

    @SerializedName("map_modify_transaction_index")
    private long mMap_modify_transaction_index;

    @SerializedName("update_time")
    private long mUpdate_time;

    @SerializedName("video_link")
    private String mVideo_link;

    @SerializedName("wishlist_flag")
    private String mWishlist_flag;

    @SerializedName("store_language")
    private String mStore_language;

    public String getSku()
    {
        return mMap_sku;
    }

    public String getName()
    {
        return mMap_name;
    }

    public String getPrice()
    {
        return mMap_price;
    }

    public String getImage1()
    {
        return mMap_image1;
    }

    public String getImage2()
    {
        return mMap_image2;
    }

    public String getImage3()
    {
        return mMap_image3;
    }

    public String getDesc()
    {
        return mMap_desc;
    }

    public String getLat()
    {
        return mMap_lat;
    }

    public String getLng()
    {
        return mMap_lon;
    }

    public String getDistance()
    {
        return mMap_distanc;
    }

    public int getRating1()
    {
        return mMap_rating1;
    }

    public int getRatingCount()
    {
        return mMap_rating_count;
    }

    public long getModifyTransactionIndex()
    {
        return mMap_modify_transaction_index;
    }

    public long getUpdateTime()
    {
        return mUpdate_time;
    }

    public String getMapSellerName()
    {
        return mMap_seller_name;
    }

    public String getMapSellerId()
    {
        return mMap_seller_id;
    }

    public String getMapThemedType()
    {
        return mMap_themed_type;
    }

    public String getMapSpecialFoodType()
    {
        return mMap_special_food_type;
    }

    public String getMapTransType()
    {
        return mMap_trans_type;
    }

    public String getMapRequiredDuration()
    {
        return mMap_required_duration;
    }

    public String getMapExpectedExpenses()
    {
        return mMap_expected_expenses;
    }

    public String getVideoLink()
    {
        return mVideo_link;
    }

    public boolean isWishlistAdded()
    {
        if("true".equals(mWishlist_flag) == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public String getStoreLanaguage()
    {
        return mStore_language;
    }

    public Product(String id, String image_path, String title, String price, long updateTime, long transactionIndex, int rating1, String storeId)
    {
        this.mMap_sku = id;
        this.mMap_image1 = image_path;
        //this.mMap_image2 = image_path;
        //this.mMap_image3 = image_path;
        this.mMap_name = title;
        this.mMap_price = price;
        this.mUpdate_time = updateTime;
        this.mMap_modify_transaction_index = transactionIndex;
        this.mMap_rating1 = rating1;
        //this.mMap_rating2 = rating2;
        this.mStore_language = storeId;
    }
}