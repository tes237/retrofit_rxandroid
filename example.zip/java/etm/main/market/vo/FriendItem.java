package etm.main.market.vo;

public class FriendItem
{
    private String mUserName;

    private String mUserId;

    private String mFriendPhotoUrl;

    private String mServerReceiveTime;

    private String mLocalReceiveTime;

    private boolean itHasNewReceiveMessage;

    private boolean itHasNewSendMessage;

    private boolean itNeedNewAlarm;

    public String getUserName()
    {
        return mUserName;
    }

    public String getUserId()
    {
        return mUserId;
    }

    public String getUserPhotoUrl()
    {
        return mFriendPhotoUrl;
    }

    public String getServerReceiveTime()
    {
        return mServerReceiveTime;
    }

    public String getLocalReceiveTime()
    {
        return mLocalReceiveTime;
    }

    public boolean itHasNewReceiveMessage()
    {
        return itHasNewReceiveMessage;
    }

    public boolean itHasNewSendMessage()
    {
        return itHasNewSendMessage;
    }

    public boolean itNeedNewAlarm()
    {
        return itNeedNewAlarm;
    }

    public void setItHasNewReceiveMessage(boolean flag)
    {
        itHasNewReceiveMessage = flag;
    }

    public void setItHasNewSendMessage(boolean flag)
    {
        itHasNewSendMessage = flag;
    }

    public void setItNeedNewAlarm(boolean flag)
    {
        itNeedNewAlarm = flag;
    }

    public FriendItem(String user_name, String user_id, String user_photo_url, String server_receive_time, String local_receive_time, boolean new_receive, boolean new_send, boolean new_alarm)
    {
        this.mUserName = user_name;
        this.mUserId = user_id;
        this.mFriendPhotoUrl = user_photo_url;
        this.mServerReceiveTime = server_receive_time;
        this.mLocalReceiveTime = local_receive_time;
        this.itHasNewReceiveMessage =new_receive;
        this.itHasNewSendMessage = new_send;
        this.itNeedNewAlarm = new_alarm;
    }
}