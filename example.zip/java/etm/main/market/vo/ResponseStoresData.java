package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseStoresData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private Stores mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public Stores getData()
    {
        return mData;
    }
}