package etm.main.market.vo;

import com.google.android.gms.maps.model.LatLng;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ServerMapSpotData implements Comparable<Object>
{
    public static final int NO_INDEX = 9999;

    public static final int NODE_TYPE_NONE = 0;
    public static final int NODE_TYPE_SINGLE = 1;
    public static final int NODE_TYPE_MULTI = 2;
    public static final int NODE_TYPE_INTRO = 3;
    public static final int NODE_TYPE_MOVEMENT = 4;

    //public static final int NODE_CATEGORY_MOVEMENT = 100;
    public static final int NODE_CATEGORY_ETC = 1000;

    public static final int NODE_RECOMMENDED_NONE = 0;
    public static final int NODE_RECOMMENDED_TRUE = 1;

    public static final int NO_NEXT_RECOMMENDED_SPOT_ID = -1;

    int spot_id;
    int index;
    String title;
    int type;
    int category;
    int nexts[];
    int prevs[];
    int next_recommended_spot_id = -1;
    String maker;
    //int distance;
    ArrayList<LatLng> area = null;
    //int recommended = -1;

    //String image_id;
    //float coordinates[] = new float[4];

    //String rectangleId;
    String imageData;

    List<ServerMapEventData> event;

    public int getId() { return spot_id; }
    public int getIndex() { return index; }
    public String getTitle() { return title; }
    public int getType() { return type; }
    public int getCategory() { return category; }
    public int[] getNexts() { return nexts; }
    public int[] getPrevs() { return prevs; }
    public int getNextRecommendedSpotId() { return next_recommended_spot_id; }
    public String getMaker() { return maker; }
    public ArrayList<LatLng> getArea() { return area; }

    //public int getRecommended() { return recommended; }

    public List<ServerMapEventData> getEvent() { return event; }

    public void setId(String tmpSpotId)
    {
        spot_id = Integer.valueOf(tmpSpotId);
    }

    public void setIndex(String tmpIndex)
    {
        if ((tmpIndex == null) || (tmpIndex.equals("") == true))
        {
            index = NO_INDEX;
        }
        else
        {
            index = Integer.valueOf(tmpIndex);
        }
    }
    public void setTitle(String tmpTitle) { title = tmpTitle; }
    public void setType(String tmpType)
    {
        if ((tmpType == null) || (tmpType.equals("") == true))
        {
            type = NODE_TYPE_NONE;
        }
        else
        {
            type = Integer.valueOf(tmpType);
        }
    }

    public void setCategory(String tmpCategory)
    {
        if ((tmpCategory == null) || (tmpCategory.equals("") == true))
        {
            category = NODE_TYPE_NONE;
        }
        else
        {
            category = Integer.valueOf(tmpCategory);
        }
    }
    public void setNexts(int []tmpNext) { nexts = tmpNext; }
    public void setPrevs(int []tmpPrev) { prevs = tmpPrev; }
    public void setNextRecommendedSpotId(String tmpNextRecommendedSpotId)
    {
        if ((tmpNextRecommendedSpotId == null) || ("".equals(tmpNextRecommendedSpotId) == true) || ("null".equals(tmpNextRecommendedSpotId)) )
        {
            next_recommended_spot_id = NO_NEXT_RECOMMENDED_SPOT_ID;
        }
        else
        {
            next_recommended_spot_id = Integer.valueOf(tmpNextRecommendedSpotId);
        }
    }
    public void setMaker(String tmpMaker) { maker = tmpMaker; }
    public void setArea(String tmpArea)
    {
        if(area == null)
        {
            area = new ArrayList<LatLng>();
        }
        else
        {
            area.clear();
        }

        if((tmpArea != null) && (tmpArea.equals("") == false))
        {
            String latLngRaw[] = tmpArea.split("_");

            for(int x = 0; x < latLngRaw.length; x++)
            {
                String tmpLatLngString = latLngRaw[x];

                String LatLngArray[] = tmpLatLngString.split(" ");
                double lat = Double.parseDouble(LatLngArray[0]);
                double lng = Double.parseDouble(LatLngArray[1]);

                LatLng tmpLatLng = new LatLng(lat, lng);
                area.add(tmpLatLng);
            }
        }

    }

    /*
    public void setRecommended(String tmpRecommended)
    {
        int tmpInt = Integer.parseInt(tmpRecommended);
        recommended = tmpInt;
    }
    */

    public void setEvent(List<ServerMapEventData> tmpEvent) { event = tmpEvent; }
    public void addEvent(ServerMapEventData tmpEvent)
    {
        if(event == null)
        {
            event = new ArrayList<ServerMapEventData>();
            event.add(tmpEvent);
        }
        else
        {
            event.add(tmpEvent);
        }
    }

    /*
    public String getImageId() { return image_id; }
    public void setImageId(String tmpImage) { image_id = tmpImage; }

    //public String getRectangleId()
    public float[] getRectangleId()
    {
        return coordinates;
        //return rectangleId;
    }
    public void setRectangleId(String tmpRectangleId)
    {
        if((tmpRectangleId != null) && (tmpRectangleId.equals("") == false))
        {
            //rectangleId = tmpRectangleId;

            String coords[] = tmpRectangleId.split(",");

            for (int x = 0; x < 4; x++)
            {
                coordinates[x] = Float.valueOf(coords[x]);
            }
        }
    }
    */

    public void setImageData(String tmpImageData)
    {
        if((tmpImageData != null) && (tmpImageData.equals("") == false))
        {
            imageData = tmpImageData;
            //String tmpImageDataArr[] = tmpImageData.split("_");
            //this.setImageId(tmpImageDataArr[0]);
            //this.setRectangleId(tmpImageDataArr[1]);
        }
    }

    public String getImageData() { return imageData; }

    @Override
    public int compareTo(Object another)
    {
        ServerMapSpotData f = (ServerMapSpotData) another;
        if(index == f.index)
        {
            return 0;
        }
        else if(index > f.index)
        {
            return 1;
        }
        else //if(index < f.index)
        {
            return -1;
        }
    }


}