package etm.main.market.vo;

public class PurchasedItem
{
    public static final int DOWNLOAD_NOT_STARTED = 1;
    public static final int DOWNLOAD_STARTED = 2;
    public static final int DOWNLOAD_FINISHED = 3;

    private String mMap_sku;

    private String mMap_name;

    private String mMap_price;

    private String mMap_image1;

    private String mMap_image2;

    private String mMap_image3;

    private long mVersion_index;

    private long mUpdated_time_stamp;

    private boolean mNeedToBeDownloaded;

    private int mDownloadProgress;

    private int mDownloadStatus;

    public String getSku()
    {
        return mMap_sku;
    }

    public String getName()
    {
        return mMap_name;
    }

    public String getPrice()
    {
        return mMap_price;
    }

    public String getImage1()
    {
        return mMap_image1;
    }

    public String getImage2()
    {
        return mMap_image2;
    }

    public String getImage3()
    {
        return mMap_image3;
    }

    public long getVersionIndex()
    {
        return mVersion_index;
    }

    public long getUpdatedTimeStamp()
    {
        return mUpdated_time_stamp;
    }

    public boolean getNeedToBeDownloaded()
    {
        return mNeedToBeDownloaded;
    }

    public void setNeedToBeDownloaded(boolean flag)
    {
        mNeedToBeDownloaded = flag;
    }

    public void setDownloadProgress(int tmpProgress)
    {
        mDownloadProgress = tmpProgress;
    }

    public int getDownloadProgress()
    {
        return mDownloadProgress;
    }

    public void setDownloadStatus(int tmpStatus)
    {
        mDownloadStatus = tmpStatus;
    }

    public int getDownloadStatus()
    {
        return mDownloadStatus;
    }

    public PurchasedItem(String id, String image_path, String title, String price, boolean tmpNeedToBeDownloaded, long tmpIndex, long tmpTimeStamp)
    {
        this.mMap_sku = id;
        this.mMap_image1 = image_path;
        //this.mMap_image2 = image_path;
        //this.mMap_image3 = image_path;
        this.mMap_name = title;
        this.mMap_price = price;
        this.mNeedToBeDownloaded = tmpNeedToBeDownloaded;
        this.mVersion_index = tmpIndex;
        this.mUpdated_time_stamp = tmpTimeStamp;

        this.mDownloadProgress = 0;
        this.mDownloadStatus = DOWNLOAD_NOT_STARTED;
    }
}