package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class Customer
{
    @SerializedName("first_name")
    private String mFirst_name;

    @SerializedName("last_name")
    private String mLast_name;

    @SerializedName("nick_name")
    private String mNick_name;

    @SerializedName("passwd")
    private String mPasswd;

    @SerializedName("image_path")
    private String mImage_path;


    @SerializedName("payment_email")
    private String mPaymeny_email;

    @SerializedName("minimum_payout")
    private String mMinimum_payout;

    @SerializedName("payment_method")
    private int mPayment_method;

    @SerializedName("transaction_state")
    private int mTransaction_state;

    public String getFirst_name()
    {
        return mFirst_name;
    }

    public String getLast_name()
    {
        return mLast_name;
    }

    public String getNick_name()
    {
        return mNick_name;
    }

    public String getPasswd()
    {
        return mPasswd;
    }

    public String getImage_path()
    {
        return mImage_path;
    }


    public String getPaymeny_email()
    {
        return mPaymeny_email;
    }

    public String getMinimum_payout()
    {
        return mMinimum_payout;
    }

    public int getPayment_method()
    {
        return mPayment_method;
    }

    public int getTransaction_state()
    {
        return mTransaction_state;
    }

    public Customer(String first_name, String last_name, String nick_name, String passwd, String image_path, String payout_email, String min_pay, int method, int state)
    {
        this.mFirst_name = first_name;
        this.mLast_name = last_name;
        this.mNick_name = nick_name;
        this.mPasswd = passwd;
        this.mImage_path = image_path;

        this.mPaymeny_email = payout_email;
        this.mMinimum_payout = min_pay;
        this.mPayment_method = method;
        this.mTransaction_state = state;
    }
}