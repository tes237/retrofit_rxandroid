package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class Friend
{
    @SerializedName("friend_photo_url")
    private String mFriendPhotoUrl;

    @SerializedName("from_id")
    private long mFrom_id;

    @SerializedName("to_id")
    private long mTo_id;

    @SerializedName("from_name")
    private String mFrom_name;

    @SerializedName("to_name")
    private String mTo_name;

    @SerializedName("last_msg_date")
    private String mLast_msg_date;

    @SerializedName("is_blocked")
    private long mIs_blocked;

    @SerializedName("is_deleted")
    private long mIs_deleted;

    public String getFriendPhotoUrl()
    {
        return mFriendPhotoUrl;
    }

    public long getFrom_id()
    {
        return mFrom_id;
    }

    public long getTo_id()
    {
        return mTo_id;
    }

    public String getFrom_name()
    {
        return mFrom_name;
    }

    public String getTo_name()
    {
        return mTo_name;
    }

    public String getLast_msg_date()
    {
        return mLast_msg_date;
    }

    public long getIs_blocked()
    {
        return mIs_blocked;
    }

    public long getIs_deleted()
    {
        return mIs_deleted;
    }

    public Friend(long from_id, long to_id, String from_name, String to_name, String last_msg_date, long is_blocked, long Is_deleted)
    {
        this.mFrom_id = from_id;
        this.mTo_id = to_id;
        this.mFrom_name = from_name;
        this.mTo_name = to_name;
        this.mLast_msg_date = last_msg_date;
        this.mIs_blocked = is_blocked;
        this.mIs_deleted = Is_deleted;
    }
}