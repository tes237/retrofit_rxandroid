package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class ServerMapPreData
{
    String title;
    String type;
    ServerMapTextData text;
    String picture;
    String audio;

    public String getTitle() { return title; }
    public String getType() { return type; }
    public ServerMapTextData getText() { return text; }
    public String getPicture() { return picture; }
    public String getAudio() { return audio; }


    public void setTitle(String tmpTitle) { title = tmpTitle; }
    public void setType(String tmpType) { type = tmpType; }
    public void setText(ServerMapTextData tmpText) { text = tmpText; }
    public void setPicture(String tmpPicture) { picture = tmpPicture; }
    public void setAudio(String tmpAudio) { audio = tmpAudio; }

}