package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseSendReturnData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private SendReturn mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public SendReturn getData()
    {
        return mData;
    }
}