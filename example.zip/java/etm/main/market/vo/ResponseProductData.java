package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseProductData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private Product mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public Product getData()
    {
        return mData;
    }
}