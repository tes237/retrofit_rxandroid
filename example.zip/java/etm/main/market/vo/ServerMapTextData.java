package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;


public class ServerMapTextData
{
    List<ServerMapLineData> lines;

    public List<ServerMapLineData> getLines() { return lines; }
    public void setLines(List<ServerMapLineData> tmpLineList) { lines = tmpLineList; }
    public void addLine(ServerMapLineData tmpLine)
    {
        if(lines == null)
        {
            lines = new ArrayList<ServerMapLineData>();
            lines.add(tmpLine);
        }
        else
        {
            lines.add(tmpLine);
        }
    }
}