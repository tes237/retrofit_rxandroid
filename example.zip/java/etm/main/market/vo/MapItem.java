package etm.main.market.vo;

public class MapItem
{
    public static final int DOWNLOAD_NOT_STARTED = 1;
    public static final int DOWNLOAD_STARTED = 2;
    public static final int DOWNLOAD_FINISHED = 3;

    private String mMap_id;

    private String mMap_title;

    private int mMap_verified;

    private long mVersion_index;

    private long mUpdated_time_stamp;

    private boolean mNeedToBeDownloaded;

    private int mDownloadProgress;

    private int mDownloadStatus;

    public String getId()
    {
        return mMap_id;
    }

    public String getTitle()
    {
        return mMap_title;
    }

    public int getVerified()
    {
        return mMap_verified;
    }

    public long getVersionIndex()
    {
        return mVersion_index;
    }

    public long getUpdatedTimeStamp()
    {
        return mUpdated_time_stamp;
    }

    public boolean getNeedToBeDownloaded()
    {
        return mNeedToBeDownloaded;
    }

    public void setNeedToBeDownloaded(boolean flag)
    {
        mNeedToBeDownloaded = flag;
    }

    public void setDownloadProgress(int tmpProgress)
    {
        mDownloadProgress = tmpProgress;
    }

    public int getDownloadProgress()
    {
        return mDownloadProgress;
    }

    public void setDownloadStatus(int tmpStatus)
    {
        mDownloadStatus = tmpStatus;
    }

    public int getDownloadStatus()
    {
        return mDownloadStatus;
    }


    public MapItem(String id, String title, int verified, boolean tmpNeedToBeDownloaded, long tmpIndex, long tmpTimeStamp)
    {
        this.mMap_id = id;
        this.mMap_title = title;
        this.mMap_verified = verified;

        this.mNeedToBeDownloaded = tmpNeedToBeDownloaded;
        this.mVersion_index = tmpIndex;
        this.mUpdated_time_stamp = tmpTimeStamp;

        this.mDownloadProgress = 0;
        this.mDownloadStatus = DOWNLOAD_NOT_STARTED;
    }
}