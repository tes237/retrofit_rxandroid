package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

public class TestMap implements Comparable<Object>
{
    @SerializedName("map_id")
    private String mMap_id;

    @SerializedName("map_title")
    private String mMap_title;

    @SerializedName("map_verified")
    private int mMap_verified;

    @SerializedName("map_modify_transaction_index")
    private long mMap_modify_transaction_index;

    @SerializedName("update_time")
    private long mUpdate_time;

    public String getMapId()
    {
        return mMap_id;
    }

    public String getTitle()
    {
        return mMap_title;
    }

    public int getVerified()
    {
        return mMap_verified;
    }

    public long getModifyTransactionIndex()
    {
        return mMap_modify_transaction_index;
    }

    public long getUpdateTime()
    {
        return mUpdate_time;
    }

    public TestMap(String id, String title, int verified, long updateTime, long transactionIndex)
    {
        this.mMap_id = id;
        this.mMap_title = title;
        this.mMap_verified = verified;
        this.mUpdate_time = updateTime;
        this.mMap_modify_transaction_index = transactionIndex;
    }

    @Override
    public int compareTo(Object another)
    {
        TestMap f = (TestMap) another;
        return mMap_id.compareTo(f.mMap_id);
    }
}