package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseSettingData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private Setting mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public Setting getData()
    {
        return mData;
    }
}