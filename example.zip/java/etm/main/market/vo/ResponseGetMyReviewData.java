package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseGetMyReviewData
{
    @SerializedName("result")
    private String mResult;

    @SerializedName("data")
    private Review mData;

    @SerializedName("result_code")
    private int mResultCode;

    public int getResultCode()
    {
        return mResultCode;
    }

    public String getResult()
    {
        return mResult;
    }

    public Review getData()
    {
        return mData;
    }
}