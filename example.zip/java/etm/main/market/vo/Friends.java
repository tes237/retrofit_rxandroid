package etm.main.market.vo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Friends
{
    public List<Friend> friends;

    public List<Friend> getFriends()
    {
        return friends;
    }
}