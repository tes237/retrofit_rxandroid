package etm.main.market.receiver;

import android.content.Context;
import android.view.View;

public interface RemoteControlListener
{
    public static final int MEDIA_BUTTON = 0;
    public static final int MEDIA_BUTTON2 = 1;

    void onYesNoButtonClickListener(int button_type);


}