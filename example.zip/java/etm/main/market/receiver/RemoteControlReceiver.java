package etm.main.market.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.KeyEvent;

public class RemoteControlReceiver extends BroadcastReceiver
{
    private static final String TAG = RemoteControlReceiver.class.getSimpleName();
    //private RemoteControlListener mRemoteControlListener;

    //오디오 볼륨 조절
    @Override
    public void onReceive(Context context, Intent intent)
    {
        if (Intent.ACTION_MEDIA_BUTTON.equals(intent.getAction()))
        {
            Log.e(TAG, "ACTION_MEDIA_BUTTON");

            KeyEvent event = (KeyEvent) intent .getParcelableExtra(Intent.EXTRA_KEY_EVENT);

            if (event == null)
            {
                return;
            }

            if (event.getAction() == KeyEvent.ACTION_DOWN)
            {
                //context.sendBroadcast(new Intent(Intents.ACTION_PLAYER_PAUSE));
                Log.e(TAG, "ACTION_DOWN");
            }
            else if(event.getAction() == KeyEvent.ACTION_UP)
            {
                Log.e(TAG, "ACTION_UP");
            }
            else if(event.getAction() == KeyEvent.KEYCODE_MEDIA_NEXT)
            {
                Log.e(TAG, "KEYCODE_MEDIA_NEXT");
            }
            else if(event.getAction() == KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            {
                Log.e(TAG, "KEYCODE_MEDIA_PREVIOUS");
            }
            else if(event.getAction() == KeyEvent.KEYCODE_HEADSETHOOK)
            {
                Log.e(TAG, "KEYCODE_HEADSETHOOK");
            }


            Log.e(TAG, event.toString());
        }
        else if (Intent.ACTION_HEADSET_PLUG.equals(intent.getAction()) )
        {
            Log.e(TAG, "ACTION_HEADSET_PLUG");
            //Toast.makeText(context, "earphones activity",Toast.LENGTH_SHORT).show();
            //if (intent.getExtras().getInt("state")==1)//if plugged
            //    Toast.makeText(context, "earphones plugged",Toast.LENGTH_LONG).show();
            //else Toast.makeText(context, "earphones un-plugged",Toast.LENGTH_LONG).show();


            KeyEvent event = (KeyEvent) intent .getParcelableExtra(Intent.EXTRA_KEY_EVENT);
            Log.e(TAG, event.toString());
        }

    }

}