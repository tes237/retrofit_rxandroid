package etm.main.market.connects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;

public class LocalCookieJar implements CookieJar
{
    private final HashMap<String, String> cookieStore = new HashMap<>();
    private final HashMap<String, String> cid_cookieStore = new HashMap<>();

    private boolean mCookieSaveEndbled = false;

    private List<Cookie> mRequestCookies = new ArrayList<>();

    private Object mSyncObj = new Object();

    public HashMap<String, String> getCookieStore()
    {
        return cookieStore;
    }

    @Override
    public void saveFromResponse(HttpUrl url, List<Cookie> cookies)
    {
        if(isCookieSaveEnabled() == true)
        {
            for (int x = 0; x < cookies.size(); x++)
            {
                Cookie tmpCookie = cookies.get(x);
                String rawCookieStr = tmpCookie.toString();
                String rawCookieStrArr[] = rawCookieStr.split(";");
                if (rawCookieStrArr.length > 0)
                {
                    //if (rawCookieStrArr[0].contains("frontend") == true)
                    if (rawCookieStrArr[0].contains("frontend_cid") == true)
                    {
                        String keyStr = url.host();

                        String frontEndCookieArr[] = rawCookieStrArr[0].split("=");

                        if(frontEndCookieArr.length > 1)
                        {
                            //cookieStore.put(keyStr, rawCookieStrArr[0]);
                            cid_cookieStore.put(keyStr, frontEndCookieArr[1]);
                        }
                    }
                    else if (rawCookieStrArr[0].contains("frontend") == true)
                    {
                        String keyStr = url.host();

                        String frontEndCookieArr[] = rawCookieStrArr[0].split("=");

                        if(frontEndCookieArr.length > 1)
                        {
                            //cookieStore.put(keyStr, rawCookieStrArr[0]);
                            cookieStore.put(keyStr, frontEndCookieArr[1]);
                        }
                    }
                }

            }
            //cookieStore.put(url, cookies);
        }
    }


    @Override
    public List<Cookie> loadForRequest(HttpUrl url)
    {
        synchronized(mSyncObj)
        {
            if (mRequestCookies.size() == 0)
            {
                //private Cookie(String name, String value, long expiresAt, String domain, String path, boolean secure, boolean httpOnly, boolean hostOnly, boolean persistent)

                Iterator it = cookieStore.entrySet().iterator();
                while (it.hasNext())
                {
                    Map.Entry pair = (Map.Entry) it.next();

                    //Cookie tmpCookie = new Cookie("frontend", pair.getValue().toString(), -1, pair.getKey().toString(), "/", false, true, false, true);
                    Cookie tmpCookie = new Cookie.Builder()
                            .domain(pair.getKey().toString())
                            .path("/")
                            .name("frontend")
                            .value(pair.getValue().toString())
                            .httpOnly()
                            .build();

                    mRequestCookies.add(tmpCookie);
                }

                Iterator it_cid = cid_cookieStore.entrySet().iterator();
                while (it_cid.hasNext())
                {
                    Map.Entry pair = (Map.Entry) it_cid.next();

                    //Cookie tmpCookie = new Cookie("frontend", pair.getValue().toString(), -1, pair.getKey().toString(), "/", false, true, false, true);
                    Cookie tmpCookie = new Cookie.Builder()
                            .domain(pair.getKey().toString())
                            .path("/")
                            .name("frontend_cid")
                            .secure()
                            .value(pair.getValue().toString())
                            .httpOnly()
                            .build();

                    mRequestCookies.add(tmpCookie);
                }
            }
        }
        return mRequestCookies;
        //return mDummpCookies;
        /*
        List<Cookie> useCookies = new ArrayList<>();
        for (HttpUrl cookieBatchUrl : cookieStore.keySet())
        {
            List<Cookie> cookieBatch = cookieStore.get(cookieBatchUrl);
            for (Cookie cookie : cookieBatch)
            {
                //if (!StringUtils.isEmpty(cookie.path()))
                if( (cookie.path() != null)  && (cookie.path().equals("") == false) )
                {
                    List<String> paths = Arrays.asList(cookie.path().split("\\s*,\\s*"));
                    for (String path : paths)
                    {
                        if (url.toString().contains(path) && url.host().equals(cookieBatchUrl.host()))
                        {
                            useCookies.add(cookie);
                            break;
                        }
                    }
                }
                else if (cookieBatchUrl.toString().equals(url.toString()))
                {
                    useCookies.add(cookie);
                }
            }
        }
        return useCookies;
        */
    }
    public void setCookieSaveEnabled(boolean flag)
    {
        mCookieSaveEndbled = flag;
    }

    public boolean isCookieSaveEnabled()
    {
        return mCookieSaveEndbled;
    }

    public void clearCookies()
    {
        cookieStore.clear();
        cid_cookieStore.clear();
        mRequestCookies.clear();
    }
}