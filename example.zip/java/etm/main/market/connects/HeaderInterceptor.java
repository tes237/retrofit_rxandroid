package etm.main.market.connects;


import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class HeaderInterceptor implements Interceptor
{
    private final HashMap<String, String> cookieStore = new HashMap<>();

    public void setCookieStore(HashMap<String, String> tmpMap)
    {
        cookieStore.clear();

        Iterator it = tmpMap.entrySet().iterator();
        while (it.hasNext())
        {
            Map.Entry pair = (Map.Entry)it.next();

            cookieStore.put(pair.getKey().toString(), pair.getValue().toString());

            //it.remove(); // avoids a ConcurrentModificationException
        }
    }

    public int getCookieStoreSize()
    {
        return cookieStore.size();
    }

    @Override
    public Response intercept(Chain chain) throws IOException
    {
        Request request = chain.request();

        Request.Builder tmpBuilder = request.newBuilder();

        Iterator it = cookieStore.entrySet().iterator();
        while (it.hasNext())
        {
            Map.Entry pair = (Map.Entry)it.next();

            tmpBuilder.addHeader("Cookie", pair.getValue().toString());
            //cookieStore.put(pair.getKey().toString(), pair.getValue().toString());
            //it.remove(); // avoids a ConcurrentModificationException
        }
        request = tmpBuilder.build();

        /*
        request = request.newBuilder()
                .addHeader("Cookie", "hello")
                //.addHeader("appid", "hello")
                //.addHeader("deviceplatform", "android")
                //.removeHeader("User-Agent")
                //.addHeader("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:38.0) Gecko/20100101 Firefox/38.0")
                .build();
        */

        Response response = chain.proceed(request);
        return response;
    }
}