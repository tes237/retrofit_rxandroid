package etm.main.market.connects;

public interface DownloadProgressListener
{
    void update(String fileKey, long bytesRead, long contentLength, boolean done);
}