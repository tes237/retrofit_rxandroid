package etm.main.market.connects;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.widget.ImageView;

import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;

import org.reactivestreams.Subscriber;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookiePolicy;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subscribers.DefaultSubscriber;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.JavaNetCookieJar;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Query;
import etm.main.market.common.CircleTransformation;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.baseDefine;

import etm.main.market.vo.BaseResponse;
import etm.main.market.vo.ResponseCustomerData;
import etm.main.market.vo.ResponseCustomerStatsData;
import etm.main.market.vo.ResponseDummyData;
import etm.main.market.vo.ResponseFriendMessagesData;
import etm.main.market.vo.ResponseFriendsData;
import etm.main.market.vo.ResponseGetMyReviewData;
import etm.main.market.vo.ResponseLoginData;

import etm.main.market.vo.ResponseLogoutData;
import etm.main.market.vo.ResponseMapFilesData;
import etm.main.market.vo.ResponseProductData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponsePurchaseData;
import etm.main.market.vo.ResponseRegisterData;
import etm.main.market.vo.ResponseResetEmailData;
import etm.main.market.vo.ResponseReviewsData;
import etm.main.market.vo.ResponseSalesData;
import etm.main.market.vo.ResponseSendReturnData;
import etm.main.market.vo.ResponseSendSessionData;
import etm.main.market.vo.ResponseSetMyReviewData;
import etm.main.market.vo.ResponseSettingData;
import etm.main.market.vo.ResponseSimpleData;
import etm.main.market.vo.ResponseStoresData;
import etm.main.market.vo.ResponseTestMapsData;
import etm.main.market.vo.ResponseUpdateCustomerData;
import etm.main.market.vo.ResponseUploadImageData;

import etm.main.market.R;

public class WebManager implements baseDefine
{
	private static final String TAG = WebManager.class.getSimpleName();
	private String WEB_IP = "";
	private String API_URL = "";
	private String FB_API_URL = "";
	private static final int DEFAULT_TIMEOUT = 15;

	private	Context mContext;
	private	Communication mTGMCommunication;
    private LocalCookieJar mTGMCookieJar;

	private double currentLat = 0;
	private double currentLng = 0;

	private String mServerLanguage = "";

	public WebManager(Context tmpContext)
	{
		mContext = tmpContext;

		//WEB_IP = "http://www.travelguidemarket.com";
		WEB_IP = "https://www.tourguidemarket.com";
		API_URL = WEB_IP + "/mapeditor/mobile/";
		FB_API_URL = WEB_IP + "/sociallogin/facebook/";

		mTGMCommunication = new Communication(tmpContext);
		mTGMCommunication.setContext(mContext);


		//mTGMCookieManager = new TGMCookieManager();
		//mTGMCookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
		//CookieHandler.setDefault(mTGMCookieManager);

        mTGMCookieJar = new LocalCookieJar();
        //mTGMHeaderInterceptor = new TGMHeaderInterceptor();
	}
	
	public void setContext(Context curContext)
	{
		mContext = curContext;
	}

	public String getServer()
	{
		return WEB_IP;
	}

	public void setServer(String tmpUrl)
	{
		WEB_IP = tmpUrl;
		API_URL = WEB_IP + "mapeditor/mobile/";
		FB_API_URL = WEB_IP + "sociallogin/facebook/";
	}

	public void setLanguage(String tmpLang)
	{
		mServerLanguage = tmpLang;
	}

	public String getLanguage()
	{
		return mServerLanguage;
	}

	//-------------------------------------------- unused code -------------------------------------------------//
	public void setLng(double lng)
	{
		currentLng = lng;
	}
	public void setLat(double lat)
	{
		currentLat = lat;
	}

	public double getLng()
	{
		return currentLng;
	}
	public double getLat()
	{
		return currentLat;
	}

	public double getLatestLat()
	{
		return 0;
	}
	public void location_update(double lat, double lng, BooleanWrapper tmp)
	{

	}

	public void setCookieState(boolean flag)
    {
        mTGMCookieJar.setCookieSaveEnabled(flag);
    }

	public CompositeDisposable login(String IdStr, String PasswdStr, String devVar, String regPushId, Consumer<ResponseLoginData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		mTGMCookieJar.clearCookies();	//clear current working sessions(memory cookies)

		setCookieState(true);

		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

        disposables.add(SERVICE
				.getLoginData(IdStr, PasswdStr, devVar, regPushId)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;
	}

	public CompositeDisposable facebook_login(String token, String id, String first_name, String last_name, String email, String dev_var, String push_var, Consumer<ResponseLoginData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		mTGMCookieJar.clearCookies();	//clear current working sessions(memory cookies)

		setCookieState(true);

		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(FB_API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getFacebookLoginData(token, id, first_name, last_name, email, dev_var, push_var)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable logout(Consumer<ResponseLogoutData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		mTGMCookieJar.clearCookies();	//clear current working sessions(memory cookies)

		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getLogoutData()
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

    public CompositeDisposable register(String firstName, String lastName, String email, String passwd, String devVar, String regPushId, Consumer<ResponseRegisterData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
    {
		TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .getRegisterData(firstName, lastName, email, passwd, devVar, regPushId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;

    }

	public CompositeDisposable reset_password_email(String emapStr, Consumer<ResponseResetEmailData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.sendResetEmailData(emapStr)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

    public CompositeDisposable get_customer(Consumer<ResponseCustomerData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
    {
		TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .getCustomerData()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;
    }

    public CompositeDisposable update_customer(String firstName, String lastName, String nickname, String passwd, String path, String method, String payout_email, String min, Consumer<ResponseUpdateCustomerData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
    {
		TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .getUpdateCustomerData(firstName, lastName, nickname, passwd, path, method, payout_email, min)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;
    }

	public CompositeDisposable update_customer_name(String firstName, String lastName, String nickname, Consumer<ResponseUpdateCustomerData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.updateCustomerNameData(firstName, lastName, nickname)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable update_customer_password(String passwd, Consumer<ResponseUpdateCustomerData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.updateCustomerPasswordData(passwd)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable update_customer_payout(String method, String payout_email, String min, Consumer<ResponseUpdateCustomerData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.updateCustomerPayoutData(method, payout_email, min)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable getProductsFromCategory(String perPage, String pageNum, Consumer<ResponseProductsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .fetchProductsListData(perPage, pageNum)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;

	}

	public CompositeDisposable getViewedProducts(String perPage, String pageNum, Consumer<ResponseProductsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.fetchViewedData(perPage, pageNum)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;

	}

	public CompositeDisposable getWishlistProducts(String perPage, String pageNum, Consumer<ResponseProductsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.fetchWishlistData(perPage, pageNum)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;

	}

    public CompositeDisposable getBestSeller(String perPage, String pageNum, Consumer<ResponseProductsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
    {
        TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .fetchBestSellerListData(perPage, pageNum)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;

    }

	public CompositeDisposable getProductsFromCategoryWithRegion(String regionVar, String perPage, String pageNum, Consumer<ResponseProductsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.fetchRegionProductsData(regionVar, perPage, pageNum)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;

	}

	public CompositeDisposable searchProductsByKeywords(String keywordsVar, String exclusive_food_filters, String vehicle_filters, String theme_filters, String required_durations, String perPage, String pageNum, Consumer<ResponseProductsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .fetchSearchProductsData(keywordsVar, exclusive_food_filters, vehicle_filters, theme_filters, required_durations, perPage, pageNum)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;

	}

	public CompositeDisposable getProductInfo(String idVar, Consumer<ResponseProductData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .getProductData(idVar)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;

	}
    public CompositeDisposable addToWishlist(String idVar, String on_flag, Consumer<ResponseSimpleData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
    {
        TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .addToWishlist(idVar, on_flag)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;

    }

	public CompositeDisposable getReviews(String skuVar, String perPage, String pageNum, Consumer<ResponseReviewsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .fetchReviewsData(skuVar, perPage, pageNum)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;
	}

	public CompositeDisposable getMyReview(String skuVar, Consumer<ResponseGetMyReviewData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getMyReviewData(skuVar)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable setMyReview(String skuVar, String rating1, String rating2, String titleStr, String bodyStr, Consumer<ResponseSetMyReviewData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.setMyReviewData(skuVar, rating1, rating2, titleStr, bodyStr)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable getPurchasedProducts(String perPage, String pageNum, Consumer<ResponseProductsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .fetchPurchasedListData(perPage, pageNum)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;
	}

	public CompositeDisposable get_downloadable_files(String map_id, String skuVar, Consumer<ResponseMapFilesData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.fetchMapFilesData(map_id, skuVar)
				.subscribeOn(Schedulers.io())
				//.observeOn(AndroidSchedulers.mainThread())
				.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	private static void writeFile(BufferedSource source, File file) throws IOException
	{
		if (!file.getParentFile().exists())
			file.getParentFile().mkdirs();

		if (file.exists())
			file.delete();

		BufferedSink bufferedSink = Okio.buffer(Okio.sink(file));
		bufferedSink.writeAll(source);

		bufferedSink.close();
		source.close();
	}

	public CompositeDisposable map_download(String map_id, String sku_var, String fileKey, String destPath, DownloadProgressListener listener, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpDownloadClient(false, listener, fileKey))
				.build()
				.create(TGMWebService.class);

		SERVICE.download(map_id, sku_var, fileKey)
				.subscribeOn(Schedulers.io())
				.observeOn(Schedulers.io())
				//.observeOn(AndroidSchedulers.mainThread())
				.unsubscribeOn(Schedulers.io())
				.map(new Function<ResponseBody, BufferedSource>()
				{
					@Override
					public BufferedSource apply(ResponseBody responseBody) throws Exception
					{
						return responseBody.source();
					}
				})
				.subscribe(new Observer<BufferedSource>()
				{
					@Override
					public void onSubscribe(Disposable d)
					{
						//cd.add(d);
					}

					@Override
					public void onNext(BufferedSource bufferedSource)
					{
						try {
							writeFile(bufferedSource, new File(destPath));
						} catch (IOException e) {
							e.printStackTrace();
						}
					}

					@Override
					public void onError(Throwable e)
					{
					}

					@Override
					public void onComplete()
					{
					}
				});

		return disposables;
	}

	public CompositeDisposable purchaseProduct(String skuStr, Consumer<ResponsePurchaseData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.purchase(skuStr)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;

	}


	public CompositeDisposable getSaleItems(String perPage, String pageNum, Consumer<ResponseSalesData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getSales(perPage, pageNum)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;

	}

	public CompositeDisposable getCustomerStats(Consumer<ResponseCustomerStatsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getStats()
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable getFriends(Consumer<ResponseFriendsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getFriends()
				.subscribeOn(Schedulers.io())
				.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable getFriendMessages(String friend_id, String startDateTime, Consumer<ResponseFriendMessagesData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getFriendMessages(friend_id, startDateTime)
				.subscribeOn(Schedulers.io())
				.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public ResponseFriendMessagesData Blocking_getFriendMessages(String friend_id, String startDateTime)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		Call<ResponseFriendMessagesData> call = SERVICE.getBlockingFriendMessages(friend_id, startDateTime);

		try
		{
			ResponseFriendMessagesData singleResult = call.execute().body();
			return singleResult;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public CompositeDisposable sendMessage(String friend_id, String messageText, Consumer<ResponseSendReturnData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.sendMessage(friend_id, messageText)
				.subscribeOn(Schedulers.io())
				.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable image_download(String fileKey, String destPath, DownloadProgressListener listener, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		SERVICE.download_profile_image()
				.subscribeOn(Schedulers.io())
				.observeOn(Schedulers.io())
				.map(new Function<ResponseBody, BufferedSource>()
				{
					@Override
					public BufferedSource apply(ResponseBody responseBody) throws Exception
					{
						return responseBody.source();
					}
				})
				.subscribe(new Observer<BufferedSource>()
				{
					@Override
					public void onSubscribe(Disposable d)
					{
						//cd.add(d);
					}

					@Override
					public void onNext(BufferedSource bufferedSource)
					{
						try
						{
							writeFile(bufferedSource, new File(destPath));
						}
						catch (IOException e)
						{
							listener.update(fileKey, -1, -1, true);
							e.printStackTrace();
							return;
						}

						listener.update(fileKey, 0, 0, true);
					}

					@Override
					public void onError(Throwable e)
					{
						//unSubscribe(cd);
						Log.d(TAG, "error");
					}

					@Override
					public void onComplete()
					{
						Log.d(TAG, fileKey + " completed");
					}
				});

		return disposables;
	}


	public CompositeDisposable image_upload(String element_name, String file_name, RequestBody reqBody, Consumer<ResponseUploadImageData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		//File file = new File(file_path);
		//RequestBody imgbody = RequestBody.create(MediaType.parse("multipart/form-data"), file);

		// MultipartBody.Part is used to send also the actual file name
		MultipartBody.Part body = MultipartBody.Part.createFormData(element_name, file_name, reqBody);

		String sessionCookieStr = "";

		Iterator it = getSessionVars().entrySet().iterator();
		while (it.hasNext())
		{
			Map.Entry pair = (Map.Entry) it.next();

			sessionCookieStr = "frontend=" + (String)pair.getValue();
			break;
		}

		SERVICE.uploadProfileImage(sessionCookieStr, body)
				.subscribeOn(Schedulers.io())
				.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler);

		return disposables;
	}

	public CompositeDisposable getTestMapList(String perPage, String pageNum, Consumer<ResponseTestMapsData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.fetchTestMapsData(perPage, pageNum)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}


	public CompositeDisposable get_test_downloadable_files(String map_id, Consumer<ResponseMapFilesData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.fetchDataForTestMap(map_id)
				.subscribeOn(Schedulers.io())
				//.observeOn(AndroidSchedulers.mainThread())
				.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}


	public CompositeDisposable test_map_download(String map_id, String fileKey, String destPath, DownloadProgressListener listener, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpDownloadClient(false, listener, fileKey))
				.build()
				.create(TGMWebService.class);

		SERVICE.download_for_test_map(map_id, fileKey)
				.subscribeOn(Schedulers.io())
				.observeOn(Schedulers.io())
				//.observeOn(AndroidSchedulers.mainThread())
				.unsubscribeOn(Schedulers.io())
				.map(new Function<ResponseBody, BufferedSource>()
				{
					@Override
					public BufferedSource apply(ResponseBody responseBody) throws Exception
					{
						return responseBody.source();
					}
				})
				.subscribe(new Observer<BufferedSource>()
				{
					@Override
					public void onSubscribe(Disposable d)
					{
						//cd.add(d);
					}

					@Override
					public void onNext(BufferedSource bufferedSource)
					{
						try {
							writeFile(bufferedSource, new File(destPath));
						} catch (IOException e) {
							e.printStackTrace();
						}
					}

					@Override
					public void onError(Throwable e)
					{
					}

					@Override
					public void onComplete()
					{
					}
				});


		return disposables;
	}


	public CompositeDisposable getSettingData(Consumer<ResponseSettingData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.fetchSettingData()
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				//.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

    public CompositeDisposable getStorelist(Consumer<ResponseStoresData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
    {
        TGMWebService SERVICE = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHttpClient(false))
                .build()
                .create(TGMWebService.class);

        disposables.add(SERVICE
                .getStorelist()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                //.observeOn(Schedulers.io())
                .subscribe(responseHandler, errorHandler)
        );
        return disposables;
    }

	public CompositeDisposable setMessageAlarmDisable(String flag, Consumer<ResponseDummyData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.setMessageAlarmDisable(flag)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				//.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable setSellingAlarmDisable(String flag, Consumer<ResponseDummyData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.setSellingAlarmDisable(flag)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				//.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable setBuyingAlarmDisable(String flag, Consumer<ResponseDummyData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.setBuyingAlarmDisable(flag)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				//.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable getTermOfUse(Consumer<ResponseDummyData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getTermOfUse()
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				//.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable getPrivacyPolicy(Consumer<ResponseDummyData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.getPrivacyPolicy()
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				//.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}


	public CompositeDisposable agreeTerms(Consumer<ResponseDummyData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.agreeTerms()
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				//.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	public CompositeDisposable agreePrivacy(Consumer<ResponseDummyData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		TGMWebService SERVICE = new Retrofit.Builder()
				.baseUrl(API_URL)
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.client(createOkHttpClient(false))
				.build()
				.create(TGMWebService.class);

		disposables.add(SERVICE
				.agreePrivacy()
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				//.observeOn(Schedulers.io())
				.subscribe(responseHandler, errorHandler)
		);
		return disposables;
	}

	//we need inform previous session data to another domain
	//http://japanese.travelguidemarket.com/?SID=voti3v6v36v33dvl8s3q1bk455
	public CompositeDisposable sendSessionData(Consumer<ResponseSendSessionData> responseHandler, Consumer<Throwable> errorHandler, CompositeDisposable disposables)
	{
		if(mTGMCookieJar.getCookieStore().entrySet().size() > 0)
		{
			Map.Entry<String,String> entry = mTGMCookieJar.getCookieStore().entrySet().iterator().next();
			//String key = entry.getKey();
			String sidString = entry.getValue();
			//String sidString = "";

			TGMWebService SERVICE = new Retrofit.Builder()
					.baseUrl(API_URL)
					.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
					.addConverterFactory(GsonConverterFactory.create())
					.client(createOkHttpClient(false))
					.build()
					.create(TGMWebService.class);

			disposables.add(SERVICE
					.sendSessionData(sidString)
					.subscribeOn(Schedulers.io())
					.observeOn(AndroidSchedulers.mainThread())
					//.observeOn(Schedulers.io())
					.subscribe(responseHandler, errorHandler)
			);
			return disposables;
		}
		else
		{
			return null;
		}
	}

	public void picasso_load_simple(String urlStr, String idVar, ImageView target)
	{
		Picasso picasso = new Picasso.Builder(mContext)
				.downloader(new OkHttp3Downloader(createOkHttpClient(false)))
				.build();

		picasso.load(urlStr).into(target);
	}

	public void picasso_load_circle(String urlStr, String idVar, ImageView target)
	{
		Picasso picasso = new Picasso.Builder(mContext)
				.downloader(new OkHttp3Downloader(createOkHttpClient(false)))
				.build();

		picasso.load(urlStr).transform(new CircleTransformation()).into(target);
	}

	public OkHttpClient createOkHttpClient(boolean isCookieCopy)
    {
        CookieJar cookieJar = mTGMCookieJar;

		/*
        if(isCookieCopy == true)
        {
            HashMap<String, String> tmpCookies = mTGMCookieJar.getCookieStore();
            mTGMHeaderInterceptor.setCookieStore(tmpCookies);
        }
        else
        {
            HashMap<String, String> tmpCookies = mTGMCookieJar.getCookieStore();
            if(mTGMHeaderInterceptor.getCookieStoreSize() == 0)
            {
                mTGMHeaderInterceptor.setCookieStore(tmpCookies);
            }
        }
        */

        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        //interceptor.setLevel(HttpLoggingInterceptor.Level.HEADERS);
		interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        builder.addInterceptor(interceptor);
		builder.connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
        //builder.addInterceptor(mTGMHeaderInterceptor);
        //builder.cookieJar(new JavaNetCookieJar(cookieHandler));
        builder.cookieJar(cookieJar);
		builder.sslSocketFactory(getPinnedCertSslSocketFactory(mContext));
		builder.followRedirects(false);

        return builder.build();
    }

	private OkHttpClient createOkHttpDownloadClient(boolean isCookieCopy, DownloadProgressListener listener, String fileKey)
	{
		CookieJar cookieJar = mTGMCookieJar;

		OkHttpClient.Builder builder = new OkHttpClient.Builder();
		DownloadProgressInterceptor interceptor = new DownloadProgressInterceptor(listener, fileKey);
		//interceptor.setLevel(HttpLoggingInterceptor.Level.HEADER);
		builder.addInterceptor(interceptor);
		builder.connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
		//builder.addInterceptor(mTGMHeaderInterceptor);
		//builder.cookieJar(new JavaNetCookieJar(cookieHandler));
		builder.cookieJar(cookieJar);
		builder.sslSocketFactory(getPinnedCertSslSocketFactory(mContext));
		builder.followRedirects(false);

		return builder.build();
	}


	public static SSLSocketFactory getPinnedCertSslSocketFactory(Context context)
	{
		try
		{
			CertificateFactory cf = CertificateFactory.getInstance("X.509", "BC");
			InputStream caInput = context.getResources().openRawResource(R.raw.www_tourguidemarket_com);
			Certificate ca = null;
			try
			{
				ca = cf.generateCertificate(caInput);
				//System.out.println("ca=" + ((X509Certificate) ca).getSubjectDN());
			}
			catch (CertificateException e)
			{
				e.printStackTrace();
			}
			finally
			{
				caInput.close();
			}

			String keyStoreType = KeyStore.getDefaultType();
			KeyStore keyStore = KeyStore.getInstance(keyStoreType);
			keyStore.load(null, null);
			if (ca == null)
			{
				return null;
			}
			keyStore.setCertificateEntry("ca", ca);

			String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
			tmf.init(keyStore);

			SSLContext sslContext= SSLContext.getInstance("TLS");
			sslContext.init(null, tmf.getTrustManagers(), null);

			return sslContext.getSocketFactory();
		}
		catch (NoSuchAlgorithmException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (KeyStoreException e)
		{
			e.printStackTrace();
		}
		catch (KeyManagementException e)
		{
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	/*
	private OkHttpClient createOkHttpUploadClient(boolean isCookieCopy, DownloadProgressListener listener, String fileKey)
	{
		CookieJar cookieJar = mTGMCookieJar;


		OkHttpClient.Builder builder = new OkHttpClient.Builder();
		TGMDownloadProgressInterceptor interceptor = new TGMDownloadProgressInterceptor(listener, fileKey);
		//interceptor.setLevel(HttpLoggingInterceptor.Level.HEADER);
		builder.addInterceptor(interceptor);
		builder.connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
		builder.readTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
		builder.writeTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
		//builder.addInterceptor(mTGMHeaderInterceptor);
		//builder.cookieJar(new JavaNetCookieJar(cookieHandler));
		builder.cookieJar(cookieJar);

		return builder.build();
	}
	*/

	public HashMap<String, String> getSessionVars()
	{
		return mTGMCookieJar.getCookieStore();
	}


}

