package etm.main.market.connects;

import android.content.Context;
import etm.main.market.generalApplication;

public class Communication
{
	private static final boolean DEBUG = true;
	
	private static final String TAG = Communication.class.getSimpleName();

	private	Context mContext;

	private generalApplication mGeneralApplication;

	public Communication(Context tmpContext)
	{
		mContext = tmpContext;
	}

	public void setContext(Context curContext)
	{
		mContext = curContext;
	}

};


