package etm.main.market.connects;

import io.reactivex.Observable;
import io.reactivex.Single;
import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import retrofit2.http.Streaming;
import etm.main.market.vo.ResponseCustomerData;
import etm.main.market.vo.ResponseCustomerStatsData;
import etm.main.market.vo.ResponseDummyData;
import etm.main.market.vo.ResponseFriendMessagesData;
import etm.main.market.vo.ResponseFriendsData;
import etm.main.market.vo.ResponseGetMyReviewData;
import etm.main.market.vo.ResponseLoginData;
import etm.main.market.vo.ResponseLogoutData;
import etm.main.market.vo.ResponseMapFilesData;
import etm.main.market.vo.ResponseProductData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponsePurchaseData;
import etm.main.market.vo.ResponseRegisterData;
import etm.main.market.vo.ResponseResetEmailData;
import etm.main.market.vo.ResponseReviewsData;
import etm.main.market.vo.ResponseSalesData;
import etm.main.market.vo.ResponseSendReturnData;
import etm.main.market.vo.ResponseSendSessionData;
import etm.main.market.vo.ResponseSetMyReviewData;
import etm.main.market.vo.ResponseSettingData;
import etm.main.market.vo.ResponseSimpleData;
import etm.main.market.vo.ResponseStoresData;
import etm.main.market.vo.ResponseTestMapsData;
import etm.main.market.vo.ResponseUpdateCustomerData;
import etm.main.market.vo.ResponseUploadImageData;


public interface TGMWebService
{
    //@GET("updatecustomer")
    //public Single<ResponseUpdateCustomerData> getUpdateCustomerData(@Query("first_name_var") String first_name_var, @Query("last_name_var") String last_name_var,  @Query("nick_name_var") String nick_name_var, @Query("passwd_var") String passwd_var, @Query("image_path") String image_path, @Query("method_var") String method_var, @Query("payment_email_var") String payment_email_var, @Query("min_var") String min_var);

    @POST("updatecustomer")
    @FormUrlEncoded
    public Single<ResponseUpdateCustomerData> getUpdateCustomerData(@Field("first_name_var") String first_name_var, @Field("last_name_var") String last_name_var,  @Field("nick_name_var") String nick_name_var, @Field("passwd_var") String passwd_var, @Field("image_path") String image_path, @Field("method_var") String method_var, @Field("payment_email_var") String payment_email_var, @Field("min_var") String min_var);


    //@GET("updatecustomername")
    //public Single<ResponseUpdateCustomerData> updateCustomerNameData(@Query("first_name_var") String first_name_var, @Query("last_name_var") String last_name_var,  @Query("nick_name_var") String nick_name_var);

    @POST("updatecustomername")
    @FormUrlEncoded
    public Single<ResponseUpdateCustomerData> updateCustomerNameData(@Field("first_name_var") String first_name_var, @Field("last_name_var") String last_name_var,  @Field("nick_name_var") String nick_name_var);


    //@GET("updatecustomerpassword")
    //public Single<ResponseUpdateCustomerData> updateCustomerPasswordData(@Query("passwd_var") String passwd_var);

    @POST("updatecustomerpassword")
    @FormUrlEncoded
    public Single<ResponseUpdateCustomerData> updateCustomerPasswordData(@Field("passwd_var") String passwd_var);

    //@GET("updatecustomerpayout")
    //public Single<ResponseUpdateCustomerData> updateCustomerPayoutData(@Query("method_var") String method_var, @Query("payment_email_var") String payment_email_var, @Query("min_var") String min_var);

    @POST("updatecustomerpayout")
    @FormUrlEncoded
    public Single<ResponseUpdateCustomerData> updateCustomerPayoutData(@Field("method_var") String method_var, @Field("payment_email_var") String payment_email_var, @Field("min_var") String min_var);

    @GET("gettestmaplist")
    public Single<ResponseTestMapsData> fetchTestMapsData(@Query("per_page") String per_page, @Query("page_num") String page_num);

    //@GET("sendmessage")
    //public Single<ResponseSendReturnData> sendMessage(@Query("to_id") String to_id, @Query("message") String message);

    @POST("sendmessage")
    @FormUrlEncoded
    public Single<ResponseSendReturnData> sendMessage(@Field("to_id") String to_id, @Field("message") String message);

    //@GET("searchproduct")
    //public Single<ResponseProductsData> fetchSearchProductsData(@Query("keywords_var") String keywords_var, @Query("exclusive_food_filters") String exclusive_food_filters, @Query("vehicle_filters") String vehicle_filters, @Query("theme_filters") String theme_filters, @Query("required_durations") String required_durations, @Query("per_page") String per_page, @Query("page_num") String page_num);

    @POST("searchproduct")
    @FormUrlEncoded
    public Single<ResponseProductsData> fetchSearchProductsData(@Field("keywords_var") String keywords_var, @Field("exclusive_food_filters") String exclusive_food_filters, @Field("vehicle_filters") String vehicle_filters, @Field("theme_filters") String theme_filters, @Field("required_durations") String required_durations, @Field("per_page") String per_page, @Field("page_num") String page_num);

    @GET("getsoldproducts")
    public Single<ResponseSalesData> getSales(@Query("per_page") String per_page, @Query("page_num") String page_num);

    //@GET("reviewslist")
    //public Single<ResponseReviewsData> fetchReviewsData(@Query("sku_var") String sku_var, @Query("per_page") String per_page, @Query("page_num") String page_num);

    @POST("reviewslist")
    @FormUrlEncoded
    public Single<ResponseReviewsData> fetchReviewsData(@Field("sku_var") String sku_var, @Field("per_page") String per_page, @Field("page_num") String page_num);

    //@GET("getmyreview")
    //public Single<ResponseGetMyReviewData> getMyReviewData(@Query("sku_var") String sku_var);

    @POST("getmyreview")
    @FormUrlEncoded
    public Single<ResponseGetMyReviewData> getMyReviewData(@Field("sku_var") String sku_var);

    //@GET("setmyreview")
    //public Single<ResponseSetMyReviewData> setMyReviewData(@Query("sku_var") String skuVar, @Query("rating1") String rating1, @Query("rating2") String rating2, @Query("review_title") String titleStr, @Query("review_body") String bodyStr);

    @POST("setmyreview")
    @FormUrlEncoded
    public Single<ResponseSetMyReviewData> setMyReviewData(@Field("sku_var") String skuVar, @Field("rating1") String rating1, @Field("rating2") String rating2, @Field("review_title") String titleStr, @Field("review_body") String bodyStr);

    //@GET("resetpassword")
    //public Single<ResponseResetEmailData> sendResetEmailData(@Query("email_var") String email_var);

    @POST("resetpassword")
    @FormUrlEncoded
    public Single<ResponseResetEmailData> sendResetEmailData(@Field("email_var") String email_var);

    //@GET("register")
    //public Single<ResponseRegisterData> getRegisterData(@Query("first_name_var") String first_name_var, @Query("last_name_var") String last_name_var, @Query("email_var") String email_var, @Query("passwd_var") String passwd_var, @Query("dev_var")  String dev_var, @Query("push_var")  String push_var);

    @POST("register")
    @FormUrlEncoded
    public Single<ResponseRegisterData> getRegisterData(@Field("first_name_var") String first_name_var, @Field("last_name_var") String last_name_var, @Field("email_var") String email_var, @Field("passwd_var") String passwd_var, @Field("dev_var")  String dev_var, @Field("push_var")  String push_var);

    //@GET("purchaseproduct")
    //public Single<ResponsePurchaseData> purchase(@Query("sku_var") String sku_var);

    @POST("purchaseproduct")
    @FormUrlEncoded
    public Single<ResponsePurchaseData> purchase(@Field("sku_var") String sku_var);

    @GET("purchasedlist")
    public Single<ResponseProductsData> fetchPurchasedListData(@Query("per_page") String per_page, @Query("page_num") String page_num);

    //@GET("productinfo")
    //public Single<ResponseProductData> getProductData(@Query("sku_var") String sku_var);

    @POST("productinfo")
    @FormUrlEncoded
    public Single<ResponseProductData> getProductData(@Field("sku_var") String sku_var);

    //@GET("addtowishlist")
    //public Single<ResponseSimpleData> addToWishlist(@Query("sku_var") String sku_var, @Query("on_flag") String on_flag);

    @POST("addtowishlist")
    @FormUrlEncoded
    public Single<ResponseSimpleData> addToWishlist(@Field("sku_var") String sku_var, @Field("on_flag") String on_flag);

    //@GET("getdownloadablemap")
    //public Single<ResponseMapFilesData> fetchMapFilesData(@Query("map_id") String map_id, @Query("sku_var") String sku_var );

    @POST("getdownloadablemap")
    @FormUrlEncoded
    public Single<ResponseMapFilesData> fetchMapFilesData(@Field("map_id") String map_id, @Field("sku_var") String sku_var );

    //@GET("gettestdownloadablemap")
    //public Single<ResponseMapFilesData> fetchDataForTestMap(@Query("map_id") String map_id);

    @POST("gettestdownloadablemap")
    @FormUrlEncoded
    public Single<ResponseMapFilesData> fetchDataForTestMap(@Field("map_id") String map_id);

    //@Streaming
    //@GET("mapdownload")
    //Observable<ResponseBody> download(@Query("map_id") String map_id, @Query("sku_var") String sku_var, @Query("file_key") String file_key);

    @Streaming
    @POST("mapdownload")
    @FormUrlEncoded
    Observable<ResponseBody> download(@Field("map_id") String map_id, @Field("sku_var") String sku_var, @Field("file_key") String file_key);

    //@Streaming
    //@GET("testmapdownload")
    //Observable<ResponseBody> download_for_test_map(@Query("map_id") String map_id, @Query("file_key") String file_key);

    @Streaming
    @POST("testmapdownload")
    @FormUrlEncoded
    Observable<ResponseBody> download_for_test_map(@Field("map_id") String map_id, @Field("file_key") String file_key);

    //@GET("login")
    //public Single<ResponseLoginData> getLoginData(@Query("id_var") String id_var, @Query("passwd_var") String passwd_var, @Query("dev_var")  String dev_var, @Query("push_var")  String push_var);

    @POST("login")
    @FormUrlEncoded
    public Single<ResponseLoginData> getLoginData(@Field("id_var") String id_var, @Field("passwd_var") String passwd_var, @Field("dev_var")  String dev_var, @Field("push_var")  String push_var);

    //@GET("andconnect")
    //public Single<ResponseLoginData> getFacebookLoginData(@Query("token") String token, @Query("id") String id, @Query("first_name") String first_name, @Query("last_name") String last_name, @Query("email") String email, @Query("dev_var")  String dev_var, @Query("push_var")  String push_var);

    @POST("andconnect")
    @FormUrlEncoded
    public Single<ResponseLoginData> getFacebookLoginData(@Field("token") String token, @Field("id") String id, @Field("first_name") String first_name, @Field("last_name") String last_name, @Field("email") String email, @Field("dev_var")  String dev_var, @Field("push_var")  String push_var);

    @GET("logout")
    public Single<ResponseLogoutData> getLogoutData();

    @Multipart
    @POST("uploadprofileimage")
    Observable<ResponseUploadImageData> uploadProfileImage(
            @Header("Set-Cookie") String sessionIdAndToken,
            @Part MultipartBody.Part file
            //@Part("profile_image_path\"; name=\"image.jpg\"")RequestBody img
    );

    @GET("getprofileimage")
    Observable<ResponseBody> download_profile_image();

    @GET("getcustomer")
    public Single<ResponseCustomerData> getCustomerData();

    @GET("getfriends")
    public Single<ResponseFriendsData> getFriends();

    //@GET("getmessage")
    //public Single<ResponseFriendMessagesData> getFriendMessages(@Query("friend_id") String to_id, @Query("start_time") String start_time);

    @POST("getmessage")
    @FormUrlEncoded
    public Single<ResponseFriendMessagesData> getFriendMessages(@Field("friend_id") String to_id, @Field("start_time") String start_time);

    //@GET("getmessage")
    //public Call<ResponseFriendMessagesData> getBlockingFriendMessages(@Query("friend_id") String to_id, @Query("start_time") String start_time);

    @POST("getmessage")
    @FormUrlEncoded
    public Call<ResponseFriendMessagesData> getBlockingFriendMessages(@Field("friend_id") String to_id, @Field("start_time") String start_time);

    @GET("getcusomerstats")
    public Single<ResponseCustomerStatsData> getStats();

    @GET("productslist")
    public Single<ResponseProductsData> fetchProductsListData(@Query("per_page") String per_page, @Query("page_num") String page_num);

    @GET("getrecentlyviewed")
    public Single<ResponseProductsData> fetchViewedData(@Query("per_page") String per_page, @Query("page_num") String page_num);

    @GET("getwishlist")
    public Single<ResponseProductsData> fetchWishlistData(@Query("per_page") String per_page, @Query("page_num") String page_num);

    @GET("getbestseller")
    public Single<ResponseProductsData> fetchBestSellerListData(@Query("per_page") String per_page, @Query("page_num") String page_num);

    //@GET("regionproductlist")
    //public Single<ResponseProductsData> fetchRegionProductsData(@Query("region_var") String region_var, @Query("per_page") String per_page, @Query("page_num") String page_num);

    @POST("regionproductlist")
    @FormUrlEncoded
    public Single<ResponseProductsData> fetchRegionProductsData(@Field("region_var") String region_var, @Field("per_page") String per_page, @Field("page_num") String page_num);

    @GET("getsetting")
    public Single<ResponseSettingData> fetchSettingData();

    //@GET("setmessagealarm")
    //public Single<ResponseDummyData> setMessageAlarmDisable(@Query("flag") String flag);

    //@GET("setsellingalarm")
    //public Single<ResponseDummyData> setSellingAlarmDisable(@Query("flag") String flag);

    //@GET("setbuyingalarm")
    //public Single<ResponseDummyData> setBuyingAlarmDisable(@Query("flag") String flag);

    @POST("setmessagealarm")
    @FormUrlEncoded
    public Single<ResponseDummyData> setMessageAlarmDisable(@Field("flag") String flag);

    @POST("setsellingalarm")
    @FormUrlEncoded
    public Single<ResponseDummyData> setSellingAlarmDisable(@Field("flag") String flag);

    @POST("setbuyingalarm")
    @FormUrlEncoded
    public Single<ResponseDummyData> setBuyingAlarmDisable(@Field("flag") String flag);

    @GET("getterms")
    public Single<ResponseDummyData> getTermOfUse();

    @GET("getprivacy")
    public Single<ResponseDummyData> getPrivacyPolicy();

    @GET("agreeterms")
    public Single<ResponseDummyData> agreeTerms();

    @GET("agreeprivacy")
    public Single<ResponseDummyData> agreePrivacy();

    @GET("gettgmstoreslist")
    public Single<ResponseStoresData> getStorelist();

    //@GET("sendsession")
    //public Single<ResponseSendSessionData> sendSessionData(@Query("SID") String sidString);

    @POST("sendsession")
    @FormUrlEncoded
    public Single<ResponseSendSessionData> sendSessionData(@Field("SID") String sidString);

}
