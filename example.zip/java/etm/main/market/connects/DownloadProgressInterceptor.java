package etm.main.market.connects;


import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Response;

public class DownloadProgressInterceptor implements Interceptor
{
    private DownloadProgressListener listener;
    private String mFileKey;

    public DownloadProgressInterceptor(DownloadProgressListener listener, String fileKey)
    {
        this.listener = listener;
        this.mFileKey = fileKey;
    }

    @Override
    public Response intercept(Interceptor.Chain chain) throws IOException
    {
        Response originalResponse = chain.proceed(chain.request());

        return originalResponse.newBuilder()
                .body(new DownloadProgressResponseBody(originalResponse.body(), listener, mFileKey))
                .build();
    }
}