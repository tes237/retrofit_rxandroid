package etm.main.market;

import java.io.*;
import java.lang.*;
import java.util.*;

import android.graphics.Bitmap;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.widget.Toast;

import etm.main.market.connects.WebManager;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.StringWrapper;

import android.content.*;
import android.content.res.Configuration;
import android.support.multidex.*;

public class generalApplication extends MultiDexApplication
{
    private static final String TAG = generalApplication.class.getSimpleName();

    //----------------------------- server result code -----------------------------//
    public static final int TGM_MOBILE_LOGIN_EMAIL_NOT_CONFIRMED = 20101;
    public static final int TGM_MOBILE_LOGIN_INVALID_EMAIL_PASSWORD = 20102;
    public static final int TGM_MOBILE_LOGIN_DEFAULT_ERROR = 20103;
    public static final int TGM_MOBILE_LOGIN_EXCEPTION_ERROR = 20104;
    public static final int TGM_MOBILE_LOGIN_EMAIL_OR_PASSWORD_ARE_MISSING = 20105;

    public static final int TGM_MOBILE_GET_CUSTOMER_EXCEPTION_ERROR = 20151;
    public static final int TGM_MOBILE_UPDATE_CUSTOMER_EXCEPTION_ERROR = 20201;
    public static final int TGM_MOBILE_REGISTER_EXCEPTION_ERROR = 20251;
    public static final int TGM_MOBILE_SECURITY_PERMISSION_ERROR = 20301;

    public static final int TGM_MOBILE_MAP_DOWNLOAD_NOT_FOUND_ERROR = 20351;
    public static final int TGM_MOBILE_MAP_DOWNLOAD_EXCEPTION_ERROR = 20352;

    public static final int TGM_MOBILE_DOWNLOADABLE_FILES_INVALID_MAPDATA = 20401;
    public static final int TGM_MOBILE_DOWNLOADABLE_FILES_EXCEPTION_ERROR = 20402;

    public static final int TGM_MOBILE_GET_MESSAGE_INVALID_REQUEST = 20451;
    public static final int TGM_MOBILE_SEND_MESSAGE_INVALID_REQUEST = 20501;
    public static final int TGM_MOBILE_SEND_MESSAGE_EXCEPTION_ERROR = 20502;

    public static final int TGM_MOBILE_PURCHASE_PRODUCT_INVALID_REQUEST = 20551;
    public static final int TGM_MOBILE_PURCHASE_PRODUCT_EXCEPTION_ERROR = 20552;
    public static final int TGM_MOBILE_GET_REVIEWS_NOT_PUBLISHED = 20601;
    public static final int TGM_MOBILE_GET_REVIEWS_INVALID_REQUEST = 20602;

    public static final int TGM_MOBILE_GET_MY_REVIEW_NOT_PURCHASED = 20651;
    public static final int TGM_MOBILE_GET_MY_REVIEW_NOT_PUBLISHED = 20652;
    public static final int TGM_MOBILE_GET_MY_REVIEW_INVALID_REQUEST = 20653;
    public static final int TGM_MOBILE_SET_MY_REVIEW_NOT_PURCHASED = 20701;
    public static final int TGM_MOBILE_SET_MY_REVIEW_NOT_PUBLISHED = 20702;
    public static final int TGM_MOBILE_SET_MY_REVIEW_INVALID_REQUEST = 20703;

    public static final int TGM_MOBILE_GET_PRODUCT_INFO_NOT_PUBLISHED = 20751;
    public static final int TGM_MOBILE_GET_PRODUCT_INFO_INVALID_REQUEST = 20752;

    public static final int TGM_MOBILE_UPLOAD_PROFILE_IMAGE_FAIL = 20801;

    public static final int TGM_MOBILE_ADD_WISHLIST_INVALID_REQUEST = 20851;

    public static final int TGM_MOBILE_GET_SETTING_EXCEPTION_ERROR = 20901;

    public static final int TGM_MOBILE_GET_TERMS_EXCEPTION_ERROR = 20951;

    public static final int TGM_MOBILE_SET_MESSAGE_ALARM_EXCEPTION_ERROR = 21001;

    public static final int TGM_MOBILE_SET_SELLING_ALARM_DISABLE_EXCEPTION_ERROR = 21051;

    public static final int TGM_MOBILE_SET_BUYING_ALARM_DISABLE_EXCEPTION_ERROR = 21101;

    public static final int TGM_MOBILE_SET_VIEWED_INVALID_REQUEST = 21151;
    public static final int TGM_MOBILE_SET_VIEWED_EXCEPTION_ERROR = 21152;

    public static final int TGM_MOBILE_RESET_PASSWD_INVALID_EMAIL = 21201;
    public static final int TGM_MOBILE_RESET_PASSWD_OPERATION_FAILED = 21202;

    public static final boolean TGM_PROFILE_ON = false;

    private ArrayList<Locale> mLanguages;

    private static WebManager mTGMWebManager;
    private static Context mContext;
    private String mIdString;
    private String mNumString;

    private boolean mMessageAlarm = false;
    private boolean mSellingAlarm = false;
    private boolean mBuyingAlarm = false;

    private boolean mIsLoggedIn = false;

    private long mTickCount = 0;

    private boolean mIsProfileLoaded = false;

    private boolean mIsTermsAgreed = false;
    private boolean mIsPrivacyAgreed = false;

    public void setIdString(String tmpId)
    {
        mIdString = tmpId;
    }

    public String getIdString()
    {
        return mIdString;
    }

    public void setNumString(String tmpNum)
    {
        mNumString = tmpNum;
    }

    public String getNumString()
    {
        return mNumString;
    }

    public void setMessageAlarm(boolean flag)
    {
        mMessageAlarm = flag;
    }

    public boolean getMessageAlarmFlag()
    {
        return mMessageAlarm;
    }

    public void setSellingAlarm(boolean flag)
    {
        mSellingAlarm = flag;
    }

    public boolean getSellingAlarmFlag()
    {
        return mSellingAlarm;
    }

    public void setBuyingAlarm(boolean flag)
    {
        mBuyingAlarm = flag;
    }

    public boolean getBuyingAlarmFlag()
    {
        return mBuyingAlarm;
    }

    public String getAppDirectory()
    {
        if(BuildConfig.FAKE_DIR == true)
        {
            return "/mnt/sdcard/tgm";
        }
        else
        {
            return getBaseContext().getFilesDir().getAbsolutePath();
        }
    }

    public boolean IsLoggedIn()
    {
        return mIsLoggedIn;
    }

    public void setLoggedIn(boolean flag)
    {
        mIsLoggedIn = flag;
    }

    public void onCreate()
    {
        super.onCreate();

        mContext = getApplicationContext();
        mTGMWebManager = new WebManager(mContext);
    }

    public static Context getAppContext()
    {
        return mContext;
    }

    public static WebManager getTGMWeb()
    {
        return mTGMWebManager;
    }

    public static boolean isLocationService(Context context)
    {
        String gps = android.provider.Settings.Secure.getString(
                context.getContentResolver(),
                android.provider.Settings.Secure.LOCATION_PROVIDERS_ALLOWED);

        return gps.matches(".*gps.*") || gps.matches(".*network.*");
    }

    public void checkLocationService(Context activityContext)
    {
        if(isLocationService(activityContext) == false)
        {
            Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            activityContext.startActivity(intent);
        }
    }

    public void setTick(String title)
    {
        if(TGM_PROFILE_ON == false)
            return;

        long currentTick = System.currentTimeMillis();
        long tmpDuration = currentTick - mTickCount;
        Log.d(TAG, String.format("######## %s tick = %d", title, tmpDuration));

        mTickCount = currentTick;
    }

    public void setProfileLoaded(boolean flag)
    {
        mIsProfileLoaded = flag;
    }

    public boolean isProfileLoaded()
    {
        return mIsProfileLoaded;
    }

    public void setIsTermsAgreed(boolean flag)
    {
        mIsTermsAgreed = flag;
    }

    public void setIsPrivacyAgreed(boolean flag)
    {
        mIsPrivacyAgreed = flag;
    }

    public boolean isTermsAgreed()
    {
        return mIsTermsAgreed;
    }

    public boolean isPrivacyAgreed()
    {
        return mIsPrivacyAgreed;
    }

    public String getResultString(int resultCode)
    {
        switch(resultCode)
        {
            case TGM_MOBILE_LOGIN_EMAIL_NOT_CONFIRMED:
                return mContext.getString(R.string.result_code_login_email_not_confirmed);
            case TGM_MOBILE_LOGIN_INVALID_EMAIL_PASSWORD:
                return mContext.getString(R.string.result_code_login_invalid_email_password);
            case TGM_MOBILE_LOGIN_DEFAULT_ERROR:
                return mContext.getString(R.string.result_code_login_default_error);
            case TGM_MOBILE_LOGIN_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_login_exception_error);
            case TGM_MOBILE_LOGIN_EMAIL_OR_PASSWORD_ARE_MISSING:
                return mContext.getString(R.string.result_code_login_email_or_password_missing);

            case TGM_MOBILE_GET_CUSTOMER_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_get_customer_exception_error);
            case TGM_MOBILE_UPDATE_CUSTOMER_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_update_customer_exception_error);
            case TGM_MOBILE_REGISTER_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_register_exception_error);
            case TGM_MOBILE_SECURITY_PERMISSION_ERROR:
                return mContext.getString(R.string.result_code_security_permission_error);

            case TGM_MOBILE_MAP_DOWNLOAD_NOT_FOUND_ERROR:
                return mContext.getString(R.string.result_code_map_download_not_found_error);
            case TGM_MOBILE_MAP_DOWNLOAD_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_map_download_exception_error);

            case TGM_MOBILE_DOWNLOADABLE_FILES_INVALID_MAPDATA:
                return mContext.getString(R.string.result_code_downloadable_files_invalid_mapdata);
            case TGM_MOBILE_DOWNLOADABLE_FILES_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_downloadable_files_exception_error);

            case TGM_MOBILE_GET_MESSAGE_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_get_message_invalid_request);
            case TGM_MOBILE_SEND_MESSAGE_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_send_message_invalid_request);
            case TGM_MOBILE_SEND_MESSAGE_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_send_message_exception_error);

            case TGM_MOBILE_PURCHASE_PRODUCT_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_purchase_product_invalid_request);
            case TGM_MOBILE_PURCHASE_PRODUCT_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_purchase_product_exception_error);
            case TGM_MOBILE_GET_REVIEWS_NOT_PUBLISHED:
                return mContext.getString(R.string.result_code_get_reviewes_not_published);
            case TGM_MOBILE_GET_REVIEWS_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_get_reviewes_invalid_request);

            case TGM_MOBILE_GET_MY_REVIEW_NOT_PURCHASED:
                return mContext.getString(R.string.result_code_get_my_review_not_purchased);
            case TGM_MOBILE_GET_MY_REVIEW_NOT_PUBLISHED:
                return mContext.getString(R.string.result_code_get_my_review_not_published);
            case TGM_MOBILE_GET_MY_REVIEW_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_get_my_review_invalid_request);
            case TGM_MOBILE_SET_MY_REVIEW_NOT_PURCHASED:
                return mContext.getString(R.string.result_code_set_my_review_not_purchased);
            case TGM_MOBILE_SET_MY_REVIEW_NOT_PUBLISHED:
                return mContext.getString(R.string.result_code_set_my_review_not_published);
            case TGM_MOBILE_SET_MY_REVIEW_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_set_my_review_invalid_request);

            case TGM_MOBILE_GET_PRODUCT_INFO_NOT_PUBLISHED:
                return mContext.getString(R.string.result_code_get_product_info_not_published);
            case TGM_MOBILE_GET_PRODUCT_INFO_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_get_product_info_invalid_request);

            case TGM_MOBILE_UPLOAD_PROFILE_IMAGE_FAIL:
                return mContext.getString(R.string.result_code_upload_profile_image_fail);

            case TGM_MOBILE_ADD_WISHLIST_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_add_wishlist_invalid_request);

            case TGM_MOBILE_GET_SETTING_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_get_setting_exception_error);

            case TGM_MOBILE_GET_TERMS_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_get_terms_exception_error);

            case TGM_MOBILE_SET_MESSAGE_ALARM_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_set_message_alarm_exception_error);

            case TGM_MOBILE_SET_SELLING_ALARM_DISABLE_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_set_selling_alarm_disable_exception_error);

            case TGM_MOBILE_SET_BUYING_ALARM_DISABLE_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_set_buying_alarm_disable_exception_error);

            case TGM_MOBILE_SET_VIEWED_INVALID_REQUEST:
                return mContext.getString(R.string.result_code_set_viewed_invalid_request);
            case TGM_MOBILE_SET_VIEWED_EXCEPTION_ERROR:
                return mContext.getString(R.string.result_code_set_viewed_exception_error);

            case TGM_MOBILE_RESET_PASSWD_INVALID_EMAIL:
                return mContext.getString(R.string.result_code_reset_pw_invalid_email);
            case TGM_MOBILE_RESET_PASSWD_OPERATION_FAILED:
                return mContext.getString(R.string.result_code_reset_pw_oper_failed);

            default:
                return mContext.getString(R.string.result_code_unknown_error);
        }
    }

}
