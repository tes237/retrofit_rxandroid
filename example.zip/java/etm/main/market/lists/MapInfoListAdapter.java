package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import etm.main.market.R;
import etm.main.market.vo.MapItem;
import etm.main.market.vo.Product;
import etm.main.market.vo.PurchasedItem;

public class MapInfoListAdapter extends RecyclerView.Adapter<MapInfoListAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    List<MapItem> items;
    PurchasedInfoListListener mPurchasedInfoListListener;

    public MapInfoListAdapter(Context context, List<MapItem> items, PurchasedInfoListListener tmpPurchasedInfoListListener)
    {
        this.mContext=context;
        this.items=items;
        this.mPurchasedInfoListListener = tmpPurchasedInfoListListener;
    }

    @Override
    public MapInfoListAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.tour_guide_purchased_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(MapInfoListAdapter.CustomViewHolder holder, final int position)
    {
        final MapItem item = items.get(position);

        //Picasso.with(mContext).load(R.drawable.experiment_icon).into(holder.mImage);
        Picasso.get().load(R.drawable.experiment_icon).into(holder.mImage);

        holder.mTitle.setText(item.getTitle());

        boolean isNeedToBeDownloaded = item.getNeedToBeDownloaded();

        int tmpStatus = item.getDownloadStatus();
        if(tmpStatus == PurchasedItem.DOWNLOAD_NOT_STARTED)
        {
            if(isNeedToBeDownloaded)
            {
                holder.mDownloadButton.setVisibility(View.VISIBLE);
                holder.mReviewButton.setVisibility(View.GONE);
                holder.mReviewIcon.setVisibility(View.GONE);
                holder.mSelect.setVisibility(View.GONE);
            }
            else
            {
                holder.mDownloadButton.setVisibility(View.GONE);
                holder.mReviewButton.setVisibility(View.GONE);
                holder.mReviewIcon.setVisibility(View.GONE);
                holder.mSelect.setVisibility(View.VISIBLE);
            }

            holder.mProgress.setVisibility(View.INVISIBLE);
            holder.mProgressScene.setVisibility(View.INVISIBLE);

        }
        else if(tmpStatus == PurchasedItem.DOWNLOAD_STARTED)
        {
            holder.mProgress.setProgress(item.getDownloadProgress());
            holder.mProgress.setVisibility(View.VISIBLE);

            holder.mDownloadButton.setVisibility(View.INVISIBLE);
            holder.mReviewButton.setVisibility(View.GONE);
            holder.mReviewIcon.setVisibility(View.GONE);
            holder.mSelect.setVisibility(View.INVISIBLE);

            holder.mProgressScene.setVisibility(View.VISIBLE);
        }
        else if(tmpStatus == PurchasedItem.DOWNLOAD_FINISHED)
        {
            holder.mProgress.setVisibility(View.INVISIBLE);
            if(isNeedToBeDownloaded)
            {
                holder.mDownloadButton.setVisibility(View.VISIBLE);
                holder.mReviewButton.setVisibility(View.GONE);
                holder.mReviewIcon.setVisibility(View.GONE);
                holder.mSelect.setVisibility(View.GONE);
            }
            else
            {
                holder.mDownloadButton.setVisibility(View.GONE);
                holder.mReviewButton.setVisibility(View.GONE);
                holder.mReviewIcon.setVisibility(View.GONE);
                holder.mSelect.setVisibility(View.VISIBLE);
            }
            holder.mProgressScene.setVisibility(View.INVISIBLE);
        }

        holder.mCardView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mPurchasedInfoListListener.onListClickListener(v, position, 0);
            }
        });

        holder.mDownloadButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mPurchasedInfoListListener.onDownloadClickListener(v, position, 0);
            }
        });

        holder.mReviewButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mPurchasedInfoListListener.onReviewClickListener(v, position, 0);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return (null != items ? items.size() : 0);
    }

    @Override
    public void onClick(View v)
    {

    }

    public void refreshStatus(int position, int status)
    {
        MapItem item = items.get(position);
        item.setDownloadStatus(status);
        items.set(position, item);
    }

    public void refreshProgress(int position, int percent)
    {
        MapItem item = items.get(position);
        item.setDownloadProgress(percent);
        item.setDownloadStatus(PurchasedItem.DOWNLOAD_STARTED);
        items.set(position, item);
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public ImageView mImage;
        public TextView mTitle;
        public CardView mCardView;
        public ImageButton mDownloadButton;

        public ImageView mReviewIcon;
        public TextView mReviewButton;
        public ProgressBar mProgress;
        public LinearLayout mProgressScene;
        public ImageView mSelect;


        public CustomViewHolder(View itemView)
        {
            super(itemView);
            mImage = (ImageView)itemView.findViewById(R.id.image);
            mTitle = (TextView)itemView.findViewById(R.id.title);
            mCardView = (CardView)itemView.findViewById(R.id.cardview);
            mDownloadButton = (ImageButton)itemView.findViewById(R.id.download_map_button);
            mReviewIcon = (ImageView)itemView.findViewById(R.id.review_map_icon);
            mReviewButton = (TextView)itemView.findViewById(R.id.review_map_text);
            mProgress = (ProgressBar)itemView.findViewById(R.id.download_progress);
            mProgressScene = (LinearLayout)itemView.findViewById(R.id.download_background);
            mSelect = (ImageView)itemView.findViewById(R.id.select_map_button);
        }
    }
}