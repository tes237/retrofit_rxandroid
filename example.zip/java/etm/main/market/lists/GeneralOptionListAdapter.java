package etm.main.market.lists;

import java.io.File;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import etm.main.market.baseDefine;
//import etm.main.market.widgets.CircleDrawable;
import etm.main.market.R;
import etm.main.market.common.Base64;
import etm.main.market.dialog.GeneralOptionListener;
import etm.main.market.generalApplication;
import etm.main.market.graphs.VertexGroup;
import etm.main.market.vo.ServerMapSpotData;

public class GeneralOptionListAdapter extends ArrayAdapter implements baseDefine
{
    static class ViewHolder
    {
        TextView title_label;
    }

    private ArrayList<String>	mStringNameList;

    private Context mContext;
    private GeneralOptionListener mGeneralOptionListener;

    protected generalApplication mGeneralApplication = null;

    public GeneralOptionListAdapter(Context context, ArrayList<String> item_title_array, GeneralOptionListener tmpGeneralOptionListener)
    {
        super(context, R.layout.list_spot_option_item, item_title_array);

        this.mContext = context;

        this.mStringNameList = item_title_array;
        this.mGeneralOptionListener = tmpGeneralOptionListener;

        mGeneralApplication = (generalApplication)mContext.getApplicationContext();
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewHolder tmp_holder;
        View row = null;

        if(convertView == null)
        {
            LayoutInflater inflater = ((Activity)mContext).getLayoutInflater();

            row = (View)inflater.inflate(R.layout.list_general_option_item, null);

            tmp_holder = new ViewHolder();

            tmp_holder.title_label = (TextView)row.findViewById(R.id.general_title_label_textview);

            convertView = row;
            convertView.setTag(tmp_holder);
        }
        else
        {
            tmp_holder = (ViewHolder)convertView.getTag();
        }

        String tmpText = mStringNameList.get(position);

        tmp_holder.title_label.setText(tmpText);
        tmp_holder.title_label.setClickable(true);
        tmp_holder.title_label.setOnClickListener(mOnViewItemClickListener);
        tmp_holder.title_label.setTag(Integer.valueOf(position));

        return convertView;
    }

    public void setListener(GeneralOptionListener tmpGeneralOptionListener)
    {
        mGeneralOptionListener = tmpGeneralOptionListener;
    }

    private OnClickListener mOnViewItemClickListener = new OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            Integer position = (Integer)v.getTag();

            mGeneralOptionListener.onListClickListener(v, position);
        }
    };
}
