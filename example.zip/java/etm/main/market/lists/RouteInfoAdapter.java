package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import etm.main.market.R;
import etm.main.market.vo.Product;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.Route;
import etm.main.market.vo.Sale;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class RouteInfoAdapter extends RecyclerView.Adapter<RouteInfoAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    List<Route> items;
    SaleInfoListListener mSaleInfoListListener;

    public RouteInfoAdapter(Context context, List<Route> items, SaleInfoListListener tmpSaleInfoListListener)
    {
        this.mContext = context;
        this.items = items;
        this.mSaleInfoListListener = tmpSaleInfoListListener;
    }

    @Override
    public RouteInfoAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.tour_guide_route_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(RouteInfoAdapter.CustomViewHolder holder, final int position)
    {
        final Route item = items.get(position);

        holder.mNumView.setText(String.format("%02d", position+1));
        holder.mTitle.setText(item.getTitle());

        holder.mRouteView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mSaleInfoListListener.onListClickListener(v, position, 0);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return (null != items ? items.size() : 0);
    }

    @Override
    public void onClick(View v)
    {

    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public TextView mNumView;
        public TextView mTitle;
        public ScalableLayout mRouteView;

        public CustomViewHolder(View itemView)
        {
            super(itemView);

            mNumView = (TextView)itemView.findViewById(R.id.number_title);
            mTitle = (TextView)itemView.findViewById(R.id.title);
            mRouteView = (ScalableLayout)itemView.findViewById(R.id.route_item_layout);
        }
    }
}