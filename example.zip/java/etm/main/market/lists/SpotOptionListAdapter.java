package etm.main.market.lists;

import java.io.File;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import etm.main.market.baseDefine;
//import etm.main.market.widgets.CircleDrawable;
import etm.main.market.R;
import etm.main.market.common.Base64;
import etm.main.market.common.CircleTransformation;
import etm.main.market.generalApplication;
import etm.main.market.graphs.VertexGroup;
import etm.main.market.vo.ServerMapSpotData;

public class SpotOptionListAdapter extends ArrayAdapter implements baseDefine
{
    static class ViewHolder
    {
        TextView title_label;
        ImageView spot_image;
        TextView recommended_label;
    }

    private ArrayList<String>	mStringNameList;
    private ArrayList<Integer> mRecommendationList;
    private ArrayList<String>	mImagePathList;
    private int mFromIndex;
    private ArrayList<VertexGroup> mVerticesArray;
    private ArrayList<Integer> mSpotIndex;

    private Context mContext;
    private SpotOptionListener mSpotOptionListener;

    protected generalApplication mGeneralApplication = null;
    private  String APP_DIRECTORY;
    private String mUserDir;
    private String mSkuStr;

    public SpotOptionListAdapter(Context context, String tmpSkuStr, ArrayList<String> item_title_array, ArrayList<Integer> item_recommendation_array, ArrayList<String> item_image_path_array, int fromIndex, ArrayList<VertexGroup> vertexArray, ArrayList<Integer> spotIndexArray, SpotOptionListener tmpSpotOptionListener)
    {
        super(context, R.layout.list_spot_option_item, item_title_array);

        this.mContext = context;

        this.mSkuStr = tmpSkuStr;

        this.mStringNameList = item_title_array;
        this.mRecommendationList = item_recommendation_array;
        this.mImagePathList = item_image_path_array;
        this.mFromIndex = fromIndex;
        this.mVerticesArray = vertexArray;
        this.mSpotIndex = spotIndexArray;

        this.mSpotOptionListener = tmpSpotOptionListener;

        mGeneralApplication = (generalApplication)mContext.getApplicationContext();

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();
        String tmpUserIdStr = mGeneralApplication.getIdString();
        mUserDir = Base64.mod_encode(tmpUserIdStr);
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewHolder tmp_holder;
        View row = null;

        if(convertView == null)
        {
            LayoutInflater inflater = ((Activity)mContext).getLayoutInflater();

            row = (View)inflater.inflate(R.layout.list_spot_option_item, null);

            tmp_holder = new ViewHolder();

            tmp_holder.title_label = (TextView)row.findViewById(R.id.spot_title_label_textview);
            tmp_holder.recommended_label = (TextView)row.findViewById(R.id.spot_label_recommended_textview);
            tmp_holder.spot_image = (ImageView)row.findViewById(R.id.spot_imageview);

            convertView = row;
            convertView.setTag(tmp_holder);
        }
        else
        {
            tmp_holder = (ViewHolder)convertView.getTag();
        }

        String imagePath = mImagePathList.get(position);

        if( (imagePath == null) || (imagePath.equals("") == true))
        {
            //tmp_holder.spot_image.setImageResource(R.drawable.tgm_no_picture);
            //Picasso.with(this.mContext).load(R.drawable.error_icon).transform(new CircleTransformation()).into(tmp_holder.spot_image);
            Picasso.get().load(R.drawable.error_icon).transform(new CircleTransformation()).into(tmp_holder.spot_image);
        }
        else
        {
            String localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + imagePath;
            //Picasso.with(this.mContext).load("file://" + localPathStr).transform(new CircleTransformation()).into(tmp_holder.spot_image);
            Picasso.get().load("file://" + localPathStr).transform(new CircleTransformation()).into(tmp_holder.spot_image);
            /*
            File imageFile = new File(localPathStr);

            if (imageFile.exists()) {
                //supportMapFragment.getView().setVisibility(View.INVISIBLE);
                Bitmap tmpBitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
                tmp_holder.spot_image.setImageBitmap(null);
                tmp_holder.spot_image.setImageBitmap(tmpBitmap);
            }
            */
        }
        tmp_holder.spot_image.setOnClickListener(mOnViewItemClickListener);
        tmp_holder.spot_image.setTag(Integer.valueOf(position));

        String tmpText = mStringNameList.get(position);

        int tmpRecommendation = mRecommendationList.get(position);
        if(tmpRecommendation == ServerMapSpotData.NODE_RECOMMENDED_TRUE)
        {
            tmp_holder.recommended_label.setText("Recommended by seller");
        }
        else
        {
            tmp_holder.recommended_label.setText("");
        }
        tmp_holder.recommended_label.setOnClickListener(mOnViewItemClickListener);
        tmp_holder.recommended_label.setTag(Integer.valueOf(position));

        tmp_holder.title_label.setText(tmpText);
        tmp_holder.title_label.setClickable(true);
        tmp_holder.title_label.setOnClickListener(mOnViewItemClickListener);
        tmp_holder.title_label.setTag(Integer.valueOf(position));

        return convertView;
    }

    public void setListener(SpotOptionListener tmpSpotOptionListener)
    {
        mSpotOptionListener = tmpSpotOptionListener;
    }

    private OnClickListener mOnViewItemClickListener = new OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            //TextView tmpTv = (TextView)v;
            Integer position = (Integer)v.getTag();

            mSpotOptionListener.onListClickListener(v, position, mFromIndex, mVerticesArray.get(position), mSpotIndex.get(position));
        }
    };
}
