package etm.main.market.lists;

public interface NodeChangeListener
{
    void OnTGNodeChangeListener(int nodeIndex, int index, boolean fromUser);
}
