package etm.main.market.lists;

import java.io.File;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import etm.main.market.baseDefine;
import etm.main.market.R;
import etm.main.market.common.Base64;
import etm.main.market.dialog.LanguageOptionListener;
import etm.main.market.generalApplication;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class LanguageOptionListAdapter extends ArrayAdapter implements baseDefine
{
    static class ViewHolder
    {
        TextView title_label;
        ImageView language_image;
        ScalableLayout background_layout;
    }

    private ArrayList<String>	mStringNameList;
    private Context mContext;
    private LanguageOptionListener mLanguageOptionListener;
    private int mSelectedIndex = -1;

    protected generalApplication mGeneralApplication = null;
    //private  String APP_DIRECTORY;
    //private String mUserDir;

    public LanguageOptionListAdapter(Context context, ArrayList<String> item_title_array, LanguageOptionListener tmpLanguageOptionListener)
    {
        super(context, R.layout.list_language_option_item, item_title_array);

        this.mContext = context;

        this.mStringNameList = item_title_array;

        this.mLanguageOptionListener = tmpLanguageOptionListener;

        mGeneralApplication = (generalApplication)mContext.getApplicationContext();

        //APP_DIRECTORY = mGeneralApplication.getAppDirectory();
        //String tmpUserIdStr = mGeneralApplication.getIdString();
        //mUserDir = Base64.mod_encode(tmpUserIdStr);
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewHolder tmp_holder;
        View row = null;

        if(convertView == null)
        {
            LayoutInflater inflater = ((Activity)mContext).getLayoutInflater();

            row = (View)inflater.inflate(R.layout.list_language_option_item, null);

            tmp_holder = new ViewHolder();

            tmp_holder.background_layout = (ScalableLayout)row.findViewById(R.id.language_select_layout);
            tmp_holder.title_label = (TextView)row.findViewById(R.id.language_title_label_textview);
            tmp_holder.language_image = (ImageView)row.findViewById(R.id.language_imageview);

            convertView = row;
            convertView.setTag(tmp_holder);
        }
        else
        {
            tmp_holder = (ViewHolder)convertView.getTag();
        }

        int left_val = position % 5;
        switch(left_val)
        {
            case 0:
                tmp_holder.language_image.setImageResource(R.drawable.language_choice1);
                break;
            case 1:
                tmp_holder.language_image.setImageResource(R.drawable.language_choice2);
                break;
            case 2:
                tmp_holder.language_image.setImageResource(R.drawable.language_choice3);
                break;
            case 3:
                tmp_holder.language_image.setImageResource(R.drawable.language_choice4);
                break;
            case 4:
                tmp_holder.language_image.setImageResource(R.drawable.language_choice5);
                break;
        }

        tmp_holder.language_image.setOnClickListener(mOnViewItemClickListener);
        tmp_holder.language_image.setTag(Integer.valueOf(position));

        String tmpText = mStringNameList.get(position);

        tmp_holder.title_label.setText(tmpText);
        tmp_holder.title_label.setClickable(true);
        tmp_holder.title_label.setOnClickListener(mOnViewItemClickListener);
        tmp_holder.title_label.setTag(Integer.valueOf(position));

        if(mSelectedIndex == position)
        {
            tmp_holder.background_layout.setBackgroundColor(0xffD6CECD);
        }
        else
        {
            tmp_holder.background_layout.setBackgroundColor(0xffffffff);
        }

        return convertView;
    }

    public void setListener(LanguageOptionListener tmpSpotOptionListener)
    {
        mLanguageOptionListener = tmpSpotOptionListener;
    }

    private OnClickListener mOnViewItemClickListener = new OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            Integer position = (Integer)v.getTag();

            mSelectedIndex = position;

            mLanguageOptionListener.onListClickListener(v, position);
        }
    };
}
