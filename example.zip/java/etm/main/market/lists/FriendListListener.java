package etm.main.market.lists;

import android.view.View;

public interface FriendListListener
{
    void onListClickListener(View v, int index, int status);
}