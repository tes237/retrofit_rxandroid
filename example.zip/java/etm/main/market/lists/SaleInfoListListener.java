package etm.main.market.lists;

import android.view.View;

public interface SaleInfoListListener
{
    void onListClickListener(View v, int index, int status);
}