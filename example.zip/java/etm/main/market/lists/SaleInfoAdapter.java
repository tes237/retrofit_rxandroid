package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import etm.main.market.R;
import etm.main.market.common.CircleTransformation;
import etm.main.market.connects.WebManager;
import etm.main.market.vo.Product;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.Sale;

public class SaleInfoAdapter extends RecyclerView.Adapter<SaleInfoAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    List<Sale> items;
    SaleInfoListListener mSaleInfoListListener;
    WebManager mTGMWebManager;

    public SaleInfoAdapter(Context context, List<Sale> items, SaleInfoListListener tmpSaleInfoListListener, WebManager tmpManager)
    {
        this.mContext=context;
        this.items=items;
        this.mSaleInfoListListener = tmpSaleInfoListListener;
        this.mTGMWebManager = tmpManager;
    }

    @Override
    public SaleInfoAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.tour_guide_sale_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(SaleInfoAdapter.CustomViewHolder holder, final int position)
    {
        final Sale item = items.get(position);

        String customerId = item.getSale_customer_id();

        String tmpUrlStr = item.getCustomerPhotoUrl();
        if(tmpUrlStr != null && "".equals(tmpUrlStr) == false)
        {
            try
            {
                tmpUrlStr = URLDecoder.decode(tmpUrlStr, "utf-8");

                //Picasso.with(mContext).load(tmpUrlStr).transform(new CircleTransformation()).into(holder.mMessageButton);
                //Picasso.with(mContext).load(tmpUrlStr).into(holder.mMessageButton);
                //Picasso.get().load(tmpUrlStr).into(holder.mMessageButton);
                mTGMWebManager.picasso_load_simple(tmpUrlStr, customerId, holder.mMessageButton);

                //Picasso.with(mContext).load(R.drawable.send_message).transform(new CircleTransformation()).into(holder.mMessageButton);
                //Picasso.with(mContext).load(R.drawable.send_message).into(holder.mMessageButton);
            }
            catch (UnsupportedEncodingException e)
            {
                e.printStackTrace();
            }
        }
        else
        {
            //Picasso.with(mContext).load(R.drawable.sample_photo).transform(new CircleTransformation()).into(holder.mMessageButton);
            //Picasso.get().load(R.drawable.sample_photo).transform(new CircleTransformation()).into(holder.mMessageButton);
            Picasso.get().load(R.drawable.sample_photo).into(holder.mMessageButton);
        }


        //Picasso.get().load(R.drawable.send_message).into(holder.mMessageButton);

        holder.mTitle.setText(item.getSale_title());
        holder.mName.setText(item.getSale_customer());
        holder.mDate.setText(item.getSale_date());

        holder.mCardView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mSaleInfoListListener.onListClickListener(v, position, 0);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return (null != items ? items.size() : 0);
    }

    @Override
    public void onClick(View v)
    {

    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public TextView mTitle;
        public CardView mCardView;
        public ImageView mMessageButton;
        public TextView mName;
        public TextView mDate;

        public CustomViewHolder(View itemView)
        {
            super(itemView);
            mTitle = (TextView)itemView.findViewById(R.id.title);
            mCardView = (CardView)itemView.findViewById(R.id.cardview);
            mMessageButton = (ImageView)itemView.findViewById(R.id.message_button);
            mName = (TextView)itemView.findViewById(R.id.name);
            mDate = (TextView)itemView.findViewById(R.id.date);
        }
    }
}