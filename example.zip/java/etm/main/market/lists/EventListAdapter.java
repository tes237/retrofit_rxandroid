package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.util.List;

import etm.main.market.activities.PlayerActivity;
import etm.main.market.R;

public class EventListAdapter extends RecyclerView.Adapter<EventListAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    List<PlayerActivity.EventGUI> items;
    NodeChangeListener mNodeChangeListener;

    public static final int AREA_NO = 0;
    public static final int AREA_IMAGE_GALLERY = 1;
    public static final int AREA_BALLOON = 2;

    public static final int NODE_OPTIONAL = 999;
    public static final int NODE_SINGLE = 1;
    public static final int NODE_MULTI = 2;
    public static final int NODE_INTRO = 3;

    private float mSelectedBalloonIndex = 0;

    public EventListAdapter(Context context, List<PlayerActivity.EventGUI> items, NodeChangeListener tmpNodeChangeListener)
    {
        this.mContext=context;
        this.items=items;
        this.mNodeChangeListener = tmpNodeChangeListener;
    }

    @Override
    public EventListAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.event_list_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(EventListAdapter.CustomViewHolder holder, final int position)
    {
        final PlayerActivity.EventGUI item = items.get(position);

        /*
        if(item.mEventType == NODE_INTRO)
        {
            if(mSelectedBalloonIndex == position)
            {

            }
            else
            {
                holder.mEventIcon.setImageResource(R.drawable.speaker_disable);
            }
        }
        else if(item.mEventType == NODE_SINGLE)
        {
            if(mSelectedBalloonIndex == position)
            {

            }
            else
            {
                holder.mEventIcon.setImageResource(R.drawable.speaker_disable);
            }
        }
        */
        if(mSelectedBalloonIndex == position)
        {
            holder.mEventIcon.setImageResource(R.drawable.speaker_enable);
        }
        else
        {
            holder.mEventIcon.setImageResource(R.drawable.speaker_disable);
        }

        holder.mEventIcon.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mSelectedBalloonIndex = position;
                mNodeChangeListener.OnTGNodeChangeListener(AREA_BALLOON, (int)position, true);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return (null != items ? items.size() : 0);
    }

    @Override
    public void onClick(View v) {

    }

    public void setBalloonIndex(final float index)
    {
        this.mSelectedBalloonIndex = index;
    }


    public float getBalloonIndex()
    {
        return mSelectedBalloonIndex;
    }

    public int [] getEventProperty()
    {
        int []tmpBalloonProperties = new int[items.size()];
        for(int i = 0; i < items.size(); i++)
        {
            tmpBalloonProperties[i] = items.get(i).mEventType;
        }
        return tmpBalloonProperties;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public ImageView mEventIcon;

        public CustomViewHolder(View itemView)
        {
            super(itemView);

            mEventIcon = (ImageView)itemView.findViewById(R.id.event_item);
        }
    }
}