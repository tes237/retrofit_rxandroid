package etm.main.market.lists;

import java.io.File;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import etm.main.market.baseDefine;
//import etm.main.market.widgets.CircleDrawable;
import etm.main.market.R;

public class KeywordRecommendationAdapter extends ArrayAdapter implements baseDefine
{
    static class ViewHolder
    {
        TextView title_label;
    }

    private	ArrayList<String>	mStringNameList;
    private	Context mContext;
    protected ListView mListView;
    private KeywordRecommendationListener mKeywordRecommendationListener;

    //private JobManagementListListener listener = null;

    public KeywordRecommendationAdapter(Context context, ListView listObject, ArrayList<String> item_title_array, KeywordRecommendationListener tmpKeywordRecommendationListener)
    {
        super(context, R.layout.list_keyword_recommendation_item, item_title_array);

        this.mContext = context;
        this.mListView = listObject;

        this.mStringNameList = item_title_array;
        this.mKeywordRecommendationListener = tmpKeywordRecommendationListener;
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewHolder tmp_holder;

        View row = null;

        if(convertView == null)
        {
            LayoutInflater inflater = ((Activity)mContext).getLayoutInflater();

            row = (View)inflater.inflate(R.layout.list_keyword_recommendation_item, null);
            //row.setBackgroundResource(R.xml.list_jobseeker_cell_design);

            tmp_holder = new ViewHolder();

            tmp_holder.title_label = (TextView)row.findViewById(R.id.keyword_label_textview);

            String tmpText = mStringNameList.get(position);
            tmp_holder.title_label.setText(tmpText);

            tmp_holder.title_label.setClickable(true);
            tmp_holder.title_label.setOnClickListener(mOnTextViewClickListener);
            tmp_holder.title_label.setTag(Integer.valueOf(position));

            convertView = row;
            convertView.setTag(tmp_holder);
        }
        else
        {
            tmp_holder = (ViewHolder)convertView.getTag();
        }

        tmp_holder.title_label.setText(mStringNameList.get(position));

        return convertView;
    }



    public void setListener(KeywordRecommendationListener newListener)
    {
        mKeywordRecommendationListener = newListener;
    }

    private OnClickListener mOnTextViewClickListener = new OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            TextView tmpTv = (TextView)v;
            Integer position = (Integer)tmpTv.getTag();

            mKeywordRecommendationListener.onKeywordListClickListener(0, v, position, 0);
        }
    };


}
