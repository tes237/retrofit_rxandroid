package etm.main.market.lists;

import android.view.View;

import java.util.ArrayList;

import etm.main.market.graphs.VertexGroup;

public interface SpotOptionListener
{
    void onListClickListener(View v, int index, int fromIndex, VertexGroup vertex, int spotIndex);
}