package etm.main.market.lists;

import android.view.View;

public interface MapInfoListListener
{
    void onListClickListener(View v, int index, int status);
    void onDownloadClickListener(View v, int index, int status);
}