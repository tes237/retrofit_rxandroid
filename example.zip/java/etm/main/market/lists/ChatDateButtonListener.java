package etm.main.market.lists;

import android.view.View;

public interface ChatDateButtonListener
{
    void onDateClickListener(int index, int year, int month, int date);
}