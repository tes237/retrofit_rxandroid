package etm.main.market.lists;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import etm.main.market.activities.RouteListActivity;
import etm.main.market.common.CircleTransformation;
import etm.main.market.vo.ChatMessage;

import etm.main.market.R;
import etm.main.market.widgets.roundedImage.MLRoundedImageView;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

//public class ChatAdapter extends BaseAdapter
//public class ChatAdapter extends BaseAdapter
public class ChatAdapter extends BaseAdapter
{
    private final List<ChatMessage> chatMessages;
    private Activity context;
    private ChatDateButtonListener mChatDateButtonListener;
    private String mProfilePath = "";
    private Bitmap mProfileImage = null;

    public ChatAdapter(Activity context, List<ChatMessage> chatMessages, String profilePath, ChatDateButtonListener listener)
    {
        this.context = context;
        this.chatMessages = chatMessages;
        this.mChatDateButtonListener = listener;
        this.mProfilePath = profilePath;
        if(mProfilePath == null)
        {
            this.mProfileImage = BitmapFactory.decodeResource(context.getResources(), R.drawable.sample_photo);
        }
        else
        {
            this.mProfileImage = BitmapFactory.decodeFile(mProfilePath);
        }
    }

    @Override
    public int getCount()
    {
        if (chatMessages != null)
        {
            return chatMessages.size();
        }
        else
        {
            return 0;
        }
    }

    @Override
    public ChatMessage getItem(int position)
    {
        if (chatMessages != null)
        {
            return chatMessages.get(position);
        } else {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        ViewHolder holder;
        ChatMessage chatMessage = getItem(position);
        LayoutInflater vi = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null)
        {
            convertView = vi.inflate(R.layout.list_item_chat_message, null);
            holder = createViewHolder(convertView);
            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) convertView.getTag();
        }

        if(chatMessage.getType() == ChatMessage.CHAT_MESSAGE_TYPE)
        {
            holder.dateLayout.setVisibility(View.GONE);
            holder.dateButton.setOnClickListener(null);

            if(holder.profileIcon.isEnabled() == true)
            {
                if(mProfilePath == null)
                {
                    holder.profileIcon.setImageBitmap(mProfileImage);
                    //Picasso.with(context).load(R.drawable.sample_photo).transform(new CircleTransformation()).into(holder.profileIcon);
                    //Picasso.get().load(R.drawable.sample_photo).transform(new CircleTransformation()).into(holder.profileIcon);
                }
                else
                {
                    holder.profileIcon.setImageBitmap(mProfileImage);
                    //Picasso.with(context).load(mProfilePath).transform(new CircleTransformation()).into(holder.profileIcon);
                    //Picasso.get().load(mProfilePath).transform(new CircleTransformation()).into(holder.profileIcon);
                }
            }

        }
        else if(chatMessage.getType() == ChatMessage.MORE_DATE_TYPE)
        {
            holder.dateLayout.setVisibility(View.VISIBLE);

            holder.dateButton.setText(String.format("%d/%d/%d", chatMessage.getPrevious_year(), chatMessage.getPrevious_month(), chatMessage.getPrevious_date()));
            holder.dateButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    mChatDateButtonListener.onDateClickListener(position, chatMessage.getPrevious_year(), chatMessage.getPrevious_month(), chatMessage.getPrevious_date());
                }
            });
        }
        //holder.dateButton;

        boolean myMsg = chatMessage.getIsme() ;//Just a dummy check
        //to simulate whether it me or other sender
        setAlignment(holder, myMsg);

        //holder.

        holder.txtMessage.setText(chatMessage.getMessage());
        //holder.txtInfo.setText(chatMessage.getDate());

        String microSecondsStr = chatMessage.getDate();
        if((microSecondsStr != null) && ("".equals(microSecondsStr) == false))
        {
            String splittedArr[] = microSecondsStr.split("\\.");
            if(splittedArr.length == 2)
            {
                long seconds = Long.valueOf(splittedArr[0]);
                long milli_seconds = seconds*1000;
                Date date = new Date(milli_seconds);
                //SimpleDateFormat sdf = new SimpleDateFormat("EEEE,MMMM d,yyyy h:mm,a", Locale.ENGLISH);
                SimpleDateFormat sdf = new SimpleDateFormat("h:mm:ss,a", Locale.ENGLISH);
                //sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
                sdf.setTimeZone(TimeZone.getDefault());
                String formattedDate = sdf.format(date);
                holder.txtInfo.setText(formattedDate);
            }
        }

        return convertView;
    }


    public void clearAll()
    {
        chatMessages.clear();
    }

    public void add(ChatMessage message) {
        chatMessages.add(message);
    }

    public void add(List<ChatMessage> messages) {
        chatMessages.addAll(messages);
    }

    private void setAlignment(ViewHolder holder, boolean isMe)
    {
        if (!isMe)
        {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) holder.contentWithBG.getLayoutParams();
            layoutParams.gravity = Gravity.RIGHT;
            holder.contentWithBG.setLayoutParams(layoutParams);

            RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) holder.content.getLayoutParams();
            lp.addRule(RelativeLayout.ALIGN_PARENT_LEFT, 0);
            lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
            holder.content.setLayoutParams(lp);

            holder.profileIcon.setVisibility(View.GONE);
            holder.profileIcon.setEnabled(false);

            layoutParams = (LinearLayout.LayoutParams) holder.txtMessage.getLayoutParams();
            layoutParams.gravity = Gravity.RIGHT;
            holder.txtMessage.setLayoutParams(layoutParams);
            holder.txtMessage.setBackgroundResource(R.drawable.tgm_message_ballon2);

            layoutParams = (LinearLayout.LayoutParams) holder.txtInfo.getLayoutParams();
            layoutParams.gravity = Gravity.RIGHT;
            holder.txtInfo.setLayoutParams(layoutParams);
        }
        else
        {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) holder.contentWithBG.getLayoutParams();
            layoutParams.gravity = Gravity.LEFT;
            holder.contentWithBG.setLayoutParams(layoutParams);

            RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) holder.content.getLayoutParams();
            lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, 0);
            lp.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
            holder.content.setLayoutParams(lp);

            holder.profileIcon.setVisibility(View.VISIBLE);
            holder.profileIcon.setEnabled(true);

            layoutParams = (LinearLayout.LayoutParams) holder.txtMessage.getLayoutParams();
            layoutParams.gravity = Gravity.LEFT;
            holder.txtMessage.setLayoutParams(layoutParams);
            holder.txtMessage.setBackgroundResource(R.drawable.tgm_message_ballon);

            layoutParams = (LinearLayout.LayoutParams) holder.txtInfo.getLayoutParams();
            layoutParams.gravity = Gravity.LEFT;
            holder.txtInfo.setLayoutParams(layoutParams);
        }
    }

    private ViewHolder createViewHolder(View v)
    {
        ViewHolder holder = new ViewHolder();
        holder.dateLayout = (LinearLayout) v.findViewById(R.id.more_content);
        holder.dateButton = (Button) v.findViewById(R.id.dateInfo);

        //holder.profileIcon = (ImageView) v.findViewById(R.id.iconProfile);
        holder.profileIcon = (MLRoundedImageView) v.findViewById(R.id.iconProfile);
        holder.txtMessage = (TextView) v.findViewById(R.id.txtMessage);
        holder.content = (LinearLayout) v.findViewById(R.id.content);
        holder.contentWithBG = (LinearLayout) v.findViewById(R.id.contentWithBackground);
        holder.txtInfo = (TextView) v.findViewById(R.id.txtInfo);
        return holder;
    }

    private static class ViewHolder
    {
        public LinearLayout dateLayout;
        public Button dateButton;

        //public ImageView profileIcon;
        public MLRoundedImageView profileIcon;
        public TextView txtMessage;
        public TextView txtInfo;
        public LinearLayout content;
        public LinearLayout contentWithBG;
    }
}