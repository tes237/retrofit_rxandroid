package etm.main.market.lists;

import android.view.View;

public interface RatingListListener
{
    void onListClickListener(View v, int index, int status);
}