package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import etm.main.market.R;
import etm.main.market.vo.MapItem;
import etm.main.market.vo.Product;
import etm.main.market.vo.PurchasedItem;

public class HorizontalCardListAdapter extends RecyclerView.Adapter<HorizontalCardListAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    List<String> mNameList;
    List<Integer> mResList;

    public HorizontalCardListAdapter(Context context, List<String> name_items, List<Integer> res_items)
    {
        this.mContext=context;
        this.mNameList = name_items;
        this.mResList = res_items;
    }

    @Override
    public HorizontalCardListAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.themed_type_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(HorizontalCardListAdapter.CustomViewHolder holder, final int position)
    {
        final String itemName = mNameList.get(position);
        final int itemRes = mResList.get(position);

        //Picasso.with(mContext).load(itemRes).placeholder(R.drawable.sample_photo).resize(100, 100).into(holder.mImage);
        //Picasso.with(mContext).load(itemRes).placeholder(R.drawable.sample_photo).into(holder.mImage);
        Picasso.get().load(itemRes).placeholder(R.drawable.sample_photo).into(holder.mImage);

        holder.mTitle.setText(itemName);
    }

    @Override
    public int getItemCount()
    {
        return (null != mNameList ? mNameList.size() : 0);
    }

    @Override
    public void onClick(View v)
    {
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public ImageView mImage;
        public TextView mTitle;
        public CardView mCardView;

        public CustomViewHolder(View itemView)
        {
            super(itemView);
            mImage = (ImageView)itemView.findViewById(R.id.themed_image);
            mTitle = (TextView)itemView.findViewById(R.id.themed_title);
            mCardView = (CardView)itemView.findViewById(R.id.cardview);
        }
    }
}