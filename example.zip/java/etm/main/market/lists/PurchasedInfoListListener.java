package etm.main.market.lists;

import android.view.View;

public interface PurchasedInfoListListener
{
    void onListClickListener(View v, int index, int status);
    void onDownloadClickListener(View v, int index, int status);
    void onReviewClickListener(View v, int index, int status);
}