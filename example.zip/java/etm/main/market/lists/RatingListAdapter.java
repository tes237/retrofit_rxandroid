package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import etm.main.market.R;
import etm.main.market.connects.WebManager;
import etm.main.market.vo.MessageListData;
import etm.main.market.vo.Review;
import etm.main.market.widgets.ratingbar.ColoredRatingBar;
import etm.main.market.widgets.roundedImage.MLRoundedImageView;


import java.io.File;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import etm.main.market.baseDefine;
import etm.main.market.R;

public class RatingListAdapter extends ArrayAdapter implements baseDefine
{
    Context mContext;
    ArrayList<Review> items;
    RatingListListener mRatingListListener;
    WebManager mTGMWebManager;

    static class CustomViewHolder
    {

        public MLRoundedImageView mImage;
        public TextView mUserName;
        public TextView mTitle;;
        public TextView mMessage;
        public TextView mDate;
        public LinearLayout mWrappingView;
        public ColoredRatingBar mRating1;
        public LinearLayout mWholeLayout;

    }

    //private JobManagementListListener listener = null;

    public RatingListAdapter(Context context, ArrayList<Review> items, RatingListListener tmpRatingListListener, WebManager tmpManager)
    {
        super(context, R.layout.rating_list_item, items);

        this.mContext=context;
        this.items=items;
        this.mRatingListListener = tmpRatingListListener;
        this.mTGMWebManager = tmpManager;
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        RatingListAdapter.CustomViewHolder tmp_holder;

        View row = null;

        final Review item = items.get(position);

        if(convertView == null)
        {
            LayoutInflater inflater = ((Activity)mContext).getLayoutInflater();

            row = (View)inflater.inflate(R.layout.rating_list_item, null);
            //row.setBackgroundResource(R.xml.list_jobseeker_cell_design);

            tmp_holder = new RatingListAdapter.CustomViewHolder();

            tmp_holder.mWholeLayout = (LinearLayout) row.findViewById(R.id.rating_whole_layout);
            tmp_holder.mWrappingView = (LinearLayout) row.findViewById(R.id.wrapping_layout);
            tmp_holder.mImage = (MLRoundedImageView)row.findViewById(R.id.photo_image);
            tmp_holder.mUserName = (TextView)row.findViewById(R.id.user_name);
            tmp_holder.mTitle = (TextView)row.findViewById(R.id.rating_title);
            tmp_holder.mMessage = (TextView)row.findViewById(R.id.rating_message);
            tmp_holder.mDate = (TextView)row.findViewById(R.id.rating_date);

            tmp_holder.mRating1 = (ColoredRatingBar)row.findViewById(R.id.user_rating1);

            convertView = row;
            convertView.setTag(tmp_holder);
        }
        else
        {
            tmp_holder = (RatingListAdapter.CustomViewHolder)convertView.getTag();
        }

        //holder.image.setBackground(drawable);
        tmp_holder.mUserName.setText(item.getNickname());
        tmp_holder.mTitle.setText(item.getTitle());
        tmp_holder.mMessage.setText(item.getDetail());

        String dateStr = item.getCreatedAt();
        if(dateStr != null && "".equals(dateStr) == false)
        {
            String[] dataArr = dateStr.split(" ");
            tmp_holder.mDate.setText(dataArr[0]);
        }
        tmp_holder.mRating1.setIndicator(true);
        tmp_holder.mRating1.setRating(Float.valueOf(item.getRating1()));
        tmp_holder.mRating1.invalidate();

        String tmpUrl = item.getProfileUrl();

        mTGMWebManager.picasso_load_simple(tmpUrl, null, tmp_holder.mImage);

        tmp_holder.mWrappingView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mRatingListListener.onListClickListener(v, position, 0);
            }
        });

        //holder.mWholeLayout.requestLayout();

        return convertView;
    }


}


/*
public class RatingListAdapter extends RecyclerView.Adapter<RatingListAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    ArrayList<Review> items;
    RatingListListener mRatingListListener;

    public RatingListAdapter(Context context, ArrayList<Review> items, RatingListListener tmpRatingListListener)
    {
        this.mContext=context;
        this.items=items;
        this.mRatingListListener = tmpRatingListListener;
    }

    @Override
    public RatingListAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.rating_list_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(RatingListAdapter.CustomViewHolder holder, final int position)
    {
        final Review item = items.get(position);
        //Drawable drawable=context.getResources().getDrawable(item.getImagePath());

        //Picasso.with(mContext).load(item.getImagePath()).placeholder(R.drawable.sample_photo).resize(400, 100).into(holder.mImage);
        //Picasso.with(mContext).load(R.drawable.sample_photo).resize(400, 100).into(holder.mImage);

        //holder.image.setBackground(drawable);
        holder.mUserName.setText(item.getNickname());
        holder.mTitle.setText(item.getTitle());
        holder.mMessage.setText(item.getDetail());

        String dateStr = item.getCreatedAt();
        if(dateStr != null && "".equals(dateStr) == false)
        {
            String[] dataArr = dateStr.split(" ");
            holder.mDate.setText(dataArr[0]);
        }
        holder.mRating1.setIndicator(true);
        holder.mRating1.setRating(Float.valueOf(item.getRating1()));
        holder.mRating1.invalidate();

        //holder.mRating2.setIndicator(true);
        //holder.mRating2.setRating(Float.valueOf(item.getRating2()));
        //holder.mRating2.invalidate();
        //holder.mRating3.setRating(item.getRating3());

        holder.mWrappingView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mRatingListListener.onListClickListener(v, position, 0);
            }
        });
        holder.mWholeLayout.requestLayout();
    }

    @Override
    public int getItemCount()
    {
        return (null != items ? items.size() : 0);
    }

    @Override
    public void onClick(View v) {

    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public MLRoundedImageView mImage;
        public TextView mUserName;
        public TextView mTitle;;
        public TextView mMessage;
        public TextView mDate;
        public LinearLayout mWrappingView;
        public ColoredRatingBar mRating1;
        public LinearLayout mWholeLayout;
        //public ColoredRatingBar mRating2;
        //public ColoredRatingBar mRating3;

        public CustomViewHolder(View itemView)
        {
            super(itemView);

            mWholeLayout = (LinearLayout) itemView.findViewById(R.id.rating_whole_layout);
            mWrappingView = (LinearLayout) itemView.findViewById(R.id.wrapping_layout);
            mImage = (MLRoundedImageView)itemView.findViewById(R.id.photo_image);
            mUserName = (TextView)itemView.findViewById(R.id.user_name);
            mTitle = (TextView)itemView.findViewById(R.id.rating_title);
            mMessage = (TextView)itemView.findViewById(R.id.rating_message);
            mDate = (TextView)itemView.findViewById(R.id.rating_date);

            mRating1 = (ColoredRatingBar)itemView.findViewById(R.id.user_rating1);
            //mRating2 = (ColoredRatingBar)itemView.findViewById(R.id.user_rating2);
            //mRating3 = (ColoredRatingBar)itemView.findViewById(R.id.user_rating3);
        }

    }
}
*/