package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;

import etm.main.market.R;
import etm.main.market.activities.PlayerActivity;
import etm.main.market.common.CircleTransformation;
import etm.main.market.common.GrayscaleTransformation;
import etm.main.market.vo.FriendItem;
import etm.main.market.vo.MessageListData;
import etm.main.market.widgets.roundedImage.MLRoundedImageView;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class SpotListAdapter extends RecyclerView.Adapter<SpotListAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    List<PlayerActivity.SpotGUI> items;
    NodeChangeListener mTGNodeChangeListener;

    public static final int AREA_NO = 0;
    public static final int AREA_IMAGE_GALLERY = 1;
    public static final int AREA_BALLOON = 2;

    public static final int NODE_OPTIONAL = 999;
    public static final int NODE_SINGLE = 1;
    public static final int NODE_MULTI = 2;
    public static final int NODE_INTRO = 3;

    private float mSelectedImageGalleryIndex = 0;

    public SpotListAdapter(Context context, List<PlayerActivity.SpotGUI> items, NodeChangeListener tmpTGNodeChangeListener)
    {
        this.mContext=context;
        this.items=items;
        this.mTGNodeChangeListener = tmpTGNodeChangeListener;

    }

    @Override
    public SpotListAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.spot_list_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(SpotListAdapter.CustomViewHolder holder, final int position)
    {
        final PlayerActivity.SpotGUI item = items.get(position);

        if(mSelectedImageGalleryIndex == position)
        {
            holder.mHighlight.setVisibility(View.VISIBLE);
            holder.mBlackFilter.setVisibility(View.INVISIBLE);
            holder.mTitle.setTextColor(0xffffffff);
        }
        else
        {
            holder.mHighlight.setVisibility(View.INVISIBLE);
            holder.mBlackFilter.setVisibility(View.VISIBLE);
            holder.mTitle.setTextColor(0x70ffffff);
        }

        if( items.get(position).mSpotType ==  NODE_INTRO)
        {
            if(mSelectedImageGalleryIndex == position)
            {
                //Picasso.with(mContext).load(R.drawable.intro).transform(new CircleTransformation()).into(holder.mImage);
                //Picasso.get().load(R.drawable.intro).transform(new CircleTransformation()).into(holder.mImage);

                Bitmap tmpImage = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.intro);
                holder.mImage.setImageBitmap(tmpImage);
            }
            else
            {
                //Picasso.with(mContext).load(R.drawable.intro).transform(new CircleTransformation()).transform(new GrayscaleTransformation()).into(holder.mImage);
                //Picasso.with(mContext).load(R.drawable.intro).transform(new CircleTransformation()).into(holder.mImage);
                //Picasso.get().load(R.drawable.intro).transform(new CircleTransformation()).into(holder.mImage);

                Bitmap tmpImage = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.intro);
                holder.mImage.setImageBitmap(tmpImage);
            }
        }
        else if(items.get(position).mSpotType ==  NODE_SINGLE)
        {
            if(mSelectedImageGalleryIndex == position)
            {
                //Picasso.with(mContext).load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).into(holder.mImage);
                //Picasso.get().load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).into(holder.mImage);

                /*
                Picasso.get().load("file://" + item.mSpotImagePath).into(holder.mImage, new Callback() {
                    @Override
                    public void onSuccess()
                    {
                        Log.d("TAG", "onSuccess");
                    }

                    @Override
                    public void onError(Exception e)
                    {
                        Log.d("TAG", "onError");
                    }
                });
                */
                Bitmap tmpImage = BitmapFactory.decodeFile(item.mSpotImagePath);
                holder.mImage.setImageBitmap(tmpImage);
            }
            else
            {
                //Picasso.with(mContext).load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).transform(new GrayscaleTransformation()).into(holder.mImage);
                //Picasso.with(mContext).load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).into(holder.mImage);
                //Picasso.get().load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).into(holder.mImage);
                /*
                Picasso.get().load("file://" + item.mSpotImagePath).into(holder.mImage, new Callback() {
                    @Override
                    public void onSuccess()
                    {
                        Log.d("TAG", "onSuccess");
                    }

                    @Override
                    public void onError(Exception e)
                    {
                        Log.d("TAG", "onError");
                    }
                });
                */
                Bitmap tmpImage = BitmapFactory.decodeFile(item.mSpotImagePath);
                holder.mImage.setImageBitmap(tmpImage);
            }
        }
        else if(items.get(position).mSpotType ==  NODE_MULTI)
        {
            if(mSelectedImageGalleryIndex == position)
            {
                //Picasso.with(mContext).load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).into(holder.mImage);
                //Picasso.get().load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).into(holder.mImage);

                Bitmap tmpImage = BitmapFactory.decodeFile(item.mSpotImagePath);
                holder.mImage.setImageBitmap(tmpImage);
            }
            else
            {
                //Picasso.with(mContext).load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).transform(new GrayscaleTransformation()).into(holder.mImage);
                //Picasso.with(mContext).load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).into(holder.mImage);
                //Picasso.get().load("file://" + item.mSpotImagePath).transform(new CircleTransformation()).into(holder.mImage);

                Bitmap tmpImage = BitmapFactory.decodeFile(item.mSpotImagePath);
                holder.mImage.setImageBitmap(tmpImage);
            }
        }
        else if(items.get(position).mSpotType ==  NODE_OPTIONAL)
        {
            if(mSelectedImageGalleryIndex == position)
            {
                //Picasso.with(mContext).load(R.drawable.big_crossroads).transform(new CircleTransformation()).into(holder.mImage);
                Picasso.get().load(R.drawable.big_crossroads).transform(new CircleTransformation()).into(holder.mImage);
            }
            else
            {
                //Picasso.with(mContext).load(R.drawable.big_crossroads).transform(new CircleTransformation()).into(holder.mImage);
                Picasso.get().load(R.drawable.big_crossroads).transform(new CircleTransformation()).into(holder.mImage);
            }
        }

        holder.mTitle.setText(item.mSpotTitle);

        holder.mImage.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mSelectedImageGalleryIndex = position;
                mTGNodeChangeListener.OnTGNodeChangeListener(AREA_IMAGE_GALLERY, (int)position, true);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return (null != items ? items.size() : 0);
    }

    @Override
    public void onClick(View v)
    {
    }

    public float getImageGalleryIndex()
    {
        return this.mSelectedImageGalleryIndex;
    }

    public void setImageGalleryIndex(final float index)
    {
        this.mSelectedImageGalleryIndex = index;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public MLRoundedImageView mImage;
        public TextView mTitle;
        public ImageView mHighlight;
        public LinearLayout mBlackFilter;

        public CustomViewHolder(View itemView)
        {
            super(itemView);

            mImage = (MLRoundedImageView)itemView.findViewById(R.id.spot_image);
            mTitle = (TextView)itemView.findViewById(R.id.spot_title);
            mHighlight = (ImageView)itemView.findViewById(R.id.spot_highlight);
            mBlackFilter = (LinearLayout)itemView.findViewById(R.id.black_filter);
        }
    }
}