package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.List;

import etm.main.market.R;
import etm.main.market.vo.Product;
import etm.main.market.widgets.ratingbar.ColoredRatingBar;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class InfoAdapter extends RecyclerView.Adapter<InfoAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    List<Product> items;
    InfoListListener mInfoListListener;

    public InfoAdapter(Context context, List<Product> items, InfoListListener tmpInfoListListener)
    {
        this.mContext=context;
        this.items=items;
        this.mInfoListListener = tmpInfoListListener;
    }

    @Override
    public InfoAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.tour_guide_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(InfoAdapter.CustomViewHolder holder, final int position)
    {
        final Product item = items.get(position);
        //Drawable drawable=context.getResources().getDrawable(item.getImagePath());

        //Picasso.with(mContext).load(item.getImage1()).placeholder(R.drawable.sample_photo).resize(400, 100).into(holder.mImage);
        Picasso.get().load(item.getImage1()).placeholder(R.drawable.sample_photo).resize(400, 100).into(holder.mImage);

        //holder.image.setBackground(drawable);
        holder.mTitle.setText(item.getName());

        if(item.getRating1() == 0)
        {
            holder.mRating1.setVisibility(View.INVISIBLE);
            //holder.mRatingTextView1.setVisibility(View.INVISIBLE);
        }
        else
        {
            holder.mRating1.setNumStars(5);
            holder.mRating1.setRating(item.getRating1());
        }
        /*
        if(item.getRating2() == 0)
        {
            holder.mRating2.setVisibility(View.INVISIBLE);
            holder.mRatingTextView2.setVisibility(View.INVISIBLE);
        }
        else
        {
            holder.mRating2.setNumStars(5);
            holder.mRating2.setRating(item.getRating2());
        }
        */

        holder.mRating1.setIndicator(true);
        //holder.mRating2.setIndicator(true);

        holder.mSpaceView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mInfoListListener.onListClickListener(v, position, 0);
            }
        });
        //DecimalFormat df2 = new DecimalFormat(".##");
        float tmpPrice =  Float.valueOf(item.getPrice());
        //String tmpReducedPrice = df2.format(tmpPrice);
        String tmpReducedPrice = String.format("%.2f", tmpPrice);

        holder.mPrice.setText("$" + tmpReducedPrice);

        /*
        holder.cardview.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(mContext,item.getTitle(), Toast.LENGTH_SHORT).show();
            }
        });
        */
    }

    @Override
    public int getItemCount()
    {
        return (null != items ? items.size() : 0);
    }

    @Override
    public void onClick(View v) {

    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public ImageView mImage;
        public TextView mTitle;
        public ScalableLayout mSpaceView;
        public ColoredRatingBar mRating1;
        public TextView mPrice;
        //public ColoredRatingBar mRating2;
        //public TextView mRatingTextView1;
        //public TextView mRatingTextView2;

        public CustomViewHolder(View itemView)
        {
            super(itemView);
            mImage = (ImageView)itemView.findViewById(R.id.image);
            mTitle = (TextView)itemView.findViewById(R.id.title);
            mSpaceView = (ScalableLayout)itemView.findViewById(R.id.list_item_whole_layout);
            mRating1 = (ColoredRatingBar)itemView.findViewById(R.id.ratingbar1);
            mPrice = (TextView)itemView.findViewById(R.id.product_price);
            //mRating2 = (ColoredRatingBar)itemView.findViewById(R.id.ratingbar2);
            //mRatingTextView1 = (TextView)itemView.findViewById(R.id.rating_comment_stat1);
            //mRatingTextView2 = (TextView)itemView.findViewById(R.id.rating_comment_stat2);
        }

    }
}