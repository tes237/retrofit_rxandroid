package etm.main.market.lists;

import android.view.View;

public interface KeywordRecommendationListener
{
    void onKeywordListClickListener(int listType, View v, int index, int status);
}