package etm.main.market.lists;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import etm.main.market.R;
import etm.main.market.common.CircleTransformation;
import etm.main.market.connects.WebManager;
import etm.main.market.vo.FriendItem;
import etm.main.market.vo.MessageListData;
import etm.main.market.widgets.roundedImage.MLRoundedImageView;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class FriendListAdapter extends RecyclerView.Adapter<FriendListAdapter.CustomViewHolder> implements View.OnClickListener
{
    Context mContext;
    List<FriendItem> items;
    FriendListListener mFriendListListener;
    WebManager mTGMWebManager;

    public FriendListAdapter(Context context, List<FriendItem> items, FriendListListener tmpFriendListListener, WebManager tmpWeb)
    {
        this.mContext=context;
        this.items=items;
        this.mFriendListListener = tmpFriendListListener;
        this.mTGMWebManager = tmpWeb;
    }

    @Override
    public FriendListAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.message_list_item, null);
        CustomViewHolder viewHolder = new CustomViewHolder(v);

        return viewHolder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(FriendListAdapter.CustomViewHolder holder, final int position)
    {
        final FriendItem item = items.get(position);
        //Drawable drawable=context.getResources().getDrawable(item.getImagePath());

        /*
        String photoUrl = item.getUserPhotoUrl();
        if(photoUrl != null)
        {
            //Picasso.with(mContext).load(item.getUserPhotoUrl()).transform(new CircleTransformation()).into(holder.mImage);
            //Picasso.get().load(photoUrl).transform(new CircleTransformation()).into(holder.mImage);

            mTGMWebManager.picasso_load_circle(photoUrl, null, holder.mImage);
        }
        else
        {
            //Picasso.with(mContext).load(R.drawable.sample_photo).transform(new CircleTransformation()).into(holder.mImage);
            Picasso.get().load(R.drawable.sample_photo).transform(new CircleTransformation()).into(holder.mImage);
        }
        */
        Picasso.get().load(R.drawable.sample_photo).transform(new CircleTransformation()).into(holder.mImage);

        //holder.image.setBackground(drawable);
        holder.mUserName.setText(item.getUserName());
        //holder.mMessage.setText(item.getLastMessage());
        //holder.mDate.setText(item.getServerReceiveTime());

        if(item.itNeedNewAlarm() == true)
        {
            holder.mAlarm.setVisibility(View.VISIBLE);
        }
        else
        {
            holder.mAlarm.setVisibility(View.INVISIBLE);
        }

        holder.mMessageView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mFriendListListener.onListClickListener(v, position, 0);
            }
        });

        /*
        holder.cardview.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(mContext,item.getTitle(), Toast.LENGTH_SHORT).show();
            }
        });
        */
    }

    @Override
    public int getItemCount()
    {
        return (null != items ? items.size() : 0);
    }

    @Override
    public void onClick(View v) {

    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public MLRoundedImageView mImage;
        public TextView mUserName;
        //public TextView mMessage;
        public TextView mDate;
        public ScalableLayout mMessageView;
        public ImageView mAlarm;

        public CustomViewHolder(View itemView)
        {
            super(itemView);

            mMessageView = (ScalableLayout)itemView.findViewById(R.id.message_list_message_view);
            mImage = (MLRoundedImageView)itemView.findViewById(R.id.photo_image);
            mUserName = (TextView)itemView.findViewById(R.id.user_name);
            //mMessage = (TextView)itemView.findViewById(R.id.last_message);
            mDate = (TextView)itemView.findViewById(R.id.message_date);
            mAlarm = (ImageView)itemView.findViewById(R.id.new_message_alarm);
        }

    }
}