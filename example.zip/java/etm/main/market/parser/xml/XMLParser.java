package etm.main.market.parser.xml;

import android.util.Log;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;


import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import etm.main.market.vo.ServerMapData;
import etm.main.market.vo.ServerMapEventData;
import etm.main.market.vo.ServerMapLineData;
import etm.main.market.vo.ServerMapPreData;
import etm.main.market.vo.ServerMapResourceData;
import etm.main.market.vo.ServerMapRouteData;
import etm.main.market.vo.ServerMapSpotData;
import etm.main.market.vo.ServerMapTextData;

public class XMLParser
{
    private static final String TAG = XMLParser.class.getSimpleName();
    /*
    public static class Entry
    {
        public final String title;
        public final String link;
        public final String summary;

        private Entry(String title, String summary, String link)
        {
            this.title = title;
            this.summary = summary;
            this.link = link;
        }
    }
    */

    // We don't use namespaces
    private static final String ns = null;

    public ServerMapData parse(InputStream in) throws XmlPullParserException, IOException
    {
        try
        {
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(in, null);
            parser.nextTag();
            return readMap(parser);
        }
        finally
        {
            in.close();
            in = null;
        }
    }

    /*
    public ServerMapData parse(StringReader in) throws XmlPullParserException, IOException
    {
        try
        {
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(in);
            parser.nextTag();

            return readMap(parser);
        }
        finally
        {
            in.close();
            in = null;
        }
    }
    */


    private ServerMapData readMap(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "main");

        ServerMapData tmpMap = new ServerMapData();

        while (parser.next() != XmlPullParser.END_TAG)
        {
            if (parser.getEventType() != XmlPullParser.START_TAG)
            {
                continue;
            }

            String name = parser.getName();
            String value = "";

            // Starts by looking for the entry tag
            if (name.equals("pre"))
            {
                tmpMap.addPre(readPre(parser));
            }
            else if (name.equals("route"))
            {
                tmpMap.addRoute(readRoute(parser));
            }
            else if (name.equals("resource"))
            {
                tmpMap.addResource(readResource(parser));
            }
            else if (name.equals("time"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "time");

                value = readString(parser);

                parser.require(XmlPullParser.END_TAG, ns, "time");

                tmpMap.setTime(value);
            }
            /*
            else if (name.equals("route_count"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "route_count");

                value = readString(parser);

                parser.require(XmlPullParser.END_TAG, ns, "route_count");

                tmpMap.setRouteCount(value);
            }
            */
            else
            {
                skip(parser);
            }
        }
        return tmpMap;
    }

    // Parses the contents of an entry. If it encounters a title, summary, or link tag, hands them off
// to their respective "read" methods for processing. Otherwise, skips the tag.
    /*
    private ServerMapData readEntry(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "entry");
        String title = null;
        String summary = null;
        String link = null;

        while (parser.next() != XmlPullParser.END_TAG)
        {
            if (parser.getEventType() != XmlPullParser.START_TAG)
            {
                continue;
            }

            String name = parser.getName();
            if (name.equals("title"))
            {
                title = readTitle(parser);
            }
            else if (name.equals("summary"))
            {
                summary = readSummary(parser);
            }
            else if (name.equals("link"))
            {
                link = readLink(parser);
            }
            else
            {
                skip(parser);
            }
        }
        return new ServerMapData(title, summary, link);
    }
    */

    private ServerMapPreData readPre(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "pre");
        ServerMapPreData tmpPre = new ServerMapPreData();

        while (parser.next() != XmlPullParser.END_TAG)
        {
            if (parser.getEventType() != XmlPullParser.START_TAG)
            {
                continue;
            }

            String name = parser.getName();
            if (name.equals("title"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "title");
                String title = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "title");
                tmpPre.setTitle(title);
            }
            else if (name.equals("type"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "type");
                String type = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "type");
                tmpPre.setType(type);
            }
            else if (name.equals("text"))
            {
                //parser.require(XmlPullParser.START_TAG, ns, "text");
                //ServerMapTextData text = readText(parser);
                tmpPre.setText(readText(parser));
                //parser.require(XmlPullParser.END_TAG, ns, "text");
            }
            /*
            else if (name.equals("picture"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "picture");
                String picture = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "picture");
                tmpPre.setPicture(picture);
            }
            else if (name.equals("audio"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "audio");
                String audio = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "audio");
                tmpPre.setAudio(audio);
            }
            else if (name.equals("sync_info"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "sync_info");
                String sync_info = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "sync_info");
                tmpPre.setSyncInfo(sync_info);
            }
            */
            else
            {
                skip(parser);
            }
        }

        return tmpPre;
    }

    private ServerMapRouteData readRoute(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "route");
        ServerMapRouteData tmpRoute = new ServerMapRouteData();

        while (parser.next() != XmlPullParser.END_TAG)
        {
            if (parser.getEventType() != XmlPullParser.START_TAG)
            {
                continue;
            }

            String name = parser.getName();
            if (name.equals("time"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "time");
                String time = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "time");
                tmpRoute.setTime(time);
            }
            /*
            else if (name.equals("spots_count"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "spots_count");
                String spots_count = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "spots_count");
                tmpRoute.setSpotsCount(spots_count);
            }
            */
            else if (name.equals("spot"))
            {
                //parser.require(XmlPullParser.START_TAG, ns, "spot");
                tmpRoute.addSpot(readSpot(parser));
                //parser.require(XmlPullParser.END_TAG, ns, "spot");
            }
            else
            {
                skip(parser);
            }
        }

        return tmpRoute;
    }

    private ServerMapResourceData readResource(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "resource");
        ServerMapResourceData tmpResource = new ServerMapResourceData();

        while (parser.next() != XmlPullParser.END_TAG)
        {
            if (parser.getEventType() != XmlPullParser.START_TAG)
            {
                continue;
            }

            String name = parser.getName();
            if (name.equals("audio"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "audio");
                String id = parser.getAttributeValue(null, "id");
                String path = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "audio");

                tmpResource.addAudio(id, path);
            }
            else if (name.equals("image"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "image");
                String id = parser.getAttributeValue(null, "id");
                String path = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "image");

                tmpResource.addImage(id, path);
            }
            else if (name.equals("rectangle"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "rectangle");
                String id = parser.getAttributeValue(null, "id");
                String path = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "rectangle");

                tmpResource.addRectangle(id, path);
            }
            else if (name.equals("video"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "video");
                String id = parser.getAttributeValue(null, "id");
                String path = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "video");

                tmpResource.addVideo(id, path);
            }
            else
            {
                skip(parser);
            }
        }

        return tmpResource;
    }

    private ServerMapSpotData readSpot(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "spot");
        ServerMapSpotData tmpSpot = new ServerMapSpotData();

        //String image_id = parser.getAttributeValue(null, "image");
        //String rectangle_id = parser.getAttributeValue(null, "rectangle");

        //tmpSpot.setImageId(image_id);
        //tmpSpot.setRectangleId(rectangle_id);

        String image_data = parser.getAttributeValue(null, "image_data");
        tmpSpot.setImageData(image_data);

        while (parser.next() != XmlPullParser.END_TAG)
        {
            if (parser.getEventType() != XmlPullParser.START_TAG)
            {
                continue;
            }

            String name = parser.getName();
            if (name.equals("index"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "index");
                String index = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "index");
                tmpSpot.setIndex(index);
            }
            else if (name.equals("title"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "title");
                String title = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "title");
                tmpSpot.setTitle(title);
            }
            else if (name.equals("type"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "type");
                String type = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "type");
                tmpSpot.setType(type);
            }
            else if (name.equals("category"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "category");
                String category = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "category");
                tmpSpot.setCategory(category);
            }
            else if (name.equals("next"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "next");
                String next = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "next");

                if(next != null)
                {
                    if(next.equals("") == false)
                    {
                        String nextNumString[] = next.split(",");
                        int nextNumInt[] = new int[nextNumString.length];
                        for (int x = 0; x < nextNumString.length; x++) {
                            nextNumInt[x] = Integer.valueOf(nextNumString[x]);
                        }
                        tmpSpot.setNexts(nextNumInt);
                    }
                }
            }
            else if (name.equals("prev"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "prev");
                String prev = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "prev");
                if(prev != null)
                {
                    if(prev.equals("") == false)
                    {
                        String prevNumString[] = prev.split(",");
                        int prevNumInt[] = new int[prevNumString.length];
                        for (int x = 0; x < prevNumString.length; x++) {
                            prevNumInt[x] = Integer.valueOf(prevNumString[x]);
                        }
                        tmpSpot.setPrevs(prevNumInt);
                    }
                }
            }
            /*
            if (name.equals("next_recommended"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "next_recommended");
                String next_recommended = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "next_recommended");
                tmpSpot.setNextRecommended(next_recommended);
            }
            */
            /*
            else if (name.equals("events_count"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "events_count");
                String events_count = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "events_count");
                tmpSpot.setEventsCount(events_count);
            }
            */
            else if (name.equals("maker"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "maker");
                String maker = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "maker");
                tmpSpot.setMaker(maker);
            }
            /*
            else if (name.equals("loc"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "loc");
                String loc = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "loc");

                if ((loc != null) && (loc.length() > 1))
                {
                    //tmpSpot.setLoc(loc);
                    String locInfo[] = loc.split(" ");
                    tmpSpot.setLat(locInfo[0]);
                    tmpSpot.setLng(locInfo[1]);
                }
            }
            */
            else if (name.equals("area"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "area");
                String area = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "area");
                tmpSpot.setArea(area);
            }
            /*
            else if (name.equals("recommended"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "recommended");
                String recommended = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "recommended");
                tmpSpot.setRecommended(recommended);
            }
            */
            else if (name.equals("event"))
            {
                //parser.require(XmlPullParser.START_TAG, ns, "event");
                tmpSpot.addEvent(readEvent(parser));
                //parser.require(XmlPullParser.END_TAG, ns, "event");
            }
            else
            {
                skip(parser);
            }
        }

        return tmpSpot;
    }

    private ServerMapEventData readEvent(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "event");
        ServerMapEventData tmpEvent = new ServerMapEventData();

        //String image_id = parser.getAttributeValue(null, "image");
        //String rectangle_id = parser.getAttributeValue(null, "rectangle");

        //tmpEvent.setImageId(image_id);
        //tmpEvent.setRectangleId(rectangle_id);

        String image_data = parser.getAttributeValue(null, "image_data");
        tmpEvent.setImageData(image_data);

        while (parser.next() != XmlPullParser.END_TAG)
        {
            if (parser.getEventType() != XmlPullParser.START_TAG)
            {
                continue;
            }

            String name = parser.getName();
            if (name.equals("index"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "index");
                String index = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "index");
                tmpEvent.setIndex(index);
            }
            else if (name.equals("title"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "title");
                String title = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "title");
                tmpEvent.setTitle(title);
            }
            else if (name.equals("loc"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "loc");
                String loc = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "loc");

                if ((loc != null) && (loc.length() > 1))
                {
                    //tmpSpot.setLoc(loc);
                    String locInfo[] = loc.split(" ");
                    tmpEvent.setLat(locInfo[0]);
                    tmpEvent.setLng(locInfo[1]);
                }
            }
            else if (name.equals("type"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "type");
                String type = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "type");
                tmpEvent.setType(type);
            }
            else if (name.equals("category"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "category");
                String category = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "category");
                tmpEvent.setCategory(category);
            }
            else if (name.equals("next"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "next");
                String next = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "next");
                if(next != null)
                {
                    if(next.equals("") == false)
                    {
                        String nextNumString[] = next.split(",");
                        int nextNumInt[] = new int[nextNumString.length];
                        for (int x = 0; x < nextNumString.length; x++) {
                            nextNumInt[x] = Integer.valueOf(nextNumString[x]);
                        }
                        tmpEvent.setNexts(nextNumInt);
                    }
                }
            }
            else if (name.equals("prev"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "prev");
                String prev = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "prev");
                if(prev != null)
                {
                    if(prev.equals("") == false)
                    {
                        String prevNumString[] = prev.split(",");
                        int prevNumInt[] = new int[prevNumString.length];
                        for (int x = 0; x < prevNumString.length; x++) {
                            prevNumInt[x] = Integer.valueOf(prevNumString[x]);
                        }
                        tmpEvent.setNexts(prevNumInt);
                    }
                }
            }
            else if (name.equals("time"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "time");
                String time = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "time");
                tmpEvent.setTime(time);
            }
            else if (name.equals("text"))
            {
                //parser.require(XmlPullParser.START_TAG, ns, "text");
                ServerMapTextData text = readText(parser);
                //parser.require(XmlPullParser.END_TAG, ns, "text");
                tmpEvent.setText(text);
                //tmpEvent.setText(readText(parser));
            }
            else if (name.equals("location_detection"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "location_detection");
                String location_detection = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "location_detection");
                tmpEvent.setLocationDetection(location_detection);
            }
            /*
            else if (name.equals("picture"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "picture");
                String picture = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "picture");
                tmpEvent.setPicture(picture);
            }
            else if (name.equals("audio"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "audio");
                String audio = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "audio");
                tmpEvent.setAudio(audio);
            }
            else if (name.equals("sync_info"))
            {
                parser.require(XmlPullParser.START_TAG, ns, "sync_info");
                String sync_info = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "sync_info");
                tmpEvent.setSyncInfo(sync_info);
            }
            */
            else
            {
                skip(parser);
            }
        }

        return tmpEvent;
    }

    private ServerMapTextData readText(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "text");
        ServerMapTextData tmpText = new ServerMapTextData();

        while (parser.next() != XmlPullParser.END_TAG)
        {
            if (parser.getEventType() != XmlPullParser.START_TAG)
            {
                continue;
            }

            String name = parser.getName();
            if (name.equals("line"))
            {
                ServerMapLineData lineData = readLine(parser);
                tmpText.addLine(lineData);
                /*
                parser.require(XmlPullParser.START_TAG, ns, "line");

                String image_id = parser.getAttributeValue(null, "image");

                tmpEvent.setImage(image_path);

                String line = readString(parser);
                parser.require(XmlPullParser.END_TAG, ns, "line");
                tmpText.addLine(line);

                Log.d(TAG, line);
                */
            }
            else
            {
                skip(parser);
            }
        }

        return tmpText;
    }

    private ServerMapLineData readLine(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        parser.require(XmlPullParser.START_TAG, ns, "line");
        ServerMapLineData tmpLine = new ServerMapLineData();

        String audio_id = parser.getAttributeValue(null, "audio");
        String video_id = parser.getAttributeValue(null, "video");

        //String image_id = parser.getAttributeValue(null, "image");
        //String rectangle_id = parser.getAttributeValue(null, "rectangle");
        //tmpLine.setImageId(image_id);
        //tmpLine.setRectangleId(rectangle_id);

        String image_data = parser.getAttributeValue(null, "image_data");
        tmpLine.setImageData(image_data);

        tmpLine.setAudioId(audio_id);
        tmpLine.setVideoId(video_id);

        String line = readString(parser);
        parser.require(XmlPullParser.END_TAG, ns, "line");
        tmpLine.setLineText(line);

        return tmpLine;
    }

    // For the tags title and summary, extracts their text values.
    private String readString(XmlPullParser parser) throws IOException, XmlPullParserException
    {
        String result = "";
        if (parser.next() == XmlPullParser.TEXT)
        {
            result = parser.getText();
            parser.nextTag();
        }
        return result;
    }

    private void skip(XmlPullParser parser) throws XmlPullParserException, IOException
    {
        if (parser.getEventType() != XmlPullParser.START_TAG)
        {
            throw new IllegalStateException();
        }
        int depth = 1;
        while (depth != 0)
        {
            switch (parser.next())
            {
                case XmlPullParser.END_TAG:
                    depth--;
                    break;
                case XmlPullParser.START_TAG:
                    depth++;
                    break;
            }
        }
    }

}