package etm.main.market.parser.json;

import android.util.Log;
import android.util.Xml;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import etm.main.market.vo.ServerMapData;
import etm.main.market.vo.ServerMapEventData;
import etm.main.market.vo.ServerMapLineData;
import etm.main.market.vo.ServerMapPreData;
import etm.main.market.vo.ServerMapResourceData;
import etm.main.market.vo.ServerMapRouteData;
import etm.main.market.vo.ServerMapSpotData;
import etm.main.market.vo.ServerMapTextData;

public class JsonParser
{
    private static final String TAG = JsonParser.class.getSimpleName();

    // We don't use namespaces
    private static final String ns = null;

    public ServerMapData parse(InputStream in) throws JSONException, IOException
    {
        BufferedReader reader = null;
        InputStreamReader isr = null;
        try
        {
            isr = new InputStreamReader(in);
            reader = new BufferedReader(isr);
            String line;
            String totalJsonData = "";
            while ((line = reader.readLine()) != null)
            {
                totalJsonData += line;
            }

            JSONObject jsonRouteObject =  new JSONObject(totalJsonData);

            ServerMapData tmpData = readMap(jsonRouteObject);

            totalJsonData = "";

            return tmpData;
        }
        finally
        {
            in.close();
            isr.close();
            reader.close();
        }
        /*
        try
        {
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(in, null);
            parser.nextTag();
            return readMap(parser);
        }
        finally
        {
            in.close();
            in = null;
        }
        */
    }




    private ServerMapData readMap(JSONObject tmpObj) throws JSONException, IOException
    {
        ServerMapData tmpMap = new ServerMapData();

        // Starts by looking for the entry tag
        if(tmpObj.has("pre") == true)
        {
            JSONArray preObj = (JSONArray)tmpObj.get("pre");
            if (preObj != null)
            {
                tmpMap.addPre(readPre(preObj));
            }
        }

        if(tmpObj.has("route") == true)
        {
            JSONArray routeArray = (JSONArray)tmpObj.get("route");
            if (routeArray != null)
            {
                for(int i = 0; i < routeArray.length(); i++)
                {
                    JSONObject routeObject = (JSONObject)routeArray.get(i);

                    tmpMap.addRoute(readRoute(routeObject));
                }
            }
        }

        //if (name.equals("resource"))
        if(tmpObj.has("resource") == true)
        {
            JSONObject resourceObj = (JSONObject)tmpObj.get("resource");
            if (resourceObj != null)
            {
                tmpMap.addResource(readResource(resourceObj));
            }
        }

        /*
        else if (name.equals("time"))
        {
            parser.require(XmlPullParser.START_TAG, ns, "time");

            value = readString(parser);

            parser.require(XmlPullParser.END_TAG, ns, "time");

            tmpMap.setTime(value);
        }
        */

        return tmpMap;
    }


    private ServerMapPreData readPre(JSONArray arrayItems) throws JSONException, IOException
    {
        ServerMapPreData tmpPre = new ServerMapPreData();

        if(arrayItems != null)
        {
            int total_array_count = arrayItems.length();

            for (int i = 0; i < total_array_count; i++)
            {
                JSONObject eachPre = (JSONObject)arrayItems.get(i);

                if(eachPre.has("title") == true)
                {
                    String title = eachPre.getString("title");
                    if (title != null)
                    {
                        /*
                        try
                        {
                            title = URLDecoder.decode(title, "utf-8");
                        }
                        catch (UnsupportedEncodingException e)
                        {
                            e.printStackTrace();
                        }
                        */

                        tmpPre.setTitle(title);
                    }
                }

                if(eachPre.has("type") == true)
                {
                    String type = eachPre.getString("type");
                    if (type != null)
                    {
                        tmpPre.setType(type);
                    }
                }

                if(eachPre.has("lines") == true)
                {
                    JSONArray linesArray = (JSONArray) eachPre.get("lines");
                    if (linesArray != null)
                    {
                        tmpPre.setText(readText(linesArray));
                    }
                }
            }
        }

        return tmpPre;
    }

    private ServerMapRouteData readRoute(JSONObject routeObj) throws JSONException, IOException
    {
        ServerMapRouteData tmpRoute = new ServerMapRouteData();

        if(routeObj.has("time") == true)
        {
            String time = routeObj.getString("time");
            if (time != null)
            {
                tmpRoute.setTime(time);
            }
        }

        if(routeObj.has("title") == true)
        {
            String title = routeObj.getString("title");
            if (title != null)
            {
                tmpRoute.setTitle(title);
            }
        }

        if(routeObj.has("area") == true)
        {
            String area = routeObj.getString("area");
            if (area != null)
            {
                tmpRoute.setArea(area);
            }
        }

        if(routeObj.has("spot") == true)
        {
            JSONArray spotArray = (JSONArray)routeObj.get("spot");
            if (spotArray != null)
            {
                for(int i = 0; i < spotArray.length(); i++)
                {
                    JSONObject spotObject = (JSONObject)spotArray.get(i);

                    tmpRoute.addSpot(readSpot(spotObject));
                }
            }
        }

        return tmpRoute;
    }

    private ServerMapResourceData readResource(JSONObject resourceObj) throws JSONException, IOException
    {
        ServerMapResourceData tmpResource = new ServerMapResourceData();

        if(resourceObj.has("audio") == true)
        {
            JSONArray audioArray = (JSONArray)resourceObj.get("audio");
            JSONArray audioKeyArray = (JSONArray)resourceObj.get("audio_key");
            if ((audioArray != null) && (audioKeyArray != null))
            {
                for(int i = 0; i < audioArray.length(); i++)
                {
                    String audioPath = audioArray.getString(i);
                    //String audioIdAndPathArray[] = audioIdAndPath.split("_");
                    String audioKey = audioKeyArray.getString(i);

                    if(audioPath != null && audioKey != null)
                    {
                        tmpResource.addAudio(audioKey, audioPath);
                    }
                }
            }
        }

        if(resourceObj.has("video") == true)
        {
            JSONArray videoArray = (JSONArray)resourceObj.get("video");
            JSONArray videoKeyArray = (JSONArray)resourceObj.get("video_key");
            if ((videoArray != null) && (videoKeyArray != null))
            {
                for(int i = 0; i < videoArray.length(); i++)
                {
                    String videoPath = videoArray.getString(i);
                    String videoKey = videoKeyArray.getString(i);

                    if(videoPath != null && videoKey != null)
                    {
                        tmpResource.addVideo(videoKey, videoPath);
                    }
                }
            }
        }

        if(resourceObj.has("image") == true)
        {
            JSONArray imageArray = (JSONArray)resourceObj.get("image");
            JSONArray imageKeyArray = (JSONArray)resourceObj.get("image_key");
            if ((imageArray != null) && (imageKeyArray != null))
            {
                for(int i = 0; i < imageArray.length(); i++)
                {
                    String imagePath = imageArray.getString(i);
                    String imageKey = imageKeyArray.getString(i);

                    if(imagePath != null && imageKey != null)
                    {
                        tmpResource.addImage(imageKey, imagePath);
                    }
                }
            }
        }

        if(resourceObj.has("rectangle") == true)
        {
            JSONArray rectangleArray = (JSONArray)resourceObj.get("rectangle");
            if (rectangleArray != null)
            {
                for(int i = 0; i < rectangleArray.length(); i++)
                {
                    String imageIdRectangleIdAndData = rectangleArray.getString(i);

                    String imageIdRectangleIdAndDataArray[] = imageIdRectangleIdAndData.split("_");
                    if(imageIdRectangleIdAndDataArray != null && imageIdRectangleIdAndDataArray.length == 3)
                    {
                        tmpResource.addRectangle(imageIdRectangleIdAndDataArray[0], imageIdRectangleIdAndDataArray[1] + '_' + imageIdRectangleIdAndDataArray[2]);
                    }
                }
            }
        }

        return tmpResource;
    }

    private ServerMapSpotData readSpot(JSONObject spotObj) throws JSONException, IOException
    {
        ServerMapSpotData tmpSpot = new ServerMapSpotData();

        if(spotObj.has("spot_id") == true)
        {
            String spot_id = spotObj.getString("spot_id");
            if (spot_id != null)
            {
                tmpSpot.setId(spot_id);
            }
        }

        if(spotObj.has("image_data") == true)
        {
            String image_data = spotObj.getString("image_data");
            if (image_data != null)
            {
                tmpSpot.setImageData(image_data);
            }
        }

        if(spotObj.has("sequence") == true)
        {
            String index = spotObj.getString("sequence");
            if (index != null)
            {
                tmpSpot.setIndex(index);
            }
        }

        if(spotObj.has("title") == true)
        {
            String title = spotObj.getString("title");
            if (title != null)
            {
                /*
                try
                {
                    title = URLDecoder.decode(title, "utf-8");
                }
                catch (UnsupportedEncodingException e)
                {
                    e.printStackTrace();
                }
                */

                tmpSpot.setTitle(title);
            }
        }

        if(spotObj.has("type") == true)
        {
            String type = spotObj.getString("type");
            if (type != null)
            {
                tmpSpot.setType(type);
            }
        }

        if(spotObj.has("category") == true)
        {
            String category = spotObj.getString("category");
            if (category != null)
            {
                tmpSpot.setCategory(category);
            }
        }

        if(spotObj.has("next") == true)
        {
            String next = spotObj.getString("next");
            if (next != null)
            {
                if((next.equals("") == false) && (next.equals("null") == false))
                {
                    String nextNumString[] = next.split("-");
                    int nextNumInt[] = new int[nextNumString.length];
                    for (int x = 0; x < nextNumString.length; x++) {
                        nextNumInt[x] = Integer.valueOf(nextNumString[x]);
                    }
                    tmpSpot.setNexts(nextNumInt);
                }
            }
        }

        if(spotObj.has("prev") == true)
        {
            String prev = spotObj.getString("prev");

            if(prev != null)
            {
                if((prev.equals("") == false) && (prev.equals("null") == false))
                {
                    String prevNumString[] = prev.split("-");
                    int prevNumInt[] = new int[prevNumString.length];
                    for (int x = 0; x < prevNumString.length; x++) {
                        prevNumInt[x] = Integer.valueOf(prevNumString[x]);
                    }
                    tmpSpot.setPrevs(prevNumInt);
                }
            }
        }

        if(spotObj.has("next_recommended_spot_id") == true)
        {
            String next_recommended_spot_id = spotObj.getString("next_recommended_spot_id");
            if (next_recommended_spot_id != null)
            {
                tmpSpot.setNextRecommendedSpotId(next_recommended_spot_id);
            }
        }

        if(spotObj.has("maker") == true)
        {
            String maker = spotObj.getString("maker");
            if (maker != null)
            {
                tmpSpot.setMaker(maker);
            }
        }

        if(spotObj.has("area") == true)
        {
            String area = spotObj.getString("area");
            if (area != null)
            {
                tmpSpot.setArea(area);
            }
        }

        if(spotObj.has("event") == true)
        {
            JSONArray eventArray = (JSONArray)spotObj.get("event");
            if (eventArray != null)
            {
                for(int i = 0; i < eventArray.length(); i++)
                {
                    JSONObject eventObject = (JSONObject)eventArray.get(i);

                    tmpSpot.addEvent(readEvent(eventObject));
                }
            }
        }

        return tmpSpot;
    }

    private ServerMapEventData readEvent(JSONObject eventObj) throws JSONException, IOException
    {
        ServerMapEventData tmpEvent = new ServerMapEventData();

        if(eventObj.has("title") == true)
        {
            String title = eventObj.getString("title");
            if (title != null)
            {
                /*
                try
                {
                    title = URLDecoder.decode(title, "utf-8");
                }
                catch (UnsupportedEncodingException e)
                {
                    e.printStackTrace();
                }
                */
                tmpEvent.setTitle(title);
            }
        }

        if(eventObj.has("image_data") == true)
        {
            String image_data = eventObj.getString("image_data");
            if (image_data != null)
            {
                tmpEvent.setImageData(image_data);
            }
        }

        if(eventObj.has("sequence") == true)
        {
            String index = eventObj.getString("sequence");
            if (index != null)
            {
                tmpEvent.setIndex(index);
            }
        }

        if(eventObj.has("type") == true)
        {
            String type = eventObj.getString("type");
            if (type != null)
            {
                tmpEvent.setType(type);
            }
        }

        if(eventObj.has("category") == true)
        {
            String category = eventObj.getString("category");
            if (category != null)
            {
                tmpEvent.setCategory(category);
            }
        }

        if(eventObj.has("latitude") == true)
        {
            String latitude = eventObj.getString("latitude");
            if (latitude != null)
            {
                tmpEvent.setLat(latitude);
            }
        }

        if(eventObj.has("longitude") == true)
        {
            String longitude = eventObj.getString("longitude");
            if (longitude != null)
            {
                tmpEvent.setLng(longitude);
            }
        }
        /*
        if(eventObj.has("loc") == true)
        {
            String loc = eventObj.getString("loc");
            if (loc != null)
            {
                if ((loc != null) && (loc.length() > 1))
                {
                    //tmpSpot.setLoc(loc);
                    String locInfo[] = loc.split(" ");
                    tmpEvent.setLat(locInfo[0]);
                    tmpEvent.setLng(locInfo[1]);
                }
            }
        }
        */

        if(eventObj.has("time") == true)
        {
            String time = eventObj.getString("time");
            if (time != null)
            {
                tmpEvent.setTime(time);
            }
        }

        if(eventObj.has("lines") == true)
        {
            JSONArray linesArray = (JSONArray)eventObj.get("lines");
            if (linesArray != null)
            {
                tmpEvent.setText(readText(linesArray));
                /*
                for(int i = 0; i < linesArray.length(); i++)
                {
                    JSONObject lineObject = (JSONObject)linesArray.get(i);

                    tmpEvent.setText(readText(lineObject));
                }
                */
            }
            /*
            JSONObject textObj = (JSONObject)eventObj.get("lines");
            if (textObj != null)
            {
                tmpEvent.setText(readText(textObj));
            }
            */
        }

        if(eventObj.has("location_detection") == true)
        {
            String location_detection = eventObj.getString("location_detection");
            if (location_detection != null)
            {
                tmpEvent.setLocationDetection(location_detection);
            }
        }

        return tmpEvent;
    }

    private ServerMapTextData readText(JSONArray linesObj) throws JSONException, IOException
    {
        ServerMapTextData tmpText = new ServerMapTextData();

        for(int i = 0; i < linesObj.length(); i++)
        {
            JSONObject lineObject = (JSONObject)linesObj.get(i);

            ServerMapLineData lineData = readLine(lineObject);
            tmpText.addLine(lineData);
        }

        /*
        if(textObj.has("line") == true)
        {
            JSONObject lineObj = (JSONObject)textObj.get("line");
            if (lineObj != null)
            {
                ServerMapLineData lineData = readLine(lineObj);
                tmpText.addLine(lineData);
            }
        }
        */

        return tmpText;
    }

    private ServerMapLineData readLine(JSONObject lineObj) throws JSONException, IOException
    {
        ServerMapLineData tmpLine = new ServerMapLineData();

        if(lineObj.has("title") == true)
        {
            String title = lineObj.getString("title");
            if (title != null)
            {
                /*
                try
                {
                    title = URLDecoder.decode(title, "utf-8");
                }
                catch (UnsupportedEncodingException e)
                {
                    e.printStackTrace();
                }
                */
                tmpLine.setLineText(title);
            }
        }

        if(lineObj.has("audio") == true)
        {
            String audio_id = lineObj.getString("audio");
            if (audio_id != null)
            {
                tmpLine.setAudioId(audio_id);
            }
        }

        if(lineObj.has("video") == true)
        {
            String video_id = lineObj.getString("video");
            if (video_id != null)
            {
                tmpLine.setVideoId(video_id);
            }
        }

        if(lineObj.has("image_data") == true)
        {
            String image_data = lineObj.getString("image_data");
            if (image_data != null)
            {
                tmpLine.setImageData(image_data);
            }
        }


        return tmpLine;
    }



}