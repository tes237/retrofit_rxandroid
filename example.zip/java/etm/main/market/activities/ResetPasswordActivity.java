package etm.main.market.activities;

import android.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.connects.WebManager;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.generalApplication;
import etm.main.market.vo.ResponseResetEmailData;

public class ResetPasswordActivity extends BaseActivity implements baseDefine, View.OnClickListener
{
    private static final String TAG = ResetPasswordActivity.class.getSimpleName();

    public static final int RESET_PASSWORD_RESULT_OK = 0;
    public static final int RESET_PASSWORD_RESULT_FAIL = 1;

    private Button mSendButton;
    private ImageButton mBackButton;

    private EditText mSendEmailEdit;

    protected generalApplication mGeneralApplication = null;

    private WebManager mWeb;

    private GeneralAlarmDialog mGeneralAlarmDialog = null;

    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mSendEmailEdit = (EditText)findViewById(R.id.reset_password_email_edit);
        mSendButton = (Button) findViewById(R.id.reset_password_submit_button);
        mSendButton.setOnClickListener(this);

        mBackButton = (ImageButton) findViewById(R.id.reset_password_activity_back_button);
        mBackButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.reset_password_submit_button)
        {
            final String tmpEmailStr = mSendEmailEdit.getText().toString();

            if("".equals(tmpEmailStr) == true)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled), null);
                return;
            }

            if(isEmailValid(tmpEmailStr) == false)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.please_fill_valid_email_id), null);
                return;
            }

            mWeb.reset_password_email(tmpEmailStr,
                new Consumer<ResponseResetEmailData>()
                {
                    @Override
                    public void accept(ResponseResetEmailData registerDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = registerDatas.getResult();
                        String serverData = registerDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.success_title), getString(R.string.recovery_email_send_successful),
                                    new GeneralAlarmButtonListener()
                                    {
                                        @Override
                                        public void onButtonClickListener(View v, int id, int button)
                                        {
                                            setResult(RESET_PASSWORD_RESULT_OK);
                                            finish();
                                        }
                                    });
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            //setResult(RESET_PASSWORD_RESULT_FAIL);
                            //finish();
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(registerDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        BaseLib().showGeneralPopup(getString(R.string.error_title), "", null);
                    }
                }, disposables
            );
        }
        else if(v.getId() == R.id.reset_password_activity_back_button)
        {
            finish();
        }
    }

    @Override
    protected void onDestroy()
    {
        disposables.dispose();

        super.onDestroy();
    }

    public final static boolean isEmailValid(CharSequence target)
    {
        if (target == null)
            return false;

        return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
}


