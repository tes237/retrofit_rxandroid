package etm.main.market.activities;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.facebook.FacebookSdk;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;

import java.io.File;

import io.reactivex.disposables.CompositeDisposable;
import etm.main.market.R;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.generalApplication;

public class SplashActivity extends BaseActivity
{
    private static final String TAG = SplashActivity.class.getSimpleName();

    //------------------------ initilize -------------------------//
    //------------------------ pre -------------------------//
    private static final int WEB_VERSION_START = 10;
    private static final int WEB_VERSION_STARTING = 11;
    private static final int WEB_VERSION_ERROR = 12;
    private static final int WEB_VERSION_FINISH = 15;
    //------------------------ online mode -------------------------//
    private static final int GOOGLE_PLAY_VERSION_START = 20;
    private static final int GOOGLE_PLAY_VERSION_STARTING = 21;
    private static final int GOOGLE_PLAY_VERSION_ERROR = 22;
    private static final int GOOGLE_PLAY_VERSION_FINISH = 25;

    private static final int ONLINE_MODE_GPS_START = 30;
    private static final int ONLINE_MODE_GPS_STARTING = 31;

    private static final int PUSH_START = 40;
    private static final int PUSH_STARTING = 41;

    private static final int DB_CHECK_START = 50;
    private static final int DB_CHECK_STARTING = 51;
    private static final int DB_CHECK_FINISH = 55;

    private static final int ADV_DOWNLOAD_START = 60;
    private static final int ADV_DOWNLOAD_STARTING = 61;
    private static final int ADV_DOWNLOAD_FINISH = 65;

    private static final int TTS_CHECK_START = 70;
    private static final int TTS_CHECK_STARTING = 71;
    private static final int TTS_CHECK_FINISH = 75;

    private static final int AUTOLOGIN_CHECK = 500;
    private static final int AUTOLOGIN_CHECK_START = 501;
    private static final int AUTOLOGIN_SUCCESS = 600;
    private static final int AUTOLOGIN_SUCCESS_STARTED = 601;
    private static final int AUTOLOGIN_FAIL= 651;
    private static final int AUTOLOGIN_FAIL_STARTED= 651;

    //------------------------ offline mode -------------------------//
    private static final int OFFLINE_MODE_START = 400;
    private static final int OFFLINE_MODE_STARTING = 401;
    private static final int OFFLINE_MODE_FINISH = 402;

    private static final int OFFLINE_MODE_GPS_START = 410;
    private static final int OFFLINE_MODE_GPS_STARTING = 411;
    private static final int OFFLINE_MODE_GPS_ERROR = 412;
    private static final int OFFLINE_MODE_GPS_FINISH = 413;

    private static final int OFFLINE_MODE_FINISH_CHECK = 1000;
    //------------------------ post -------------------------//

    //------------------------ initilize end -------------------------//

    private Context mContext;

    private ImageView mLogo;
    private ImageView mSplash;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private DBAdapter mDBAdapter;


    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);

    private int mInitializeStatus = 0;
    private int mWaitCount = 0;

    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mGeneralApplication.setTick("first");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        mGeneralApplication.setTick("setContentView");

        //mTwitterHelper = new TwitterHelper(this, this); // Twitter Initialization
        FacebookSdk.sdkInitialize(getApplicationContext()); // Facebook SDK Initialization

        //--------------------------------Facebook login--------------------------------------//
        //generateKey(this);

        initialize();

        mGeneralApplication.setTick("initialize");
    }

    @Override
    protected void onDestroy()
    {
        //recycleBitmap(mLogo);
        //recycleBitmap(mSplash);

        super.onDestroy();
    }

    private static void recycleBitmap(ImageView iv)
    {
        Drawable d = iv.getDrawable();
        if (d instanceof BitmapDrawable) {
            Bitmap b = ((BitmapDrawable)d).getBitmap();
            b.recycle();
        } // 현재로서는 BitmapDrawable 이외의 drawable 들에 대한 직접적인 메모리 해제는 불가능하다.

        d.setCallback(null);
    }

    public class PlayServicesUtils
    {
        public boolean checkGooglePlaySevices(final Activity activity)
        {
            final int googlePlayServicesCheck = GooglePlayServicesUtil.isGooglePlayServicesAvailable(activity);
            switch (googlePlayServicesCheck)
            {
                case ConnectionResult.SUCCESS:
                    mInitializeStatus = GOOGLE_PLAY_VERSION_FINISH;
                    return true;
                case ConnectionResult.SERVICE_DISABLED:
                case ConnectionResult.SERVICE_INVALID:
                case ConnectionResult.SERVICE_MISSING:
                case ConnectionResult.SERVICE_VERSION_UPDATE_REQUIRED:
                    Dialog dialog = GooglePlayServicesUtil.getErrorDialog(googlePlayServicesCheck, activity, 0);
                    dialog.setOnCancelListener(new DialogInterface.OnCancelListener()
                    {
                        @Override
                        public void onCancel(DialogInterface dialogInterface)
                        {
                            //activity.finish();
                            //getMainActivity().finish();
                            mInitializeStatus = GOOGLE_PLAY_VERSION_ERROR;
                        }
                    });
                    dialog.show();
            }
            return false;
        }
    }

    private void initialize()
    {
        mInitializeStatus = WEB_VERSION_START;
        Handler initializeHandler = new Handler()
        {
            @Override
            public void handleMessage(Message msg)
            {
                switch (mInitializeStatus)
                {
                    case WEB_VERSION_START:
                        mInitializeStatus = WEB_VERSION_STARTING;
                        checkAppVersion();

                        mGeneralApplication.setTick("WEB_VERSION_START");
                        break;
                    case WEB_VERSION_ERROR:
                       // mIsOnlineMode = false;
                        //offline mode
                        //have to confirm that user want to offline mode
                        break;
                    case WEB_VERSION_FINISH:
                        //online mode
                        mInitializeStatus = GOOGLE_PLAY_VERSION_START;
                        break;
                    case GOOGLE_PLAY_VERSION_START:
                        mInitializeStatus = GOOGLE_PLAY_VERSION_STARTING;
                        checkGooglePlayServiceVersion();
                        mGeneralApplication.setTick("GOOGLE_PLAY_VERSION_START");
                        break;
                    case GOOGLE_PLAY_VERSION_ERROR:
                        //finish
                        finish();
                        return;
                        //break;
                    case GOOGLE_PLAY_VERSION_FINISH:
                        mInitializeStatus = PUSH_START;
                        break;
                    case PUSH_START:
                        initPush();
                        mGeneralApplication.setTick("PUSH_START");
                        break;
                    case PUSH_STARTING:
                        mInitializeStatus = DB_CHECK_START;
                        break;
                    case DB_CHECK_START:
                        mInitializeStatus = DB_CHECK_STARTING;
                        downloadConf();
                        mGeneralApplication.setTick("DB_CHECK_START");
                        break;
                    case DB_CHECK_FINISH:
                        mInitializeStatus = ADV_DOWNLOAD_START;
                        break;
                    case ADV_DOWNLOAD_START:
                        mInitializeStatus = ADV_DOWNLOAD_STARTING;
                        downloadAdv();
                        mGeneralApplication.setTick("ADV_DOWNLOAD_START");
                        break;
                    case ADV_DOWNLOAD_FINISH:
                        mInitializeStatus = TTS_CHECK_START;
                        break;
                    case TTS_CHECK_START:
                        mInitializeStatus = TTS_CHECK_STARTING;
                        ttsCheckInit();
                        mGeneralApplication.setTick("DOWNLOADED_MAP_VERSION_CHECK_START");
                        break;
                    case TTS_CHECK_FINISH:
                        mInitializeStatus = AUTOLOGIN_CHECK;
                        break;
                    case AUTOLOGIN_CHECK:

                        mInitializeStatus = AUTOLOGIN_CHECK_START;

                        BaseLib().initBaseLib(SplashActivity.this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

                        LoginProcessPopup(new AutoLoginListener()
                        {
                            @Override
                            public void onAutoLoginSuccess()
                            {
                                mInitializeStatus = AUTOLOGIN_SUCCESS;
                            }

                            @Override
                            public void onAutoLoginFail()
                            {
                                mInitializeStatus = AUTOLOGIN_FAIL_STARTED;
                            }
                        });

                        /*
                        int login_ret = AutoLogin();

                        if(login_ret < 0)
                        {
                            mInitializeStatus = AUTOLOGIN_FAIL;
                        }
                        else
                        {
                            mInitializeStatus = AUTOLOGIN_CHECK_START;
                        }
                        */
                        mGeneralApplication.setTick("AUTOLOGIN_CHECK");
                        break;
                    case AUTOLOGIN_CHECK_START:
                        break;
                    case AUTOLOGIN_SUCCESS:
                        mInitializeStatus = AUTOLOGIN_SUCCESS_STARTED;
                        mGeneralApplication.setTick("AUTOLOGIN_SUCCESS");
                        Intent home_intent = new Intent(SplashActivity.this, HomeActivity.class);
                        startActivity(home_intent);
                        finish();
                        return;
                    case AUTOLOGIN_FAIL:
                        mInitializeStatus = AUTOLOGIN_FAIL_STARTED;
                        mGeneralApplication.setTick("AUTOLOGIN_FAIL");
                        //Intent login_intent = new Intent(SplashActivity.this, LoginActivity.class);
                        //startActivity(login_intent);
                        Intent home_intent2 = new Intent(SplashActivity.this, HomeActivity.class);
                        startActivity(home_intent2);
                        finish();
                        return;
                    default:
                        String debugMsg = String.format("current online mode state (%d)", mInitializeStatus);
                        Log.d(TAG, debugMsg);
                        break;
                }

                sendEmptyMessageDelayed(0, 1);
            }
        };
        initializeHandler.sendEmptyMessageDelayed(0, 1);
    }

    private void checkAppVersion()
    {
        mInitializeStatus = WEB_VERSION_FINISH;
        /*
        mServer.downloadAppversion()
            .subscribe(new Observer<List<VersionData>>()
            {
                @Override
                public void onCompleted()
                {
                    Log.e(TAG, "onCompleted");
                    mInitializeStatus = WEB_VERSION_FINISH;
                }

                @Override
                public void onError(Throwable throwable)
                {
                    Log.e(TAG, "onError");
                    mInitializeStatus = WEB_VERSION_ERROR;
                }

                @Override
                public void onNext(List<VersionData> versionDatas)
                {
                    VersionData tmpData = versionDatas.get(0);
                    String serverVersion = tmpData.getVersion();

                    String localVersion = getString(R.string.gcm_app_version);

                    mInitializeStatus = WEB_VERSION_FINISH;
                }
            });
            */
    }

    private void initPush()
    {
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        File filesDir = cw.getFilesDir();
        //System.out.println("filesDir = "+filesDir.getAbsolutePath());

        File firebase_dat = new File(filesDir.getAbsoluteFile() + "/firebase.dat");

        if (firebase_dat.exists() == true)
        {
            mInitializeStatus = PUSH_STARTING;
            //mInitializeStatus = WEB_CONF_START;
        }
        else
        {
            //pass and wait
            mWaitCount++;
            if(mWaitCount > 20) //just pass after 12 seconds.
            {
                mWaitCount = 0;
                mInitializeStatus = PUSH_STARTING;
            }
        }

        //currently not set PUSH_FINISH till completely push is registered
    }

    private void downloadConf()
    {
        initializeDatabase();

        mInitializeStatus = DB_CHECK_FINISH;
    }

    private void downloadAdv()
    {
        mInitializeStatus = ADV_DOWNLOAD_FINISH;
    }

    private void ttsCheckInit()
    {
        mInitializeStatus = TTS_CHECK_FINISH;
    }

    private void checkToGoToOfflineMode()
    {
        mInitializeStatus = OFFLINE_MODE_FINISH;
    }

    private void checkGooglePlayServiceVersion()
    {
        PlayServicesUtils tmpCheck = new PlayServicesUtils();
        tmpCheck.checkGooglePlaySevices(this);
    }

    private void initializeDatabase()
    {
        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        String static_version = getString(R.string.db_version);
        try
        {
            Cursor search_cursor = mDBAdapter.getDBVersion();
            if(search_cursor != null && search_cursor.moveToFirst())
            {
                String ver = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.VERSION));
                if(static_version.equals(ver) == false)
                {
                    mDBAdapter.close();
                    mDBAdapter.uninstall();

                    mDBAdapter.create();
                    mDBAdapter.install();
                    mDBAdapter.open();

                    mDBAdapter.putDBVersion(static_version);
                }
            }
            else
            {
                mDBAdapter.close();
                mDBAdapter.uninstall();

                mDBAdapter.create();
                mDBAdapter.install();
                mDBAdapter.open();

                mDBAdapter.putDBVersion(static_version);
            }
        }
        catch(SQLiteException sqle)
        {
            mDBAdapter.close();
            mDBAdapter.uninstall();

            mDBAdapter.create();
            mDBAdapter.install();
            mDBAdapter.open();

            mDBAdapter.putDBVersion(static_version);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
    }

    /*
    private int AutoLogin()
    {
        Cursor login_cursor = mDBAdapter.getLoginType();
        if(login_cursor != null && login_cursor.moveToFirst())
        {
            final String type_var = login_cursor.getString(login_cursor.getColumnIndex(DBAdapter.SERVICE_TYPE));
            if(type_var == null || "".equals(type_var) == true)
            {
                return -1;
            }
            final String flag_var = login_cursor.getString(login_cursor.getColumnIndex(DBAdapter.AUTO_LOGIN_FLAG));
            if(flag_var == null || LoginActivity.AUTO_LOGIN_FALSE.equals(flag_var) == true || "".equals(flag_var) == true)
            {
                return -1;
            }

            if(LoginActivity.LOGIN_TYPE_TGM.equals(type_var) == true)
            {
                return loginToTGM();
            }
            else if(LoginActivity.LOGIN_TYPE_FB.equals(type_var) == true)
            {
                return loginToFB();
            }

        }

        return -1;
    }

    private int loginToFB()
    {
        isFbLogin = true;
        fbConnectHelper.connect();
        return 0;
    }

    private int loginToTGM()
    {
        Cursor search_cursor = mDBAdapter.getAutoLoginCheck();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            final String id_var = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.ID_TEXT));
            if(id_var == null || "".equals(id_var) == true)
            {
                return -1;
            }
            final String pw_var = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.PW_TEXT));
            if(pw_var == null || "".equals(pw_var) == true)
            {
                return -1;
            }

            final String refreshedToken = FirebaseInstanceId.getInstance().getToken();

            mWeb.login(id_var, pw_var, DEV_AND, refreshedToken,
                    new Consumer<ResponseLoginData>()
                    {
                        @Override
                        public void accept(ResponseLoginData loginDatas) throws Exception
                        {
                            // TODO: Handle response.
                            String serverResult = loginDatas.getResult();
                            String serverData = loginDatas.getData();

                            mWeb.setCookieState(false);
                            mGeneralApplication.setIdString(id_var);
                            mGeneralApplication.setNumString(serverData);

                            //pd.dismiss();
                            if(serverResult.equals(JSON_SUCCESS))
                            {
                                TGMFirebaseMessagingService.setMyId(serverData);

                                mGeneralApplication.setLoggedIn(true);

                                mInitializeStatus = AUTOLOGIN_SUCCESS;
                            }
                            else //if(serverResult.equals(JSON_FAIL))
                            {
                                mInitializeStatus = AUTOLOGIN_FAIL;
                            }
                        }
                    }
                    ,new Consumer<Throwable>()
                    {
                        @Override
                        public void accept(@NonNull Throwable throwable) throws Exception
                        {
                            // TODO: Handle error.
                            //pd.dismiss();
                            mWeb.setCookieState(false);
                            mInitializeStatus = AUTOLOGIN_FAIL;
                        }
                    }, disposables
            );

            return 0;
        }
        else
        {
            return -1;
        }
    }
    */
}
