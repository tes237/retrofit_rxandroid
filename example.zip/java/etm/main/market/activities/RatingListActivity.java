package etm.main.market.activities;

import android.app.FragmentManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.net.URLDecoder;
import java.util.ArrayList;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.baseDefine;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.RatingListAdapter;
import etm.main.market.lists.RatingListListener;
import etm.main.market.vo.ResponseReviewsData;
import etm.main.market.vo.Review;
import etm.main.market.vo.Reviews;
import etm.main.market.widgets.swipyLayout.SwipyRefreshLayout;
import etm.main.market.widgets.swipyLayout.SwipyRefreshLayoutDirection;

import etm.main.market.R;

public class RatingListActivity extends BaseActivity implements baseDefine, RatingListListener, View.OnClickListener
{
    private static final String TAG = RatingListActivity.class.getSimpleName();

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;

    private ImageButton mBackButton;
    private SwipyRefreshLayout mSwipyRefreshLayout;
    private ListView mRatingListRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private RatingListAdapter mRatingListAdapter;
    private TextView mTitleText, mNoText;
    private Button mWriteButton;

    private ArrayList<Review> mRatingList = null;

    private String mSkuStr = null;
    private String mTitleStr = null;

    private GeneralAlarmDialog mGeneralAlarmDialog = null;

    private DBAdapter mDBAdapter = null;

    private int mCurrentPageIndex = 1;
    private int mTotalPageCount = 1;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_rating_list);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mSkuStr = bd.getString(CategoryListActivity.MAP_SKU);
            mTitleStr = bd.getString(CategoryListActivity.MAP_TITLE);
        }

        mSwipyRefreshLayout = (SwipyRefreshLayout)findViewById(R.id.rating_list_swipy_layout);

        mRatingListRecyclerView = (ListView)findViewById(R.id.rating_list_recycler_view);

        mBackButton = (ImageButton)findViewById(R.id.rating_list_activity_back_button);
        mBackButton.setOnClickListener(this);

        mTitleText = (TextView)findViewById(R.id.rating_list_activity_title_textview);
        mNoText = (TextView)findViewById(R.id.rating_no_list);

        mWriteButton = (Button)findViewById(R.id.write_rating_button);
        mWriteButton.setOnClickListener(this);

        mTitleText.setText(mTitleStr);

        //mRatingListRecyclerView.setHasFixedSize(true);

        //mLayoutManager = new LinearLayoutManager(this);
        //mRatingListRecyclerView.setLayoutManager(mLayoutManager);

        mRatingList = new ArrayList<Review>();
        mRatingListAdapter = new RatingListAdapter(RatingListActivity.this, mRatingList, this, mWeb);
        mRatingListRecyclerView.setAdapter(mRatingListAdapter);

        mSwipyRefreshLayout.setDirection(SwipyRefreshLayoutDirection.BOTTOM);

        mSwipyRefreshLayout.setOnRefreshListener(new SwipyRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(SwipyRefreshLayoutDirection direction)
            {
                if(mTotalPageCount < mCurrentPageIndex + 1)
                {
                    mSwipyRefreshLayout.setRefreshing(false);
                    return;
                }

                mCurrentPageIndex++;

                getReviews();
                mSwipyRefreshLayout.setRefreshing(false);
            }
        });

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        mRatingList.clear();
        getReviews();
    }

    private void getReviews()
    {
        mWeb.getReviews(mSkuStr, "10","0",
                new Consumer<ResponseReviewsData>()
                {
                    @Override
                    public void accept(ResponseReviewsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Reviews serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            if(objDatas.getIsPurchased() == 1)
                            {
                                mWriteButton.setVisibility(View.VISIBLE);
                            }
                            else
                            {
                                mWriteButton.setVisibility(View.INVISIBLE);
                            }

                            if(serverData.getReviews().size() > 0)
                            {
                                mNoText.setVisibility(View.GONE);
                            }
                            else
                            {
                                mSwipyRefreshLayout.setVisibility(View.GONE);
                                mNoText.setVisibility(View.VISIBLE);
                            }

                            for(int x = 0; x < serverData.getReviews().size(); x++)
                            {
                                Review tmpData = serverData.getReviews().get(x);
                                String idStr = tmpData.getReviewId();
                                String rating1Str = tmpData.getRating1();
                                String rating2Str = tmpData.getRating2();
                                String titleStr = tmpData.getTitle();
                                String detailStr = tmpData.getDetail();
                                String nickStr = tmpData.getNickname();
                                String createdStr = tmpData.getCreatedAt();
                                String profileUrl = tmpData.getProfileUrl();
                                profileUrl = URLDecoder.decode(profileUrl, "utf-8");

                                mRatingList.add(new Review(idStr, rating1Str, rating2Str, titleStr, detailStr, nickStr, createdStr, profileUrl));
                            }

                            mRatingListAdapter.notifyDataSetChanged();
                            //mRatingListRecyclerView.invalidate();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getReviews();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getReviews();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true) {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener() {
                                @Override
                                public void onAutoLoginSuccess() {
                                    getReviews();
                                }

                                @Override
                                public void onAutoLoginFail() {
                                    startManualLogin(new LoginListener() {
                                        @Override
                                        public void onLoginSuccess() {
                                            getReviews();
                                        }

                                        @Override
                                        public void onLoginCancel() {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        //Intent i = new Intent(RatingActivity.this, ProfileViewActivity.class);
        //startActivity(i);
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.rating_list_activity_back_button)
        {
            finish();
        }
        else if(v.getId() == R.id.write_rating_button)
        {
            Intent i = new Intent(RatingListActivity.this, RatingActivity.class);
            i.putExtra(MAP_SKU, mSkuStr);
            i.putExtra(IS_TEST_MAP, TYPE_PURCHASED_MAP);
            startActivityForResult(i, 0);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RatingActivity.WRITING_FINISHED)
        {
            mRatingList.clear();
            getReviews();
        }
        else if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }

    @Override
    public void onDestroy()
    {
        disposables.dispose();

        super.onDestroy();
    }

}
