package etm.main.market.activities;

import android.app.FragmentManager;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ScaleDrawable;
import android.net.Uri;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.ActionMode;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import java.io.File;
import java.util.ArrayList;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.HorizontalCardListAdapter;
import etm.main.market.pages.PhotoPagerAdapter;
import etm.main.market.vo.CustomerStats;
import etm.main.market.vo.Product;
import etm.main.market.vo.ResponseCustomerStatsData;
import etm.main.market.vo.ResponseProductData;
import etm.main.market.R;
import etm.main.market.vo.ResponseSimpleData;
import etm.main.market.widgets.ratingbar.ColoredRatingBar;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

import static java.lang.Math.*;

public class IntroActivity extends BaseActivity implements baseDefine, View.OnClickListener
{
    private static final String TAG = IntroActivity.class.getSimpleName();
    public static final String MAP_SKU = "map_sku";
    public static final String PRODUCT_PURCHASE_KEY = "purchase_key";
    public static final String MAP_TITLE = "map_title";
    public static final String MAP_PRICE = "map_price";
    public static final String MAP_IMAGE = "map_image";
    public static final String MAP_LANGUAGE = "map_language";

    public static final String FROM = "from";

    public static final int SEARCH_RESULT = 0;
    public static final int PURCHASED_LIST = 1;

    public static final int REQUEST_PAYMENT_ACT = 1001;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;

    private  String APP_DIRECTORY;
    private String mUserDir;
    private String mTitleStr;

    //private Product mIntroData = null;
    private ArrayList<String> mIntroPhotoList;
    private PhotoPagerAdapter mPhotoPagerAdapter;
    private ViewPager mIntroPager;
    private ImageButton mBackButton;
    private TextView mTitleText;
    private ColoredRatingBar mRatingBar1;
    //private ColoredRatingBar mRatingBar2;
    //private ColoredRatingBar mRatingBar3;

    private ScalableLayout mMapLayout;
    private GoogleMap mMap;
    private Button mPurchase;
    private Button mPlay;
    private Button mRatingViewButton;
    private ImageView mAddToWishlistButton;
    private TextView mAskButton;

    private TextView mIntroTitleText;
    private TextView mIntroDescText;
    //private TextView mProfileSellerNameText;
    private TextView mTotalDurationText;
    private TextView mPriceText;
    private TextView mTitlePriceText;
    private TextView mExpectedExpensesText;
    private TextView mSellerText;
    private TextView mLanguageText;
    private TextView mRatingText1;
    //private TextView mRatingText2;

    private TextView mEntertainment;
    private TextView mHealing;
    private TextView mAdventure;
    private TextView mWorking;
    private TextView mCulture;
    private TextView mMystery;
    private TextView mReligious;
    private TextView mSports;
    private TextView mShopping;
    private TextView mSpecialEvent;

    private TextView mHalal;
    private TextView mKosher;
    private TextView mJain;
    private TextView mHindu;
    private TextView mNutFree;
    private TextView mLactoOvo;
    private TextView mPureVeg;
    private TextView mVegan;
    private TextView mGlutenFree;

    private TextView mAirplane;
    private TextView mBicycle;
    private TextView mBus;
    private TextView mCar;
    private TextView mMonorail;
    private TextView mMotorbicycle;
    private TextView mShip;
    private TextView mSubway;
    private TextView mTrain;

    private ImageView mYoutubeButton;

    private ImageView mLeftMoveButton;
    private ImageView mRightMoveButton;

    private GeneralAlarmDialog mGeneralAlarmDialog;

    private String mSkuStr = null;
    private int mFromType = 0;

    private String mLatitude;
    private String mLongitude;
    private String mDistance;

    private String mSellerId;
    private String mSellerName;

    private String mProductFirstImageURL = "";
    private String mProductPrice = "";

    private String mYoutubeVideoLink = "";

    private boolean mIsWishlishOn = false;
    private String store_price_key = "";

    private String mStoreLanguage = null;

    private CompositeDisposable disposables = new CompositeDisposable();

    private DBAdapter mDBAdapter = null;
    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);

    @Nullable
    @Override
    public ActionMode startActionMode(ActionMode.Callback callback)
    {
        return super.startActionMode(callback);
    }

    protected void onCreate(Bundle savedInstanceState)
    {
        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        mGeneralApplication.setTick("---------- Intro first");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_intro);

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();
        //String tmpUserIdStr = mGeneralApplication.getIdString();
        //mUserDir = Base64.mod_encode(tmpUserIdStr);

        mGeneralApplication.setTick("Intro setContentView");
        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mSkuStr = bd.getString(CategoryListActivity.MAP_SKU);
            mFromType = bd.getInt(IntroActivity.FROM);
        }
        mGeneralApplication.setTick("Intro getIntent");

        mTitleText = (TextView)findViewById(R.id.list_activity_title_textview);

        mBackButton = (ImageButton)findViewById(R.id.intro_activity_back_button);
        mIntroPager = (ViewPager)findViewById(R.id.intro_photo_pager);

        mRatingBar1 = (ColoredRatingBar)findViewById(R.id.ratingbar1);
        //mRatingBar2 = (ColoredRatingBar)findViewById(R.id.ratingbar2);
        //mRatingBar3 = (ColoredRatingBar)findViewById(R.id.ratingbar3);

        mRatingText1 = (TextView)findViewById(R.id.rating_category1);
        //mRatingText2 = (TextView)findViewById(R.id.rating_category2);

        mLeftMoveButton = (ImageView)findViewById(R.id.photo_left_button);
        mRightMoveButton = (ImageView)findViewById(R.id.photo_right_button);

        mMapLayout = (ScalableLayout)findViewById(R.id.tour_place_map_layout);

        mPurchase = (Button)findViewById(R.id.intro_activity_purchase_button);
        mPlay = (Button)findViewById(R.id.intro_activity_play_button);
        /*
        if(mFromType == SEARCH_RESULT)
        {

            String mapPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" + mSkuStr;
            File checkFile = new File(mapPathStr);

            if(checkFile.exists() == true)
            {
                mPurchase.setVisibility(View.GONE);
                mPlay.setVisibility(View.VISIBLE);
            }
            else
            {
                mPurchase.setVisibility(View.VISIBLE);
                mPlay.setVisibility(View.GONE);
            }
        }
        else if(mFromType == PURCHASED_LIST)
        {
            mPurchase.setVisibility(View.GONE);
            mPlay.setVisibility(View.VISIBLE);
        }
        */
        mPurchase.setVisibility(View.VISIBLE);
        mPlay.setVisibility(View.GONE);

        mRatingViewButton = (Button)findViewById(R.id.intro_activity_comment_view_button);
        mAddToWishlistButton = (ImageView)findViewById(R.id.intro_activity_wishlist_button);

        mAskButton = (TextView)findViewById(R.id.intro_activity_ask_button);

        mIntroTitleText = (TextView)findViewById(R.id.tour_guide_intro_activity_title_text);
        mIntroDescText = (TextView)findViewById(R.id.tour_guide_intro_activity_description_text);

        //mThemedTypeRecyclerView = (RecyclerView)findViewById(R.id.themed_type_list);
        //mSpecialFoodTypeRecyclerView = (RecyclerView)findViewById(R.id.special_meal_list);
        //mTransTypeRecyclerView = (RecyclerView)findViewById(R.id.trans_list);

        mTotalDurationText = (TextView)findViewById(R.id.toral_duration_time);
        mPriceText = (TextView)findViewById(R.id.tg_price);
        mTitlePriceText = (TextView)findViewById(R.id.tg_title_price_text);

        mExpectedExpensesText = (TextView)findViewById(R.id.tg_expenses);
        mSellerText = (TextView)findViewById(R.id.tg_seller);
        mLanguageText = (TextView)findViewById(R.id.tg_language);

        mEntertainment = (TextView)findViewById(R.id.theme_entertainment);
        mHealing = (TextView)findViewById(R.id.theme_healing);
        mAdventure = (TextView)findViewById(R.id.theme_adventure);
        mWorking = (TextView)findViewById(R.id.theme_working);
        mCulture = (TextView)findViewById(R.id.theme_culture);
        mMystery = (TextView)findViewById(R.id.theme_mystery);
        mReligious = (TextView)findViewById(R.id.theme_religious);
        mSports = (TextView)findViewById(R.id.theme_sports);
        mShopping = (TextView)findViewById(R.id.theme_shopping);
        mSpecialEvent = (TextView)findViewById(R.id.theme_special_event);

         mHalal = (TextView)findViewById(R.id.food_halal);
         mKosher = (TextView)findViewById(R.id.food_kosher);
         mJain = (TextView)findViewById(R.id.food_jain);
         mHindu = (TextView)findViewById(R.id.food_hindu);
         mNutFree = (TextView)findViewById(R.id.food_nut_free);
         mLactoOvo = (TextView)findViewById(R.id.food_lactoovo);
         mPureVeg = (TextView)findViewById(R.id.food_pure_veg);
         mVegan = (TextView)findViewById(R.id.food_vegan);
         mGlutenFree = (TextView)findViewById(R.id.food_gluten_free);

         mAirplane = (TextView)findViewById(R.id.trans_airplane);
         mBicycle = (TextView)findViewById(R.id.trans_bicycle);
         mBus = (TextView)findViewById(R.id.trans_bus);
         mCar = (TextView)findViewById(R.id.trans_car);
         mMonorail = (TextView)findViewById(R.id.trans_monorail);
         mMotorbicycle = (TextView)findViewById(R.id.trans_motorbicycle);
         mShip = (TextView)findViewById(R.id.trans_ship);
         mSubway = (TextView)findViewById(R.id.trans_subway);
         mTrain = (TextView)findViewById(R.id.trans_train);

        mYoutubeButton = (ImageView)findViewById(R.id.tg_youtube);

        //mProfileSellerNameText = (TextView)findViewById(R.id.profile_name);

        mRatingBar1.setRating(3);
        //mRatingBar2.setRating(3);
        //mRatingBar3.setRating(3);

        /*
        Drawable drawable = getResources().getDrawable(R.drawable.btn_review);
        drawable.setBounds(0, 0, (int) (drawable.getIntrinsicWidth() * 0.6),
                (int) (drawable.getIntrinsicHeight() * 0.6));
        ScaleDrawable sd = new ScaleDrawable(drawable, 0, 40, 40);
        mRatingViewButton.setCompoundDrawables(sd.getDrawable(), null, null, null);
        */

        mBackButton.setOnClickListener(this);
        mRatingViewButton.setOnClickListener(this);
        mAddToWishlistButton.setOnClickListener(this);
        mAskButton.setOnClickListener(this);
        mYoutubeButton.setOnClickListener(this);

        mLeftMoveButton.setOnClickListener(this);
        mRightMoveButton.setOnClickListener(this);

        //http://192.168.0.55/mapeditor/mobile/searchproduct?keywords_var=%EA%B5%AC%EA%B2%BD&per_page=10&page_num=1

        mIntroPhotoList = new ArrayList<String>();
        mPhotoPagerAdapter = new PhotoPagerAdapter(this, mIntroPhotoList);
        mIntroPager.setAdapter(mPhotoPagerAdapter);

        mIntroPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
        {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels)
            {

            }

            @Override
            public void onPageSelected(int position)
            {
                int totalCount = mPhotoPagerAdapter.getCount();

                if(mIntroPager.getCurrentItem() == totalCount -1)
                {
                    mRightMoveButton.setVisibility(View.INVISIBLE);
                }
                else
                {
                    mRightMoveButton.setVisibility(View.VISIBLE);
                }

                if(mIntroPager.getCurrentItem() == 0)
                {
                    mLeftMoveButton.setVisibility(View.INVISIBLE);
                }
                else
                {
                    mLeftMoveButton.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state)
            {

            }
        });

        mPurchase.setOnClickListener(this);
        mPlay.setOnClickListener(this);

        mGeneralApplication.setTick("Intro ui var init");

        mGeneralApplication.setTick("Intro before button");
        Drawable drawable = getResources().getDrawable(R.drawable.btn_review);
        drawable.setBounds(0, 0, (int) (drawable.getIntrinsicWidth() * 0.6),
                (int) (drawable.getIntrinsicHeight() * 0.6));
        ScaleDrawable sd = new ScaleDrawable(drawable, 0, 40, 40);
        mRatingViewButton.setCompoundDrawables(sd.getDrawable(), null, null, null);

        mGeneralApplication.setTick("Intro after button");

        SupportMapFragment tmpFrag = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.tour_place_map));
        tmpFrag.getMapAsync(new OnMapReadyCallback()
        {
            @Override
            public void onMapReady(GoogleMap googleMap)
            {
                mMap = googleMap;

                LatLng geo_point  = new LatLng( 37.000000,  126.000000);
                CameraUpdate tmpUpdate = CameraUpdateFactory.newLatLngZoom(geo_point, 14);
                mMap.moveCamera( tmpUpdate );

                mMap.getUiSettings().setScrollGesturesEnabled(false);
                mMap.getUiSettings().setZoomGesturesEnabled(false);
            }
        });
        mGeneralApplication.setTick("Intro after map");

        loadProductInfo();

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        mGeneralApplication.setTick("Intro loadProductInfo()");

    }


    @Override
    public void onResume()
    {
        super.onResume();

        if(mGeneralApplication.IsLoggedIn() == true)
        {
            String tmpUserIdStr = mGeneralApplication.getIdString();
            mUserDir = Base64.mod_encode(tmpUserIdStr);

            //구매하기 버튼을 보여줘야 하는지 play버튼을 보여줘야 하는지를 결정하는 부분이 필요함..
            //이것을 위해서 내가 구매자인지 아닌지 알수 있는 정보를 서버에서 리턴해야 함
        }

    }

    @Override
    public void onDestroy()
    {
        disposables.dispose();

        super.onDestroy();
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.intro_activity_back_button)
        {
            finish();
        }
        else if (v.getId() == R.id.intro_activity_purchase_button)
        {
            if(mGeneralApplication.IsLoggedIn() == false)
            {
                LoginProcessPopup(new AutoLoginListener()
                {
                    @Override
                    public void onAutoLoginSuccess()
                    {
                        Intent i = new Intent(IntroActivity.this, PaymentActivity.class);
                        i.putExtra(PRODUCT_PURCHASE_KEY, store_price_key);
                        i.putExtra(MAP_SKU, mSkuStr);
                        i.putExtra(MAP_TITLE, mTitleStr);
                        i.putExtra(MAP_PRICE, mProductPrice);
                        i.putExtra(MAP_IMAGE, mProductFirstImageURL);
                        i.putExtra(MAP_LANGUAGE, mStoreLanguage);
                        startActivityForResult(i, REQUEST_PAYMENT_ACT);
                    }

                    @Override
                    public void onAutoLoginFail()
                    {
                        startManualLogin(new LoginListener()
                        {
                            @Override
                            public void onLoginSuccess()
                            {
                                Intent i = new Intent(IntroActivity.this, PaymentActivity.class);
                                i.putExtra(PRODUCT_PURCHASE_KEY, store_price_key);
                                i.putExtra(MAP_SKU, mSkuStr);
                                i.putExtra(MAP_TITLE, mTitleStr);
                                i.putExtra(MAP_PRICE, mProductPrice);
                                i.putExtra(MAP_IMAGE, mProductFirstImageURL);
                                i.putExtra(MAP_LANGUAGE, mStoreLanguage);
                                startActivityForResult(i, REQUEST_PAYMENT_ACT);
                            }

                            @Override
                            public void onLoginCancel()
                            {
                                BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                            }
                        });
                    }
                });
            }
            else
            {
                Intent i = new Intent(IntroActivity.this, PaymentActivity.class);
                i.putExtra(PRODUCT_PURCHASE_KEY, store_price_key);
                i.putExtra(MAP_SKU, mSkuStr);
                i.putExtra(MAP_TITLE, mTitleStr);
                i.putExtra(MAP_PRICE, mProductPrice);
                i.putExtra(MAP_IMAGE, mProductFirstImageURL);
                i.putExtra(MAP_LANGUAGE, mStoreLanguage);
                startActivityForResult(i, REQUEST_PAYMENT_ACT);
            }
        }
        else if (v.getId() == R.id.intro_activity_play_button)
        {
            //Intent i = new Intent(IntroActivity.this, PlayerActivity.class);
            //i.putExtra(MAP_SKU, mSkuStr);
            //startActivity(i);
            setResult(PAYMENT_FINISHED);
            finish();
        }
        else if (v.getId() == R.id.intro_activity_comment_view_button)
        {
            if(mGeneralApplication.IsLoggedIn() == false)
            {
                LoginProcessPopup(new AutoLoginListener()
                {
                    @Override
                    public void onAutoLoginSuccess()
                    {
                        Intent i = new Intent(IntroActivity.this, RatingListActivity.class);
                        i.putExtra(MAP_SKU, mSkuStr);
                        i.putExtra(CategoryListActivity.MAP_TITLE, mTitleStr);
                        startActivity(i);
                    }

                    @Override
                    public void onAutoLoginFail()
                    {
                        startManualLogin(new LoginListener()
                        {
                            @Override
                            public void onLoginSuccess()
                            {
                                Intent i = new Intent(IntroActivity.this, RatingListActivity.class);
                                i.putExtra(MAP_SKU, mSkuStr);
                                i.putExtra(CategoryListActivity.MAP_TITLE, mTitleStr);
                                startActivity(i);
                            }

                            @Override
                            public void onLoginCancel()
                            {
                                BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                            }
                        });
                    }
                });
            }
            else
            {
                Intent i = new Intent(IntroActivity.this, RatingListActivity.class);
                i.putExtra(MAP_SKU, mSkuStr);
                i.putExtra(CategoryListActivity.MAP_TITLE, mTitleStr);
                startActivity(i);
            }
        }
        else if(v.getId() == R.id.intro_activity_wishlist_button)
        {
            if(mIsWishlishOn == true)
            {
                addToWishList("false");
            }
            else
            {
                addToWishList("true");
            }
        }
        else if (v.getId() == R.id.intro_activity_ask_button)
        {
            if(mGeneralApplication.IsLoggedIn() == false)
            {
                LoginProcessPopup(new AutoLoginListener()
                {
                    @Override
                    public void onAutoLoginSuccess()
                    {
                        Intent i = new Intent(IntroActivity.this, MessageActivity.class);
                        //mServerTime = bd.getString(FriendListActivity.SERVER_TIME);
                        //mFriendId = bd.getString(FriendListActivity.FRIEND_ID);
                        i.putExtra(FriendListActivity.FRIEND_NAME, mSellerName);
                        i.putExtra(FriendListActivity.SERVER_TIME, "0");
                        i.putExtra(FriendListActivity.FRIEND_ID, mSellerId);
                        startActivity(i);
                    }

                    @Override
                    public void onAutoLoginFail()
                    {
                        startManualLogin(new LoginListener()
                        {
                            @Override
                            public void onLoginSuccess()
                            {
                                Intent i = new Intent(IntroActivity.this, MessageActivity.class);
                                //mServerTime = bd.getString(FriendListActivity.SERVER_TIME);
                                //mFriendId = bd.getString(FriendListActivity.FRIEND_ID);
                                i.putExtra(FriendListActivity.FRIEND_NAME, mSellerName);
                                i.putExtra(FriendListActivity.SERVER_TIME, "0");
                                i.putExtra(FriendListActivity.FRIEND_ID, mSellerId);
                                startActivity(i);
                            }

                            @Override
                            public void onLoginCancel()
                            {
                                BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                            }
                        });
                    }
                });
            }
            else
            {
                String myIdStr = mGeneralApplication.getNumString();
                if(myIdStr != null && myIdStr.equals(mSellerId) == true)
                {
                    BaseLib().showGeneralPopup(getString(R.string.chatting_is_not_possible), getString(R.string.chatting_is_only_possible_to_others), null);
                }
                else
                {
                    Intent i = new Intent(IntroActivity.this, MessageActivity.class);
                    //mServerTime = bd.getString(FriendListActivity.SERVER_TIME);
                    //mFriendId = bd.getString(FriendListActivity.FRIEND_ID);
                    i.putExtra(FriendListActivity.FRIEND_NAME, mSellerName);
                    i.putExtra(FriendListActivity.SERVER_TIME, "0");
                    i.putExtra(FriendListActivity.FRIEND_ID, mSellerId);
                    startActivity(i);
                }
            }
        }
        else if (v.getId() == R.id.tg_youtube)
        {
            if(mYoutubeVideoLink != null && "".equals(mYoutubeVideoLink) == false)
            {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://" + mYoutubeVideoLink));
                startActivity(browserIntent);
            }
        }
        else if (v.getId() == R.id.photo_left_button)
        {
            int currentItemIndex = mIntroPager.getCurrentItem();
            int totalCount = mPhotoPagerAdapter.getCount();

            if(currentItemIndex > 0)
            {
                mIntroPager.setCurrentItem(--currentItemIndex);
            }

            if(mIntroPager.getCurrentItem() == 0)
            {
               mLeftMoveButton.setVisibility(View.INVISIBLE);
            }
            else
            {
                mLeftMoveButton.setVisibility(View.VISIBLE);
            }

            if(mIntroPager.getCurrentItem() == totalCount -1)
            {
                mRightMoveButton.setVisibility(View.INVISIBLE);
            }
            else
            {
                mRightMoveButton.setVisibility(View.VISIBLE);
            }
        }
        else if (v.getId() == R.id.photo_right_button)
        {
            int currentItemIndex = mIntroPager.getCurrentItem();
            int totalCount = mPhotoPagerAdapter.getCount();

            if(totalCount-1 > currentItemIndex)
            {
                mIntroPager.setCurrentItem(++currentItemIndex);
            }

            if(mIntroPager.getCurrentItem() == totalCount -1)
            {
                mRightMoveButton.setVisibility(View.INVISIBLE);
            }
            else
            {
                mRightMoveButton.setVisibility(View.VISIBLE);
            }

            if(mIntroPager.getCurrentItem() == 0)
            {
                mLeftMoveButton.setVisibility(View.INVISIBLE);
            }
            else
            {
                mLeftMoveButton.setVisibility(View.VISIBLE);
            }
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_PAYMENT_ACT)
        {

        }
        else if(resultCode == PaymentActivity.PAYMENT_CANCELLED)
        {

        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
        else if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
    }

    private void addToWishList(String on_flag)
    {
        mWeb.addToWishlist(mSkuStr, on_flag,
                new Consumer<ResponseSimpleData>()
                {
                    @Override
                    public void accept(ResponseSimpleData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        String serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            if("true".equals(on_flag) == true)
                            {
                                mIsWishlishOn = true;

                                BaseLib().showGeneralPopup(getString(R.string.success_title), getString(R.string.added_to_wishlist),
                                        new GeneralAlarmButtonListener()
                                        {
                                            @Override
                                            public void onButtonClickListener(View v, int id, int button)
                                            {
                                                mAddToWishlistButton.setBackgroundResource(R.drawable.wishlist);
                                            }
                                        });
                            }
                            else
                            {
                                BaseLib().showGeneralPopup(getString(R.string.success_title), getString(R.string.remove_from_wishlist),
                                        new GeneralAlarmButtonListener()
                                        {
                                            @Override
                                            public void onButtonClickListener(View v, int id, int button)
                                            {
                                                mAddToWishlistButton.setBackgroundResource(R.drawable.wishlist_off);
                                            }
                                        });

                                mIsWishlishOn = false;
                            }
                        }
                        else if(serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    addToWishList(on_flag);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            addToWishList(on_flag);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });

                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    addToWishList(on_flag);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            addToWishList(on_flag);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void loadProductInfo()
    {
        String tmpLanguage = mWeb.getLanguage();
        mLanguageText.setText(tmpLanguage);

        mWeb.getProductInfo(mSkuStr,
                new Consumer<ResponseProductData>()
                {
                    @Override
                    public void accept(ResponseProductData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Product serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mIntroPhotoList.clear();

                            String skuStr = serverData.getSku();
                            String nameStr = serverData.getName();
                            String descStr = serverData.getDesc();

                            if(serverData.isWishlistAdded() == true)
                            {
                                mAddToWishlistButton.setBackgroundResource(R.drawable.wishlist);
                                mIsWishlishOn = true;
                            }
                            else
                            {
                                mAddToWishlistButton.setBackgroundResource(R.drawable.wishlist_off);
                                mIsWishlishOn = false;
                            }

                            mTitleStr = nameStr;

                            mTitleText.setText(mTitleStr);

                            mIntroTitleText.setText(nameStr);
                            mIntroDescText.setText(descStr);

                            mLatitude = serverData.getLat();
                            mLongitude = serverData.getLng();
                            mDistance = serverData.getDistance();

                            if(mDistance != null && mDistance.equals("") == false && mDistance.equals("0") == false)
                            {
                                if ((mLatitude != null && mLatitude.equals("") == false)
                                        && (mLongitude != null && mLongitude.equals("") == false)
                                        )
                                {
                                    double tmp_lat = Double.valueOf(mLatitude);
                                    double tmp_lng = Double.valueOf(mLongitude);
                                    double tmp_distance = Double.valueOf(mDistance);

                                    CircleOptions tmpCircleOpt = new CircleOptions()
                                            .center(new LatLng(tmp_lat, tmp_lng))
                                            .radius(tmp_distance)
                                            .strokeColor(0xA0FFFF00)
                                            .fillColor(0x60FFFF00);

                                    Circle circle = mMap.addCircle(tmpCircleOpt);

                                    int tmpZoomLevel = getZoomLevel(circle)-2;
                                    if(tmpZoomLevel <= 1)
                                    {
                                        tmpZoomLevel = 2;
                                    }

                                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom( tmpCircleOpt.getCenter(), tmpZoomLevel ));
                                }
                            }
                            else
                            {
                                mMapLayout.setVisibility(View.GONE);
                            }

                            String imageUrlStr = serverData.getImage1();
                            if(imageUrlStr != null && imageUrlStr.equals("") == false)
                            {
                                mIntroPhotoList.add(imageUrlStr);
                                mProductFirstImageURL = imageUrlStr;
                            }

                            imageUrlStr = serverData.getImage2();
                            if(imageUrlStr != null && imageUrlStr.equals("") == false)
                            {
                                mIntroPhotoList.add(imageUrlStr);
                            }

                            imageUrlStr = serverData.getImage3();
                            if(imageUrlStr != null && imageUrlStr.equals("") == false)
                            {
                                mIntroPhotoList.add(imageUrlStr);
                            }

                            String priceStr = serverData.getPrice();
                            store_price_key = getStorePriceKey(priceStr);

                            int ratingCount = serverData.getRatingCount();

                            mRatingViewButton.setText(String.format(getString(R.string.customer_reviews), ratingCount));
                            //mRatingViewButton.setText(String.format("%d", ratingCount) + "개의 평가글");

                            int tmpRating1 = Integer.valueOf(serverData.getRating1());
                            //int tmpRating2 = Integer.valueOf(serverData.getRating2());

                            mRatingBar1.setIndicator(true);
                            //mRatingBar2.setIndicator(true);

                            if(tmpRating1 != 0)
                            {
                                mRatingText1.setVisibility(View.VISIBLE);
                                mRatingBar1.setVisibility(View.VISIBLE);

                                mRatingBar1.setRating(tmpRating1);
                            }
                            else
                            {
                                mRatingText1.setVisibility(View.INVISIBLE);
                                mRatingBar1.setVisibility(View.INVISIBLE);
                            }

                            /*
                            if(tmpRating2 != 0)
                            {
                                mRatingText2.setVisibility(View.VISIBLE);
                                //mRatingBar2.setVisibility(View.VISIBLE);

                                //mRatingBar2.setRating(tmpRating2);
                            }
                            else
                            {
                                mRatingText2.setVisibility(View.INVISIBLE);
                                //mRatingBar2.setVisibility(View.INVISIBLE);
                            }
                            */

                            mSellerId = serverData.getMapSellerId();
                            mSellerName = serverData.getMapSellerName();

                            String tmpThemeTypes = serverData.getMapThemedType();
                            if((tmpThemeTypes != null) && ("".equals(tmpThemeTypes) == false))
                            {
                                String server_themed_types[] = tmpThemeTypes.split(",");

                                for(int x = 0; x < server_themed_types.length; x++)
                                {
                                    switch(server_themed_types[x])
                                    {
                                        case "41":
                                            mAdventure.setBackgroundResource(R.drawable.option_enabled);
                                            mAdventure.setTextColor(0xffffffff);
                                            break;

                                        case "44":
                                            mCulture.setBackgroundResource(R.drawable.option_enabled);
                                            mCulture.setTextColor(0xffffffff);
                                            break;

                                        case "43":
                                            mEntertainment.setBackgroundResource(R.drawable.option_enabled);
                                            mEntertainment.setTextColor(0xffffffff);
                                            break;

                                        case "34":
                                            mHealing.setBackgroundResource(R.drawable.option_enabled);
                                            mHealing.setTextColor(0xffffffff);
                                            break;

                                        case "39":
                                            mMystery.setBackgroundResource(R.drawable.option_enabled);
                                            mMystery.setTextColor(0xffffffff);
                                            break;

                                        case "42":
                                            mReligious.setBackgroundResource(R.drawable.option_enabled);
                                            mReligious.setTextColor(0xffffffff);
                                            break;

                                        case "37":
                                            mShopping.setBackgroundResource(R.drawable.option_enabled);
                                            mShopping.setTextColor(0xffffffff);
                                            break;

                                        case "40":
                                            mSpecialEvent.setBackgroundResource(R.drawable.option_enabled);
                                            mSpecialEvent.setTextColor(0xffffffff);
                                            break;

                                        case "38":
                                            mSports.setBackgroundResource(R.drawable.option_enabled);
                                            mSports.setTextColor(0xffffffff);
                                            break;

                                        case "35":
                                            mWorking.setBackgroundResource(R.drawable.option_enabled);
                                            mWorking.setTextColor(0xffffffff);
                                            break;
                                        default:
                                            continue;
                                    }
                                }
                            }

                            String tmpFoodTypes = serverData.getMapSpecialFoodType();
                            if((tmpFoodTypes != null) && ("".equals(tmpFoodTypes) == false))
                            {
                                String server_food_types[] = tmpFoodTypes.split(",");

                                for(int x = 0; x < server_food_types.length; x++)
                                {
                                    switch(server_food_types[x])
                                    {
                                        case "18":
                                            mGlutenFree.setBackgroundResource(R.drawable.option_enabled);
                                            mGlutenFree.setTextColor(0xffffffff);
                                            break;

                                        case "17":
                                            mNutFree.setBackgroundResource(R.drawable.option_enabled);
                                            mNutFree.setTextColor(0xffffffff);
                                            break;

                                        case "21":
                                            mHalal.setBackgroundResource(R.drawable.option_enabled);
                                            mHalal.setTextColor(0xffffffff);
                                            break;

                                        case "20":
                                            mHindu.setBackgroundResource(R.drawable.option_enabled);
                                            mHindu.setTextColor(0xffffffff);
                                            break;

                                        case "19":
                                            mKosher.setBackgroundResource(R.drawable.option_enabled);
                                            mKosher.setTextColor(0xffffffff);
                                            break;

                                        case "24":
                                            mLactoOvo.setBackgroundResource(R.drawable.option_enabled);
                                            mLactoOvo.setTextColor(0xffffffff);
                                            break;

                                        case "23":
                                            mPureVeg.setBackgroundResource(R.drawable.option_enabled);
                                            mPureVeg.setTextColor(0xffffffff);
                                            break;

                                        case "22":
                                            mVegan.setBackgroundResource(R.drawable.option_enabled);
                                            mVegan.setTextColor(0xffffffff);
                                            break;

                                        case "45":
                                            mJain.setBackgroundResource(R.drawable.option_enabled);
                                            mJain.setTextColor(0xffffffff);
                                            break;

                                        default:
                                            continue;
                                    }

                                }
                            }

                            String tmpTransTypes = serverData.getMapTransType();
                            if((tmpTransTypes != null) && ("".equals(tmpTransTypes) == false))
                            {
                                String server_trans_types[] = tmpTransTypes.split(",");

                                for(int x = 0; x < server_trans_types.length; x++)
                                {
                                    switch(server_trans_types[x])
                                    {
                                        case "30":
                                            mAirplane.setBackgroundResource(R.drawable.option_enabled);
                                            mAirplane.setTextColor(0xffffffff);
                                            break;

                                        case "27":
                                            mBicycle.setBackgroundResource(R.drawable.option_enabled);
                                            mBicycle.setTextColor(0xffffffff);
                                            break;

                                        case "32":
                                            mBus.setBackgroundResource(R.drawable.option_enabled);
                                            mBus.setTextColor(0xffffffff);
                                            break;

                                        case "25":
                                            mCar.setBackgroundResource(R.drawable.option_enabled);
                                            mCar.setTextColor(0xffffffff);
                                            break;

                                        case "29":
                                            mMonorail.setBackgroundResource(R.drawable.option_enabled);
                                            mMonorail.setTextColor(0xffffffff);
                                            break;

                                        case "26":
                                            mMotorbicycle.setBackgroundResource(R.drawable.option_enabled);
                                            mMotorbicycle.setTextColor(0xffffffff);
                                            break;

                                        case "28":
                                            mShip.setBackgroundResource(R.drawable.option_enabled);
                                            mShip.setTextColor(0xffffffff);
                                            break;

                                        case "31":
                                            mSubway.setBackgroundResource(R.drawable.option_enabled);
                                            mSubway.setTextColor(0xffffffff);
                                            break;

                                        case "33":
                                            mTrain.setBackgroundResource(R.drawable.option_enabled);
                                            mTrain.setTextColor(0xffffffff);
                                            break;

                                        default:
                                            continue;
                                    }
                                }
                            }

                            String tmpDuration = serverData.getMapRequiredDuration();
                            if((tmpDuration != null) && ("".equals(tmpDuration) == false))
                            {
                                switch(tmpDuration)
                                {
                                    case "16":
                                        mTotalDurationText.setText(getString(R.string.less_than_3_hours));
                                        break;

                                    case "15":
                                        mTotalDurationText.setText(getString(R.string.less_than_6_hours));
                                        break;

                                    case "14":
                                        mTotalDurationText.setText(getString(R.string.less_than_1_day));
                                        break;

                                    case "13":
                                        mTotalDurationText.setText(getString(R.string.less_than_2_days));
                                        break;

                                    case "12":
                                        mTotalDurationText.setText(getString(R.string.less_than_3_days));
                                        break;

                                    case "11":
                                        mTotalDurationText.setText(getString(R.string.less_than_a_week));
                                        break;

                                    case "10":
                                        mTotalDurationText.setText(getString(R.string.less_than_10_days));
                                        break;

                                    case "9":
                                        mTotalDurationText.setText(getString(R.string.less_than_2_weeks));
                                        break;

                                    case "8":
                                        mTotalDurationText.setText(getString(R.string.less_than_3_weeks));
                                        break;

                                    case "7":
                                        mTotalDurationText.setText(getString(R.string.less_than_a_month));
                                        break;

                                    case "6":
                                        mTotalDurationText.setText(getString(R.string.less_than_2_months));
                                        break;

                                    case "5":
                                        mTotalDurationText.setText(getString(R.string.less_than_3_months));
                                        break;

                                    case "4":
                                        mTotalDurationText.setText(getString(R.string.more_than_3_months));
                                        break;
                                    default:
                                        break;
                                }
                            }

                            String tmpPrice = serverData.getPrice();
                            if((tmpPrice != null) && ("".equals(tmpPrice) == false))
                            {
                                mPriceText.setText("$" + tmpPrice);
                                mTitlePriceText.setText("$" + tmpPrice);
                                mProductPrice = "$" + tmpPrice;
                            }

                            String tmpExpectedExpenses = serverData.getMapExpectedExpenses();
                            if((tmpExpectedExpenses != null) && ("".equals(tmpExpectedExpenses) == false))
                            {
                                mExpectedExpensesText.setText("$" + tmpExpectedExpenses);
                            }

                            String tmpSeller = serverData.getMapSellerName();
                            if((tmpSeller != null) && ("".equals(tmpSeller) == false))
                            {
                                mSellerText.setText(tmpSeller);
                            }

                            mYoutubeVideoLink = serverData.getVideoLink();
                            if(mYoutubeVideoLink != null && "".equals(mYoutubeVideoLink) == false)
                            {
                                mYoutubeButton.setImageResource(R.drawable.btn_youtube_on);
                            }
                            else
                            {
                                mYoutubeButton.setImageResource(R.drawable.btn_youtube_off);
                            }

                            int totalCount = mPhotoPagerAdapter.getCount();

                            if(totalCount > 1)
                            {
                                mLeftMoveButton.setVisibility(View.INVISIBLE);
                                mRightMoveButton.setVisibility(View.VISIBLE);
                            }
                            else
                            {
                                mLeftMoveButton.setVisibility(View.INVISIBLE);
                                mRightMoveButton.setVisibility(View.INVISIBLE);
                            }

                            mStoreLanguage = serverData.getStoreLanaguage();

                            mPhotoPagerAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.

                    }
                }, disposables
        );
    }

    public static double calculateCircleRadiusMeterForMapCircle(final int _targetRadiusDip, final double _circleCenterLatitude, final float _currentMapZoom)
    {
        //That base value seems to work for computing the meter length of a DIP
        final double arbitraryValueForDip = 156000D;
        final double oneDipDistance = Math.abs(Math.cos(Math.toRadians(_circleCenterLatitude))) * arbitraryValueForDip / Math.pow(2, _currentMapZoom);
        return oneDipDistance * (double) _targetRadiusDip;
    }
    public static LatLng computeOffset(LatLng from, double distance, double heading)
    {
        double EARTH_RADIUS = 6378100.0;

        distance /= EARTH_RADIUS;
        heading = toRadians(heading);
        // http://williams.best.vwh.net/avform.htm#LL
        double fromLat = toRadians(from.latitude);
        double fromLng = toRadians(from.longitude);
        double cosDistance = cos(distance);
        double sinDistance = sin(distance);
        double sinFromLat = sin(fromLat);
        double cosFromLat = cos(fromLat);
        double sinLat = cosDistance * sinFromLat + sinDistance * cosFromLat * cos(heading);
        double dLng = atan2(
                sinDistance * cosFromLat * sin(heading),
                cosDistance - sinFromLat * sinLat);
        return new LatLng(toDegrees(asin(sinLat)), toDegrees(fromLng + dLng));
    }

    public LatLngBounds toBounds(LatLng center, double radius)
    {
        LatLng southwest = computeOffset(center, radius * Math.sqrt(2.0), 225);
        LatLng northeast = computeOffset(center, radius * Math.sqrt(2.0), 45);
        return new LatLngBounds(southwest, northeast);
    }

    public int getZoomLevel(Circle circle)
    {
        int zoomLevel = 11;
        if (circle != null) {
            double radius = circle.getRadius() + circle.getRadius() / 2;
            double scale = radius / 500;
            zoomLevel = (int) (16 - Math.log(scale) / Math.log(2));
        }
        return zoomLevel;
    }

    private String getStorePriceKey(String priceStr)
    {
        String resultStr = "";

        float resultFloat = Float.valueOf(priceStr);
        int resultInt = (int)resultFloat;

        resultStr = "tgm_price_usd_" + String.format("%d", resultInt);
        return resultStr;
    }

}
