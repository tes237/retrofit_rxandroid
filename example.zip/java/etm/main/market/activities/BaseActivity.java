package etm.main.market.activities;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.facebook.AccessToken;
import com.facebook.GraphResponse;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;

import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.LocalFirebaseMessagingService;
import etm.main.market.baseDefine;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.dialog.TermsDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.social.FacebookHelper;
import etm.main.market.vo.CustomerInfo;
import etm.main.market.vo.ResponseDummyData;
import etm.main.market.vo.ResponseLoginData;
import etm.main.market.vo.ResponseRegisterData;

public class BaseActivity extends AppCompatActivity
{
    private static final String TAG = BaseActivity.class.getSimpleName();

    public static final String BASE_JSON_SUCCESS = "success";
    public static final String BASE_JSON_FAIL = "fail";
    public static final String BASE_JSON_LOGOUT = "logout";

    public static final String BASE_DEV_AND = "1";

    public static int BASE_LOGIN_ACTIVITY_TYPE = 3001;
    public static int BASE_LOGIN_RESULT_SUCCESS = 1001;
    public static int BASE_LOGIN_RESULT_CANCEL = 1002;

    private GeneralAlarmDialog mBaseAlarmDialog = null;

    private BaseActivity mCurrentActivity = null;
    private generalApplication mBaseGeneralApp = null;
    private DBAdapter mBaseDBAdapter = null;
    private WebManager mBaseWeb = null;
    private FacebookHelper mBaseFacebookHelper = null;
    private CompositeDisposable mBaseCompositeDisposable = null;

    public LoginListener mBaseLibLoginListener = null;
    public BooleanWrapper mBaseFBBooleanWrapper = null;

    private TermsDialog mScrollDialog;
    private GeneralAlarmButtonListener mGeneralAlarmButtonListener;

    protected void initBaseLib(BaseActivity tmpAct, generalApplication tmpGlobal, DBAdapter tmpDB, WebManager tmpWeb, CompositeDisposable tmpDisposable, BooleanWrapper tmpFBBoolean)
    {
        mCurrentActivity = tmpAct;
        mBaseGeneralApp = tmpGlobal;
        mBaseDBAdapter = tmpDB;
        mBaseWeb = tmpWeb;
        mBaseCompositeDisposable = tmpDisposable;
        mBaseFBBooleanWrapper = tmpFBBoolean;
    }

    protected BaseActivity BaseLib()
    {
        return this;
    }

    protected void showGeneralPopup(String title, String message, GeneralAlarmButtonListener tmpListener)
    {
        FragmentManager fm = getFragmentManager();
        if(mBaseAlarmDialog != null)
        {
            mBaseAlarmDialog.dismiss();
            mBaseAlarmDialog = null;
        }
        mBaseAlarmDialog = new GeneralAlarmDialog();
        mBaseAlarmDialog.setTitleText(title);
        mBaseAlarmDialog.setMessageText(message);
        mBaseAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        if(tmpListener == null)
        {
            mBaseAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
            {
                @Override
                public void onButtonClickListener(View v, int id, int button) {

                }
            });
        }
        else
        {
            mBaseAlarmDialog.setButtonListener(tmpListener);
        }
        mBaseAlarmDialog.show(fm, "tag");
        return;
    }

    public void LoginProcessPopup(AutoLoginListener autologinEvent)
    {
        Cursor login_cursor = mBaseDBAdapter.getLoginType();
        if(login_cursor != null && login_cursor.moveToFirst())
        {
            final String type_var = login_cursor.getString(login_cursor.getColumnIndex(DBAdapter.SERVICE_TYPE));
            if(type_var == null || "".equals(type_var) == true)
            {
                autologinEvent.onAutoLoginFail();
                return;
            }
            final String flag_var = login_cursor.getString(login_cursor.getColumnIndex(DBAdapter.AUTO_LOGIN_FLAG));
            if(flag_var == null || LoginActivity.AUTO_LOGIN_FALSE.equals(flag_var) == true || "".equals(flag_var) == true)
            {
                autologinEvent.onAutoLoginFail();
                return;
            }

            if(LoginActivity.LOGIN_TYPE_TGM.equals(type_var) == true)
            {
                Cursor search_cursor = mBaseDBAdapter.getAutoLoginCheck();
                if(search_cursor != null && search_cursor.moveToFirst())
                {
                    final String id_var = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.ID_TEXT));
                    if(id_var == null || "".equals(id_var) == true)
                    {
                        autologinEvent.onAutoLoginFail();
                        return;
                    }
                    final String pw_var = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.PW_TEXT));
                    if(pw_var == null || "".equals(pw_var) == true)
                    {
                        autologinEvent.onAutoLoginFail();
                        return;
                    }

                    final String refreshedToken = FirebaseInstanceId.getInstance().getToken();

                    mBaseWeb.login(id_var, pw_var, BASE_DEV_AND, refreshedToken,
                            new Consumer<ResponseLoginData>()
                            {
                                @Override
                                public void accept(ResponseLoginData loginDatas) throws Exception
                                {
                                    // TODO: Handle response.
                                    String serverResult = loginDatas.getResult();
                                    CustomerInfo serverData = loginDatas.getData();

                                    //pd.dismiss();
                                    if(serverResult.equals(BASE_JSON_SUCCESS))
                                    {

                                        mBaseWeb.setCookieState(false);
                                        mBaseGeneralApp.setIdString(id_var);
                                        mBaseGeneralApp.setNumString(serverData.getCustomer_id());

                                        if( "1".equals(serverData.getTerms_agree()) )
                                        {
                                            mBaseGeneralApp.setIsTermsAgreed(true);
                                        }
                                        else
                                        {
                                            mBaseGeneralApp.setIsTermsAgreed(false);
                                        }

                                        if( "1".equals(serverData.getPrivacy_agree()) )
                                        {
                                            mBaseGeneralApp.setIsPrivacyAgreed(true);
                                        }
                                        else
                                        {
                                            mBaseGeneralApp.setIsPrivacyAgreed(false);
                                        }

                                        LocalFirebaseMessagingService.setMyId(serverData.getCustomer_id());

                                        mBaseGeneralApp.setLoggedIn(true);

                                        autologinEvent.onAutoLoginSuccess();
                                    }
                                    else //if(serverResult.equals(JSON_FAIL))
                                    {
                                        autologinEvent.onAutoLoginFail();
                                    }
                                }
                            }
                            ,new Consumer<Throwable>()
                            {
                                @Override
                                public void accept(@NonNull Throwable throwable) throws Exception
                                {
                                    // TODO: Handle error.
                                    //pd.dismiss();
                                    mBaseWeb.setCookieState(false);
                                    autologinEvent.onAutoLoginFail();
                                }
                            }, mBaseCompositeDisposable
                    );
                }
                else
                {
                    autologinEvent.onAutoLoginFail();
                    return;
                }
            }
            else if(LoginActivity.LOGIN_TYPE_FB.equals(type_var) == true)
            {
                mBaseFBBooleanWrapper.setBoolean(true);

                //generateKey(this);
                mBaseFacebookHelper = new FacebookHelper(mCurrentActivity, new FacebookHelper.OnFbSignInListener()
                {
                    @Override
                    public void OnFbSignInComplete(GraphResponse graphResponse, String error) {

                        if (error == null)
                        {
                            try
                            {
                                JSONObject jsonObject = graphResponse.getJSONObject();
                                final String nameStr = jsonObject.getString("name");
                                final String firstNameStr = jsonObject.getString("first_name");
                                final String lastNameStr = jsonObject.getString("last_name");
                                final String emailStr = jsonObject.getString("email");
                                final String fb_id = jsonObject.getString("id");
                                final String profileImg = "http://graph.facebook.com/" + fb_id + "/picture?type=large";

                                AccessToken tmpAccessToken = AccessToken.getCurrentAccessToken();
                                String tmpFBTokenStr = tmpAccessToken.getToken();

                                final String refreshedToken = FirebaseInstanceId.getInstance().getToken();

                                mBaseWeb.facebook_login(tmpFBTokenStr, fb_id, firstNameStr, lastNameStr, emailStr, BASE_DEV_AND, refreshedToken,
                                        new Consumer<ResponseLoginData>()
                                        {
                                            @Override
                                            public void accept(ResponseLoginData loginDatas) throws Exception
                                            {
                                                // TODO: Handle response.
                                                String serverResult = loginDatas.getResult();
                                                CustomerInfo serverData = loginDatas.getData();

                                                if(serverResult.equals(BASE_JSON_SUCCESS))
                                                {
                                                    mBaseWeb.setCookieState(false);
                                                    mBaseGeneralApp.setIdString(emailStr);
                                                    mBaseGeneralApp.setNumString(serverData.getCustomer_id());

                                                    if( "1".equals(serverData.getTerms_agree()) )
                                                    {
                                                        mBaseGeneralApp.setIsTermsAgreed(true);
                                                    }
                                                    else
                                                    {
                                                        mBaseGeneralApp.setIsTermsAgreed(false);
                                                    }

                                                    if( "1".equals(serverData.getPrivacy_agree()) )
                                                    {
                                                        mBaseGeneralApp.setIsPrivacyAgreed(true);
                                                    }
                                                    else
                                                    {
                                                        mBaseGeneralApp.setIsPrivacyAgreed(false);
                                                    }

                                                    LocalFirebaseMessagingService.setMyId(serverData.getCustomer_id());

                                                    mBaseGeneralApp.setLoggedIn(true);

                                                    autologinEvent.onAutoLoginSuccess();
                                                    return;
                                                }
                                                else //if(serverResult.equals(JSON_FAIL))
                                                {
                                                    autologinEvent.onAutoLoginFail();
                                                    return;
                                                }
                                            }
                                        }
                                        ,new Consumer<Throwable>()
                                        {
                                            @Override
                                            public void accept(@NonNull Throwable throwable) throws Exception
                                            {
                                                // TODO: Handle error.
                                                mBaseWeb.setCookieState(false);
                                                autologinEvent.onAutoLoginFail();
                                                return;
                                            }
                                        }, mBaseCompositeDisposable
                                );

                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                                autologinEvent.onAutoLoginFail();
                                return;
                            }
                        }
                    }
                });

                /*
                gSignInHelper = new GooglePlusHelper(HomeActivity.this, new GooglePlusHelper.OnGoogleSignInListener()
                {
                    @Override
                    public void OnGSignInComplete(Person mPerson, String emailAddress, String error)
                    {
                        if (mPerson != null)
                        {
                            String displayName = mPerson.getDisplayName();
                        }

                        if (emailAddress != null)
                        {
                            String emailName = emailAddress;
                        }
                    }
                });
                */

                mBaseFacebookHelper.connect();

            }
            else
            {
                autologinEvent.onAutoLoginFail();
                return;
            }
        }
        else
        {
            autologinEvent.onAutoLoginFail();
            return;
        }
    }

    public void startManualLogin(LoginListener loginEvent)
    {
        mBaseLibLoginListener = loginEvent;

        FragmentManager fm = getFragmentManager();
        if(mBaseAlarmDialog != null)
        {
            mBaseAlarmDialog.dismiss();
            mBaseAlarmDialog = null;
        }
        mBaseAlarmDialog = new GeneralAlarmDialog();
        mBaseAlarmDialog.setTitleText(getString(R.string.login_is_needed));
        mBaseAlarmDialog.setMessageText(getString(R.string.lets_go_to_login_dialog));
        mBaseAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        mBaseAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
        {
            @Override
            public void onButtonClickListener(View v, int id, int button)
            {
                if(button == GeneralAlarmDialog.CANCEL_BUTTON)
                {

                }
                else
                {
                    Intent login_intent = new Intent(mCurrentActivity, LoginActivity.class);
                    startActivityForResult(login_intent, BASE_LOGIN_ACTIVITY_TYPE);
                }
            }
        });
        mBaseAlarmDialog.show(fm, "tag");
    }

    public void baseFBOnActivityResult(int requestCode, int resultCode, Intent data)
    {
        mBaseFacebookHelper.onActivityResult(requestCode, resultCode, data);
    }

    public void showScrollDialog(String title, String message, GeneralAlarmButtonListener tmpListener)
    {
        FragmentManager fm = getFragmentManager();
        if(mScrollDialog != null)
        {
            mScrollDialog.dismiss();
            mScrollDialog = null;
        }
        mScrollDialog = new TermsDialog();
        mScrollDialog.setTitleText(title);
        mScrollDialog.setMessageText(message);
        mScrollDialog.setCancelable(false);
        mScrollDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        if(mGeneralAlarmButtonListener == null)
        {
            mScrollDialog.setButtonListener(tmpListener);
        }
        else
        {
            mScrollDialog.setButtonListener(mGeneralAlarmButtonListener);
        }
        mScrollDialog.show(fm, "tag");
        return;
    }

    public void getTerms()
    {
        mBaseWeb.getTermOfUse(
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();

                        if(serverResult.equals(BASE_JSON_SUCCESS))
                        {
                            String decodedStr = URLDecoder.decode(objDatas.getData(), "utf-8");

                            showScrollDialog(getString(R.string.agree_terms), decodedStr, new GeneralAlarmButtonListener()
                            {
                                @Override
                                public void onButtonClickListener(View v, int id, int button)
                                {
                                    agreeTerms();

                                    if(mBaseGeneralApp.isPrivacyAgreed() == false)
                                    {
                                        getPrivacyPolicy();
                                    }
                                }
                            });
                        }
                        else if(serverResult.equals(BASE_JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mBaseGeneralApp.getResultString(objDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.

                    }
                }, mBaseCompositeDisposable
        );
    }

    public void getPrivacyPolicy()
    {
        mBaseWeb.getPrivacyPolicy(
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();

                        if(serverResult.equals(BASE_JSON_SUCCESS))
                        {
                            String decodedStr = URLDecoder.decode(objDatas.getData(), "utf-8");

                            showScrollDialog(getString(R.string.agree_privacy_policy), decodedStr, new GeneralAlarmButtonListener()
                            {
                                @Override
                                public void onButtonClickListener(View v, int id, int button)
                                {
                                    agreePrivacy();
                                }
                            });
                        }
                        else if(serverResult.equals(BASE_JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mBaseGeneralApp.getResultString(objDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.

                    }
                }, mBaseCompositeDisposable
        );
    }

    public void agreeTerms()
    {
        mBaseWeb.agreeTerms(
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        String serverData = objDatas.getData();

                        if(serverResult.equals(BASE_JSON_SUCCESS))
                        {
                            mBaseGeneralApp.setIsTermsAgreed(true);
                        }
                        else //if(serverResult.equals(JSON_FAIL))
                        {

                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                    }
                }, mBaseCompositeDisposable
        );
    }

    public void agreePrivacy()
    {
        mBaseWeb.agreePrivacy(
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        String serverData = objDatas.getData();

                        if(serverResult.equals(BASE_JSON_SUCCESS))
                        {
                            mBaseGeneralApp.setIsPrivacyAgreed(true);
                        }
                        else //if(serverResult.equals(JSON_FAIL))
                        {

                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                    }
                }, mBaseCompositeDisposable
        );
    }
}
