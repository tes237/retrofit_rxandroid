package etm.main.market.activities;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.FragmentManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import etm.main.market.common.Base64;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.dialog.SpotOptionDialog;
import etm.main.market.generalApplication;
import etm.main.market.baseDefine;
import etm.main.market.graphs.Edge;
import etm.main.market.graphs.Graph;
import etm.main.market.graphs.GraphSearch;
import etm.main.market.graphs.VertexGroup;
import etm.main.market.lists.EventListAdapter;
import etm.main.market.lists.SpotListAdapter;
import etm.main.market.lists.SpotOptionListener;
import etm.main.market.lists.NodeChangeListener;
import etm.main.market.parser.json.JsonParser;

import etm.main.market.receiver.RemoteControlReceiver;
import etm.main.market.vo.ServerMapData;
import etm.main.market.vo.ServerMapEventData;
import etm.main.market.vo.ServerMapLineData;
import etm.main.market.vo.ServerMapRouteData;
import etm.main.market.vo.ServerMapSpotData;
import etm.main.market.vo.ServerMapTextData;
import etm.main.market.widgets.TouchImageView;
import etm.main.market.widgets.TouchViewListener;
//import etm.main.market.widgets.nodebar.BalloonImageGalleryBar;
import etm.main.market.widgets.nodebar.NodeProgressBar;

import etm.main.market.R;

public class PlayerActivity extends AppCompatActivity implements TextToSpeech.OnInitListener,
        View.OnClickListener, NodeChangeListener, SpotOptionListener, CompoundButton.OnCheckedChangeListener, TouchViewListener,
        MediaController.MediaPlayerControl, SurfaceHolder.Callback, baseDefine
{
    private static final String TAG = PlayerActivity.class.getSimpleName();

    //private static final int INTRO_TYPE = 3;

    //private static final int MOVEMENT_CATEGORY = 100;
    private static final int MOVEMENT_TYPE = 4;

    private static final int ROUTE_NODE = 1;
    private static final int SPOT_NODE = 2;
    private static final int EVENT_NODE = 3;

    private static final int DISABLED_COLOR = 0x30707070;
    private static final int ENABLED_RED_COLOR = 0xffff0000;
    private static final int ENABLED_GREEN_COLOR = 0xff00ff00;

    private static final double INIT_DUMMY_COORDINATE = -999;

    private static final String HANDLER_HEADER = "pl";

    protected static boolean mPlayerStarted = true;
    protected static boolean mIsPlayerRunning = false;


    ////////////////////player status///////////////////////
    private static final int NOT_STARTED =  0;

    private static final int TRYING_TO_PLAY = 1;
    private static final int PLAYING =  2;

    private static final int TRYING_TO_PAUSE =  3;
    private static final int PAUSED =  4;

    private static final int TRYING_TO_STOP =  5;
    private static final int STOPPED =  6;

    private static final int TRYING_TO_MOVE_GOTO = 7;
    private static final int MOVING_GOTO = 8;

    private static final int TRYING_TO_MOVE_PREV = 9;
    private static final int MOVING_PREV = 10;

    private static final int TRYING_TO_PLAY_ETC_MEDIA = 11;
    private static final int ETC_MEDIA_PLAYING =  12;

    private static final int TRYING_TO_MOVE_NEXT = 13;
    private static final int MOVING_NEXT = 14;

    private static final int TRYING_TO_SELECT = 15;
    private static final int SELECTING = 16;

    private static final int TRYING_TO_SHOW_FINISH_ALARM = 17;
    private static final int FINISH_ALARMING = 18;

    private static final int ERROR =  -1;

    /////////////////TTS and MediaPlayer status //////////////
    private static final int TTS_NOT_STARTED = 0;
    private static final int TTS_STARTED = 1;
    private static final int TTS_STOPPED = 2;
    private static final int TTS_ERROR = 3;

    private static final int PLAYER_NOT_STARTED = 0;
    private static final int PLAYER_STARTED = 1;
    private static final int PLAYER_STOPPED = 2;
    private static final int PLAYER_PAUSED = 3;
    private static final int PLAYER_ERROR = 4;

    //index value
    private static final int LAST_INDEX = 999999;

    private static final int NO_ITEM = -1;
    private static final int NEED_TO_SELECT = -2;
    //private static final int END_OF_ROUTE = -3;

    private static final int CONTOLLER_MODE_NONE = 0;
    private static final int CONTOLLER_MODE_TTS = 1;
    private static final int CONTOLLER_MODE_MEDIA = 2;

    TextToSpeech mTTS;
    TextView mScriptTextView;
    RemoteControlReceiver mRemoteControlReceiver;


    private int mContollerMode = CONTOLLER_MODE_NONE;

    ProgressBar mLineProgressBar;
    SeekBar mMediaSeekBar;

    LinearLayout mPlayerControllerLayout;
    ImageView mTtsPlayerBackButton;
    ImageView mTtsPlayerPauseButton;
    ImageView mTtsPlayerPlayButton;
    ImageView mTtsPlayerNextButton;

    ImageView mTtsSettingButton;

    ImageView mSearchHumanButton;
    ImageView mCurrentSpotButton;

    //BalloonImageGalleryBar mBallonImageGalleryBar;

    RecyclerView mSpotListRecyclerView;
    RecyclerView mEventListRecyclerView;

    TextView mPlayerScriptTextView;
    TouchImageView mPlayerScreenImageView;

    ImageView mGoogleMapButton;
    ImageView mImageScreenButton;
    //BlinkingToggleButton mVideoScreenButton;

    //TextView mTitleTextView;

    LinearLayout mSettingLayout;
    ToggleButton mAutoNextSettingSwitch;
    boolean mAutoNextSwitchOn = false;
    ToggleButton mArrivingDetectionEventSettingSwitch;
    boolean mIsArrivingDetectionSwitchOn = false;

    //boolean mIsAutoNextSettingSwitchVisible = true;     //always true
    boolean mIsArrivingDetectionEventSettingSwitchVisible = false;  //default false

    TextView mAutoNextTitle;
    TextView mArrivingDetectionEventTitle;

    LinearLayout mPlayerControlPanelLayout;

    private SurfaceView mVideoPlayer;
    private SurfaceHolder holder;

    ServerMapData mapData = null;
    Graph routeGraph = null;
    ArrayList<NodeProgressBarItem> nodeList = new ArrayList<NodeProgressBarItem>(); //NodeProgressBar list
    //ArrayList<VertexGroup> nodeVertexList = new ArrayList<VertexGroup>();

    ArrayList<SpotGUI> mSpotDataList = new ArrayList<SpotGUI>();
    ArrayList<EventGUI> mEventDataList = new ArrayList<EventGUI>();

    SpotListAdapter mSpotListAdapter;
    EventListAdapter mEventListAdapter;

    ServerMapEventData mCurrentEvent = null;

    GraphSearch graphSearch;
    SensorManager mSensorManager = null;

    private int routeIndex = 0;
    private int spotIndex = 0;
    private int eventIndex = 0;
    private int lineIndex = 0;

    private boolean routeLastIndex = false;
    private boolean spotLastIndex = false;
    private boolean eventLastIndex = false;
    private boolean lineLastIndex = false;

    private int totalEventCount = 0;
    private int totalSpotCount = 0;
    private int totalRouteCount = 0;
    private int totalLineCount = 0;

    private String currentLineText = "";
    private String currentImageId = "";
    private float currentImageRectangle[];
    private String currentImagePath = "";
    private String currentAudioId = "";
    private String currentAudioPath = "";
    private String currentVideoId = "";
    private String currentVideoPath = "";

    private String currentTitleText = "";

    private int prevPlayerState = -1;
    private int playerState = NOT_STARTED;
    private int TtsPlayerState = TTS_NOT_STARTED;
    private int MediaPlayerState = PLAYER_NOT_STARTED;

    private int gotoNodeSpotIndex = 0;
    private int gotoNodeEventIndex = 0;

    private int selectingSpotIndexForOption = 0;

    private MediaPlayer mMediaPlayer;
    private float scriptTouch1 = 0;
    private float scriptTouch2 = 0;
    private static final int MIN_DISTANCE = 100;

    private GoogleMap mGoogleMap = null;
    private Marker mMapInfoWindow = null;
    private LatLng mIntroSpotSouthWest;
    private LatLng mIntroSpotNorthEast;

    private boolean mIsCameraLoaded = false;
    LatLngBounds mInitBounds = null;

    private SupportMapFragment supportMapFragment = null;
    private HashMap<String, MapMarkers> markersMap = null;
    private HashMap<Integer, Marker> eventMarkersMap = null;
    private Marker myLocationMarker = null;
    private Marker tourGuideLocationMarker = null;

    private float mMagneticOrientation = 0;

    float mGravity[];
    float mMagnetic[];

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb = null;

    private  String APP_DIRECTORY;
    private String mUserDir;
    private String mSkuStr;

    private static SpotOptionDialog spotDialog = null;

    private SoundPool soundPool;
    private int soundID;
    boolean plays = false, loaded = false;
    float actVolume, maxVolume, volume;
    AudioManager audioManager;

    private Vibrator mVibrator = null;

    private boolean mIsBroadcastReceiverEnabled = false;
    //protected Handler mBroadcastHandler = null;
    private PowerManager.WakeLock mWakeLock = null;

    private static GeneralAlarmDialog mGeneralAlarmDialog = null;

    private PlayerEngineThread mPlayerEngineThread;

    private DBAdapter mDBAdapter;

    private boolean mIsGoogleMapMode = false;
    private boolean mIsControlPanelVisible = false;
    private long mLastContolPanelVisibleEventTime = 0;

    private Handler mDisplayHandler = new Handler();
    private Handler mPlayerSeekBarHandler = new Handler();

    private int mIsTestMap = 0;


    //Location detection in Player
    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;

    private static boolean mIsDetectionEventEnabled = false;
    private static double mLatitudeForDetection = 0;
    private static double mLongitudeForDetection = 0;
    private static int mDistanceForDetection = 0;

    private Location mLocation = null;

    private static boolean isPlayerActivityResumed = false;
    private static boolean isPlayerActivityDestroyed = false;

    private class MapMarkers
    {
        public double lat;
        public double lng;
        public	int type;
        public	ArrayList<LatLng> area;
        public String title;
        public int index;
        public int nextIndex;
    }

    public class SpotGUI
    {
        public String mSpotImagePath;
        public String mSpotTitle;
        public int mSpotType;
    }

    public class EventGUI
    {
        public int mEventType;
    }

    private class NodeProgressBarItem
    {
        VertexGroup vertex;
        int property;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_player);

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        if (Build.VERSION.SDK_INT < 16)
        {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        else
        {
            //If i use following code, then every first click event of views/buttons in this activity do not trigger.
            /*
            View decorView = getWindow().getDecorView();
            // Hide the status bar.
            //int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            //int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN;
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
            decorView.setSystemUiVisibility(uiOptions);
            // Remember that you should never show the action bar if the
            // status bar is hidden, so hide that too if necessary.
            ActionBar actionBar = getActionBar();
            if(actionBar != null)
            {
                actionBar.hide();
            }
            */
        }

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();
        String tmpUserIdStr = mGeneralApplication.getIdString();
        mUserDir = Base64.mod_encode(tmpUserIdStr);

        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mSkuStr = bd.getString(CategoryListActivity.MAP_SKU);
            routeIndex = bd.getInt(CategoryListActivity.ROUTE_INDEX);
            mIsTestMap = bd.getInt(CategoryListActivity.IS_TEST_MAP);
        }

        mScriptTextView = (TextView) findViewById(R.id.player_script_text);
        //mBackButton = (ImageButton) findViewById(R.id.player_activity_back_button);

        //mTtsScalableLayout = (ScalableLayout) findViewById(R.id.tts_control_layout);
        mLineProgressBar = (ProgressBar) findViewById(R.id.lineProgressBar);
        mTtsPlayerBackButton = (ImageView) findViewById(R.id.tts_player_play_back_button);
        mTtsPlayerPauseButton = (ImageView) findViewById(R.id.tts_player_play_pause_button);
        mTtsPlayerPlayButton = (ImageView) findViewById(R.id.tts_player_play_play_button);
        mTtsPlayerNextButton = (ImageView) findViewById(R.id.tts_player_play_forward_button);
        mTtsSettingButton = (ImageView) findViewById(R.id.tts_player_setting_button);

        //mMediaScalableLayout = (ScalableLayout) findViewById(R.id.media_control_layout);
        mMediaSeekBar = (SeekBar) findViewById(R.id.mediaSeekBar);
        //mMediaPlayerBackButton = (ImageView) findViewById(R.id.media_player_play_back_button);
        //mMediaPlayerPauseButton = (ImageView) findViewById(R.id.media_player_play_pause_button);
        //mMediaPlayerPlayButton = (ImageView) findViewById(R.id.media_player_play_play_button);
        //mMediaPlayerNextButton = (ImageView) findViewById(R.id.media_player_play_forward_button);

        mGoogleMapButton = (ImageView) findViewById(R.id.player_activity_googlemap_btn);
        mImageScreenButton = (ImageView) findViewById(R.id.player_activity_image_btn);
        //mVideoScreenButton = (BlinkingToggleButton) findViewById(R.id.player_activity_video_btn);

        //mBallonImageGalleryBar = (BalloonImageGalleryBar) findViewById(R.id.player_spot_node);

        mSpotListRecyclerView = (RecyclerView)findViewById(R.id.spot_node_list);
        mEventListRecyclerView = (RecyclerView)findViewById(R.id.event_node_list);

        LinearLayoutManager tmpSpotLayoutManager = new LinearLayoutManager(this);
        tmpSpotLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);

        mSpotDataList = new ArrayList<SpotGUI>();
        mSpotListAdapter = new SpotListAdapter(this, mSpotDataList, this);
        mSpotListRecyclerView.setHasFixedSize(true);
        mSpotListRecyclerView.setLayoutManager(tmpSpotLayoutManager);
        mSpotListRecyclerView.setAdapter(mSpotListAdapter);

        LinearLayoutManager tmpEventLayoutManager = new LinearLayoutManager(this);
        tmpEventLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);

        mEventDataList = new ArrayList<EventGUI>();
        mEventListAdapter = new EventListAdapter(this, mEventDataList, this);
        mEventListRecyclerView.setHasFixedSize(true);
        mEventListRecyclerView.setLayoutManager(tmpEventLayoutManager);
        mEventListRecyclerView.setAdapter(mEventListAdapter);

        mPlayerControllerLayout = (LinearLayout) findViewById(R.id.player_controller_layout);

        mPlayerScriptTextView = (TextView) findViewById(R.id.player_script_text);
        mPlayerScreenImageView = (TouchImageView) findViewById(R.id.player_image_screen);

        mSearchHumanButton = (ImageView) findViewById(R.id.player_search_human);
        mCurrentSpotButton = (ImageView) findViewById(R.id.player_current_spot);

        //mTitleTextView = (TextView) findViewById(R.id.player_activity_title_textview);

        mSettingLayout = (LinearLayout) findViewById(R.id.setting_pannel);
        mAutoNextSettingSwitch = (ToggleButton) findViewById(R.id.auto_next);
        mArrivingDetectionEventSettingSwitch = (ToggleButton) findViewById(R.id.location_event);
        mAutoNextTitle = (TextView) findViewById(R.id.auto_next_title);
        mArrivingDetectionEventTitle = (TextView) findViewById(R.id.location_event_title);

        supportMapFragment = ((SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.player_map));
        supportMapFragment.getMapAsync(new OnMapReadyCallback()
        {
            @Override
            public void onMapReady(GoogleMap googleMap)
            {
                mGoogleMap = googleMap;

                LatLng geo_point  = new LatLng( 37.000000,  126.000000);
                CameraUpdate tmpUpdate = CameraUpdateFactory.newLatLngZoom(geo_point, 14);
                mGoogleMap.moveCamera( tmpUpdate );

                mGoogleMap.getUiSettings().setMyLocationButtonEnabled(true);
                mGoogleMap.getUiSettings().setCompassEnabled(true);
                mGoogleMap.getUiSettings().setRotateGesturesEnabled(false);

                mGoogleMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener()
                {
                    @Override
                    public void onCameraChange(CameraPosition arg0)
                    {
                        if(mIsCameraLoaded == false)
                        {
                            mIsCameraLoaded = true;
                            if(mInitBounds != null)
                            {
                                mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(mInitBounds, 10));
                            }
                        }
                    }
                });
            }
        });

        mVideoPlayer = (SurfaceView) findViewById(R.id.video_player);

        mPlayerControlPanelLayout = (LinearLayout) findViewById(R.id.player_control_panel_layout);


        holder = mVideoPlayer.getHolder();
        //holder.setFixedSize(176, 144);
        holder.addCallback(this);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        markersMap = new HashMap<String, MapMarkers>();
        eventMarkersMap = new HashMap<Integer, Marker>();
        //player_map

        //mBackButton.setOnClickListener(this);

        mPlayerControllerLayout.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if (
                        (event.getAction() == MotionEvent.ACTION_DOWN)
                        || (event.getAction() == MotionEvent.ACTION_MOVE)
                        )
                {
                    processShortClickOnControlPanel();
                    //return true;

                    if(event.getAction() == MotionEvent.ACTION_DOWN)
                    {
                        return true;
                    }
                }
                return false;
            }
        });

        mSpotListRecyclerView.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if (
                        (event.getAction() == MotionEvent.ACTION_DOWN)
                                || (event.getAction() == MotionEvent.ACTION_MOVE)
                        )
                {
                    processShortClickOnControlPanel();
                    //return true;

                    if(event.getAction() == MotionEvent.ACTION_DOWN)
                    {
                        return true;
                    }
                }
                return false;
            }
        });
        mEventListRecyclerView.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if (
                        (event.getAction() == MotionEvent.ACTION_DOWN)
                                || (event.getAction() == MotionEvent.ACTION_MOVE)
                        )
                {
                    processShortClickOnControlPanel();
                    //return true;

                    if(event.getAction() == MotionEvent.ACTION_DOWN)
                    {
                        return true;
                    }
                }
                return false;
            }
        });

        /*
        mSpotListRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener()
        {
            public void onScrolled(RecyclerView recyclerView, int dx, int dy)
            {
                int tmpdx = dx;
            }
        });
        */


        mTtsPlayerBackButton.setOnClickListener(this);
        mTtsPlayerPauseButton.setOnClickListener(this);
        mTtsPlayerPlayButton.setOnClickListener(this);
        mTtsPlayerNextButton.setOnClickListener(this);

        mTtsSettingButton.setOnClickListener(this);

        //mMediaPlayerBackButton.setOnClickListener(this);
        //mMediaPlayerPauseButton.setOnClickListener(this);
        //mMediaPlayerPlayButton.setOnClickListener(this);
        //mMediaPlayerNextButton.setOnClickListener(this);

        //mBallonImageGalleryBar.setOnRatingBarChangeListener(this);

        mGoogleMapButton.setOnClickListener(this);
        mImageScreenButton.setOnClickListener(this);
        //mVideoScreenButton.setOnClickListener(this);

        mSearchHumanButton.setOnClickListener(this);
        mCurrentSpotButton.setOnClickListener(this);

        mAutoNextSettingSwitch.setOnCheckedChangeListener(this);
        mArrivingDetectionEventSettingSwitch.setOnCheckedChangeListener(this);

        mPlayerScreenImageView.setShortTouchListener(this);
        //mBallonImageGalleryBar.setShortTouchListener(this);

        isPlayerActivityDestroyed = false;

        int color = 0xFFE0E0E0;
        mLineProgressBar.getIndeterminateDrawable().setColorFilter(color, PorterDuff.Mode.SRC_IN);
        mLineProgressBar.getProgressDrawable().setColorFilter(color, PorterDuff.Mode.SRC_IN);

        lineIndex = 0;
        eventIndex = 0;
        spotIndex = 0;
        //routeIndex = 0;

        mMediaPlayer = new MediaPlayer();

        buildSound();

        mTTS = new TextToSpeech(this, this);

        ((AudioManager) getSystemService(AUDIO_SERVICE)).registerMediaButtonEventReceiver(new ComponentName(this, RemoteControlReceiver.class));

        //setupSensorManager();
        initSensors();

        IntentFilter mediaFilter = new IntentFilter(Intent.ACTION_MEDIA_BUTTON);
        mediaFilter.setPriority(10000);

        loadMapArray(routeIndex);
        sortMapArray();
        loadGraph(0);

        mPlayerStarted = true;

        playerState = NOT_STARTED;
        Log.d(TAG, String.format("playerState = NOT_STARTED"));

        mIsArrivingDetectionSwitchOn = false;

        /*
        if(mIsBroadcastReceiverEnabled == false)
        {
            // TODO Auto-generated method stub
            IntentFilter filter = new IntentFilter (GENERAL_APP_ID);
            filter.addAction(GENERAL_LOCATION_DETECTION_ID);
            registerReceiver(mBroadcastReceiver, new IntentFilter(filter));
            mIsBroadcastReceiverEnabled = true;
        }
        */

        PowerManager pm = (PowerManager)getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "TourGuideLock");

        mPlayerEngineThread = new PlayerEngineThread();
        mPlayerEngineThread.start();

        //Turn off googlemap mode at the first time
        //mGoogleMapButton.setVisibility(View.VISIBLE);
        //mImageScreenButton.setVisibility(View.GONE);

        showTtsControl();

        supportMapFragment.getView().setVisibility(View.INVISIBLE);
        mSearchHumanButton.setVisibility(View.INVISIBLE);
        mCurrentSpotButton.setVisibility(View.INVISIBLE);
        mPlayerScreenImageView.setVisibility(View.VISIBLE);
        mVideoPlayer.setVisibility(View.INVISIBLE);
        mIsGoogleMapMode = false;

        mMediaSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                if(fromUser == true)
                {
                    float totalDuration = mMediaPlayer.getDuration();

                    int newPos = (int)(totalDuration * progress / 100);
                    mMediaPlayer.seekTo(newPos);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {
            }
        });

        createLocation();

        processShortClickOnControlPanel();
    }

    private void playAudio(String audioPath)
    {
        try
        {
            mMediaPlayer.reset();
            mMediaPlayer.release();

            mMediaPlayer = new MediaPlayer();

            String localPathStr = "";
            if(mIsTestMap == TYPE_TEST_MAP)
            {
                localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" + mSkuStr + "/" + audioPath;
            }
            else
            {
                localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" + mSkuStr + "/" + audioPath;
            }
            mMediaPlayer.setDataSource(localPathStr);
            //mAudio.setDataSource("/storage/sdcard0/" + audioPath);
            //mAudio.setDisplay(holder);
            //mAudio.setOnBufferingUpdateListener(this);
            //mAudio.setOnInfoListener(this);

            mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
            {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    MediaPlayerState = PLAYER_STOPPED;
                    showTtsControl();
                }
            });
            mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
            {
                @Override
                public void onPrepared(MediaPlayer mp)
                {
                    MediaPlayerState = PLAYER_STARTED;
                    mMediaPlayer.start();
                }
            });
            mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener()
            {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra)
                {
                    MediaPlayerState = PLAYER_ERROR;
                    return false;
                }
            });
            mMediaPlayer.prepare();


            mPlayerSeekBarHandler.postDelayed(updateSeekBarTimeRunnable, 100);
        }
        catch (Exception e)
        {
            MediaPlayerState = PLAYER_ERROR;
            Log.e(TAG, "error: " + e.getMessage(), e);
        }
    }

    private void playVideo(String videoPath)
    {
        try
        {
            mVideoPlayer.setVisibility(View.VISIBLE);

            mMediaPlayer.reset();
            mMediaPlayer.release();

            mMediaPlayer = new MediaPlayer();

            String localPathStr = "";

            if(mIsTestMap == TYPE_TEST_MAP)
            {
                localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + videoPath;
            }
            else
            {
                localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + videoPath;
            }

            mMediaPlayer.setDataSource(localPathStr);
            //mAudio.setDataSource("/storage/sdcard0/" + audioPath);
            mMediaPlayer.setDisplay(holder);
            //mAudio.setOnBufferingUpdateListener(this);
            //mAudio.setOnInfoListener(this);

            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
            {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    MediaPlayerState = PLAYER_STOPPED;
                    showTtsControl();
                }
            });
            mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
            {
                @Override
                public void onPrepared(MediaPlayer mp)
                {
                    MediaPlayerState = PLAYER_STARTED;
                    mMediaPlayer.start();
                }
            });
            mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener()
            {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra)
                {
                    MediaPlayerState = PLAYER_ERROR;
                    return false;
                }
            });
            mMediaPlayer.prepare();

            mPlayerSeekBarHandler.postDelayed(updateSeekBarTimeRunnable, 100);

            int surfaceView_Width = mVideoPlayer.getWidth();
            int surfaceView_Height = mVideoPlayer.getHeight();

            float video_Width = mMediaPlayer.getVideoWidth();
            float video_Height = mMediaPlayer.getVideoHeight();

            float ratio_width = surfaceView_Width/video_Width;
            float ratio_height = surfaceView_Height/video_Height;
            float aspectratio = video_Width/video_Height;

            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)mVideoPlayer.getLayoutParams();

            if (ratio_width > ratio_height)
            {
                layoutParams.width = (int) (surfaceView_Height * aspectratio);
                layoutParams.height = surfaceView_Height;
            }
            else
            {
                layoutParams.width = surfaceView_Width;
                layoutParams.height = (int) (surfaceView_Width / aspectratio);
            }

            mVideoPlayer.setLayoutParams(layoutParams);

        }
        catch (Exception e)
        {
            MediaPlayerState = PLAYER_ERROR;
            Log.e(TAG, "error: " + e.getMessage(), e);
        }
    }

    @Override
    public void onInit(int status)
    {
        if (status == TextToSpeech.SUCCESS)
        {
            mTTS.setOnUtteranceProgressListener(new UtteranceProgressListener()
            {
                @Override
                public void onDone(String utteranceId)
                {
                    TtsPlayerState = TTS_STOPPED;
                }

                @Override
                public void onError(String utteranceId)
                {
                    TtsPlayerState = TTS_ERROR;
                }

                @Override
                public void onStart(String utteranceId)
                {
                    TtsPlayerState = TTS_STARTED;
                }
            });

            int result = mTTS.setLanguage(Locale.KOREAN);

            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED)
            {
                Log.e("TTS", "This Language is not supported");
            }
            else
            {
                //btnSpeak.setEnabled(true);
                speakOut(null);
            }
        }
        else
        {
            Log.e("TTS", "Initilization Failed!");
            mTTS = null;
        }
    }

    @Override
    public void finish()
    {
        mPlayerStarted = false;

        destroyLocation();

        mPlayerEngineThread.quit();
        mPlayerEngineThread.interrupt();

        // Don't forget to shutdown tts!

        /*
        if(mIsBroadcastReceiverEnabled == true)
        {
            unregisterReceiver(mBroadcastReceiver);
            mIsBroadcastReceiverEnabled = false;
        }
        */

        if(mMediaPlayer != null)
        {
            if (mMediaPlayer.isPlaying())
            {
                mMediaPlayer.stop();
            }
            mMediaPlayer.release();
        }

        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        stopVibrate();

        uninitSensors();

        ((AudioManager) getSystemService(AUDIO_SERVICE)).unregisterMediaButtonEventReceiver(new ComponentName(this, RemoteControlReceiver.class));

        if(routeGraph != null)
        {
            routeGraph.clearData();
        }

        if(mWakeLock != null)
        {
            if (mWakeLock.isHeld())
            {
                mWakeLock.release();
                mWakeLock = null;
            }
        }

        super.finish();
    }

    @Override
    public void onDestroy()
    {
        /*
        mPlayerEngineThread.quit();
        mPlayerEngineThread.interrupt();

        // Don't forget to shutdown tts!
        LocationService.setPlayerActivityDestroyed(true);

        if(mIsBroadcastReceiverEnabled == true)
        {
            unregisterReceiver(mBroadcastReceiver);
            mIsBroadcastReceiverEnabled = false;
        }

        mPlayerStarted = false;

        if (mAudio.isPlaying())
        {
            mAudio.stop();
        }
        mAudio.release();

        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        stopVibrate();

        uninitSensors();
        //stopSensorManager();
        //unregisterReceiver(mRemoteControlReceiver);

        ((AudioManager) getSystemService(AUDIO_SERVICE)).unregisterMediaButtonEventReceiver(new ComponentName(this, RemoteControlReceiver.class));

        routeGraph.clearData();
        */

        mDBAdapter.close();

        isPlayerActivityDestroyed = true;

        super.onDestroy();
    }


    @Override
    public void onResume()
    {
        isPlayerActivityResumed = true;

        super.onResume();
    }

    @Override
    public void onPause()
    {
        isPlayerActivityResumed = false;

        super.onPause();
    }
    int a = 0;

    private void speakOut(String commentStr)
    {
        if((commentStr == null) || (commentStr.equals("") == true))
        {
            String text = mScriptTextView.getText().toString();

            HashMap<String, String> map = new HashMap<String, String>();

            map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "tourguide");

            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, map);
        }
        else
        {
            HashMap<String, String> map = new HashMap<String, String>();

            map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "tourguide");

            mTTS.speak(commentStr, TextToSpeech.QUEUE_FLUSH, map);
        }
    }

    private void reSpeakOut()
    {
        String text = mScriptTextView.getText().toString();

        HashMap<String, String> map = new HashMap<String, String>();

        map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "tourguide");

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, map);
    }

    private String getImageIdAndRectangle(String rectangleData, float tmpRectangle[])
    {
        String rectangle_image_id =  null;
        if(rectangleData != null)
        {
            String rectangle_data_arr[] = rectangleData.split("_");
            rectangle_image_id = rectangle_data_arr[0];
            String tmpRectangleRaw = rectangle_data_arr[1];

            if(tmpRectangle != null)
            {
                String coords[] = tmpRectangleRaw.split(",");

                for (int x = 0; x < 4; x++)
                {
                    tmpRectangle[x] = Float.valueOf(coords[x]);
                }
            }
        }
        else
        {
            if(tmpRectangle != null)
            {
                //clear
                for (int x = 0; x < 4; x++)
                {
                    tmpRectangle[x] = (float)0.0;
                }
            }
        }

        return rectangle_image_id;
    }

    private void setCurrentResources(ServerMapLineData oneLine, ServerMapEventData tmpe)
    {
            currentLineText = oneLine.getLineText();

            String tmpLineAudioPath = oneLine.getAudioId();
            if( (tmpLineAudioPath != null) && (tmpLineAudioPath.equals("") == false))
            {
                currentAudioId = tmpLineAudioPath;
            }
            else
            {
                currentAudioId = null;
                currentAudioPath = null;
            }

            String tmpLineVideoPath = oneLine.getVideoId();
            if( (tmpLineVideoPath != null) && (tmpLineVideoPath.equals("") == false))
            {
                currentVideoId = tmpLineVideoPath;
            }
            else
            {
                currentVideoId = null;
                currentVideoPath = null;
            }

            float tmpRectangle[] = new float[4];
            String rectangle_image_id = null;

            //String tmpImageDataRaw = null;
            String tmpLineImageData = oneLine.getImageData();
            if( (tmpLineImageData != null) && (tmpLineImageData.equals("") == false))
            {
                String rectangleData = mapData.getResource().getRectangle(tmpLineImageData);
                rectangle_image_id = getImageIdAndRectangle(rectangleData, tmpRectangle);

                if( (rectangle_image_id != null) && (rectangle_image_id.equals("") == false))
                {
                    currentImageId = rectangle_image_id;
                }
                else
                {
                    currentImageId = null;
                    currentImagePath = null;
                }
            }
            else
            {
                String tmpEventImageData = tmpe.getImageData();
                if( (tmpEventImageData != null) && (tmpEventImageData.equals("") == false))
                {
                    String rectangleData = mapData.getResource().getRectangle(tmpEventImageData);
                    rectangle_image_id = getImageIdAndRectangle(rectangleData, tmpRectangle);

                    if( (rectangle_image_id != null) && (rectangle_image_id.equals("") == false))
                    {
                        currentImageId = rectangle_image_id;
                    }
                    else
                    {
                        currentImageId = null;
                        currentImagePath = null;
                    }
                }
                else
                {
                    currentImageId = null;
                    currentImagePath = null;
                }
            }

            if(
                    (tmpRectangle != null) && (tmpRectangle.length == 4) && isRectangleCoordinateValid(tmpRectangle[0], tmpRectangle[1], tmpRectangle[2], tmpRectangle[3])
                    )
            {
                currentImageRectangle = tmpRectangle;
            }
            else
            {
                currentImageRectangle = null;
            }
    }

    private ArrayList<Integer> getCurrnetVertexRecommendedSpotIdFromPreviousVertices(VertexGroup tmpValue)
    {
        ArrayList<Edge> tmpPath = tmpValue.getNeighbors();
        ArrayList<Integer> tmpRecommendedSpotIdList = new ArrayList<Integer>();

        //there is only 1 next node, search next node
        for(int x = 0; x < tmpPath.size(); x++)
        {
            Edge tmpEdge = tmpPath.get(x);

            if (tmpValue == tmpEdge.getFront())
            {
                //prev node
            }
            else if (tmpValue == tmpEdge.getBack())
            {
                //tmpEdge.getFront().getSpots();
                //VertexGroup tmpNext = tmpEdge.getFront();
                //tmpVerticesList.add(tmpNext);
                ArrayList<ServerMapSpotData> tmpSpots = tmpValue.getSpots();

                int recommended_link[] = tmpValue.getNextRecommendedSpotId();
                if(recommended_link[1] != VertexGroup.NO_RECOMMENDED_ID)
                {
                    tmpRecommendedSpotIdList.add(recommended_link[1]);
                    break;
                }
            }
        }

        return tmpRecommendedSpotIdList;
    }

    private int getCurrentVertexRecommendedIndexFromNodeList(ArrayList<NodeProgressBarItem> tmpNodeList, int tmpSpotIndex)
    {
        NodeProgressBarItem tmpCurrentElement = null;
        tmpCurrentElement = tmpNodeList.get(tmpSpotIndex);
        if(tmpCurrentElement.property == NodeProgressBar.NODE_OPTIONAL)
        {
            return -1;
        }

        for(int x = tmpSpotIndex-1; x >= 0; x--)
        {
            if(x >= 0)
            {
                NodeProgressBarItem tmpElement = null;
                tmpElement = tmpNodeList.get(x);
                if(tmpElement.property != NodeProgressBar.NODE_OPTIONAL)
                {
                    VertexGroup tmpVertex = tmpElement.vertex;

                    if(tmpVertex != null)
                    {
                        int recommended_link[] = tmpVertex.getNextRecommendedSpotId();

                        if((recommended_link[0] != Edge.NO_RECOMMENDED_ID) && (recommended_link[1] != Edge.NO_RECOMMENDED_ID))
                        {
                            int nextRecommendedSpotId = recommended_link[1];

                            VertexGroup tmpCurrentVertex = tmpCurrentElement.vertex;
                            if(tmpVertex != null)
                            {
                                ArrayList<ServerMapSpotData> tmpSpots = tmpVertex.getSpots();

                                for(int y = 0; y < tmpSpots.size(); y++)
                                {
                                    if(nextRecommendedSpotId == tmpSpots.get(y).getId())
                                    {
                                        return y;
                                    }
                                }
                                return -1;
                            }
                            else
                            {
                                return -1;
                            }
                        }
                        else
                        {
                            return -1;
                        }
                    }
                    else
                    {
                        return -1;
                    }
                }
            }
        }
        return -1;
    }

    //만약 route 선택 하는 부분이 추가된다면 refresh_route 메시지 전송하여 새롭게 구글맵을 변경해줘야 한다.
    //왜냐하면 구글맵은 하나의 라우트만 보여주기 때문이다.
    private int gotoNode(int tmpSpotIndex, int tmpEventIndex)
    {
        if (totalEventCount <= tmpEventIndex)
        {
            return NO_ITEM;
        }
        else if (totalSpotCount <= tmpSpotIndex)
        {
            return NO_ITEM;
            //end of route
            /*
            routeIndex++;
            if(totalRouteCount <= routeIndex)
            {
                //end of route
            }
            */
        }

        List<ServerMapRouteData> tmpRoutes = mapData.getRoute();

        NodeProgressBarItem tmpElement = nodeList.get(tmpSpotIndex);
        VertexGroup tmpVertex = tmpElement.vertex;

        if(tmpVertex == null)
        {
            return NO_ITEM;
        }

        int spotSize = tmpVertex.getSpots().size();
        ServerMapSpotData tmps = null;
        if(spotSize > 1)
        {
            int weightIndex = tmpVertex.getSpotWeightIndex();
            //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
            int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, tmpSpotIndex);
            int tmpIndex = 0;
            if(weightIndex < 0)
            {
                if(recommendedIndex < 0)
                {
                    tmpIndex = 0;
                }
                else
                {
                    tmpIndex = recommendedIndex;
                }
            }
            else
            {
                tmpIndex = weightIndex;
            }
            tmps = tmpVertex.getSpots().get(tmpIndex);
        }
        else
        {
            tmps = tmpVertex.getSpots().get(0);
        }

        int eventCount = 0;
        int previous_index = -1;

        List<ServerMapEventData> tmpEvents = tmps.getEvent();
        if (tmpEvents != null)
        {
            eventCount = 0;
            previous_index = -1;
            for(int x = 0; x < tmpEvents.size(); x++)
            {
                ServerMapEventData oneEvent = tmpEvents.get(x);
                if(previous_index != oneEvent.getIndex())
                {
                    previous_index = oneEvent.getIndex();
                    eventCount++;
                }
            }

            //mPlayerEventNode.setNumOfNodex(eventCount);

            //totalEventCount = tmpEvents.size();
            totalEventCount = eventCount;

            ServerMapEventData tmpe = tmpEvents.get(tmpEventIndex);

            if (tmpe != null)
            {
                mCurrentEvent = tmpe;

                String eventTitle = tmpe.getTitle();
                String spotTitle = tmps.getTitle();
                if((eventTitle != null) && (eventTitle.equals("") == false))
                {
                    currentTitleText = eventTitle;
                }
                else if((spotTitle != null) && (spotTitle.equals("") == false))
                {
                    currentTitleText = spotTitle;
                }
                else
                {
                    currentTitleText = "";
                }

                ServerMapTextData tmpt = tmpe.getText();

                if(tmpt != null)
                {
                    List<ServerMapLineData> tmpl = tmpt.getLines();

                    if(tmpl != null)
                    {
                        lineIndex = 0;
                        spotIndex = tmpSpotIndex;
                        eventIndex = tmpEventIndex;

                        totalRouteCount = tmpRoutes.size();
                        //totalSpotCount = tmpSpots.size();
                        totalSpotCount = nodeList.size();
                        totalEventCount = tmpEvents.size();
                        totalLineCount = tmpl.size();

                        ServerMapLineData oneLine = tmpl.get(lineIndex);

                        setCurrentResources(oneLine, tmpe);

                        return eventCount;
                    }
                }
            }
            else
            {
                mCurrentEvent = null;
            }
        }

        return NO_ITEM;
    }

    private int next(boolean fromUser)
    {
        lineIndex++;
        if (totalLineCount <= lineIndex)
        {
            eventIndex++;

            lineIndex = 0;
            if (totalEventCount <= eventIndex)
            {
                spotIndex++;
                eventIndex = 0;
                if (totalSpotCount <= spotIndex)
                {
                    spotIndex = 0;
                    return NO_ITEM;
                    //end of route
                    /*
                    routeIndex++;
                    if(totalRouteCount <= routeIndex)
                    {
                        //end of route
                    }
                    */
                }
            }
        }

        List<ServerMapRouteData> tmpRoutes = mapData.getRoute();

        if (tmpRoutes != null)
        {

            //MapRouteData tmpr = tmpRoutes.get(routeIndex);
            ServerMapRouteData tmpr = tmpRoutes.get(0);
            if (tmpr != null)
            {
                NodeProgressBarItem tmpElement = nodeList.get(spotIndex);
                VertexGroup tmpVertex = tmpElement.vertex;

                if(tmpElement.property == NodeProgressBar.NODE_OPTIONAL)
                {

                    NodeProgressBarItem nextElement = nodeList.get(spotIndex+1);
                    boolean weightedFlag = isThisWieghted(nextElement.vertex);

                    //optional
                    //if(nodeList.size() == spotIndex + 1)
                    if(weightedFlag == false)
                    {
                        //last node

                        return NEED_TO_SELECT;
                    }
                    else
                    {
                        //path or multi nodes is already selected.
                        //pass selection node
                        spotIndex++;
                        tmpElement = nodeList.get(spotIndex);
                        tmpVertex = tmpElement.vertex;
                    }
                }
                else if(tmpVertex == null)
                {
                    //optional or error
                    return NO_ITEM;
                }

                int eventCount = 0;
                int previous_index = -1;

                int spotSize = tmpVertex.getSpots().size();
                ServerMapSpotData tmps = null;
                if(spotSize > 1)
                {
                    int weightIndex = tmpVertex.getSpotWeightIndex();
                    //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
                    int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, spotIndex);

                    int tmpIndex = 0;
                    if(weightIndex < 0)
                    {
                        if(recommendedIndex < 0)
                        {
                            tmpIndex = 0;
                        }
                        else
                        {
                            tmpIndex = recommendedIndex;
                        }
                    }
                    else
                    {
                        tmpIndex = weightIndex;
                    }
                    tmps = tmpVertex.getSpots().get(tmpIndex);
                }
                else
                {
                    tmps = tmpVertex.getSpots().get(0);
                }

                //mPlayerSpotNode.setNumOfNodex(count);
                //MapSpotData tmps = tmpSpots.get(spotIndex);
                if (tmps != null)
                {
                    List<ServerMapEventData> tmpEvents = tmps.getEvent();
                    if (tmpEvents != null)
                    {
                        eventCount = 0;
                        previous_index = -1;
                        for(int x = 0; x < tmpEvents.size(); x++)
                        {
                            ServerMapEventData oneEvent = tmpEvents.get(x);
                            if(previous_index != oneEvent.getIndex())
                            {
                                previous_index = oneEvent.getIndex();
                                eventCount++;
                            }
                        }

                        //mPlayerEventNode.setNumOfNodex(eventCcount);

                        ServerMapEventData tmpe = tmpEvents.get(eventIndex);
                        if (tmpe != null)
                        {
                            mCurrentEvent = tmpe;

                            String eventTitle = tmpe.getTitle();
                            String spotTitle = tmps.getTitle();
                            if((eventTitle != null) && (eventTitle.equals("") == false))
                            {
                                currentTitleText = eventTitle;
                            }
                            else if((spotTitle != null) && (spotTitle.equals("") == false))
                            {
                                currentTitleText = spotTitle;
                            }
                            else
                            {
                                currentTitleText = "";
                            }

                            ServerMapTextData tmpt = tmpe.getText();

                            if(tmpt != null)
                            {
                                List<ServerMapLineData> tmpl = tmpt.getLines();

                                if (tmpl != null)
                                {
                                    totalRouteCount = tmpRoutes.size();
                                    totalSpotCount = nodeList.size();
                                    totalEventCount = tmpEvents.size();
                                    totalLineCount = tmpl.size();

                                    ServerMapLineData oneLine = tmpl.get(lineIndex);

                                    setCurrentResources(oneLine, tmpe);

                                    return eventCount;
                                }
                            }
                        }
                        else
                        {
                            mCurrentEvent = null;
                        }
                    }
                }
            }
        }
        return NO_ITEM;   //no actual data
    }

    //이것 역시 이전 route로 이동할시에는 refresh_route 메시지를 보내줘야 한다.
    private int previous()
    {
        lineIndex--;
        if (lineIndex < 0)
        {
            eventIndex--;
            lineIndex = 0;
            lineLastIndex = true;
            if (eventIndex < 0)
            {
                spotIndex--;
                eventIndex = 0;
                eventLastIndex = true;
                if (spotIndex < 0)
                {
                    //return false;

                    spotIndex = 0;
                    spotLastIndex = true;
                    //end of route
                    /*
                    routeIndex--;
                    if(routeIndex < 0)
                    {
                        //end of route
                    }
                    */
                }
            }
        }

        List<ServerMapRouteData> tmpRoutes = mapData.getRoute();

        if (tmpRoutes != null)
        {
            ServerMapRouteData tmpr = tmpRoutes.get(routeIndex);
            if (tmpr != null)
            {

                NodeProgressBarItem tmpElement = nodeList.get(spotIndex);
                VertexGroup tmpVertex = tmpElement.vertex;

                if(tmpElement.property == NodeProgressBar.NODE_OPTIONAL)
                {
                    //optional
                    if(spotIndex - 1 < 0)
                    {
                        //first node
                        //this is non sense case.
                        return NO_ITEM;
                    }
                    else
                    {
                        //path or multi nodes is already selected.
                        //pass selection node
                        spotIndex--;
                        tmpElement = nodeList.get(spotIndex);
                        tmpVertex = tmpElement.vertex;
                    }
                }
                else if(tmpVertex == null)
                {
                    //optional or error
                    return NO_ITEM;
                }

                int eventCount = 0;
                int previous_index = -1;

                int spotSize = tmpVertex.getSpots().size();
                ServerMapSpotData tmps = null;
                if(spotSize > 1)
                {
                    int weightIndex = tmpVertex.getSpotWeightIndex();
                    //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
                    int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, spotIndex);

                    int tmpIndex = 0;
                    if(weightIndex < 0)
                    {
                        if(recommendedIndex < 0)
                        {
                            tmpIndex = 0;
                        }
                        else
                        {
                            tmpIndex = recommendedIndex;
                        }
                    }
                    else
                    {
                        tmpIndex = weightIndex;
                    }
                    tmps = tmpVertex.getSpots().get(tmpIndex);
                }
                else
                {
                    tmps = tmpVertex.getSpots().get(0);
                }

                if (tmps != null)
                {
                    List<ServerMapEventData> tmpEvents = tmps.getEvent();
                    if (tmpEvents != null)
                    {
                        eventCount = 0;
                        previous_index = -1;
                        for(int x = 0; x < tmpEvents.size(); x++)
                        {
                            ServerMapEventData oneEvent = tmpEvents.get(x);
                            if(previous_index != oneEvent.getIndex())
                            {
                                previous_index = oneEvent.getIndex();
                                eventCount++;
                            }
                        }

                        //mPlayerEventNode.setNumOfNodex(eventCount);

                        ServerMapEventData tmpe = tmpEvents.get(eventIndex);
                        if (tmpe != null)
                        {
                            mCurrentEvent = tmpe;

                            String eventTitle = tmpe.getTitle();
                            String spotTitle = tmps.getTitle();
                            if((eventTitle != null) && (eventTitle.equals("") == false))
                            {
                                currentTitleText = eventTitle;
                            }
                            else if((spotTitle != null) && (spotTitle.equals("") == false))
                            {
                                currentTitleText = spotTitle;
                            }
                            else
                            {
                                currentTitleText = "";
                            }

                            ServerMapTextData tmpt = tmpe.getText();

                            if(tmpt != null)
                            {
                                List<ServerMapLineData> tmpl = tmpt.getLines();

                                if (tmpl != null)
                                {
                                    //lineIndex = 0;
                                    totalRouteCount = tmpRoutes.size();
                                    totalSpotCount = nodeList.size();
                                    totalEventCount = tmpEvents.size();
                                    totalLineCount = tmpl.size();

                                    if (
                                            ((lineIndex == 0) && (eventIndex == 0) && (spotIndex == 0))
                                            &&
                                            ((lineLastIndex == true) && (eventLastIndex == true) && (spotLastIndex == true))
                                    )
                                    {
                                        lineIndex = 0;
                                        eventIndex = 0;
                                        spotIndex = 0;
                                    }
                                    else
                                    {
                                        if (lineLastIndex == true)
                                        {
                                            lineIndex = totalLineCount - 1;
                                        }
                                        if (eventLastIndex == true)
                                        {
                                            eventIndex = totalEventCount - 1;
                                        }
                                        if (spotLastIndex == true)
                                        {
                                            spotIndex = totalSpotCount - 1;
                                        }
                                        /*
                                        if (routeLastIndex == true)
                                        {
                                            routeIndex = totalRouteCount - 1;
                                        }
                                        */
                                    }

                                    lineLastIndex = false;
                                    eventLastIndex = false;
                                    spotLastIndex = false;
                                    routeLastIndex = false;

                                    ServerMapLineData oneLine = tmpl.get(lineIndex);

                                    setCurrentResources(oneLine, tmpe);

                                    return eventCount;
                                }
                            }
                        }
                        else
                        {
                            mCurrentEvent = null;
                        }
                    }
                }
            }
        }
        return NO_ITEM;   //no actual data
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        switch (keyCode)
        {
            /*
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                // code for fast forward
                Log.e("TTS", "KEYCODE_MEDIA_FAST_FORWARD");
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                // code for next
                Log.e("TTS", "KEYCODE_MEDIA_NEXT");
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                // code for play/pause
                Log.e("TTS", "KEYCODE_MEDIA_PLAY_PAUSE");
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                // code for previous
                Log.e("TTS", "KEYCODE_MEDIA_PREVIOUS");
                return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                // code for rewind
                Log.e("TTS", "KEYCODE_MEDIA_REWIND");
                return true;
            case KeyEvent.KEYCODE_MEDIA_STOP:
                // code for stop
                Log.e("TTS", "KEYCODE_MEDIA_STOP");
                return true;
            */

            case KeyEvent.KEYCODE_VOLUME_UP:
                Log.e("TTS", "KEYCODE_VOLUME_UP");
                return super.onKeyDown(keyCode, event);

            case KeyEvent.KEYCODE_VOLUME_DOWN:
                Log.e("TTS", "KEYCODE_VOLUME_DOWN");
                return super.onKeyDown(keyCode, event);

            case KeyEvent.KEYCODE_BACK:
                Log.e("TTS", "KEYCODE_VOLUME_DOWN");

                FragmentManager fm = getFragmentManager();
                if(mGeneralAlarmDialog != null)
                {
                    mGeneralAlarmDialog.dismiss();
                    mGeneralAlarmDialog = null;
                }
                mGeneralAlarmDialog = new GeneralAlarmDialog();
                mGeneralAlarmDialog.setTitleText(getString(R.string.do_you_want_close_player));
                mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_CANCEL);
                mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
                {
                    @Override
                    public void onButtonClickListener(View v, int id, int button)
                    {
                        if(button == GeneralAlarmDialog.OK_BUTTON)
                        {
                            finish();
                        }
                        else if(button == GeneralAlarmDialog.CANCEL_BUTTON)
                        {
                            //do nothing
                        }
                    }
                });
                mGeneralAlarmDialog.show(fm, "tag");

                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View v)
    {
        /*
        if (v.getId() == R.id.player_activity_back_button)
        {
            finish();
        }
        */
        if (v.getId() == R.id.tts_player_play_pause_button)
        {
            if(mContollerMode == CONTOLLER_MODE_TTS)
            {
                mTtsPlayerPlayButton.setVisibility(View.VISIBLE);
                mTtsPlayerPauseButton.setVisibility(View.INVISIBLE);

                playerState = TRYING_TO_PAUSE;
                Log.d(TAG, String.format("playerState = TRYING_TO_PAUSE"));
                //mTTS.stop();
                //mAudio.stop();

                processShortClickOnControlPanel();
            }
            else
            {
                mTtsPlayerPlayButton.setVisibility(View.VISIBLE);
                mTtsPlayerPauseButton.setVisibility(View.INVISIBLE);

                mMediaPlayer.pause();
                processShortClickOnControlPanel();
            }
        }
        else if (v.getId() == R.id.tts_player_play_play_button)
        {
            if(mContollerMode == CONTOLLER_MODE_TTS)
            {
                mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
                mTtsPlayerPauseButton.setVisibility(View.VISIBLE);

                playerState = TRYING_TO_PLAY;
                Log.d(TAG, String.format("playerState = TRYING_TO_PLAY"));

                processShortClickOnControlPanel();
            }
            else
            {
                mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
                mTtsPlayerPauseButton.setVisibility(View.VISIBLE);

                mMediaPlayer.start();
                processShortClickOnControlPanel();
            }
        }
        else if (v.getId() == R.id.tts_player_play_back_button)
        {
            if(mContollerMode == CONTOLLER_MODE_TTS)
            {
                mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
                mTtsPlayerPauseButton.setVisibility(View.VISIBLE);

                playerState = TRYING_TO_MOVE_PREV;
                Log.d(TAG, String.format("playerState = TRYING_TO_MOVE_PREV"));
            }
            else
            {
                mMediaPlayer.seekTo(0);
            }
        }
        else if (v.getId() == R.id.tts_player_play_forward_button)
        {
            if(mContollerMode == CONTOLLER_MODE_TTS)
            {
                mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
                mTtsPlayerPauseButton.setVisibility(View.VISIBLE);

                playerState = TRYING_TO_MOVE_NEXT;
                Log.d(TAG, String.format("playerState = TRYING_TO_MOVE_NEXT"));

                processShortClickOnControlPanel();
            }
            else
            {
                mTtsPlayerPlayButton.setVisibility(View.VISIBLE);
                mTtsPlayerPauseButton.setVisibility(View.INVISIBLE);
                mMediaPlayer.stop();

                MediaPlayerState = PLAYER_STOPPED;  //we have to set this, because forcing to stop does not invoke onCompletion() event
                playerState = TRYING_TO_MOVE_NEXT;
                Log.d(TAG, String.format("playerState = TRYING_TO_MOVE_NEXT"));

                processShortClickOnControlPanel();
            }
        }
        else if(v.getId() == R.id.player_activity_googlemap_btn)
        {
            //mGoogleMapButton.setVisibility(View.GONE);
            //mImageScreenButton.setVisibility(View.VISIBLE);
            //mVideoScreenButton.setButtonUp();

            supportMapFragment.getView().setVisibility(View.VISIBLE);
            mSearchHumanButton.setVisibility(View.VISIBLE);
            mCurrentSpotButton.setVisibility(View.VISIBLE);

            mPlayerScreenImageView.setVisibility(View.INVISIBLE);

            mVideoPlayer.setVisibility(View.INVISIBLE);

            showControlPanel();

            mIsGoogleMapMode = true;

            mPlayerControlPanelLayout.setVisibility(View.VISIBLE);
            mIsControlPanelVisible = true;
        }
        else if(v.getId() == R.id.player_activity_image_btn)
        {
            //mGoogleMapButton.setVisibility(View.VISIBLE);
            //mImageScreenButton.setVisibility(View.GONE);
            //mVideoScreenButton.setButtonUp();

            supportMapFragment.getView().setVisibility(View.INVISIBLE);
            mSearchHumanButton.setVisibility(View.INVISIBLE);
            mCurrentSpotButton.setVisibility(View.INVISIBLE);
            mPlayerScreenImageView.setVisibility(View.VISIBLE);

            //mVideoPlayer.setVisibility(View.VISIBLE);

            hideControlPanel();

            mIsGoogleMapMode = false;

            //processShortClickOnControlPanel();
        }
        else if(v.getId() == R.id.tts_player_setting_button)
        {
            if(mSettingLayout.getVisibility() == View.VISIBLE)
            {
                mSettingLayout.setVisibility(View.INVISIBLE);

                mAutoNextSettingSwitch.setVisibility(View.INVISIBLE);
                mAutoNextTitle.setVisibility(View.INVISIBLE);

                mArrivingDetectionEventSettingSwitch.setVisibility(View.INVISIBLE);
                mArrivingDetectionEventTitle.setVisibility(View.INVISIBLE);
            }
            else
            {
                mSettingLayout.setVisibility(View.VISIBLE);

                mAutoNextSettingSwitch.setVisibility(View.VISIBLE);
                mAutoNextTitle.setVisibility(View.VISIBLE);

                if(mIsArrivingDetectionEventSettingSwitchVisible == true)
                {
                    mArrivingDetectionEventSettingSwitch.setVisibility(View.VISIBLE);
                    mArrivingDetectionEventTitle.setVisibility(View.VISIBLE);
                }
                else
                {
                    mArrivingDetectionEventSettingSwitch.setVisibility(View.INVISIBLE);
                    mArrivingDetectionEventTitle.setVisibility(View.INVISIBLE);
                }
            }
        }
        /*
        else if(v.getId() == R.id.player_activity_video_btn)
        {
            if(mVideoScreenButton.isButtonUp() == true)
            {
                mGoogleMapButton.setButtonUp();
                mImageScreenButton.setButtonUp();
                mVideoScreenButton.setButtonDown();

                supportMapFragment.getView().setVisibility(View.INVISIBLE);
                mSearchHumanButton.setVisibility(View.INVISIBLE);
                mCurrentSpotButton.setVisibility(View.INVISIBLE);
                mPlayerScreenImageView.setVisibility(View.INVISIBLE);
            }
        }
        */
        else if(v.getId() == R.id.player_search_human)
        {
            if(mLocation != null)
            {
                double current_lat = mLocation.getLatitude();
                double current_lng = mLocation.getLongitude();

                moveToPoint(current_lat, current_lng);
            }
        }
        else if(v.getId() == R.id.player_current_spot)
        {
            moveToPoint(false);

            /*
            Marker tmpMarker = retrieveMarker(routeIndex, spotIndex, eventIndex, lineIndex);
            if(tmpMarker != null)
            {
                MapMarkerBounce tmpBounce = new MapMarkerBounce(tmpMarker);
                tmpBounce.startBounce();
            }
            */
        }
    }

    private void processNodeClick()
    {
        if(mIsGoogleMapMode == false)
        {
            if(mIsControlPanelVisible == true)
            {
                //Load animation
                //mPlayerControlPanelLayout.startAnimation(mSlideDown);

                //mPlayerControlPanelLayout.setVisibility(View.GONE);
                hideControlPanel();

                mIsControlPanelVisible = false;
            }
            else
            {
                mLastContolPanelVisibleEventTime = System.currentTimeMillis();
                //mPlayerControlPanelLayout.setVisibility(View.VISIBLE);

                //Animation slide_up = AnimationUtils.loadAnimation(PlayerActivity.this, R.anim.slide_up);

                //mPlayerControlPanelLayout.startAnimation(mSlideUp);
                showControlPanel();

                mIsControlPanelVisible = true;

                mDisplayHandler.postDelayed(mControlPanelDisplayRunnable, 1000);
            }
        }
        else
        {

        }
    }

    @Override
    public void onShortTouchClick()
    {
        processNodeClick();
    }

    @Override
    public void onControlPanelClick()
    {
        processShortClickOnControlPanel();
    }

    private void processShortClickOnControlPanel()
    {
        if(mIsGoogleMapMode == false)
        {
            mLastContolPanelVisibleEventTime = System.currentTimeMillis();
            //mPlayerControlPanelLayout.setVisibility(View.VISIBLE);
            //mPlayerControlPanelLayout.startAnimation(mSlideUp);
            showControlPanel();

            mIsControlPanelVisible = true;

            mDisplayHandler.removeCallbacks(mControlPanelDisplayRunnable);
            mDisplayHandler.postDelayed(mControlPanelDisplayRunnable, 1000);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
    {
        if(buttonView == mAutoNextSettingSwitch)
        {
            if(isChecked == true)
            {
                if(mIsArrivingDetectionSwitchOn == true)
                {
                    //mAutoNextSwitchOn = true;
                    FragmentManager fm = getFragmentManager();
                    if(mGeneralAlarmDialog != null)
                    {
                        mGeneralAlarmDialog.dismiss();
                        mGeneralAlarmDialog = null;
                    }
                    mGeneralAlarmDialog = new GeneralAlarmDialog();
                    mGeneralAlarmDialog.setTitleText(getString(R.string.turn_off_location_event));
                    mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
                    mGeneralAlarmDialog.show(fm, "tag");

                    mAutoNextSettingSwitch.toggle();
                    mAutoNextSwitchOn = false;
                }
                else
                {
                    mAutoNextSwitchOn = true;
                }
            }
            else
            {
                mAutoNextSwitchOn = false;
            }
        }
        else if(buttonView == mArrivingDetectionEventSettingSwitch)
        {
            if(isChecked == true)
            {
                if(mAutoNextSwitchOn == false)
                {
                    if(mCurrentEvent != null)
                    {
                        int locationDetectionState = mCurrentEvent.getLocationDetection();
                        int distanceForLocationDetection = mCurrentEvent.getDistanceForLocationDetection();

                        if((locationDetectionState == ServerMapEventData.LOCATION_DETECTION_DISABLED)
                                || (distanceForLocationDetection == 0))
                        {
                            //Toast.makeText(PlayerActivity.this, "warning", Toast.LENGTH_LONG);

                            FragmentManager fm = getFragmentManager();
                            if(mGeneralAlarmDialog != null)
                            {
                                mGeneralAlarmDialog.dismiss();
                                mGeneralAlarmDialog = null;
                            }
                            mGeneralAlarmDialog = new GeneralAlarmDialog();
                            mGeneralAlarmDialog.setTitleText(getString(R.string.location_detection_is_disabled));
                            mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
                            mGeneralAlarmDialog.show(fm, "tag");

                            mArrivingDetectionEventSettingSwitch.toggle();
                        }
                        else
                        {
                            double tmpLat = mCurrentEvent.getLat();
                            double tmpLng = mCurrentEvent.getLng();
                            int tmpDistance = mCurrentEvent.getDistanceForLocationDetection();
                            String eventTitle = mCurrentEvent.getTitle();

                            addDetectionLocation(tmpLat, tmpLng, tmpDistance, eventTitle);

                            mIsArrivingDetectionSwitchOn = true;
                        }
                    }
                    else
                    {
                        FragmentManager fm = getFragmentManager();
                        if(mGeneralAlarmDialog != null)
                        {
                            mGeneralAlarmDialog.dismiss();
                            mGeneralAlarmDialog = null;
                        }
                        mGeneralAlarmDialog = new GeneralAlarmDialog();
                        mGeneralAlarmDialog.setTitleText(getString(R.string.current_node_is_in_invalid_state));
                        mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
                        mGeneralAlarmDialog.show(fm, "tag");

                        mArrivingDetectionEventSettingSwitch.toggle();
                    }
                }
                else
                {
                    FragmentManager fm = getFragmentManager();
                    if(mGeneralAlarmDialog != null)
                    {
                        mGeneralAlarmDialog.dismiss();
                        mGeneralAlarmDialog = null;
                    }
                    mGeneralAlarmDialog = new GeneralAlarmDialog();
                    mGeneralAlarmDialog.setTitleText(getString(R.string.you_must_not_set_auto_next_to_this_function));
                    mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
                    mGeneralAlarmDialog.show(fm, "tag");

                    mArrivingDetectionEventSettingSwitch.toggle();
                    //warniing
                    //mIsArrivingDetectionSwitchOn = true;
                }
            }
            else
            {
                mIsArrivingDetectionSwitchOn = false;
                resetDetectionLocation();
            }
        }
    }

    public void loadMapArray(int index)
    {
        String indexStr = String.valueOf(index);

        FileInputStream tmpInput = null;
        try
        {
            Cursor localCursor = null;
            try
            {
                if(mIsTestMap == TYPE_TEST_MAP)
                {
                    localCursor = mDBAdapter.getFileNameForTestMap(mSkuStr, indexStr, mUserDir);
                }
                else
                {
                    localCursor = mDBAdapter.getFileName(mSkuStr, indexStr, mUserDir);
                }
            }
            catch(SQLException sqe)
            {
                sqe.printStackTrace();
            }

            String tmpJsonFile = "";
            if(localCursor.moveToFirst())
            {
                tmpJsonFile = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FILE_NAME));
            }

            String localPathStr = "";
            if(mIsTestMap == TYPE_TEST_MAP)
            {
                localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + tmpJsonFile;
            }
            else
            {
                localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + tmpJsonFile;
            }

            //tmpInput = new FileInputStream(new File("/storage/sdcard0/tourguide_001.json"));
            tmpInput = new FileInputStream(new File(localPathStr));
            JsonParser jsonParser = new JsonParser();
            try
            {
                mapData = jsonParser.parse(tmpInput);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            catch (JSONException je)
            {
                je.printStackTrace();
                Log.e(TAG, je.getMessage());
            }
        }
        catch (FileNotFoundException e)
        {
            System.out.println(e);
            e.printStackTrace();
        } finally
        {
            if (tmpInput != null)
            {
                try
                {
                    tmpInput.close();
                }
                catch (IOException e)
                {
                }
                tmpInput = null;
            }
        }

    }

    private void sortMapArray()
    {
        List<ServerMapRouteData> tmpRoutes = mapData.getRoute();

        if (tmpRoutes != null)
        {
            //MapRouteData tmpr = tmpRoutes.get(routeIndex);
            ServerMapRouteData tmpr = tmpRoutes.get(0);
            totalRouteCount = tmpRoutes.size();
            if (tmpr != null)
            {
                List<ServerMapSpotData> tmpSpots = tmpr.getSpot();
                Collections.sort(tmpSpots);

                for(int x = 0 ; x < tmpSpots.size(); x++)
                {
                    ServerMapSpotData oneSpot =  tmpSpots.get(x);

                    if (oneSpot != null)
                    {
                        List<ServerMapEventData> tmpEvents = oneSpot.getEvent();
                        Collections.sort(tmpEvents);
                    }
                }
            }
        }
    }

    private boolean isSpotsContainThisId(ArrayList<ServerMapSpotData> tmpSpots, int tmp_id)
    {
        for(int i = 0; i < tmpSpots.size(); i++)
        {
            if(tmpSpots.get(i).getId() == tmp_id)
            {
                return true;
            }
        }
        return false;
    }

    private void loadGraph(int tmpRouteIndex)   //verified
    {
        if(routeGraph == null)
        {
            routeGraph = new Graph();
        }
        else
        {
            routeGraph.clearData();
        }

        List<ServerMapRouteData> tmpRoutes = mapData.getRoute();

        if (tmpRoutes != null)
        {
            ServerMapRouteData tmpr = tmpRoutes.get(tmpRouteIndex);

            if (tmpr != null)
            {
                List<ServerMapSpotData> tmpSpots = tmpr.getSpot();

                int same_index_spots_count = 0;
                ArrayList<ServerMapSpotData> dataForVertexGroup = null;
                int previous_index = -1;
                for (int x = 0; x < tmpSpots.size(); x++)
                {
                    ServerMapSpotData tmpSpotData = tmpSpots.get(x);
                    int spot_index = tmpSpotData.getIndex();

                    if (x == (tmpSpots.size() - 1))
                    {
                        if (previous_index == -1)
                        {
                            //first and last
                            dataForVertexGroup = new ArrayList<ServerMapSpotData>();
                            dataForVertexGroup.add(tmpSpotData);

                            VertexGroup tmpVertex = new VertexGroup(dataForVertexGroup);

                            for(int z = 0; z < dataForVertexGroup.size(); z++)
                            {
                                ServerMapSpotData tmpSpot = dataForVertexGroup.get(z);
                                int tmpRecommendedId = tmpSpot.getNextRecommendedSpotId();

                                if(tmpRecommendedId != ServerMapSpotData.NO_NEXT_RECOMMENDED_SPOT_ID)
                                {
                                    tmpVertex.setNextRecommendedSpotId(tmpSpot.getId(), tmpRecommendedId);
                                    break;
                                }
                            }

                            routeGraph.addVertex(tmpVertex, true);
                        }
                        else if (spot_index != previous_index)
                        {
                            //add previous nodes
                            VertexGroup tmpVertex = new VertexGroup(dataForVertexGroup);

                            for(int z = 0; z < dataForVertexGroup.size(); z++)
                            {
                                ServerMapSpotData tmpSpot = dataForVertexGroup.get(z);
                                int tmpRecommendedId = tmpSpot.getNextRecommendedSpotId();

                                if(tmpRecommendedId != ServerMapSpotData.NO_NEXT_RECOMMENDED_SPOT_ID)
                                {
                                    tmpVertex.setNextRecommendedSpotId(tmpSpot.getId(), tmpRecommendedId);
                                    break;
                                }
                            }

                            routeGraph.addVertex(tmpVertex, true);

                            //add current last node
                            dataForVertexGroup = new ArrayList<ServerMapSpotData>();
                            dataForVertexGroup.add(tmpSpotData);

                            tmpVertex = new VertexGroup(dataForVertexGroup);

                            for(int z = 0; z < dataForVertexGroup.size(); z++)
                            {
                                ServerMapSpotData tmpSpot = dataForVertexGroup.get(z);
                                int tmpRecommendedId = tmpSpot.getNextRecommendedSpotId();

                                if(tmpRecommendedId != ServerMapSpotData.NO_NEXT_RECOMMENDED_SPOT_ID)
                                {
                                    tmpVertex.setNextRecommendedSpotId(tmpSpot.getId(), tmpRecommendedId);
                                    break;
                                }
                            }

                            routeGraph.addVertex(tmpVertex, true);
                        }
                        else
                        {
                            dataForVertexGroup.add(tmpSpotData);

                            VertexGroup tmpVertex = new VertexGroup(dataForVertexGroup);

                            for(int z = 0; z < dataForVertexGroup.size(); z++)
                            {
                                ServerMapSpotData tmpSpot = dataForVertexGroup.get(z);
                                int tmpRecommendedId = tmpSpot.getNextRecommendedSpotId();

                                if(tmpRecommendedId != ServerMapSpotData.NO_NEXT_RECOMMENDED_SPOT_ID)
                                {
                                    tmpVertex.setNextRecommendedSpotId(tmpSpot.getId(), tmpRecommendedId);
                                    break;
                                }
                            }

                            routeGraph.addVertex(tmpVertex, true);
                        }
                    }
                    else
                    {
                        if (previous_index == -1)
                        {
                            //first but not last
                            dataForVertexGroup = new ArrayList<ServerMapSpotData>();
                            dataForVertexGroup.add(tmpSpotData);
                        }
                        else if (spot_index != previous_index)
                        {
                            //add previous nodes
                            VertexGroup tmpVertex = new VertexGroup(dataForVertexGroup);

                            for(int z = 0; z < dataForVertexGroup.size(); z++)
                            {
                                ServerMapSpotData tmpSpot = dataForVertexGroup.get(z);
                                int tmpRecommendedId = tmpSpot.getNextRecommendedSpotId();

                                if(tmpRecommendedId != ServerMapSpotData.NO_NEXT_RECOMMENDED_SPOT_ID)
                                {
                                    tmpVertex.setNextRecommendedSpotId(tmpSpot.getId(), tmpRecommendedId);
                                    break;
                                }
                            }

                            routeGraph.addVertex(tmpVertex, true);

                            //add current node
                            dataForVertexGroup = new ArrayList<ServerMapSpotData>();
                            dataForVertexGroup.add(tmpSpotData);
                        }
                        else
                        {
                            //not last and same index with previous node index
                            dataForVertexGroup.add(tmpSpotData);
                        }
                    }
                    previous_index = spot_index;
                }
                dataForVertexGroup = null;

                //int tmpVerticesSize = routeGraph.getVertexsSize();

                //illustrate the fact that duplicate edges aren't added
                //for (int i = 0; i < tmpVerticesSize - 1; i++)
                //{
                Iterator it = routeGraph.getVertices().entrySet().iterator();
                while (it.hasNext())
                {
                    Map.Entry entry = (Map.Entry)it.next();

                    String key = (String)entry.getKey();
                    VertexGroup value = (VertexGroup)entry.getValue();

                    Iterator loop_it = routeGraph.getVertices().entrySet().iterator();

                    ArrayList<ServerMapSpotData> tmp_spot_list = value.getSpots();

                    int nextIndex[] = tmp_spot_list.get(0).getNexts();
                    int prevIndex[] = tmp_spot_list.get(0).getPrevs();

                    while (loop_it.hasNext())
                    {
                        Map.Entry loop_entry = (Map.Entry) loop_it.next();

                        String loop_key = (String) loop_entry.getKey();
                        VertexGroup loop_value = (VertexGroup) loop_entry.getValue();

                        ArrayList<ServerMapSpotData> loop_tmp_spot_list = loop_value.getSpots();
                        int loopIndex = loop_tmp_spot_list.get(0).getIndex();

                        //if index match next/prev, then link both
                        if (loopIndex != ServerMapSpotData.NO_INDEX)
                        {
                            if(nextIndex != null)
                            {
                                if(nextIndex[0] != ServerMapSpotData.NO_INDEX)
                                {
                                    for(int x = 0; x < nextIndex.length; x++)
                                    {
                                        if(nextIndex[x] == loopIndex)
                                        {
                                            //then value spot is prev vertex
                                            //loop_value spot is next vertex

                                            //for(int z = 0; z < tmp_spot_list.size(); z++)
                                            //{
                                            int recommended_link[] = value.getNextRecommendedSpotId();

                                            if(recommended_link[1] != VertexGroup.NO_RECOMMENDED_ID)
                                            {
                                                ArrayList<ServerMapSpotData> loop_spots = loop_value.getSpots();
                                                boolean ret_contain = isSpotsContainThisId(loop_spots, recommended_link[1]);
                                                if(ret_contain == true)
                                                {
                                                    routeGraph.addEdgeWithFalseWeight(value, loop_value, recommended_link[0], recommended_link[1]);
                                                }
                                                else
                                                {
                                                    routeGraph.addEdgeWithFalseWeight(value, loop_value, VertexGroup.NO_RECOMMENDED_ID, VertexGroup.NO_RECOMMENDED_ID);
                                                }
                                            }
                                            else
                                            {
                                                routeGraph.addEdgeWithFalseWeight(value, loop_value, VertexGroup.NO_RECOMMENDED_ID, VertexGroup.NO_RECOMMENDED_ID);
                                            }
                                            //}
                                            break;
                                        }
                                    }
                                }
                            }

                            /*
                            if(prevIndex != null)
                            {
                                if(prevIndex[0] != MapSpotData.NO_INDEX)
                                {
                                    for(int x = 0; x < prevIndex.length; x++)
                                    {
                                        if(prevIndex[x] == loopIndex)
                                        {
                                            //then this spot is next spot
                                            //for(int z = 0; z < tmp_spot_list.size(); z++)
                                            //{
                                            int recommended_link[] = value.getNextRecommendedSpotId();

                                            if(recommended_link[1] != VertexGroup.NO_RECOMMENDED_ID)
                                            {
                                                ArrayList<MapSpotData> loop_spots = loop_value.getSpots();
                                                boolean ret_contain = isSpotsContainThisId(loop_spots, recommended_link[1]);
                                                if(ret_contain == true)
                                                {
                                                    routeGraph.addEdgeWithFalseWeight(value, loop_value, recommended_link[0], recommended_link[1]);
                                                }
                                                else
                                                {
                                                    routeGraph.addEdgeWithFalseWeight(value, loop_value, VertexGroup.NO_RECOMMENDED_ID, VertexGroup.NO_RECOMMENDED_ID);
                                                }
                                            }
                                            else
                                            {
                                                routeGraph.addEdgeWithFalseWeight(value, loop_value, VertexGroup.NO_RECOMMENDED_ID, VertexGroup.NO_RECOMMENDED_ID);
                                            }
                                            //}
                                            break;
                                        }
                                    }
                                }
                            }
                            */
                        }
                    }
                }
                //}
            }
        }
    }

    private ArrayList<VertexGroup> getNextVertices(VertexGroup tmpValue)
    {
        ArrayList<Edge> tmpPath = tmpValue.getNeighbors();
        ArrayList<VertexGroup> tmpVerticesList = new ArrayList<VertexGroup>();

        //there is only 1 next node, search next node
        for(int x = 0; x < tmpPath.size(); x++)
        {
            Edge tmpEdge = tmpPath.get(x);

            if (tmpValue == tmpEdge.getFront())
            {
                //prev node
            }
            else if (tmpValue == tmpEdge.getBack())
            {
                //tmpEdge.getFront().getSpots();
                VertexGroup tmpNext = tmpEdge.getFront();
                tmpVerticesList.add(tmpNext);
            }
        }

        return tmpVerticesList;
    }

    private int getForwardSpotNodesInfoInThePath(VertexGroup tmpValue, ArrayList<NodeProgressBarItem> nodeList)
    {
        int nextPathCount = 0;
        ArrayList<Edge> tmpPath = tmpValue.getNeighbors();

        int edgeCount = 0;
        boolean isWeightPathExist = false;
        boolean isRecommendedPathExist = false;
        for(int x = 0; x < tmpPath.size(); x++)
        {
            Edge tmpEdge = tmpPath.get(x);

            if (tmpValue == tmpEdge.getFront())
            {
                //prev node
            }
            else if (tmpValue == tmpEdge.getBack())
            {
                edgeCount++;

                if(tmpEdge.getWeight() == Edge.WEIGHT_TRUE)
                {
                    isWeightPathExist = true;
                }

                int recommended_link[] = tmpEdge.getRecommendedLink();
                //if((recommended_link[0] != Edge.NO_RECOMMENDED_ID))
                if((recommended_link[0] != Edge.NO_RECOMMENDED_ID) && (recommended_link[1] != Edge.NO_RECOMMENDED_ID))
                {
                    isRecommendedPathExist = true;
                }
                /*
                if(tmpEdge.getRecommended() == Edge.RECOMMENDED_TRUE)
                {
                    isRecommendedPathExist = true;
                }
                */
            }
        }

        //there is only 1 next node, search next node
        for(int x = 0; x < tmpPath.size(); x++)
        {
            Edge tmpEdge = tmpPath.get(x);

            if (tmpValue == tmpEdge.getFront())
            {
                //prev node
            }
            else if (tmpValue == tmpEdge.getBack())
            {
                if(edgeCount > 1)   //multi path
                {
                    if(isWeightPathExist == true)
                    {
                        if(tmpEdge.getWeight() == Edge.WEIGHT_TRUE)
                        {
                            //next node is multiple node
                            //propertyList.add(NodeProgressBar.NODE_MULTI);
                            NodeProgressBarItem tmpItem = new NodeProgressBarItem();
                            tmpItem.property = NodeProgressBar.NODE_OPTIONAL;
                            nodeList.add(tmpItem);

                            nextPathCount++;

                            tmpItem = new NodeProgressBarItem();
                            tmpItem.property = NodeProgressBar.NODE_MULTI;
                            tmpItem.vertex = tmpEdge.getFront();
                            nodeList.add(tmpItem);

                            nextPathCount++;

                            nextPathCount += getForwardSpotNodesInfoInThePath(tmpEdge.getFront(), nodeList);
                        }
                    }
                    else if(isRecommendedPathExist == true)
                    {
                        //if(tmpEdge.getRecommended() == Edge.RECOMMENDED_TRUE)
                        int recommended_link[] = tmpEdge.getRecommendedLink();
                        if((recommended_link[0] != Edge.NO_RECOMMENDED_ID) && (recommended_link[1] != Edge.NO_RECOMMENDED_ID))
                        {
                            //next node is multiple node
                            //propertyList.add(NodeProgressBar.NODE_MULTI);
                            NodeProgressBarItem tmpItem = new NodeProgressBarItem();
                            tmpItem.property = NodeProgressBar.NODE_OPTIONAL;
                            nodeList.add(tmpItem);

                            nextPathCount++;

                            tmpItem = new NodeProgressBarItem();
                            tmpItem.property = NodeProgressBar.NODE_MULTI;
                            tmpItem.vertex = tmpEdge.getFront();
                            nodeList.add(tmpItem);

                            nextPathCount++;

                            nextPathCount += getForwardSpotNodesInfoInThePath(tmpEdge.getFront(), nodeList);
                        }
                    }
                    else
                    {
                        NodeProgressBarItem tmpItem = new NodeProgressBarItem();
                        tmpItem.property = NodeProgressBar.NODE_OPTIONAL;
                        nodeList.add(tmpItem);

                        return 1;
                    }
                }
                else    //single path
                {
                    //single path and single node
                    tmpEdge.setWeight(Edge.WEIGHT_TRUE);        //this code is not related to node count, but let's set weight for single path for future purpose.

                    //next node
                    NodeProgressBarItem tmpItem = new NodeProgressBarItem();
                    tmpItem.property = NodeProgressBar.NODE_SINGLE;
                    tmpItem.vertex = tmpEdge.getFront();
                    nodeList.add(tmpItem);

                    nextPathCount++;

                    nextPathCount += getForwardSpotNodesInfoInThePath(tmpEdge.getFront(), nodeList);
                }
                /*
                else if (tmpEdge.getFront().getSpots().size() > 1)   //multi node
                {
                    //single path but multi node
                    tmpEdge.setWeight(Edge.WEIGHT_TRUE);        //this code is not related to node count, but let's set weight for single path for future purpose.

                    int weightIndex = tmpEdge.getFront().getSpotWeightIndex();
                    if(weightIndex == -1)
                    {
                        //int recommendedIndex = tmpEdge.getFront().getSpotRecommendedIndex();
                        //if(recommendedIndex == -1)
                        int recommended_link[] = tmpEdge.getRecommendedLink();
                        if((recommended_link[0] == Edge.NO_RECOMMENDED_ID) || (recommended_link[1] == Edge.NO_RECOMMENDED_ID))
                        {
                            NodeProgressBarItem tmpItem = new NodeProgressBarItem();
                            tmpItem.property = NodeProgressBar.NODE_OPTIONAL;
                            nodeList.add(tmpItem);

                            return 1;
                        }
                        else
                        {
                            NodeProgressBarItem tmpItem = new NodeProgressBarItem();
                            tmpItem.property = NodeProgressBar.NODE_OPTIONAL;
                            nodeList.add(tmpItem);

                            nextPathCount++;

                            tmpItem = new NodeProgressBarItem();
                            tmpItem.property = NodeProgressBar.NODE_MULTI;
                            tmpItem.vertex = tmpEdge.getFront();
                            nodeList.add(tmpItem);

                            nextPathCount++;

                            nextPathCount += getForwardSpotNodesInfoInThePath(tmpEdge.getFront(), nodeList);
                        }
                    }
                    else
                    {
                        NodeProgressBarItem tmpItem = new NodeProgressBarItem();
                        tmpItem.property = NodeProgressBar.NODE_OPTIONAL;
                        nodeList.add(tmpItem);

                        nextPathCount++;

                        tmpItem = new NodeProgressBarItem();
                        tmpItem.property = NodeProgressBar.NODE_MULTI;
                        tmpItem.vertex = tmpEdge.getFront();
                        nodeList.add(tmpItem);

                        nextPathCount++;

                        nextPathCount += getForwardSpotNodesInfoInThePath(tmpEdge.getFront(), nodeList);
                    }
                }
                */
            }
        }

        return nextPathCount;
    }

    public void initEvent()
    {
        Message msg = playerHandler.obtainMessage();
        Bundle b = new Bundle();
        b.putString(HANDLER_HEADER, "init_event");
        msg.setData(b);
        playerHandler.sendMessage(msg);
    }

    public int loadGUI(int tmpRouteIndex, int tmpSpotIndex, int tmpEventIndex, int tmpLineIndex)
    {
        //calculating the number of spotindex for this path
        Iterator it = routeGraph.getVertices().entrySet().iterator();
        it.hasNext();
        Map.Entry entry = (Map.Entry) it.next();

        VertexGroup value = (VertexGroup) entry.getValue();
        int spotType = value.getSpots().get(0).getType();

        nodeList.clear();

        int totalNode = 0;

        if( (spotType == ServerMapSpotData.NODE_TYPE_SINGLE) || (spotType == ServerMapSpotData.NODE_TYPE_INTRO))
        {
            totalNode++;    //first node
            NodeProgressBarItem tmpNode = new NodeProgressBarItem();

            ServerMapSpotData tmpSpot = value.getSpots().get(0);
            if(tmpSpot.getType() == ServerMapSpotData.NODE_TYPE_INTRO)
            {
                //intro node
                tmpNode.property = NodeProgressBar.NODE_INTRO;
            }
            else
            {
                //normal single node
                tmpNode.property = NodeProgressBar.NODE_SINGLE;
            }

            tmpNode.vertex = value;
            nodeList.add(tmpNode);

            routeGraph.resetPathWeight();
            routeGraph.readPathFromSelectedBuffer();
            routeGraph.printPathWeight();
            totalNode += getForwardSpotNodesInfoInThePath(value, nodeList);
        }
        else
        {
            //exceptional situation : first node can't be multi or branch node
            return -1;
        }

        //routeGraph.printPathWeight();

        totalSpotCount = totalNode;
        //mBallonImageGalleryBar.setNumOfImageNodex(totalNode);

        if(nodeList.size() >= 1)
        {
            int nodePrpperty[] = new int[nodeList.size()];
            String filePaths[] = new String[nodeList.size()];
            String titles[] = new String[nodeList.size()];
            for(int x = 0; x < nodeList.size(); x++)
            {
                nodePrpperty[x] = nodeList.get(x).property;
                if(nodePrpperty[x] == NodeProgressBar.NODE_OPTIONAL)
                {
                    filePaths[x] = null;
                    titles[x] = null;
                }
                else if(nodePrpperty[x] == NodeProgressBar.NODE_MULTI)
                {
                    VertexGroup tmpVertex = nodeList.get(x).vertex;

                    int weightIndex = tmpVertex.getSpotWeightIndex();
                    //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
                    int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, x);
                    String imagePath = null;
                    String titleStr = null;
                    if(weightIndex != -1)
                    {
                        //String imageId = tmpVertex.getSpots().get(weightIndex).getImageId();
                        String tmpImageData = tmpVertex.getSpots().get(weightIndex).getImageData();
                        String imageId = null;
                        if( (tmpImageData != null) && (tmpImageData.equals("") == false))
                        {
                            String rectangleData = mapData.getResource().getRectangle(tmpImageData);
                            imageId = getImageIdAndRectangle(rectangleData, null);
                        }

                        imagePath = mapData.getResource().getImage(imageId);

                        titleStr = tmpVertex.getSpots().get(weightIndex).getTitle();
                    }
                    else if(recommendedIndex != -1)
                    {
                        //String imageId = tmpVertex.getSpots().get(recommendedIndex).getImageId();
                        String tmpImageData = tmpVertex.getSpots().get(recommendedIndex).getImageData();
                        String imageId = null;
                        if( (tmpImageData != null) && (tmpImageData.equals("") == false))
                        {
                            String rectangleData = mapData.getResource().getRectangle(tmpImageData);
                            imageId = getImageIdAndRectangle(rectangleData, null);
                        }
                        imagePath = mapData.getResource().getImage(imageId);

                        titleStr = tmpVertex.getSpots().get(recommendedIndex).getTitle();
                    }
                    else
                    {
                        //String imageId = tmpVertex.getSpots().get(0).getImageId();
                        String tmpImageData = tmpVertex.getSpots().get(0).getImageData();
                        String imageId = null;
                        if( (tmpImageData != null) && (tmpImageData.equals("") == false))
                        {
                            String rectangleData = mapData.getResource().getRectangle(tmpImageData);
                            imageId = getImageIdAndRectangle(rectangleData, null);
                        }
                        imagePath = mapData.getResource().getImage(imageId);

                        titleStr = tmpVertex.getSpots().get(0).getTitle();
                    }

                    if(imagePath != null)
                    {
                        String localPathStr = "";

                        if(mIsTestMap == TYPE_TEST_MAP)
                        {
                            localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + imagePath;
                        }
                        else
                        {
                            localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + imagePath;
                        }
                        //filePaths[x] = "/storage/sdcard0/" + imagePath;
                        filePaths[x] = localPathStr;
                    }
                    else
                    {
                        filePaths[x] = null;
                    }

                    if(titleStr != null)
                    {
                        titles[x] = titleStr;
                    }
                    else
                    {
                        titles[x] = null;
                    }
                }
                else if((nodePrpperty[x] == NodeProgressBar.NODE_SINGLE) || (nodePrpperty[x] == NodeProgressBar.NODE_INTRO))
                {
                    VertexGroup tmpVertex = nodeList.get(x).vertex;

                    //String imageId = tmpVertex.getSpots().get(0).getImageId();
                    String tmpImageData = tmpVertex.getSpots().get(0).getImageData();
                    String imageId = null;
                    if( (tmpImageData != null) && (tmpImageData.equals("") == false))
                    {
                        String rectangleData = mapData.getResource().getRectangle(tmpImageData);
                        imageId = getImageIdAndRectangle(rectangleData, null);
                    }

                    String imagePath = mapData.getResource().getImage(imageId);

                    String titleStr = tmpVertex.getSpots().get(0).getTitle();

                    if(imagePath != null)
                    {
                        String localPathStr = "";

                        if(mIsTestMap == TYPE_TEST_MAP)
                        {
                            localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + imagePath;
                        }
                        else
                        {
                            localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + imagePath;
                        }
                        filePaths[x] = localPathStr;
                    }
                    else
                    {
                        filePaths[x] = null;
                    }

                    if(titleStr != null)
                    {
                        titles[x] = titleStr;
                    }
                    else
                    {
                        titles[x] = null;
                    }
                }
            }

            mSpotDataList.clear();
            for(int k = 0; k < filePaths.length; k++)
            {
                SpotGUI tmpSpot = new SpotGUI();
                tmpSpot.mSpotImagePath = filePaths[k];
                tmpSpot.mSpotTitle = titles[k];
                tmpSpot.mSpotType = nodePrpperty[k];
                mSpotDataList.add(tmpSpot);
            }

            Message msg = playerHandler.obtainMessage();
            Bundle b = new Bundle();
            b.putString(HANDLER_HEADER, "spot_gui");
            msg.setData(b);
            playerHandler.sendMessage(msg);

            //mBallonImageGalleryBar.setmImageGalleryInfos(filePaths, titles);
            //mBallonImageGalleryBar.setImageGalleryProperty(nodePrpperty);
        }

        if(tmpSpotIndex >= nodeList.size())
        {
            return -1;
        }

        NodeProgressBarItem tmpElement = nodeList.get(tmpSpotIndex);
        VertexGroup tmpVertex = tmpElement.vertex;

        if(tmpVertex == null)
        {
            return -1;
        }

        int spotSize = tmpVertex.getSpots().size();
        ServerMapSpotData tmps = null;

        if(spotSize > 1)
        {
            int weightIndex = tmpVertex.getSpotWeightIndex();
            //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
            int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, tmpSpotIndex);

            int tmpIndex = 0;
            if(weightIndex < 0)
            {
                if(recommendedIndex < 0)
                {
                    tmpIndex = 0;
                }
                else
                {
                    tmpIndex = recommendedIndex;
                }
            }
            else
            {
                tmpIndex = weightIndex;
            }
            tmps = tmpVertex.getSpots().get(tmpIndex);
        }
        else
        {
            tmps = tmpVertex.getSpots().get(0);
        }

        int count = 0;
        int previous_index = -1;

        List<ServerMapEventData> tmpEvents = tmps.getEvent();
        if (tmpEvents != null)
        {
            count = 0;
            previous_index = -1;
            for(int x = 0; x < tmpEvents.size(); x++)
            {
                ServerMapEventData oneEvent = tmpEvents.get(x);
                if(previous_index != oneEvent.getIndex())
                {
                    previous_index = oneEvent.getIndex();
                    count++;
                }
            }

            //mBallonImageGalleryBar.setNumOfBalloonNodex(count, true);

            int eventNodePrpperty[] = new int[tmpEvents.size()];


            for(int x = 0; x < tmpEvents.size(); x++)
            {
                if(tmps.getType() == ServerMapSpotData.NODE_TYPE_INTRO)
                {
                    eventNodePrpperty[x] = NodeProgressBar.NODE_INTRO;
                }
                else
                {
                    if(tmpEvents.get(x).getType() == ServerMapEventData.NODE_TYPE_NO_LOCATION_RELATED)
                    {
                        eventNodePrpperty[x] = NodeProgressBar.NODE_INTRO;
                    }
                    else
                    {
                        eventNodePrpperty[x] = NodeProgressBar.NODE_SINGLE;
                    }
                }
            }


            mEventDataList.clear();
            for(int k = 0; k < eventNodePrpperty.length; k++)
            {
                EventGUI tmpEvent = new EventGUI();
                tmpEvent.mEventType = eventNodePrpperty[k];
                mEventDataList.add(tmpEvent);
            }

            Message msg = playerHandler.obtainMessage();
            Bundle b = new Bundle();
            b.putString(HANDLER_HEADER, "event_gui");
            msg.setData(b);
            playerHandler.sendMessage(msg);


            //mBallonImageGalleryBar.setBalloonProperty(eventNodePrpperty);
            //mBallonImageGalleryBar.setNumOfBalloonNodex(count, false);

            totalEventCount = count;

            ServerMapEventData tmpe = tmpEvents.get(eventIndex);

            if (tmpe != null)
            {
                mCurrentEvent = tmpe;

                String eventTitle = tmpe.getTitle();
                String spotTitle = tmps.getTitle();
                if((eventTitle != null) && (eventTitle.equals("") == false))
                {
                    currentTitleText = eventTitle;
                }
                else if((spotTitle != null) && (spotTitle.equals("") == false))
                {
                    currentTitleText = spotTitle;
                }
                else
                {
                    currentTitleText = "";
                }

                ServerMapTextData tmpt = tmpe.getText();

                if(tmpt != null)
                {
                    List<ServerMapLineData> tmpl = tmpt.getLines();

                    if (tmpl != null)
                    {
                        totalLineCount = tmpl.size();

                        lineIndex = 0;

                        ServerMapLineData oneLine = tmpl.get(lineIndex);

                        setCurrentResources(oneLine, tmpe);

                        return 0;
                    }
                }
            }
            else
            {
                mCurrentEvent = null;
            }
        }

        return -1;
    }

    /*
    private void setCurrentNode()
    {
        int totalSpotsSize = mapData.getRoute().get(routeIndex).getSpot().size();
        int spotTypes[] = new int[totalSpotsSize];
        for(int i = 0; i < totalSpotsSize; i++)
        {
            spotTypes[i] = mapData.getRoute().get(routeIndex).getSpot().get(i).getType();
        }

        mPlayerSpotNode.setTypes(spotTypes);
    }
    */

    private void showOrHideLocationDetectionSetting()
    {
        int locationDetectionState = mCurrentEvent.getLocationDetection();
        int distanceForLocationDetection = mCurrentEvent.getDistanceForLocationDetection();

        if((locationDetectionState == ServerMapEventData.LOCATION_DETECTION_DISABLED)
                || (distanceForLocationDetection == 0))
        {
            //mArrivingDetectionEventSettingSwitch.setVisibility(View.GONE);
            //mArrivingDetectionEventTitle.setVisibility(View.GONE);

            mIsArrivingDetectionEventSettingSwitchVisible = false;

            resetDetectionLocation();

            if(mIsArrivingDetectionSwitchOn == true)
            {
                mArrivingDetectionEventSettingSwitch.toggle();
                mIsArrivingDetectionSwitchOn = false;
            }
        }
        else
        {
            //mArrivingDetectionEventSettingSwitch.setVisibility(View.VISIBLE);
            //mArrivingDetectionEventTitle.setVisibility(View.VISIBLE);

            mIsArrivingDetectionEventSettingSwitchVisible = true;

            resetDetectionLocation();

            if(mIsArrivingDetectionSwitchOn == true)
            {
                mArrivingDetectionEventSettingSwitch.toggle();
                mIsArrivingDetectionSwitchOn = false;
            }
        }
    }


    private void setTitle(String text)
    {
        //mTitleTextView.setText(text);
    }

    private boolean isPlayAudioPlanned()
    {
        String audioPath = mapData.getResource().getAudio(currentAudioId);

        if ((audioPath != null) && (audioPath.equals("") == false))
        {
            {
                currentAudioPath = audioPath;

                //show new audio
                String localPathStr = "";
                if(mIsTestMap == TYPE_TEST_MAP)
                {
                    localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + currentAudioPath;
                }
                else
                {
                    localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + currentAudioPath;
                }
                File audioFile = new  File(localPathStr);
                //File audioFile = new  File("/storage/sdcard0/" + currentAudioPath);


                if(audioFile.exists())
                {
                    //supportMapFragment.getView().setVisibility(View.INVISIBLE);
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isPlayVideoPlanned()
    {
        String videoPath = mapData.getResource().getVideo(currentVideoId);

        if ((videoPath != null) && (videoPath.equals("") == false))
        {
            {
                currentVideoPath = videoPath;

                //show new audio
                String localPathStr = "";
                if(mIsTestMap == TYPE_TEST_MAP)
                {
                    localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + currentVideoPath;
                }
                else
                {
                    localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + currentVideoPath;
                }
                File videoFile = new  File(localPathStr);
                //File audioFile = new  File("/storage/sdcard0/" + currentAudioPath);

                if(videoFile.exists())
                {
                    //supportMapFragment.getView().setVisibility(View.INVISIBLE);
                    return true;
                }
            }
        }

        return false;
    }

    private void showImage()
    {
        String imagePath = mapData.getResource().getImage(currentImageId);

        mVideoPlayer.setVisibility(View.INVISIBLE);

        if ((imagePath != null) && (imagePath.equals("") == false))
        {
            if(imagePath.equals(currentImagePath) == false)
            {
                currentImagePath = imagePath;

                //show new image
                String localPathStr = "";

                if(mIsTestMap == TYPE_TEST_MAP)
                {
                    localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + currentImagePath;
                }
                else
                {
                    localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + currentImagePath;
                }
                File imageFile = new  File(localPathStr);
                //File imageFile = new  File("/storage/sdcard0/" + currentImagePath);

                if(imageFile.exists())
                {
                    //supportMapFragment.getView().setVisibility(View.INVISIBLE);
                    /*
                    Drawable d = mPlayerScreenImageView.getDrawable();
                    if (d instanceof BitmapDrawable)
                    {
                        Bitmap b = ((BitmapDrawable)d).getBitmap();
                        b.recycle();
                    } // 현재로서는 BitmapDrawable 이외의 drawable 들에 대한 직접적인 메모리 해제는 불가능하다.
                    d.setCallback(null);
                    */
                    mPlayerScreenImageView.setImageBitmap(null);

                    Bitmap tmpBitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
                    //Bitmap tmpBitmap = decodeSampledBitmapFromResource(imageFile.getAbsolutePath(), mPlayerScreenImageView.getWidth(), mPlayerScreenImageView.getHeight());

                    mPlayerScreenImageView.setImageBitmap(tmpBitmap);

                    /*
                    if(mImageScreenButton.isButtonUp() == true)
                    {
                        mImageScreenButton.setBlink(3);
                    }
                    */

                    if(currentImageRectangle == null)
                    {
                        mPlayerScreenImageView.setVisibleRect(false);
                    }
                    else
                    {
                        mPlayerScreenImageView.setRect(currentImageRectangle[0], currentImageRectangle[1], currentImageRectangle[2], currentImageRectangle[3]);
                        mPlayerScreenImageView.setVisibleRect(true);
                    }
                }
            }
            else
            {
                //do nothing
                //mPlayerScreenImageView.setVisibleRect(false);
                if(currentImageRectangle == null)
                {
                    mPlayerScreenImageView.setVisibleRect(false);
                }
                else
                {
                    float rect[] = mPlayerScreenImageView.getRect();

                    if(
                            (rect[0] != currentImageRectangle[0]) || (rect[1] != currentImageRectangle[1]) || (rect[2] != currentImageRectangle[2]) || (rect[3] != currentImageRectangle[3])
                            )
                    {
                        mPlayerScreenImageView.setRect(currentImageRectangle[0], currentImageRectangle[1], currentImageRectangle[2], currentImageRectangle[3]);
                        mPlayerScreenImageView.setVisibleRect(true);
                    }
                }
            }
            if(mPlayerScreenImageView.getVisibility() == View.INVISIBLE)
            {
                mPlayerScreenImageView.setVisibility(View.VISIBLE);
            }
        }
        else
        {
            if(isPlayAudioPlanned() == true || isPlayVideoPlanned() == true)
            {
                mPlayerScreenImageView.setImageBitmap(null);
                mPlayerScreenImageView.setImageResource(R.drawable.player_state);
                mPlayerScreenImageView.setVisibleRect(false);
            }
            else
            {
                mPlayerScreenImageView.setImageBitmap(null);
                mPlayerScreenImageView.setImageResource(R.drawable.no_image);
                mPlayerScreenImageView.setVisibleRect(false);
            }
        }
    }

    private static Bitmap decodeSampledBitmapFromResource(String resPath, int reqWidth, int reqHeight)
    {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        //BitmapFactory.decodeResource(res, resId, options);
        BitmapFactory.decodeFile(resPath, options);

        // Calculate inSampleSize
        //options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inSampleSize = 8;

                // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        //return BitmapFactory.decodeResource(res, resId, options);
        return BitmapFactory.decodeFile(resPath, options);
    }

    private static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight)
    {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth)
        {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth)
            {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    //getCurrentVertexRecommendedIndexFromNodeList(ArrayList<NodeProgressBarItem> tmpNodeList, int tmpSpotIndex);

    private void showOptionDialog(int nodeIndex)
    {
        NodeProgressBarItem tmpCurrentItem = nodeList.get(nodeIndex);

        NodeProgressBarItem tmpPreItem = nodeList.get(nodeIndex-1);
        ArrayList<VertexGroup> tmpVerticesList = getNextVertices(tmpPreItem.vertex);

        ArrayList<Integer> tmpRecommendedSpotIdList = getCurrnetVertexRecommendedSpotIdFromPreviousVertices(tmpPreItem.vertex);

        ArrayList<String> tmpImagePaths = new ArrayList<String>();
        ArrayList<String> tmpTitles = new ArrayList<String>();
        ArrayList<Integer> tmpRecommendations = new ArrayList<Integer>();
        ArrayList<VertexGroup> tmpVerticesArray = new ArrayList<VertexGroup>();
        ArrayList<Integer> tmpSpotIndex = new ArrayList<Integer>();

        if (tmpCurrentItem.property == NodeProgressBar.NODE_OPTIONAL)
        {
            //next can be multi spots or multi paths
        }
        else
        {
            //strange case
            return;
        }

        for(int x = 0; x < tmpVerticesList.size(); x++)
        {
            VertexGroup tmpVertex = tmpVerticesList.get(x);

            ArrayList<ServerMapSpotData> tmpSpots = tmpVertex.getSpots();
            for(int y = 0 ; y < tmpSpots.size(); y++)
            {
                tmpTitles.add(tmpSpots.get(y).getTitle());

                boolean recommendSelectedFlag = false;

                for(int z = 0; z < tmpRecommendedSpotIdList.size(); z++)
                {
                    if(tmpSpots.get(y).getId() == tmpRecommendedSpotIdList.get(z))
                    {
                        tmpRecommendations.add(ServerMapSpotData.NODE_RECOMMENDED_TRUE);
                        recommendSelectedFlag = true;
                    }
                }

                if(recommendSelectedFlag == false)
                {
                    tmpRecommendations.add(ServerMapSpotData.NODE_RECOMMENDED_NONE);
                }

                //tmpRecommendations.add(tmpSpots.get(y).getRecommended());
                //String tmpImageId = tmpSpots.get(y).getEvent().get(0).getImageId();

                //String tmpImageData = tmpSpots.get(y).getEvent().get(0).getImageData();
                String tmpImageData = tmpSpots.get(y).getImageData();
                String tmpImageId = null;
                if( (tmpImageData != null) && (tmpImageData.equals("") == false))
                {
                    String rectangleData = mapData.getResource().getRectangle(tmpImageData);
                    tmpImageId = getImageIdAndRectangle(rectangleData, null);
                }

                String imagePath = mapData.getResource().getImage(tmpImageId);
                tmpImagePaths.add(imagePath);

                tmpVerticesArray.add(tmpVertex);

                tmpSpotIndex.add(y);
            }
        }

        FragmentManager fm = getFragmentManager();
        spotDialog = new SpotOptionDialog();
        //Bundle args = new Bundle();
        //args.putString("titles", tmpTitles);
        //args.putString("paths", tmpImagePaths);
        //dialog.setArguments(args);
        spotDialog.setLists(mSkuStr, tmpTitles, tmpRecommendations, tmpImagePaths, tmpVerticesArray, tmpSpotIndex);
        spotDialog.setOptionListener(this);
        spotDialog.setFromNode(nodeIndex);
        spotDialog.setCancelable(false);
        //dialog.setTargetFragment(this,  0);
        spotDialog.show(fm, "tag");
    }

    public void moveToPoint(boolean init_flag)
    {
        //MapEventData tmpEvent = mapData.getRoute().get(routeIndex).getSpot().get(spotIndex).getEvent().get(eventIndex);
        NodeProgressBarItem tmpElement = nodeList.get(spotIndex);
        VertexGroup tmpVertex = tmpElement.vertex;

        if(tmpVertex == null)
        {
            return;
        }

        int spotSize = tmpVertex.getSpots().size();
        ServerMapSpotData tmps = null;
        if(spotSize > 1)
        {
            int weightIndex = tmpVertex.getSpotWeightIndex();
            //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
            int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, spotIndex);

            int tmpIndex = 0;
            if(weightIndex < 0)
            {
                if(recommendedIndex < 0)
                {
                    tmpIndex = 0;
                }
                else
                {
                    tmpIndex = recommendedIndex;
                }
            }
            else
            {
                tmpIndex = weightIndex;
            }
            tmps = tmpVertex.getSpots().get(tmpIndex);
        }
        else
        {
            tmps = tmpVertex.getSpots().get(0);
        }

        if(tmps.getType() == ServerMapSpotData.NODE_TYPE_INTRO)
        {
            LatLng tmpSouthWest = null;
            LatLng tmpNorthEast = null;

            if(init_flag == true)
            {
                double smallestLat = INIT_DUMMY_COORDINATE;
                double smallestLng = INIT_DUMMY_COORDINATE;
                double biggestLat = INIT_DUMMY_COORDINATE;
                double biggestLng = INIT_DUMMY_COORDINATE;

                //ArrayList<LatLng> tmpAreas = tmps.getArea();
                ArrayList<LatLng> tmpAreas = new ArrayList<LatLng>();
                List<ServerMapRouteData> tmpRoutes = mapData.getRoute();

                if (tmpRoutes != null)
                {
                    //MapRouteData tmpr = tmpRoutes.get(routeIndex);
                    ServerMapRouteData tmpr = tmpRoutes.get(0);

                    if (tmpr != null)
                    {
                        tmpAreas = tmpr.getArea();
                    }
                }

                for (int x = 0; x < tmpAreas.size(); x++)
                {
                    LatLng oneLatLng = tmpAreas.get(x);

                    if (oneLatLng != null)
                    {
                        double tmpLat = oneLatLng.latitude;
                        double tmpLng = oneLatLng.longitude;

                        if (smallestLat == INIT_DUMMY_COORDINATE)
                        {
                            smallestLat = tmpLat;
                        }
                        else
                        {
                            if (smallestLat > tmpLat)
                            {
                                smallestLat = tmpLat;
                            }
                        }

                        if (smallestLng == INIT_DUMMY_COORDINATE)
                        {
                            smallestLng = tmpLng;
                        }
                        else
                        {
                            if (smallestLng > tmpLng)
                            {
                                smallestLng = tmpLng;
                            }
                        }

                        if (biggestLat == INIT_DUMMY_COORDINATE)
                        {
                            biggestLat = tmpLat;
                        }
                        else
                        {
                            if (biggestLat < tmpLat)
                            {
                                biggestLat = tmpLat;
                            }
                        }

                        if (biggestLng == INIT_DUMMY_COORDINATE)
                        {
                            biggestLng = tmpLng;
                        }
                        else
                        {
                            if (biggestLng < tmpLng)
                            {
                                biggestLng = tmpLng;
                            }
                        }
                    }
                }

                if( (biggestLat == 0) &&  (smallestLat == 0) && (biggestLng == 0) && (smallestLng == 0))
                {
                    //we will not allow these coordinates
                    return;
                }

                double latOffset = (biggestLat - smallestLat)/7;
                double lngOffset = (biggestLng - smallestLng)/7;

                tmpSouthWest = new LatLng(smallestLat - latOffset, smallestLng - lngOffset);
                tmpNorthEast = new LatLng(biggestLat + latOffset, biggestLng + lngOffset);

                mIntroSpotSouthWest = tmpSouthWest;
                mIntroSpotNorthEast = tmpNorthEast;
            }
            else
            {
                tmpSouthWest = mIntroSpotSouthWest;
                tmpNorthEast = mIntroSpotNorthEast;
            }

            if( (tmpSouthWest.latitude == 0) &&  (tmpSouthWest.longitude == 0) && (tmpNorthEast.latitude == 0) && (tmpNorthEast.longitude == 0))
            {
                //we will not allow these coordinates
                return;
            }

            LatLngBounds tmpBounds = new LatLngBounds(tmpSouthWest, tmpNorthEast);
            if(init_flag == true)
            {
                //it will do it in map callback
                if(mIsCameraLoaded == false)
                {
                    mInitBounds = tmpBounds;
                }
                else
                {
                    mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(tmpBounds, 10));
                }
            }
            else
            {
                mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(tmpBounds, 10));
            }
        }
        //else if(tmps.getCategory() == MapSpotData.NODE_CATEGORY_MOVEMENT)
        else
        {
            ServerMapEventData tmpEvent = tmps.getEvent().get(eventIndex);
            if (tmpEvent != null)
            {
                if(
                        (tmps.getType() == ServerMapSpotData.NODE_TYPE_MOVEMENT) && (tmpEvent.getType() == ServerMapEventData.NODE_TYPE_NO_LOCATION_RELATED)
                        )
                {
                    //there are two ways to do camera animation, (1)get spot area (2)get all node event location
                    //we are suing (2) option, because movement spot doesn't have area
                    double smallestLat = 0;
                    double smallestLng = 0;
                    double biggestLat = 0;
                    double biggestLng = 0;

                    for(int x = 0; x < tmps.getEvent().size(); x++)
                    {
                        ServerMapEventData oneEvent = tmps.getEvent().get(x);

                        if(oneEvent.getType() == ServerMapEventData.NODE_TYPE_NO_LOCATION_RELATED)
                        {
                            //we continue, because intro event doesn't have lat/lng.
                            continue;
                        }

                        //LatLng tmpLatLng = tmpArea.get(i);
                        double tmpLat = oneEvent.getLat();
                        double tmpLng = oneEvent.getLng();

                        if( (tmpLat == 0) || (tmpLng == 0))
                        {
                            continue;
                        }

                        if(smallestLat == 0)
                        {
                            smallestLat = tmpLat;
                        }
                        if(biggestLat == 0)
                        {
                            biggestLat = tmpLat;
                        }
                        if(smallestLng == 0)
                        {
                            smallestLng = tmpLng;
                        }
                        if(biggestLng == 0)
                        {
                            biggestLng = tmpLng;
                        }

                        if(tmpLat > biggestLat)
                        {
                            biggestLat = tmpLat;
                        }
                        if(tmpLat < smallestLat)
                        {
                            smallestLat = tmpLat;
                        }
                        if(tmpLng > biggestLng)
                        {
                            biggestLng = tmpLng;
                        }
                        if(tmpLng < smallestLng)
                        {
                            smallestLng = tmpLng;
                        }
                    }

                    if( (biggestLat == 0) &&  (smallestLat == 0) && (biggestLng == 0) && (smallestLng == 0))
                    {
                        //we will not allow these coordinates
                        return;
                    }


                    double latOffset = (biggestLat - smallestLat)/7;
                    double lngOffset = (biggestLng - smallestLng)/7;

                    LatLng tmpSouthWest = new LatLng(smallestLat - latOffset, smallestLng - lngOffset);
                    LatLng tmpNorthEast = new LatLng(biggestLat + latOffset, biggestLng + lngOffset);

                    //LatLng tmpSouthWest = new LatLng(smallestLat, smallestLng);
                    //LatLng tmpNorthEast = new LatLng(biggestLat, biggestLng);
                    LatLngBounds tmpBounds = new LatLngBounds(tmpSouthWest, tmpNorthEast);

                    if( (tmpSouthWest.latitude == 0) &&  (tmpSouthWest.longitude == 0) && (tmpNorthEast.latitude == 0) && (tmpNorthEast.longitude == 0))
                    {
                        //we will not allow these coordinates
                        return;
                    }

                    mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(tmpBounds, 10));
                }
                else if
                (
                        (tmps.getType() != ServerMapSpotData.NODE_TYPE_MOVEMENT) && (tmpEvent.getType() == ServerMapEventData.NODE_TYPE_NO_LOCATION_RELATED)
                )
                {
                    //there are two ways to do camera animation, (1)get spot area (2)get all node event location
                    //we are suing (1) option

                    //normal spot's intro event
                    LatLng tmpSouthWest = null;
                    LatLng tmpNorthEast = null;

                    double smallestLat = INIT_DUMMY_COORDINATE;
                    double smallestLng = INIT_DUMMY_COORDINATE;
                    double biggestLat = INIT_DUMMY_COORDINATE;
                    double biggestLng = INIT_DUMMY_COORDINATE;

                    ArrayList<LatLng> tmpAreas = tmps.getArea();
                    for (int x = 0; x < tmpAreas.size(); x++) {
                        LatLng oneLatLng = tmpAreas.get(x);

                        if (oneLatLng != null) {
                            double tmpLat = oneLatLng.latitude;
                            double tmpLng = oneLatLng.longitude;

                            if (smallestLat == INIT_DUMMY_COORDINATE) {
                                smallestLat = tmpLat;
                            } else {
                                if (smallestLat > tmpLat) {
                                    smallestLat = tmpLat;
                                }
                            }

                            if (smallestLng == INIT_DUMMY_COORDINATE) {
                                smallestLng = tmpLng;
                            } else {
                                if (smallestLng > tmpLng) {
                                    smallestLng = tmpLng;
                                }
                            }

                            if (biggestLat == INIT_DUMMY_COORDINATE) {
                                biggestLat = tmpLat;
                            } else {
                                if (biggestLat < tmpLat) {
                                    biggestLat = tmpLat;
                                }
                            }

                            if (biggestLng == INIT_DUMMY_COORDINATE) {
                                biggestLng = tmpLng;
                            } else {
                                if (biggestLng < tmpLng) {
                                    biggestLng = tmpLng;
                                }
                            }
                        }
                    }

                    if ((biggestLat == 0) && (smallestLat == 0) && (biggestLng == 0) && (smallestLng == 0)) {
                        //we will not allow these coordinates
                        return;
                    }

                    double latOffset = (biggestLat - smallestLat) / 7;
                    double lngOffset = (biggestLng - smallestLng) / 7;

                    tmpSouthWest = new LatLng(smallestLat - latOffset, smallestLng - lngOffset);
                    tmpNorthEast = new LatLng(biggestLat + latOffset, biggestLng + lngOffset);

                    if ((tmpSouthWest.latitude == 0) && (tmpSouthWest.longitude == 0) && (tmpNorthEast.latitude == 0) && (tmpNorthEast.longitude == 0)) {
                        //we will not allow these coordinates
                        return;
                    }

                    LatLngBounds tmpBounds = new LatLngBounds(tmpSouthWest, tmpNorthEast);
                    //mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(tmpBounds, 10));

                    int width = getResources().getDisplayMetrics().widthPixels;
                    int height = getResources().getDisplayMetrics().heightPixels;
                    mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(tmpBounds, width, height, 10));

                    /*
                    double smallestLat = 0;
                    double smallestLng = 0;
                    double biggestLat = 0;
                    double biggestLng = 0;

                    //there is town way to do camera animation, (1)get spot area (2)get all node event location
                    //we are suing (1) option
                    for(int x = 0; x < tmps.getEvent().size(); x++)
                    {
                        MapEventData oneEvent = tmps.getEvent().get(x);

                        //LatLng tmpLatLng = tmpArea.get(i);
                        double tmpLat = oneEvent.getLat();
                        double tmpLng = oneEvent.getLng();

                        if( (tmpLat == 0) || (tmpLng == 0))
                        {
                            continue;
                        }

                        if(smallestLat == 0)
                        {
                            smallestLat = tmpLat;
                        }
                        if(biggestLat == 0)
                        {
                            biggestLat = tmpLat;
                        }
                        if(smallestLng == 0)
                        {
                            smallestLng = tmpLng;
                        }
                        if(biggestLng == 0)
                        {
                            biggestLng = tmpLng;
                        }

                        if(tmpLat > biggestLat)
                        {
                            biggestLat = tmpLat;
                        }
                        if(tmpLat < smallestLat)
                        {
                            smallestLat = tmpLat;
                        }
                        if(tmpLng > biggestLng)
                        {
                            biggestLng = tmpLng;
                        }
                        if(tmpLng < smallestLng)
                        {
                            smallestLng = tmpLng;
                        }
                    }

                    if( (biggestLat == 0) &&  (smallestLat == 0) && (biggestLng == 0) && (smallestLng == 0))
                    {
                        //we will not allow these coordinates
                        return;
                    }


                    double latOffset = (biggestLat - smallestLat)/7;
                    double lngOffset = (biggestLng - smallestLng)/7;

                    LatLng tmpSouthWest = new LatLng(smallestLat - latOffset, smallestLng - lngOffset);
                    LatLng tmpNorthEast = new LatLng(biggestLat + latOffset, biggestLng + lngOffset);

                    //LatLng tmpSouthWest = new LatLng(smallestLat, smallestLng);
                    //LatLng tmpNorthEast = new LatLng(biggestLat, biggestLng);
                    LatLngBounds tmpBounds = new LatLngBounds(tmpSouthWest, tmpNorthEast);

                    if( (tmpSouthWest.latitude == 0) &&  (tmpSouthWest.longitude == 0) && (tmpNorthEast.latitude == 0) && (tmpNorthEast.longitude == 0))
                    {
                        //we will not allow these coordinates
                        return;
                    }

                    mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(tmpBounds, 10));
                    */
                }
                else
                {
                    //we are trying to get two locations,(before location, current destination), so we can see its whole path line.
                    ServerMapEventData prevEvent = null;
                    double smallestLat = 0;
                    double smallestLng = 0;
                    double biggestLat = 0;
                    double biggestLng = 0;

                    if(eventIndex -1 >= 0)
                    {
                        prevEvent = tmps.getEvent().get(eventIndex - 1);

                        if (prevEvent.getType() != ServerMapEventData.NODE_TYPE_NO_LOCATION_RELATED)
                        {
                            //pass
                        }
                        else
                        {
                            //tmpEvent;
                            //get previous event
                            if(spotIndex -1 >= 0)
                            {
                                tmpElement = nodeList.get(spotIndex-1);
                                tmpVertex = tmpElement.vertex;

                                if(tmpVertex == null)
                                {
                                    return;
                                }

                                spotSize = tmpVertex.getSpots().size();
                                tmps = null;
                                if(spotSize > 1)
                                {
                                    int weightIndex = tmpVertex.getSpotWeightIndex();
                                    //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
                                    int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, spotIndex-1);

                                    int tmpIndex = 0;
                                    if(weightIndex < 0)
                                    {
                                        if(recommendedIndex < 0)
                                        {
                                            tmpIndex = 0;
                                        }
                                        else
                                        {
                                            tmpIndex = recommendedIndex;
                                        }
                                    }
                                    else
                                    {
                                        tmpIndex = weightIndex;
                                    }
                                    tmps = tmpVertex.getSpots().get(tmpIndex);
                                }
                                else
                                {
                                    tmps = tmpVertex.getSpots().get(0);
                                }

                                int lastNodeSize = tmps.getEvent().size();
                                prevEvent = tmps.getEvent().get(lastNodeSize-1);
                            }
                        }
                    }
                    else
                    {
                        //tmpEvent;
                        //get previous event
                        if(spotIndex -1 >= 0)
                        {
                            tmpElement = nodeList.get(spotIndex-1);
                            tmpVertex = tmpElement.vertex;

                            if(tmpVertex == null)
                            {
                                return;
                            }

                            spotSize = tmpVertex.getSpots().size();
                            tmps = null;
                            if(spotSize > 1)
                            {
                                int weightIndex = tmpVertex.getSpotWeightIndex();
                                //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
                                int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, spotIndex-1);

                                int tmpIndex = 0;
                                if(weightIndex < 0)
                                {
                                    if(recommendedIndex < 0)
                                    {
                                        tmpIndex = 0;
                                    }
                                    else
                                    {
                                        tmpIndex = recommendedIndex;
                                    }
                                }
                                else
                                {
                                    tmpIndex = weightIndex;
                                }
                                tmps = tmpVertex.getSpots().get(tmpIndex);
                            }
                            else
                            {
                                tmps = tmpVertex.getSpots().get(0);
                            }

                            int lastNodeSize = tmps.getEvent().size();
                            prevEvent = tmps.getEvent().get(lastNodeSize-1);
                        }
                    }

                    ServerMapEventData oneEvent = null;
                    for(int k = 0; k < 2; k++)
                    {
                        if(k == 0)
                        {
                            oneEvent = tmpEvent;
                        }
                        else
                        {
                            oneEvent = prevEvent;
                        }

                        //LatLng tmpLatLng = tmpArea.get(i);
                        if(oneEvent == null)
                        {
                            return;
                        }
                        double tmpLat = oneEvent.getLat();
                        double tmpLng = oneEvent.getLng();

                        if( (tmpLat == 0) || (tmpLng == 0))
                        {
                            continue;
                        }

                        if(smallestLat == 0)
                        {
                            smallestLat = tmpLat;
                        }
                        if(biggestLat == 0)
                        {
                            biggestLat = tmpLat;
                        }
                        if(smallestLng == 0)
                        {
                            smallestLng = tmpLng;
                        }
                        if(biggestLng == 0)
                        {
                            biggestLng = tmpLng;
                        }

                        if(tmpLat > biggestLat)
                        {
                            biggestLat = tmpLat;
                        }
                        if(tmpLat < smallestLat)
                        {
                            smallestLat = tmpLat;
                        }
                        if(tmpLng > biggestLng)
                        {
                            biggestLng = tmpLng;
                        }
                        if(tmpLng < smallestLng)
                        {
                            smallestLng = tmpLng;
                        }
                    }

                    if( (biggestLat == 0) &&  (smallestLat == 0) && (biggestLng == 0) && (smallestLng == 0))
                    {
                        //we will not allow these coordinates
                        return;
                    }


                    double latOffset = (biggestLat - smallestLat)/7;
                    double lngOffset = (biggestLng - smallestLng)/7;

                    LatLng tmpSouthWest = new LatLng(smallestLat - latOffset, smallestLng - lngOffset);
                    LatLng tmpNorthEast = new LatLng(biggestLat + latOffset, biggestLng + lngOffset);

                    //LatLng tmpSouthWest = new LatLng(smallestLat, smallestLng);
                    //LatLng tmpNorthEast = new LatLng(biggestLat, biggestLng);
                    LatLngBounds tmpBounds = new LatLngBounds(tmpSouthWest, tmpNorthEast);

                    if( (tmpSouthWest.latitude == 0) &&  (tmpSouthWest.longitude == 0) && (tmpNorthEast.latitude == 0) && (tmpNorthEast.longitude == 0))
                    {
                        //we will not allow these coordinates
                        return;
                    }

                    mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(tmpBounds, 10));

                    return;
                }
            }
        }
    }

    public void moveToPoint(double lat, double lng)
    {
        float currentZoolLevel = mGoogleMap.getCameraPosition().zoom;

        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(new LatLng(lat, lng)) // Center Set
                .zoom(currentZoolLevel)                // Zoom
                //.bearing(90)                // Orientation of the camera to east
                //.tilt(30)                   // Tilt of the camera to 30 degrees
                .build();                   // Creates a CameraPosition from the builder
        mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
    }

    public void goToCurrentLocation()
    {

    }

    /*
    public void zoomToPoint()
    {
        //MapEventData tmpEvent = mapData.getRoute().get(routeIndex).getSpot().get(spotIndex).getEvent().get(eventIndex);
        NodeProgressBarItem tmpElement = nodeList.get(spotIndex);
        VertexGroup tmpVertex = tmpElement.vertex;

        if(tmpVertex == null)
        {
            return;
        }

        int spotSize = tmpVertex.getSpots().size();
        MapSpotData tmps = null;
        if(spotSize > 1)
        {
            int weightIndex = tmpVertex.getSpotWeightIndex();
            int recommendedIndex = tmpVertex.getSpotRecommendedIndex();

            int tmpIndex = 0;
            if(weightIndex < 0)
            {
                if(recommendedIndex < 0)
                {
                    tmpIndex = 0;
                }
                else
                {
                    tmpIndex = recommendedIndex;
                }
            }
            else
            {
                tmpIndex = weightIndex;
            }
            tmps = tmpVertex.getSpots().get(tmpIndex);
        }
        else
        {
            tmps = tmpVertex.getSpots().get(0);
        }

        if(tmps.getType() == MapSpotData.NODE_TYPE_INTRO)
        {
            MapEventData tmpEvent = tmps.getEvent().get(eventIndex);
            if (tmpEvent != null)
            {
                //float currentZoolLevel = mGoogleMap.getCameraPosition().zoom;
                float currentZoolLevel = 13;

                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(new LatLng(tmps.getLat(), tmps.getLng())) // Center Set
                        .zoom(currentZoolLevel)                // Zoom
                        //.bearing(90)                // Orientation of the camera to east
                        //.tilt(30)                   // Tilt of the camera to 30 degrees
                        .build();                   // Creates a CameraPosition from the builder
                mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
            }
        }
        else
        {
            MapEventData tmpEvent = tmps.getEvent().get(eventIndex);
            if (tmpEvent != null)
            {
                if(tmpEvent.getType() == MapEventData.NODE_TYPE_INTRO)
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(new LatLng(tmps.getLat(), tmps.getLng())) // Center Set
                            .zoom(18.0f)                // Zoom
                            //.bearing(90)                // Orientation of the camera to east
                            //.tilt(30)                   // Tilt of the camera to 30 degrees
                            .build();                   // Creates a CameraPosition from the builder
                    mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(new LatLng(tmpEvent.getLat(), tmpEvent.getLng())) // Center Set
                            .zoom(18.0f)                // Zoom
                            //.bearing(90)                // Orientation of the camera to east
                            //.tilt(30)                   // Tilt of the camera to 30 degrees
                            .build();                   // Creates a CameraPosition from the builder
                    mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
            }
        }
    }
    */

    public void loadMapPoint()
    {
        addMarkers();
    }

    public void updateMyPosition()
    {
        if(myLocationMarker != null)
        {
            myLocationMarker.remove();
            myLocationMarker = null;
        }

        if(mLocation != null)
        {
            double current_lat = mLocation.getLatitude();
            double current_lng = mLocation.getLongitude();

            //mGoogleMap.setOnPolygonClickListener();
            if(mMagneticOrientation != 0)
            {
                myLocationMarker = mGoogleMap.addMarker(new MarkerOptions()
                        .position(new LatLng(current_lat, current_lng))
                        //.title("name:" + mNameList.get(x))
                        //.snippet("location:" + mDesiredLocList.get(x))
                        .rotation(mMagneticOrientation)
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.human_pin)));
            }
            else
            {
                myLocationMarker = mGoogleMap.addMarker(new MarkerOptions()
                        .position(new LatLng(current_lat, current_lng))
                        //.title("name:" + mNameList.get(x))
                        //.snippet("location:" + mDesiredLocList.get(x))
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.human_pin)));
            }
        }
    }

    private void updateObject()
    {
        //LocationMarker;
        if(tourGuideLocationMarker != null)
        {
            tourGuideLocationMarker.remove();
            tourGuideLocationMarker = null;
        }

        /*
        double current_lat = mServer.getLat();
        double current_lng = mServer.getLng();

        tourGuideLocationMarker = mGoogleMap.addMarker(new MarkerOptions()
                .position(new LatLng(current_lat, current_lng))
                //.title("name:" + mNameList.get(x))
                //.snippet("location:" + mDesiredLocList.get(x))
                //.rotation(mMagneticOrientation)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.tgm_tour_guide_object)));
        */

        NodeProgressBarItem tmpElement = nodeList.get(spotIndex);
        VertexGroup tmpVertex = tmpElement.vertex;

        if(tmpVertex == null)
        {
            return;
        }

        int spotSize = tmpVertex.getSpots().size();
        ServerMapSpotData tmps = null;
        if(spotSize > 1)
        {
            int weightIndex = tmpVertex.getSpotWeightIndex();
            //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
            int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, spotIndex);

            int tmpIndex = 0;
            if(weightIndex < 0)
            {
                if(recommendedIndex < 0)
                {
                    tmpIndex = 0;
                }
                else
                {
                    tmpIndex = recommendedIndex;
                }
            }
            else
            {
                tmpIndex = weightIndex;
            }
            tmps = tmpVertex.getSpots().get(tmpIndex);
        }
        else
        {
            tmps = tmpVertex.getSpots().get(0);
        }

        if(tmps.getType() == ServerMapSpotData.NODE_TYPE_INTRO)
        {
            //no need to show any marker
            /*
            MapEventData tmpEvent = tmps.getEvent().get(eventIndex);
            if (tmpEvent != null)
            {
                if(tmps.getLat() != 0 && tmps.getLng() != 0)
                {
                    //float currentZoolLevel = mGoogleMap.getCameraPosition().zoom;
                    LocationMarker = mGoogleMap.addMarker(new MarkerOptions()
                            .position(new LatLng(tmps.getLat(), tmps.getLng()))
                            //.title("name:" + mNameList.get(x))
                            //.snippet("location:" + mDesiredLocList.get(x))
                            //.rotation(mMagneticOrientation)
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.tgm_tour_guide_object)));
                }
            }
            */
        }
        else
        {
            ServerMapEventData tmpEvent = tmps.getEvent().get(eventIndex);
            if (tmpEvent != null)
            {
                if(tmpEvent.getType() == ServerMapEventData.NODE_TYPE_NO_LOCATION_RELATED)
                {
                    //no need to show any marker
                    /*
                    if(tmps.getLat() != 0 && tmps.getLng() != 0)
                    {
                        LocationMarker = mGoogleMap.addMarker(new MarkerOptions()
                                .position(new LatLng(tmps.getLat(), tmps.getLng()))
                                //.title("name:" + mNameList.get(x))
                                //.snippet("location:" + mDesiredLocList.get(x))
                                //.rotation(mMagneticOrientation)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.tgm_tour_guide_object)));
                    }
                    */
                }
                else
                {
                    if(tmpEvent.getLat() != 0 && tmpEvent.getLng() != 0)
                    {
                        tourGuideLocationMarker = mGoogleMap.addMarker(new MarkerOptions()
                                .position(new LatLng(tmpEvent.getLat(), tmpEvent.getLng()))
                                //.title("name:" + mNameList.get(x))
                                //.snippet("location:" + mDesiredLocList.get(x))
                                //.rotation(mMagneticOrientation)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.tgm_tour_guide_object)));
                    }
                }
            }
        }
    }

    public void addMarkers()
    {
        if(markersMap != null)
        {
            markersMap.clear();
        }
        if(eventMarkersMap != null)
        {
            eventMarkersMap.clear();
        }
        if(mGoogleMap != null)
        {
            mGoogleMap.clear();
        }

        List<ServerMapRouteData> tmpRoutes = mapData.getRoute();

        if (tmpRoutes != null)
        {
            //MapRouteData tmpr = tmpRoutes.get(routeIndex);
            ServerMapRouteData tmpr = tmpRoutes.get(0);
            totalRouteCount = tmpRoutes.size();
            if (tmpr != null)
            {
                Iterator it = routeGraph.getVertices().entrySet().iterator();
                it.hasNext();
                Map.Entry entry = (Map.Entry) it.next();

                VertexGroup value = (VertexGroup) entry.getValue();
                //int spotType = value.getSpots().get(0).getType();

                graphSearch = new GraphSearch(routeGraph);
                graphSearch.setStartNode(value);
                VertexGroup tmpVertex = null;

                while((tmpVertex = graphSearch.getNext()) != null )
                {
                    if(tmpVertex.getIndexString().equals("0") == true)
                    {
                        //skip intro spot node
                        continue;
                    }

                    List<ServerMapSpotData> tmpSpots = tmpVertex.getSpots();

                    int tmpSize = tmpSpots.size();

                    boolean isEdgeWeightExist = false;
                    boolean isEdgeRecommendedExist = false;

                    ArrayList<Edge> tmpEdges = tmpVertex.getNeighbors();

                    int edgeCount = 0;
                    for(int x = 0; x < tmpEdges.size(); x++)
                    {
                        Edge tmpEdge = tmpEdges.get(x);

                        if (tmpVertex == tmpEdge.getFront())
                        {
                            //prev node
                        }
                        else if (tmpVertex == tmpEdge.getBack())
                        {
                            edgeCount++;

                            if(tmpEdge.getWeight() == Edge.WEIGHT_TRUE)
                            {
                                isEdgeWeightExist = true;
                            }

                            int tmpRecommendedLink[] = tmpEdge.getRecommendedLink();
                            if( (tmpRecommendedLink[0] != Edge.NO_RECOMMENDED_ID) && (tmpRecommendedLink[1] != Edge.NO_RECOMMENDED_ID))
                            {
                                isEdgeRecommendedExist = true;
                            }
                        }
                    }

                    for(int x = 0; x < tmpEdges.size(); x++)
                    {
                        if (tmpVertex == tmpEdges.get(x).getFront())
                        {
                            //prev node
                        }
                        else if (tmpVertex == tmpEdges.get(x).getBack())
                        {
                            if(edgeCount > 1)
                            {
                                int ret = addMultiPathLineForForwardDirection(tmpEdges, x, isEdgeWeightExist, isEdgeRecommendedExist);
                                if(ret < 0)
                                {
                                    continue;
                                }
                            }
                            else
                            {
                                int ret = addSinglePathLineForForwardDirection(tmpEdges, x);
                                if(ret < 0)
                                {
                                    continue;
                                }
                            }
                        }
                    }

                    //NODE_TYPE_SINGLE, NODE_TYPE_MULTI
                    for(int i = 0; i < tmpSize; i++)
                    {
                        ServerMapSpotData oneSpot = tmpSpots.get(i);

                        boolean isNodeBarPlanned = isThisVertexExistInPlannedPathOfNodeBar(tmpVertex);

                        Edge plannedPreviousEdge = getPlannedBackEdge(tmpVertex);

                        addSpotArea(oneSpot, i, tmpVertex, isNodeBarPlanned, plannedPreviousEdge, tmpSize, isEdgeWeightExist, isEdgeRecommendedExist);

                        if (oneSpot != null)
                        {
                            PolylineOptions eventLine = new PolylineOptions();

                            if(isNodeBarPlanned == true)
                            {
                                eventLine.color(ENABLED_RED_COLOR);
                            }
                            else
                            {
                                eventLine.color(DISABLED_COLOR);
                            }

                            List<ServerMapEventData> tmpEvents = oneSpot.getEvent();
                            if (tmpEvents != null)
                            {
                                for (int y = 0; y < tmpEvents.size(); y++)
                                {
                                    ServerMapEventData tmpe = tmpEvents.get(y);

                                    if(tmpe.getType() == ServerMapEventData.NODE_TYPE_NO_LOCATION_RELATED)
                                    {
                                        continue;
                                    }

                                    double lat = tmpe.getLat();
                                    double lng = tmpe.getLng();
                                    String title = tmpe.getTitle();

                                    eventLine.add(new LatLng(lat, lng));

                                    MapMarkers tour_guide_map_object = new MapMarkers();
                                    tour_guide_map_object.area = null;
                                    tour_guide_map_object.lat = lat;
                                    tour_guide_map_object.lng = lng;
                                    tour_guide_map_object.type = EVENT_NODE;
                                    tour_guide_map_object.title = title;

                                    Marker map_marker = mGoogleMap.addMarker(new MarkerOptions()
                                            .position(new LatLng(lat, lng))
                                            .anchor(0.5f, 0.5f)
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.tgm_event)));

                                    eventMarkersMap.put(tmpe.hashCode(), map_marker);

                                    markersMap.put(map_marker.getId(), tour_guide_map_object);
                                }

                                if( (oneSpot.getType() == MOVEMENT_TYPE) )
                                {

                                }
                                else
                                {
                                    Polyline polyline = mGoogleMap.addPolyline(eventLine);
                                    polyline.setWidth(5);
                                }
                            }
                        }
                    }
                }
                graphSearch.resetSearch();
            }
        }

        /*
        mGoogleMap.setOnCircleClickListener(new GoogleMap.OnCircleClickListener()
        {
            @Override
            public void onCircleClick(Circle circle)
            {
                MapMarkers tmpMarkerInfo = markersMap.get(circle.getId());

                final LatLng TMP_LOCATION = new LatLng(tmpMarkerInfo.lat, tmpMarkerInfo.lng);

                if(mMapInfoWindow != null)
                {
                    mMapInfoWindow.remove();
                    mMapInfoWindow = null;
                }

                MarkerOptions tmpMarkerOption = new MarkerOptions();
                tmpMarkerOption.position(TMP_LOCATION);
                tmpMarkerOption.title(tmpMarkerInfo.title);

                mMapInfoWindow = mGoogleMap.addMarker(tmpMarkerOption);
                mMapInfoWindow.showInfoWindow();
            }
        });
        */

        mGoogleMap.setOnPolygonClickListener(new GoogleMap.OnPolygonClickListener()
        {
            @Override
            public void onPolygonClick(Polygon polyg)
            {
                MapMarkers tmpMarkerInfo = markersMap.get(polyg.getId());

                final LatLng TMP_LOCATION = new LatLng(tmpMarkerInfo.lat, tmpMarkerInfo.lng);

                if(mMapInfoWindow != null)
                {
                    mMapInfoWindow.remove();
                    mMapInfoWindow = null;
                }

                MarkerOptions tmpMarkerOption = new MarkerOptions();
                tmpMarkerOption.position(TMP_LOCATION);
                tmpMarkerOption.anchor(0.5f, 0.5f);
                tmpMarkerOption.title(tmpMarkerInfo.title);
                tmpMarkerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.tgm_event6));

                mMapInfoWindow = mGoogleMap.addMarker(tmpMarkerOption);
                mMapInfoWindow.showInfoWindow();
            }
        });
        mGoogleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener()
        {
            @Override
            public void onMapClick(LatLng latLng)
            {
                LatLng tmp = latLng;
                tmp = tmp;
            }
        });
    }

    private void addSpotArea(ServerMapSpotData oneSpot, int i, VertexGroup tmpVertex, boolean plannedFlag, Edge previousEdge, int tmpSize, boolean isEdgeWeightExist, boolean isEdgeRecommendedExist)
    {
        if( (oneSpot.getType() == MOVEMENT_TYPE) /*&& (oneSpot.getType() != MapSpotData.NODE_TYPE_MULTI) && (oneSpot.getType() != MapSpotData.NODE_TYPE_INTRO)*/)
        {
            //double lat = oneSpot.getLat();
            //double lng = oneSpot.getLng();
            ArrayList<LatLng> area = oneSpot.getArea();
            String title = oneSpot.getTitle();

            //CircleOptions circleOptions = new CircleOptions();
            //circleOptions.center(new LatLng(lat, lng));

            PolylineOptions polyOptions = new PolylineOptions();

            for(int x = 0; x < area.size(); x++)
            {
                polyOptions.add(area.get(x));
            }

            double center_lat = 0, center_lng = 0;
            for(int x = 0; x < area.size(); x++)
            {
                center_lat += area.get(x).latitude;
                center_lng += area.get(x).longitude;
            }
            if(area.size() > 0)
            {
                center_lat /= area.size();
                center_lng /= area.size();
            }

            if(tmpSize > 1)
            {
                //multi node
                if(plannedFlag == true)
                {
                    int tmpWeightIndex = tmpVertex.getSpotWeightIndex();
                    //int tmpRecommendedIndex = tmpVertex.getSpotRecommendedIndex();

                    int tmpRecommendedIndex = getFrontRecommendedIndexFromEdge(previousEdge);

                    if ((isEdgeWeightExist == true) || (isEdgeRecommendedExist == true))
                    {
                        if (tmpWeightIndex == i)
                        {
                            polyOptions.color(0xffff0000);
                        }
                        else if((tmpRecommendedIndex == i) && (tmpWeightIndex == -1))
                        {
                            polyOptions.color(0xffff0000);
                        }
                        else
                        {
                            polyOptions.color(0x40404040);
                        }
                    }
                    else if(tmpWeightIndex == i)
                    {
                        polyOptions.color(0xffff0000);
                    }
                    else if((tmpRecommendedIndex == i) && (tmpWeightIndex == -1))
                    {
                        polyOptions.color(0xffff0000);
                    }
                    else
                    {
                        polyOptions.color(0x40404040);
                    }
                }
                else
                {
                    polyOptions.color(0x40404040);
                }
            }
            else
            {
                if(plannedFlag == true)
                {
                    //single node
                    polyOptions.color(0xffff0000);
                }
                else
                {
                    polyOptions.color(0x40404040);
                }
            }
            polyOptions.width(5);
            //circleOptions.radius(distance);
            polyOptions.clickable(true);

            // In meters
            Polyline polyG = mGoogleMap.addPolyline(polyOptions);
            polyG.setClickable(true);

            MapMarkers tour_guide_map_object = new MapMarkers();
            tour_guide_map_object.area = area;
            tour_guide_map_object.lat = center_lat;
            tour_guide_map_object.lng = center_lng;
            tour_guide_map_object.type = SPOT_NODE;
            tour_guide_map_object.title = title;

            markersMap.put(polyG.getId(), tour_guide_map_object);
        }
        else
        {
            //double lat = oneSpot.getLat();
            //double lng = oneSpot.getLng();
            ArrayList<LatLng> area = oneSpot.getArea();
            String title = oneSpot.getTitle();

            //CircleOptions circleOptions = new CircleOptions();
            //circleOptions.center(new LatLng(lat, lng));

            PolygonOptions polyOptions = new PolygonOptions();

            for(int x = 0; x < area.size(); x++)
            {
                polyOptions.add(area.get(x));
            }

            double center_lat = 0, center_lng = 0;
            for(int x = 0; x < area.size(); x++)
            {
                center_lat += area.get(x).latitude;
                center_lng += area.get(x).longitude;
            }
            if(area.size() > 0)
            {
                center_lat /= area.size();
                center_lng /= area.size();
            }
            if(tmpSize > 1)
            {
                //multi node
                if(plannedFlag == true)
                {
                    int tmpWeightIndex = tmpVertex.getSpotWeightIndex();
                    //int tmpRecommendedIndex = tmpVertex.getSpotRecommendedIndex();

                    int tmpRecommendedIndex = getFrontRecommendedIndexFromEdge(previousEdge);

                    if ((isEdgeWeightExist == true) || (isEdgeRecommendedExist == true))
                    {
                        if (tmpWeightIndex == i)
                        {
                            polyOptions.fillColor(0x40ff0000);
                        }
                        else if((tmpRecommendedIndex == i) && (tmpWeightIndex == -1))
                        {
                            polyOptions.fillColor(0x40ff0000);
                        }
                        else
                        {
                            polyOptions.fillColor(0x40404040);
                        }
                    }
                    else if(tmpWeightIndex == i)
                    {
                        polyOptions.fillColor(0x40ff0000);
                    }
                    else if((tmpRecommendedIndex == i) && (tmpWeightIndex == -1))
                    {
                        polyOptions.fillColor(0x40ff0000);
                    }
                    else
                    {
                        polyOptions.fillColor(0x40404040);
                    }
                }
                else
                {
                    polyOptions.fillColor(0x40404040);
                }
            }
            else
            {
                if(plannedFlag == true)
                {
                    //single node
                    polyOptions.fillColor(0x40ff0000);
                }
                else
                {
                    polyOptions.fillColor(0x40404040);
                }
            }

            polyOptions.strokeWidth(1);
            //circleOptions.radius(distance);
            polyOptions.clickable(true);

            // In meters
            Polygon polyG = mGoogleMap.addPolygon(polyOptions);
            polyG.setClickable(true);

            MapMarkers tour_guide_map_object = new MapMarkers();
            tour_guide_map_object.area = area;
            tour_guide_map_object.lat = center_lat;
            tour_guide_map_object.lng = center_lng;
            tour_guide_map_object.type = SPOT_NODE;
            tour_guide_map_object.title = title;

            markersMap.put(polyG.getId(), tour_guide_map_object);
        }
    }

    private int addMultiPathLineForForwardDirection(ArrayList<Edge> tmpEdges, int x, boolean isEdgeWeightExist, boolean isEdgeRecommendationExist)
    {
        //multi path
        //멀티패스일 때 weight처리를 해줘야 하나?
        //멀티패스에도 edge weight이 존재할 수 있나? -> 있음
        //또한 멀티패스 & 멀티스팟일 경우 path와 스팟을 동시에 처리해줘야 함

        //멀티패스일 recommendation에서는 edge recommendation이 있다.
        //또한 멀티패스 & 멀티스팟일 경우 path와 스팟을 동시에 처리해줘야 함

        int front_multi_count = tmpEdges.get(x).getFront().getSpots().size();
        int back_multi_count = tmpEdges.get(x).getBack().getSpots().size();

        double every_front_lat[] = new double[front_multi_count];
        double every_front_lng[] = new double[front_multi_count];
        double every_back_lat[] = new double[back_multi_count];
        double every_back_lng[] = new double[back_multi_count];

        //////////////////////////// draw every path with black color /////////////////////////
        for(int i = 0; i < front_multi_count; i++ )
        {
            //every_front_lat[i] = tmpEdges.get(x).getFront().getSpots().get(i).getLat();
            //every_front_lng[i] = tmpEdges.get(x).getFront().getSpots().get(i).getLng();

            double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(i));
            every_front_lat[i] = tmpDouble[0];
            every_front_lng[i] = tmpDouble[1];

        }

        for(int i = 0; i < back_multi_count; i++ )
        {
            //every_back_lat[i] = tmpEdges.get(x).getBack().getSpots().get(i).getLat();
            //every_back_lng[i] = tmpEdges.get(x).getBack().getSpots().get(i).getLng();

            double tmpDouble[] = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(i));
            every_back_lat[i] = tmpDouble[0];
            every_back_lng[i] = tmpDouble[1];
        }

        for(int i = 0; i < front_multi_count; i++)
        {
            for(int j = 0; j < back_multi_count; j++)
            {
                PolylineOptions spotLine = new PolylineOptions();

                spotLine.add(new LatLng(every_front_lat[i], every_front_lng[i]));
                spotLine.add(new LatLng(every_back_lat[j], every_back_lng[j]));

                spotLine.color(DISABLED_COLOR);

                Polyline polyline = mGoogleMap.addPolyline(spotLine);
                polyline.setWidth(5);
            }
        }

        //////////////////////////// draw weighted or recommended with red color /////////////////////////
        PolylineOptions spotLine = new PolylineOptions();

        boolean front_multi_flag = ((tmpEdges.get(x).getFront().getSpots().size() > 1)? true:false);
        boolean back_multi_flag = ((tmpEdges.get(x).getBack().getSpots().size() > 1)? true:false);
        double front_lat = 0;
        double front_lng = 0;
        double back_lat = 0;
        double back_lng = 0;

        boolean isThisEdgeWeighted = false;
        boolean isThisEdgeRecommended = false;

        if (tmpEdges.get(x).getWeight() == Edge.WEIGHT_TRUE)
        {
            isThisEdgeWeighted = true;
        }

        int tmpRecommendedLink[] = tmpEdges.get(x).getRecommendedLink();
        if( (tmpRecommendedLink[0] != Edge.NO_RECOMMENDED_ID) && (tmpRecommendedLink[1] != Edge.NO_RECOMMENDED_ID))
        {
            isThisEdgeRecommended = true;
        }

        if (isThisEdgeWeighted == true)
        {
            if(front_multi_flag == true)
            {
                //forward node is multi
                if(back_multi_flag == true)
                {
                    //self node is multi
                    int frontWeightIndex = tmpEdges.get(x).getFront().getSpotWeightIndex();
                    int backWeightIndex = tmpEdges.get(x).getBack().getSpotWeightIndex();

                    if ((frontWeightIndex != -1) && (backWeightIndex != -1))
                    {
                        //front_lat = tmpEdges.get(x).getFront().getSpots().get(frontWeightIndex).getLat();
                        //front_lng = tmpEdges.get(x).getFront().getSpots().get(frontWeightIndex).getLng();

                        double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(frontWeightIndex));
                        front_lat = tmpDouble[0];
                        front_lng = tmpDouble[1];

                        //back_lat = tmpEdges.get(x).getBack().getSpots().get(backWeightIndex).getLat();
                        //back_lng = tmpEdges.get(x).getBack().getSpots().get(backWeightIndex).getLng();

                        tmpDouble = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(backWeightIndex));
                        back_lat = tmpDouble[0];
                        back_lng = tmpDouble[1];

                        spotLine.color(ENABLED_RED_COLOR);
                    }
                    else
                    {
                        return -1;
                    }
                }
                else
                {
                    int frontWeightIndex = tmpEdges.get(x).getFront().getSpotWeightIndex();
                    //int backWeightIndex = tmpEdges.get(x).getBack().getSpotWeightIndex();

                    if (frontWeightIndex != -1)
                    {
                        //front_lat = tmpEdges.get(x).getFront().getSpots().get(frontWeightIndex).getLat();
                        //front_lng = tmpEdges.get(x).getFront().getSpots().get(frontWeightIndex).getLng();

                        double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(frontWeightIndex));
                        front_lat = tmpDouble[0];
                        front_lng = tmpDouble[1];

                        //back_lat = tmpEdges.get(x).getBack().getSpots().get(0).getLat();
                        //back_lng = tmpEdges.get(x).getBack().getSpots().get(0).getLng();

                        tmpDouble = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(0));
                        back_lat = tmpDouble[0];
                        back_lng = tmpDouble[1];

                        spotLine.color(ENABLED_RED_COLOR);
                    }
                    else
                    {
                        return -1;
                    }
                }
            }
            else
            {
                if(back_multi_flag == true)
                {
                    //self node is multi
                    int backWeightIndex = tmpEdges.get(x).getBack().getSpotWeightIndex();
                    if (backWeightIndex != -1)
                    {
                        //front_lat = tmpEdges.get(x).getFront().getSpots().get(0).getLat();
                        //front_lng = tmpEdges.get(x).getFront().getSpots().get(0).getLng();

                        double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(0));
                        front_lat = tmpDouble[0];
                        front_lng = tmpDouble[1];

                        //back_lat = tmpEdges.get(x).getBack().getSpots().get(backWeightIndex).getLat();
                        //back_lng = tmpEdges.get(x).getBack().getSpots().get(backWeightIndex).getLng();

                        tmpDouble = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(backWeightIndex));
                        back_lat = tmpDouble[0];
                        back_lng = tmpDouble[1];

                        spotLine.color(ENABLED_RED_COLOR);
                    }
                    else
                    {
                        return -1;
                    }
                }
                else
                {
                    //front_lat = tmpEdges.get(x).getFront().getSpots().get(0).getLat();
                    //front_lng = tmpEdges.get(x).getFront().getSpots().get(0).getLng();

                    double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(0));
                    front_lat = tmpDouble[0];
                    front_lng = tmpDouble[1];

                    //back_lat = tmpEdges.get(x).getBack().getSpots().get(0).getLat();
                    //back_lng = tmpEdges.get(x).getBack().getSpots().get(0).getLng();

                    tmpDouble = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(0));
                    back_lat = tmpDouble[0];
                    back_lng = tmpDouble[1];

                    spotLine.color(ENABLED_RED_COLOR);
                }
            }
        }
        else if ((isThisEdgeRecommended == true) && isEdgeWeightExist == false)     //if there is another weighted edge, don't draw current recommended edge.
        {
            //this is selectable multi path? or another path that we never go?
            boolean ret = isThisEdgeExistInPlannedPathOfNodeBar(tmpEdges.get(x));

            if(ret == true)
            {
                if (front_multi_flag == true)
                {
                    //forward node is multi
                    if (back_multi_flag == true)
                    {
                        //self node is multi
                        //int frontRecommendationIndex = getNextRecommendedIndexFromPreviousVertex(tmpEdges.get(x).getBack(), tmpEdges.get(x).getFront());
                        //int backRecommendationIndex = getSourceRecommendedIndexFromPreviousVertex(tmpEdges.get(x).getBack());

                        //int frontRecommendationIndex = tmpEdges.get(x).getFront().getSpotRecommendedIndex();
                        //int backRecommendationIndex = tmpEdges.get(x).getBack().getSpotRecommendedIndex();
                        int frontRecommendationIndex = getFrontRecommendedIndexFromEdge(tmpEdges.get(x));
                        int backRecommendationIndex = getBackRecommendedIndexFromEdge(tmpEdges.get(x));

                        if ((frontRecommendationIndex != -1) && (backRecommendationIndex != -1))
                        {
                            //front_lat = tmpEdges.get(x).getFront().getSpots().get(frontRecommendationIndex).getLat();
                            //front_lng = tmpEdges.get(x).getFront().getSpots().get(frontRecommendationIndex).getLng();

                            double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(frontRecommendationIndex));
                            front_lat = tmpDouble[0];
                            front_lng = tmpDouble[1];

                            //back_lat = tmpEdges.get(x).getBack().getSpots().get(backRecommendationIndex).getLat();
                            //back_lng = tmpEdges.get(x).getBack().getSpots().get(backRecommendationIndex).getLng();

                            tmpDouble = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(backRecommendationIndex));
                            back_lat = tmpDouble[0];
                            back_lng = tmpDouble[1];

                            spotLine.color(ENABLED_RED_COLOR);
                        }
                        else
                        {
                            return -1;
                        }
                    }
                    else
                    {
                        //int frontRecommendationIndex = tmpEdges.get(x).getFront().getSpotRecommendedIndex();
                        int frontRecommendationIndex = getFrontRecommendedIndexFromEdge(tmpEdges.get(x));
                        //int backWeightIndex = tmpEdges.get(x).getBack().getSpotWeightIndex();

                        if (frontRecommendationIndex != -1)
                        {
                            //front_lat = tmpEdges.get(x).getFront().getSpots().get(frontRecommendationIndex).getLat();
                            //front_lng = tmpEdges.get(x).getFront().getSpots().get(frontRecommendationIndex).getLng();

                            double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(frontRecommendationIndex));
                            front_lat = tmpDouble[0];
                            front_lng = tmpDouble[1];

                            //back_lat = tmpEdges.get(x).getBack().getSpots().get(0).getLat();
                            //back_lng = tmpEdges.get(x).getBack().getSpots().get(0).getLng();

                            tmpDouble = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(0));
                            back_lat = tmpDouble[0];
                            back_lng = tmpDouble[1];

                            spotLine.color(ENABLED_RED_COLOR);
                        }
                        else
                        {
                            return -1;
                        }
                    }
                }
                else
                {
                    if (back_multi_flag == true)
                    {
                        //self node is multi
                        //int backRecommendationIndex = tmpEdges.get(x).getBack().getSpotRecommendedIndex();
                        int backRecommendationIndex = getBackRecommendedIndexFromEdge(tmpEdges.get(x));
                        if (backRecommendationIndex != -1)
                        {
                            //front_lat = tmpEdges.get(x).getFront().getSpots().get(0).getLat();
                            //front_lng = tmpEdges.get(x).getFront().getSpots().get(0).getLng();
                            double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(0));
                            front_lat = tmpDouble[0];
                            front_lng = tmpDouble[1];

                            //back_lat = tmpEdges.get(x).getBack().getSpots().get(backRecommendationIndex).getLat();
                            //back_lng = tmpEdges.get(x).getBack().getSpots().get(backRecommendationIndex).getLng();
                            tmpDouble = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(backRecommendationIndex));
                            back_lat = tmpDouble[0];
                            back_lng = tmpDouble[1];

                            spotLine.color(ENABLED_RED_COLOR);
                        }
                        else
                        {
                            return -1;
                        }
                    }
                    else
                    {
                        //front_lat = tmpEdges.get(x).getFront().getSpots().get(0).getLat();
                        //front_lng = tmpEdges.get(x).getFront().getSpots().get(0).getLng();

                        double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(0));
                        front_lat = tmpDouble[0];
                        front_lng = tmpDouble[1];

                        //back_lat = tmpEdges.get(x).getBack().getSpots().get(0).getLat();
                        //back_lng = tmpEdges.get(x).getBack().getSpots().get(0).getLng();

                        tmpDouble = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(0));
                        back_lat = tmpDouble[0];
                        back_lng = tmpDouble[1];

                        spotLine.color(ENABLED_RED_COLOR);
                    }
                }
            }
            else
            {
                //this is not planned path(we are not supposed to visit). this is another multi path that we will not visit.
                return -1;
            }
        }
        else
        {
            return -1;
        }

        spotLine.add(new LatLng(front_lat, front_lng));
        spotLine.add(new LatLng(back_lat, back_lng));

        Polyline polyline = mGoogleMap.addPolyline(spotLine);
        polyline.setWidth(5);

        return 0;
    }

    /*
    private int getNextRecommendedIndexFromPreviousVertex(VertexGroup back, VertexGroup front)
    {
        if(back == null)
        {
            return -1;
        }

        int recommended_link[] = back.getNextRecommendedSpotId();
        if((recommended_link[0] != Edge.NO_RECOMMENDED_ID) && (recommended_link[1] != Edge.NO_RECOMMENDED_ID))
        {
            int nextRecommendedSpotId = recommended_link[1];

            if(front != null)
            {
                ArrayList<MapSpotData> tmpSpots = front.getSpots();

                for(int y = 0; y < tmpSpots.size(); y++)
                {
                    if(nextRecommendedSpotId == tmpSpots.get(y).getId())
                    {
                        return y;
                    }
                }
                return -1;
            }
            else
            {
                return -1;
            }
        }
        else
        {
            return -1;
        }
    }

    private int getSourceRecommendedIndexFromPreviousVertex(VertexGroup back)
    {
        if(back == null)
        {
            return -1;
        }

        int recommended_link[] = back.getNextRecommendedSpotId();
        if((recommended_link[0] != Edge.NO_RECOMMENDED_ID) && (recommended_link[1] != Edge.NO_RECOMMENDED_ID))
        {
            int sourceRecommendedSpotId = recommended_link[0];

            ArrayList<MapSpotData> tmpSpots = back.getSpots();

            for(int y = 0; y < tmpSpots.size(); y++)
            {
                if(sourceRecommendedSpotId == tmpSpots.get(y).getId())
                {
                    return y;
                }
            }
            return -1;
        }
        else
        {
            return -1;
        }
    }
    */

    private int getFrontRecommendedIndexFromEdge(Edge tmpEdge)
    {
        int recommended_link[] = tmpEdge.getRecommendedLink();

        if( (recommended_link[0] != Edge.NO_RECOMMENDED_ID) && (recommended_link[1] != Edge.NO_RECOMMENDED_ID) )
        {
            ArrayList<ServerMapSpotData> tmpSpots = tmpEdge.getFront().getSpots();
            for(int i = 0; i <tmpSpots.size(); i++)
            {
                if(tmpSpots.get(i).getId() == recommended_link[1])
                {
                    return i;
                }
            }
        }
        return -1;
    }

    private int getBackRecommendedIndexFromEdge(Edge tmpEdge)
    {
        int recommended_link[] = tmpEdge.getRecommendedLink();

        if( (recommended_link[0] != Edge.NO_RECOMMENDED_ID) && (recommended_link[1] != Edge.NO_RECOMMENDED_ID) )
        {
            return recommended_link[0];
        }
        return -1;
    }

    //There is only one path from Back Vertex to Front Vertex at Edge.get(x)
    private int addSinglePathLineForForwardDirection(ArrayList<Edge> tmpEdges, int x)
    {
        //single path111
        //edgeCount == 1

        //싱글패스일 때 weight처리를 해줘야 하나?
        //싱글패스에도 edge weight이 존재할 수 있나? -> 없음, edge weight은 멀티패스일 때만 존재함
        //하지만 싱글패스 멀티스팟일 경우 spot weight은 존재할 수 있따.

        //싱글패스 recommendation에서는 edge recommendation은 없지만
        //하지만 멀티스팟일 경우 spot recommendation이 존재 할 수 있다.

        boolean front_multi_flag = ((tmpEdges.get(x).getFront().getSpots().size() > 1)? true:false);
        boolean back_multi_flag = ((tmpEdges.get(x).getBack().getSpots().size() > 1)? true:false);

        int front_multi_count = tmpEdges.get(x).getFront().getSpots().size();
        int back_multi_count = tmpEdges.get(x).getBack().getSpots().size();

        double every_front_lat[] = new double[front_multi_count];
        double every_front_lng[] = new double[front_multi_count];
        double every_back_lat[] = new double[back_multi_count];
        double every_back_lng[] = new double[back_multi_count];

        //////////////////////////// draw every path with black color /////////////////////////
        for(int i = 0; i < front_multi_count; i++ )
        {
            //every_front_lat[i] = tmpEdges.get(x).getFront().getSpots().get(i).getLat();
            //every_front_lng[i] = tmpEdges.get(x).getFront().getSpots().get(i).getLng();

            double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(i));
            every_front_lat[i] = tmpDouble[0];
            every_front_lng[i] = tmpDouble[1];
        }

        for(int i = 0; i < back_multi_count; i++ )
        {
            //every_back_lat[i] = tmpEdges.get(x).getBack().getSpots().get(i).getLat();
            //every_back_lng[i] = tmpEdges.get(x).getBack().getSpots().get(i).getLng();

            double tmpDouble[] = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(i));
            every_back_lat[i] = tmpDouble[0];
            every_back_lng[i] = tmpDouble[1];
        }

        for(int i = 0; i < front_multi_count; i++)
        {
            for(int j = 0; j < back_multi_count; j++)
            {
                PolylineOptions spotLine = new PolylineOptions();

                spotLine.add(new LatLng(every_front_lat[i], every_front_lng[i]));
                spotLine.add(new LatLng(every_back_lat[j], every_back_lng[j]));

                spotLine.color(DISABLED_COLOR);

                Polyline polyline = mGoogleMap.addPolyline(spotLine);
                polyline.setWidth(5);
            }
        }

        //////////////////////////// draw weighted or recommended with red color /////////////////////////
        double front_lat = 0;
        double front_lng = 0;
        double back_lat = 0;
        double back_lng = 0;

        int weightIndex = -1;
        int recommendedIndex = -1;

        PolylineOptions spotLine = new PolylineOptions();

        if(front_multi_flag == true)
        {
            //아래쪽은 spot's weight말고 edge weight를 봐야 하지 않나?
            weightIndex = tmpEdges.get(x).getFront().getSpotWeightIndex();
            //recommendedIndex = tmpEdges.get(x).getFront().getSpotRecommendedIndex();

            recommendedIndex = getFrontRecommendedIndexFromEdge(tmpEdges.get(x));

            if(weightIndex != -1)
            {
                //front_lat = tmpEdges.get(x).getFront().getSpots().get(weightIndex).getLat();
                //front_lng = tmpEdges.get(x).getFront().getSpots().get(weightIndex).getLng();

                double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(weightIndex));
                front_lat = tmpDouble[0];
                front_lng = tmpDouble[1];

                spotLine.color(ENABLED_RED_COLOR);
            }
            else if (recommendedIndex != -1)
            {
                //front_lat = tmpEdges.get(x).getFront().getSpots().get(recommendedIndex).getLat();
                //front_lng = tmpEdges.get(x).getFront().getSpots().get(recommendedIndex).getLng();
                double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(recommendedIndex));
                front_lat = tmpDouble[0];
                front_lng = tmpDouble[1];

                spotLine.color(ENABLED_RED_COLOR);
            }
            else
            {
                return -1;
            }
        }
        else
        {
            //front_lat = tmpEdges.get(x).getFront().getSpots().get(0).getLat();
            //front_lng = tmpEdges.get(x).getFront().getSpots().get(0).getLng();

            double tmpDouble[] = getFirstEventLocation(tmpEdges.get(x).getFront().getSpots().get(0));
            front_lat = tmpDouble[0];
            front_lng = tmpDouble[1];

            if (tmpEdges.get(x).getWeight() == Edge.WEIGHT_TRUE)
            {
                spotLine.color(ENABLED_RED_COLOR);
            }
            else
            {
                //this line is on another path that we never went through yet.
                //spotLine.color(0x70707070);
                return -1;
            }
        }

        if(back_multi_flag == true)
        {
            if (tmpEdges.get(x).getWeight() == Edge.WEIGHT_TRUE)
            {
                weightIndex = tmpEdges.get(x).getBack().getSpotWeightIndex();
                //recommendedIndex = tmpEdges.get(x).getBack().getSpotRecommendedIndex();
                recommendedIndex = getBackRecommendedIndexFromEdge(tmpEdges.get(x));

                if (weightIndex != -1)
                {
                    //back_lat = tmpEdges.get(x).getBack().getSpots().get(weightIndex).getLat();
                    //back_lng = tmpEdges.get(x).getBack().getSpots().get(weightIndex).getLng();

                    double tmpDouble[] = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(weightIndex));
                    back_lat = tmpDouble[0];
                    back_lng = tmpDouble[1];

                    spotLine.color(ENABLED_RED_COLOR);
                }
                else if (recommendedIndex != -1)
                {
                    //back_lat = tmpEdges.get(x).getBack().getSpots().get(recommendedIndex).getLat();
                    //back_lng = tmpEdges.get(x).getBack().getSpots().get(recommendedIndex).getLng();

                    double tmpDouble[] = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(recommendedIndex));
                    back_lat = tmpDouble[0];
                    back_lng = tmpDouble[1];

                    spotLine.color(ENABLED_RED_COLOR);
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                //this line is from multi spots not from multi path, so we should not draw this.
                return -1;
            }
        }
        else
        {
            //back_lat = tmpEdges.get(x).getBack().getSpots().get(0).getLat();
            //back_lng = tmpEdges.get(x).getBack().getSpots().get(0).getLng();
            double tmpDouble[] = getLastEventLocation(tmpEdges.get(x).getBack().getSpots().get(0));
            back_lat = tmpDouble[0];
            back_lng = tmpDouble[1];

            if (tmpEdges.get(x).getWeight() == Edge.WEIGHT_TRUE)
            {
                spotLine.color(ENABLED_RED_COLOR);
            }
            else
            {
                //this line is on another path that we never went through yet.
                //spotLine.color(0x70707070);
                return -1;
            }
        }

        spotLine.add(new LatLng(front_lat, front_lng));
        spotLine.add(new LatLng(back_lat, back_lng));

        Polyline polyline = mGoogleMap.addPolyline(spotLine);
        polyline.setWidth(5);

        return 0;
    }

    public static String decodeURIComponent(String s)
    {
        return s;

        /*
        if (s == null)
        {
            return null;
        }

        String result = null;

        try
        {
            result = URLDecoder.decode(s, "UTF-8");
        }

        // This exception should never occur.
        catch (UnsupportedEncodingException e)
        {
            result = s;
        }

        return result;
        */
    }

    final Handler playerHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

            int linePlus = 0;
            String decodedText = "";
            String comment = "";

            String type_str = msg.getData().getString(HANDLER_HEADER);
            switch(type_str)
            {
                case "spot_gui":
                    mSpotListAdapter.notifyDataSetChanged();
                    break;

                case "event_gui":
                    mEventListAdapter.notifyDataSetChanged();
                    break;

                case "refresh_event":
                    int eventCount = msg.getData().getInt("event_count");

                    if(eventCount > 0)
                    {
                        //int currentEventNodePrpperty[] = mBallonImageGalleryBar.getEventProperty();

                        int currentEventNodePrpperty[] = mEventListAdapter.getEventProperty();
                        int newEventNodePrpperty[] = makeEventNodeProgressProperty(spotIndex);

                        //if (eventCount != mBallonImageGalleryBar.getNumOfBalloonNodes())    //we must not check with node number.
                        if (Arrays.equals(currentEventNodePrpperty, newEventNodePrpperty) == false)
                        {
                            mEventDataList.clear();
                            for(int k = 0; k < newEventNodePrpperty.length; k++)
                            {
                                EventGUI tmpEvent = new EventGUI();
                                tmpEvent.mEventType = newEventNodePrpperty[k];
                                mEventDataList.add(tmpEvent);
                            }
                            mEventListAdapter.notifyDataSetChanged();

                            //mBallonImageGalleryBar.setNumOfBalloonNodex(eventCount, false);
                            //mBallonImageGalleryBar.setBalloonProperty(newEventNodePrpperty);

                            //mBallonImageGalleryBar.blinkingRefresh();
                        }
                    }

                    //if(mBallonImageGalleryBar.getImageGalleryIndex() != spotIndex)
                    if(mSpotListAdapter.getImageGalleryIndex() != spotIndex)
                    {
                        //mBallonImageGalleryBar.setImageGalleryIndex(spotIndex);

                        mSpotListAdapter.setImageGalleryIndex(spotIndex);
                        mSpotListAdapter.notifyDataSetChanged();
                    }
                    //if(mBallonImageGalleryBar.getBalloonIndex() != eventIndex)
                    if(mEventListAdapter.getBalloonIndex() != eventIndex)
                    {
                        //mBallonImageGalleryBar.setBalloonIndex(eventIndex);

                        mEventListAdapter.setBalloonIndex(eventIndex);
                        mEventListAdapter.notifyDataSetChanged();
                    }

                    linePlus = (lineIndex + 1 > totalLineCount) ? totalLineCount : lineIndex + 1;

                    mLineProgressBar.setMax(totalLineCount);
                    mLineProgressBar.setProgress(linePlus);
                    //mLineProgressBar.invalidate();

                    Log.d(TAG, String.format("line progress : %d/%d-%d/%d", spotIndex, eventIndex, linePlus, totalLineCount));

                    decodedText = decodeURIComponent(currentLineText);
                    mPlayerScriptTextView.setText(decodedText);
                    setTitle(currentTitleText);

                    updateMyPosition();

                    showImage();

                    if(lineIndex == 0)
                    {
                        showOrHideLocationDetectionSetting();

                        updateObject();

                        if (eventIndex == 0)
                        {
                            //mBallonImageGalleryBar.resetBalloonFirstLocation();
                        }

                        moveToPoint(false);

                        playSound();

                        return;
                    }

                    showTtsControl();

                    speakOut(null);
                    break;

                case "refresh_event_etc1":
                    showTtsControl();

                    plays = true;
                    speakOut(null);
                    mIsPlayerRunning = false;
                    break;

                case "refresh_audio_media":
                    if(mPlayerScreenImageView.getVisibility() == View.INVISIBLE)
                    {
                        mPlayerScreenImageView.setVisibility(View.VISIBLE);
                    }

                    showMediaControl();

                    playAudio(currentAudioPath);
                    break;

                case "refresh_video_media":
                    if(mPlayerScreenImageView.getVisibility() == View.VISIBLE)
                    {
                        mPlayerScreenImageView.setVisibility(View.INVISIBLE);
                    }

                    showMediaControl();

                    playVideo(currentVideoPath);
                    break;

                case "refresh_route":
                    loadMapPoint();
                    break;

                case "init_event":
                    showOrHideLocationDetectionSetting();

                    //if(mBallonImageGalleryBar.getImageGalleryIndex() != spotIndex)
                    if(mSpotListAdapter.getImageGalleryIndex() != spotIndex)
                    {
                        //mBallonImageGalleryBar.setImageGalleryIndex(spotIndex);

                        mSpotListAdapter.setImageGalleryIndex(spotIndex);
                        mSpotListAdapter.notifyDataSetChanged();
                    }
                    //if(mBallonImageGalleryBar.getBalloonIndex() != eventIndex)
                    if(mEventListAdapter.getBalloonIndex() != eventIndex)
                    {
                        //mBallonImageGalleryBar.setBalloonIndex(eventIndex);

                        mEventListAdapter.setBalloonIndex(eventIndex);
                        mEventListAdapter.notifyDataSetChanged();

                        int newEventNodePrpperty[] = makeEventNodeProgressProperty(spotIndex);

                        mEventDataList.clear();
                        for(int k = 0; k < newEventNodePrpperty.length; k++)
                        {
                            EventGUI tmpEvent = new EventGUI();
                            tmpEvent.mEventType = newEventNodePrpperty[k];
                            mEventDataList.add(tmpEvent);
                        }
                        mEventListAdapter.notifyDataSetChanged();

                        //mBallonImageGalleryBar.setBalloonProperty(newEventNodePrpperty);
                    }

                    linePlus = (lineIndex + 1 > totalLineCount) ? totalLineCount : lineIndex + 1;
                    mLineProgressBar.setProgress(linePlus);
                    mLineProgressBar.setMax(totalLineCount);

                    decodedText = decodeURIComponent(currentLineText);
                    mPlayerScriptTextView.setText(decodedText);
                    setTitle(currentTitleText);

                    loadMapPoint();

                    moveToPoint(true);
                    //zoomToPoint();
                    showTtsControl();

                    speakOut(null);
                    break;

                case "selecting_event":
                    comment = getString(R.string.please_select_spot_comment);
                    speakOut(comment);
                    break;

                case "finished_event":
                    comment = getString(R.string.route_finished_comment);
                    speakOut(comment);
                    break;

                case "location_detection":
                    PowerManager pm = (PowerManager)getSystemService(Context.POWER_SERVICE);
                    boolean isScreenOn = pm.isScreenOn();

                    if(isScreenOn==false)
                    {
                        //mWakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "TourGuideLock");
                        mWakeLock.acquire(10000);
                    }

                    mArrivingDetectionEventSettingSwitch.toggle();
                    /*
                    if(mIsArrivingDetectionSwitchOn)
                    {
                        mIsArrivingDetectionSwitchOn = false;
                    }
                    else
                    {
                        mIsArrivingDetectionSwitchOn = true;
                    }
                    */

                    resetDetectionLocation();

                    startVibrate();

                    FragmentManager fm = getFragmentManager();
                    if(mGeneralAlarmDialog != null)
                    {
                        mGeneralAlarmDialog.dismiss();
                        mGeneralAlarmDialog = null;
                    }
                    mGeneralAlarmDialog = new GeneralAlarmDialog();
                    mGeneralAlarmDialog.setTitleText(getString(R.string.arrived_to_the_location));
                    mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
                    mGeneralAlarmDialog.setCancelable(false);
                    mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
                    {
                        @Override
                        public void onButtonClickListener(View v, int id, int button)
                        {
                            if(button == GeneralAlarmDialog.OK_BUTTON)
                            {
                                stopVibrate();
                            }
                        }
                    });
                    mGeneralAlarmDialog.show(fm, "tag");
                    break;

                case "my_new_location":
                    updateMyPosition();
                    break;

                case "show_option":
                    showOptionDialog(selectingSpotIndexForOption);
                    break;
            }
        }
    };

    private void showTtsControl()
    {
        //if(mTtsScalableLayout.getVisibility() != View.VISIBLE)
        if(mContollerMode == CONTOLLER_MODE_MEDIA || mContollerMode == CONTOLLER_MODE_NONE)
        {
            mContollerMode = CONTOLLER_MODE_TTS;
            //mTtsScalableLayout.setVisibility(View.VISIBLE);
            //mMediaScalableLayout.setVisibility(View.GONE);

            //mTtsPlayerBackButton.setVisibility(View.VISIBLE);
            //mTtsPlayerPauseButton.setVisibility(View.VISIBLE);
            //mTtsPlayerPlayButton.setVisibility(View.VISIBLE);
            //mTtsPlayerNextButton.setVisibility(View.VISIBLE);

            //mMediaPlayerBackButton.setVisibility(View.GONE);
            //mMediaPlayerPauseButton.setVisibility(View.GONE);
            //mMediaPlayerPlayButton.setVisibility(View.GONE);
            //mMediaPlayerNextButton.setVisibility(View.GONE);

            mLineProgressBar.setVisibility(View.VISIBLE);
            mMediaSeekBar.setVisibility(View.GONE);

            mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
            mTtsPlayerPauseButton.setVisibility(View.VISIBLE);
        }
    }

    private void showMediaControl()
    {
        if(mContollerMode == CONTOLLER_MODE_TTS || mContollerMode == CONTOLLER_MODE_NONE)
        {
            mContollerMode = CONTOLLER_MODE_MEDIA;
            //mTtsScalableLayout.setVisibility(View.GONE);
            //mMediaScalableLayout.setVisibility(View.VISIBLE);

            //mTtsPlayerBackButton.setVisibility(View.VISIBLE);
            //mTtsPlayerPauseButton.setVisibility(View.VISIBLE);
            //mTtsPlayerPlayButton.setVisibility(View.VISIBLE);
            //mTtsPlayerNextButton.setVisibility(View.VISIBLE);

            //mMediaPlayerBackButton.setVisibility(View.VISIBLE);
            //mMediaPlayerPauseButton.setVisibility(View.VISIBLE);
            //mMediaPlayerPlayButton.setVisibility(View.VISIBLE);
            //mMediaPlayerNextButton.setVisibility(View.VISIBLE);

            mLineProgressBar.setVisibility(View.GONE);
            mMediaSeekBar.setVisibility(View.VISIBLE);

            mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
            mTtsPlayerPauseButton.setVisibility(View.VISIBLE);
        }
    }


    @Override
    public void OnTGNodeChangeListener(int nodeIndex, int index, boolean fromUser)
    {
        if(nodeIndex == SpotListAdapter.AREA_IMAGE_GALLERY)
        {
            if(index != spotIndex)
            {
                if(nodeList.get(index).property == NodeProgressBar.NODE_OPTIONAL)
                {
                    mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
                    mTtsPlayerPauseButton.setVisibility(View.VISIBLE);

                    selectingSpotIndexForOption = index;

                    playerState = TRYING_TO_SELECT;
                }
                else
                {
                    mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
                    mTtsPlayerPauseButton.setVisibility(View.VISIBLE);

                    gotoNodeSpotIndex = index;
                    gotoNodeEventIndex = 0;

                    playerState = TRYING_TO_MOVE_GOTO;
                    //gotoNode(index, 0);
                }
                mSpotListAdapter.notifyDataSetChanged();
            }
        }
        else if(nodeIndex == EventListAdapter.AREA_BALLOON)
        {
            if(index != eventIndex)
            {
                //gotoNode(spotIndex, index);

                gotoNodeSpotIndex = spotIndex;
                gotoNodeEventIndex = index;

                playerState = TRYING_TO_MOVE_GOTO;
                mEventListAdapter.notifyDataSetChanged();
            }

        }
        processShortClickOnControlPanel();
    }

    /*
    @Override
    public void onNodeProgressChanged(BalloonImageGalleryBar nodeBar, int nodeIndex, int index, boolean fromUser)
    {
        if(nodeIndex == BalloonImageGalleryBar.AREA_IMAGE_GALLERY)
        {
            if(index != spotIndex)
            {
                if(nodeList.get(index).property == NodeProgressBar.NODE_OPTIONAL)
                {
                    mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
                    mTtsPlayerPauseButton.setVisibility(View.VISIBLE);

                    selectingSpotIndexForOption = index;

                    playerState = TRYING_TO_SELECT;
                }
                else
                {
                    //NodeProgressBar.NODE_MULTI
                    //NodeProgressBar.NODE_SINGLE
                    mTtsPlayerPlayButton.setVisibility(View.INVISIBLE);
                    mTtsPlayerPauseButton.setVisibility(View.VISIBLE);

                    gotoNodeSpotIndex = index;
                    gotoNodeEventIndex = 0;

                    playerState = TRYING_TO_MOVE_GOTO;
                    //gotoNode(index, 0);
                }
            }
        }
        else if(nodeIndex == BalloonImageGalleryBar.AREA_BALLOON)
        {
            if(index != eventIndex)
            {
                //gotoNode(spotIndex, index);

                gotoNodeSpotIndex = spotIndex;
                gotoNodeEventIndex = index;

                playerState = TRYING_TO_MOVE_GOTO;
            }
        }
    }
    */

    public void draw(float angle)
    {
        if(myLocationMarker != null)
        {
            myLocationMarker.setRotation(angle);
        }
        /*
        // Take the relevant Marker from the marker list where available in map
        AndroidMapGoogleOverlayItem myself = (AndroidMapGoogleOverlayItem) getOverlayItem(0);

        if (myself == null) {
            return;
        }
        myself.getMarker().setRotation(mOrientation);  // set the orientation value returned from the senserManager
        */
    }

    private void resetForwardWeight(VertexGroup before)
    {
        ArrayList<Edge> tmpPath = before.getNeighbors();

        //there is only 1 next node, search next node
        for(int x = 0; x < tmpPath.size(); x++)
        {
            Edge tmpEdge = tmpPath.get(x);

            if (before == tmpEdge.getFront())
            {
                //prev node
            } else if (before == tmpEdge.getBack())
            {
                tmpEdge.setWeight(Edge.WEIGHT_FALSE);
            }
        }
    }

    private void setWeight(VertexGroup before, VertexGroup after, boolean flag)
    {
        ArrayList<Edge> tmpPath = before.getNeighbors();

        //there is only 1 next node, search next node
        for(int x = 0; x < tmpPath.size(); x++)
        {
            Edge tmpEdge = tmpPath.get(x);

            if (before == tmpEdge.getFront())
            {
                //prev node
            }
            else if (before == tmpEdge.getBack())
            {

                VertexGroup tmpNext = tmpEdge.getFront();
                if(after == tmpNext)
                {
                    if(flag == true)
                    {
                        tmpEdge.setWeight(Edge.WEIGHT_TRUE);
                    }
                    else
                    {
                        tmpEdge.setWeight(Edge.WEIGHT_FALSE);
                    }
                }
                /*
                else
                {
                    tmpEdge.setWeight(Edge.WEIGHT_FALSE);   // <--- another path is always false;
                }
                */
            }
        }
    }

    @Override
    public void onListClickListener(View v, int index, int fromIndex, VertexGroup destinationVertex, int destinationSpotIndex)
    {
        if(index == -1)
        {
            /*
            playerState = MOVING;
            Log.d(TAG, String.format("playerState = MOVING"));
            mTTS.stop();
            mAudio.stop();
            */

            playerState = TRYING_TO_MOVE_GOTO;
        }
        else
        {
            NodeProgressBarItem tmpCurrentItem = nodeList.get(fromIndex);
            NodeProgressBarItem tmpPreItem = nodeList.get(fromIndex - 1);

            if (tmpCurrentItem.property == NodeProgressBar.NODE_OPTIONAL)
            {
                ArrayList<Edge> tmpPath = tmpPreItem.vertex.getNeighbors();

                int nextPath = 0;
                for(int x = 0; x < tmpPath.size(); x++)
                {
                    Edge tmpEdge = tmpPath.get(x);

                    if (tmpPreItem.vertex == tmpEdge.getFront())
                    {
                        //prev node
                    }
                    else if (tmpPreItem.vertex == tmpEdge.getBack())
                    {
                        nextPath++;
                    }
                }

                if (destinationVertex.getSpots().size() > 1) //multi spots
                {
                    if(nextPath > 1)
                    {
                        //multi spots & multi path

                        resetForwardWeight(tmpPreItem.vertex);

                        for(int x = 0; x < tmpPath.size(); x++)
                        {
                            Edge tmpEdge = tmpPath.get(x);

                            if (tmpPreItem.vertex == tmpEdge.getFront())
                            {
                                //prev node
                            }
                            else if (tmpPreItem.vertex == tmpEdge.getBack())
                            {
                                if(tmpEdge.getFront() == destinationVertex)
                                {
                                    setWeight(tmpPreItem.vertex, destinationVertex, true);

                                    routeGraph.addPathToSelectedBuffer(tmpEdge);

                                    destinationVertex.resetSpotWeight();
                                    destinationVertex.setSpotWeight(destinationSpotIndex, true);
                                }
                                else
                                {
                                    //deselect weight of another path
                                    setWeight(tmpPreItem.vertex, tmpEdge.getFront(), false);

                                    routeGraph.removePathToSelectedBuffer(tmpEdge);

                                    tmpEdge.getFront().resetSpotWeight();
                                }
                            }
                        }
                    }
                    else
                    {
                        destinationVertex.resetSpotWeight();
                        destinationVertex.setSpotWeight(destinationSpotIndex, true);
                    }
                }
                else    //multi path
                {
                    if(nextPath > 1)
                    {
                        resetForwardWeight(tmpPreItem.vertex);

                        setWeight(tmpPreItem.vertex, destinationVertex, true);

                        ArrayList<Edge> tmpEdges = tmpPreItem.vertex.getNeighbors();
                        for(int k = 0; k < tmpEdges.size(); k++)
                        {
                            Edge oneEdge = tmpEdges.get(k);
                            if(oneEdge.getFront() == destinationVertex)
                            {
                                routeGraph.addPathToSelectedBuffer(oneEdge);
                                break;
                            }
                        }
                    }
                    else
                    {
                        //? what is this case?????
                        //this should not happen
                        //setWeight(tmpPreItem.vertex, destinationVertex, true);
                    }
                }

                eventIndex = 0;
                lineIndex = 0;
                //loadGUI(routeIndex, spotIndex, eventIndex, lineIndex);
                loadGUI(0, spotIndex, eventIndex, lineIndex);

                addMarkers();

                gotoNodeSpotIndex = fromIndex + 1;
                gotoNodeEventIndex = 0;

                playerState = TRYING_TO_MOVE_GOTO;
                Log.d(TAG, String.format("playerState = TRYING_TO_MOVE_GOTO"));

                //gotoNode(fromIndex + 1, 0);
            }
            else
            {
                //strange case
                return;
            }
        }
    }

    private void playSelectingComment()
    {
        Message msg = playerHandler.obtainMessage();
        Bundle b = new Bundle();
        b.putString(HANDLER_HEADER, "selecting_event");
        msg.setData(b);
        playerHandler.sendMessage(msg);
    }

    private void playFinishedComment()
    {
        Message msg = playerHandler.obtainMessage();
        Bundle b = new Bundle();
        b.putString(HANDLER_HEADER, "finished_event");
        msg.setData(b);
        playerHandler.sendMessage(msg);
    }

    private boolean isRectangleCoordinateValid(float arr1, float arr2, float arr3, float arr4)
    {
        if(arr1 == 0)
        {
            if(arr2 == 0)
            {
                if(arr3 == 0)
                {
                    if(arr4 == 0)
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private boolean isThisVertexExistInPlannedPathOfNodeBar(VertexGroup currnetVertex)
    {
        NodeProgressBarItem tmpPrevElement = null;
        for(int x = 0; x < nodeList.size(); x++)
        {
            NodeProgressBarItem tmpCurrentElement = nodeList.get(x);

            if(tmpCurrentElement.property == NodeProgressBar.NODE_OPTIONAL)
            {
                continue;
            }
            else
            {
                if(tmpCurrentElement.vertex == currnetVertex)
                {
                    return true;
                }
            }
        }

        return false;
    }

    private Edge getPlannedBackEdge(VertexGroup currnetVertex)
    {
        boolean currentVertexFound = false;
        NodeProgressBarItem tmpPrevElement = null;
        for(int x = nodeList.size()-1; x >= 0; x--)
        {
            NodeProgressBarItem tmpCurrentElement = nodeList.get(x);

            if(tmpCurrentElement.property == NodeProgressBar.NODE_OPTIONAL)
            {
                continue;
            }
            else
            {
                if(currentVertexFound == false)
                {
                    if(tmpCurrentElement.vertex == currnetVertex)
                    {
                        currentVertexFound = true;
                    }
                }
                else
                {
                    //previous vertex in nodeList
                    //and
                    ArrayList<Edge> tmpEdges = tmpCurrentElement.vertex.getNeighbors();
                    for(int i = 0; i < tmpEdges.size(); i++)
                    {
                        Edge oneEdge = tmpEdges.get(i);

                        if (currnetVertex == oneEdge.getFront())
                        {
                            //prev node
                            return oneEdge;
                        }
                    }
                }
            }
        }

        return null;
    }

    private boolean isThisEdgeExistInPlannedPathOfNodeBar(Edge currentEdge)
    {
        NodeProgressBarItem tmpPrevElement = null;
        for(int x = 0; x < nodeList.size(); x++)
        {
            NodeProgressBarItem tmpCurrentElement = nodeList.get(x);

            if(tmpCurrentElement.property == NodeProgressBar.NODE_OPTIONAL)
            {
                continue;
            }
            //else if(tmpCurrentElement.property == NodeProgressBar.NODE_MULTI)
            //else if(tmpCurrentElement.property == NodeProgressBar.NODE_SINGLE)
            else
            {
                if(tmpPrevElement != null)
                {
                    ArrayList<Edge> tmpEdges = tmpPrevElement.vertex.getNeighbors();
                    for(int i = 0; i < tmpEdges.size(); i++)
                    {
                        Edge oneEdge = tmpEdges.get(i);

                        if (tmpPrevElement.vertex == oneEdge.getFront())
                        {
                            //prev node
                        }
                        else if (tmpPrevElement.vertex == oneEdge.getBack())
                        {
                            //next node

                            ArrayList<Edge> tmpNextEdges = tmpCurrentElement.vertex.getNeighbors();
                            for(int j = 0; j < tmpNextEdges.size(); j++)
                            {
                                Edge oneNextEdge = tmpNextEdges.get(j);

                                if (tmpCurrentElement.vertex == oneNextEdge.getFront())
                                {
                                    //prev node
                                    if(oneEdge == oneNextEdge)
                                    {
                                        if(oneEdge == currentEdge)
                                        {
                                            return true;
                                        }
                                    }

                                }
                                else if (tmpPrevElement.vertex == oneNextEdge.getBack())
                                {
                                    //next node

                                }
                            }
                        }
                    }
                }
            }

            tmpPrevElement = tmpCurrentElement;
        }

        return false;
    }

    private int loadSound(int filename)
    {
        //int soundID = 0;
        if (soundPool == null)
        {
            soundPool = buildSound();
        }

        try
        {
            soundID = soundPool.load(this, filename, 1);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return soundID;
    }

    private Marker retrieveMarker(int tmpRouteIndex, int tmpSpotIndex, int tmpEventIndex, int tmpLineIndex)
    {
        NodeProgressBarItem tmpElement = nodeList.get(tmpSpotIndex);
        VertexGroup tmpVertex = tmpElement.vertex;

        if(tmpVertex == null)
        {
            return null;
        }

        int spotSize = tmpVertex.getSpots().size();
        ServerMapSpotData tmps = null;

        if(spotSize > 1)
        {
            int weightIndex = tmpVertex.getSpotWeightIndex();
            //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
            int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, tmpSpotIndex);

            int tmpIndex = 0;
            if(weightIndex < 0)
            {
                if(recommendedIndex < 0)
                {
                    tmpIndex = 0;
                }
                else
                {
                    tmpIndex = recommendedIndex;
                }
            }
            else
            {
                tmpIndex = weightIndex;
            }
            tmps = tmpVertex.getSpots().get(tmpIndex);
        }
        else
        {
            tmps = tmpVertex.getSpots().get(0);
        }

        List<ServerMapEventData> tmpEvents = tmps.getEvent();
        ServerMapEventData oneEvent = tmpEvents.get(tmpEventIndex);

        Marker tmpMarker = eventMarkersMap.get(oneEvent.hashCode());

        return tmpMarker;
    }

    public void playSound()
    {
        if (loaded )
        {
            actVolume = (float) audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            maxVolume = (float) audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            volume = actVolume / maxVolume;

            if(mIsPlayerRunning == true)
            {
                //Log.d(TAG, "mIsPlayerRunning == true, not play sound");

                Message new_msg = playerHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putString(HANDLER_HEADER, "refresh_event_etc1");
                new_msg.setData(b);
                playerHandler.sendMessage(new_msg);

                return;
            }

            soundPlayThread tmpSoundPlayThread = new soundPlayThread();
            tmpSoundPlayThread.setVolume(soundPool, volume);
            tmpSoundPlayThread.start();

            //soundPool.play(soundID, volume, volume, 1, 0, 1f);
        }
    }

    public void stopSound()
    {
        if (plays)
        {
            soundPool.stop(soundID);
            plays = false;
        }
    }

    @SuppressWarnings("deprecation")
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private SoundPool buildSound()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            soundPool = new SoundPool.Builder()
                    //.setMaxStreams(25)
                    .setAudioAttributes(audioAttributes)
                    .build();
        }
        else
        {
            buildForAPI21();
        }

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        this.setVolumeControlStream(AudioManager.STREAM_MUSIC);

        actVolume = (float) audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        maxVolume = (float) audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        volume = actVolume / maxVolume;

        soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener()
        {
            @Override
            public void onLoadComplete(SoundPool soundPool, int sampleId, int status)
            {
                loaded = true;
            }
        });

        loadSound(R.raw.next_alarm);

        return soundPool;
    }

    public void buildForAPI21()
    {
        soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
    }

    public void startVibrate()
    {
        long pattern[] = { 0, 100, 200, 300, 400 };
        mVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        mVibrator.vibrate(pattern, 0);
    }

    public void stopVibrate()
    {
        if(mVibrator != null)
        {
            mVibrator.cancel();
        }
    }

    private boolean isThisWieghted(VertexGroup oneVertex)
    {
        if(oneVertex.getSpotWeightIndex() != -1)
        {
            return true;
        }

        ArrayList<Edge> tmpPath = oneVertex.getNeighbors();
        //ArrayList<VertexGroup> tmpVerticesList = new ArrayList<VertexGroup>();

        //there is only 1 next node, search next node
        for(int x = 0; x < tmpPath.size(); x++)
        {
            Edge tmpEdge = tmpPath.get(x);

            if (oneVertex == tmpEdge.getFront())
            {
                //prev node
                int totalSpotsSize = oneVertex.getSpots().size();

                if(
                        (tmpEdge.getWeight() == Edge.WEIGHT_TRUE) && (totalSpotsSize == 1)
                    )
                {
                    return true;
                }

            }
            else if (oneVertex == tmpEdge.getBack())
            {
                //next node
            }
        }

        return false;
    }

    private int[] makeEventNodeProgressProperty(int tmpSpotIndex)
    {
        NodeProgressBarItem tmpElement = nodeList.get(tmpSpotIndex);
        VertexGroup tmpVertex = tmpElement.vertex;

        if(tmpVertex == null)
        {
            return null;
        }

        int spotSize = tmpVertex.getSpots().size();
        ServerMapSpotData tmps = null;

        if(spotSize > 1)
        {
            int weightIndex = tmpVertex.getSpotWeightIndex();
            //int recommendedIndex = tmpVertex.getSpotRecommendedIndex();
            int recommendedIndex = getCurrentVertexRecommendedIndexFromNodeList(nodeList, tmpSpotIndex);
            int tmpIndex = 0;
            if(weightIndex < 0)
            {
                if(recommendedIndex < 0)
                {
                    tmpIndex = 0;
                }
                else
                {
                    tmpIndex = recommendedIndex;
                }
            }
            else
            {
                tmpIndex = weightIndex;
            }
            tmps = tmpVertex.getSpots().get(tmpIndex);
        }
        else
        {
            tmps = tmpVertex.getSpots().get(0);
        }

        List<ServerMapEventData> tmpEvents = tmps.getEvent();
        int eventNodePrpperty[] = new int[tmpEvents.size()];

        for(int x = 0; x < tmpEvents.size(); x++)
        {
            if(tmps.getType() == ServerMapSpotData.NODE_TYPE_INTRO)
            {
                eventNodePrpperty[x] = NodeProgressBar.NODE_INTRO;
            }
            else
            {
                if (tmpEvents.get(x).getType() == ServerMapEventData.NODE_TYPE_NO_LOCATION_RELATED)
                {
                    eventNodePrpperty[x] = NodeProgressBar.NODE_INTRO;
                }
                else
                {
                    eventNodePrpperty[x] = NodeProgressBar.NODE_SINGLE;
                }
            }
        }
        return eventNodePrpperty;
        //mBallonImageGalleryBar.setBalloonProperty(eventNodePrpperty);
    }

    private double[] getFirstEventLocation(ServerMapSpotData tmpSpot)
    {
        double tmpLocation[] = new double[2];
        tmpLocation[0] = 0;
        tmpLocation[1] = 0;

        if( (tmpSpot.getType() == MOVEMENT_TYPE) )
        {
            ArrayList<LatLng> tmpAreas = tmpSpot.getArea();
            if(tmpAreas != null && tmpAreas.size() > 0)
            {
                tmpLocation[0] = tmpAreas.get(0).latitude;
                tmpLocation[1] = tmpAreas.get(0).longitude;
            }
        }
        else
        {
            List<ServerMapEventData> tmpEvents = tmpSpot.getEvent();

            int lastIndex = tmpEvents.size();
            for (int x = 0; x < lastIndex; x++)
            {
                ServerMapEventData oneEvent = tmpEvents.get(x);

                double lat = oneEvent.getLat();
                double lng = oneEvent.getLng();

                if (lat == 0 && lng == 0)
                {
                    //no location data
                    continue;
                }
                else
                {
                    tmpLocation[0] = lat;
                    tmpLocation[1] = lng;
                    break;
                }
            }
        }

        if( tmpLocation[0] == 0 && tmpLocation[1] == 0)
        {
            //This is impossible case, so just return the zero location
            //tmpLocation[0] = tmpSpot.getLat();
            //tmpLocation[1] = tmpSpot.getLng();

            return tmpLocation;
        }
        else
        {
            return tmpLocation;
        }
    }

    private double[] getLastEventLocation(ServerMapSpotData tmpSpot)
    {
        double tmpLocation[] = new double[2];
        tmpLocation[0] = 0;
        tmpLocation[1] = 0;

        if( (tmpSpot.getType() == MOVEMENT_TYPE) )
        {
            ArrayList<LatLng> tmpAreas = tmpSpot.getArea();
            if(tmpAreas != null && tmpAreas.size() > 0)
            {
                tmpLocation[0] = tmpAreas.get(tmpAreas.size()-1).latitude;
                tmpLocation[1] = tmpAreas.get(tmpAreas.size()-1).longitude;
            }
        }
        else
        {
            List<ServerMapEventData> tmpEvents = tmpSpot.getEvent();

            int lastIndex = tmpEvents.size();
            for (int x = lastIndex - 1; x >= 0; x--)
            {
                ServerMapEventData oneEvent = tmpEvents.get(x);

                double lat = oneEvent.getLat();
                double lng = oneEvent.getLng();

                if (lat == 0 && lng == 0)
                {
                    //no location data
                    continue;
                }
                else
                {
                    tmpLocation[0] = lat;
                    tmpLocation[1] = lng;
                    break;
                }
            }
        }

        if( tmpLocation[0] == 0 && tmpLocation[1] == 0)
        {
            //This is impossible case, so just return the zero location
            //tmpLocation[0] = tmpSpot.getLat();
            //tmpLocation[1] = tmpSpot.getLng();

            return tmpLocation;
        }
        else
        {
            return tmpLocation;
        }
    }

    private void initSensors()
    {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        Sensor mSensorGravity = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        Sensor mSensorMagneticField = sensorManager
                .getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        /* Initialize the gravity sensor */
        if (mSensorGravity != null)
        {
            Log.i(TAG, "Gravity sensor available. (TYPE_GRAVITY)");
            sensorManager.registerListener(mSensorEventListener,
                    mSensorGravity, SensorManager.SENSOR_DELAY_GAME);
        }
        else
        {
            Log.i(TAG, "Gravity sensor unavailable. (TYPE_GRAVITY)");
        }

        /* Initialize the magnetic field sensor */
        if (mSensorMagneticField != null)
        {
            Log.i(TAG, "Magnetic field sensor available. (TYPE_MAGNETIC_FIELD)");
            sensorManager.registerListener(mSensorEventListener,
                    mSensorMagneticField, SensorManager.SENSOR_DELAY_GAME);
        }
        else
        {
            Log.i(TAG,
                    "Magnetic field sensor unavailable. (TYPE_MAGNETIC_FIELD)");
        }

        mSensorManager = sensorManager;
    }

    private void uninitSensors()
    {
        if((mSensorEventListener != null) && (mSensorManager != null))
        {
            mSensorManager.unregisterListener(mSensorEventListener);
        }
    }

    private SensorEventListener mSensorEventListener = new SensorEventListener()
    {
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy)
        {
        }

        @Override
        public void onSensorChanged(SensorEvent event)
        {
            if (event.sensor.getType() == Sensor.TYPE_GRAVITY)
            {
                mGravity = event.values.clone();
            }
            else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
            {
                mMagnetic = event.values.clone();
            }

            if (mGravity != null && mMagnetic != null)
            {
                /* Create rotation Matrix */
                float[] rotationMatrix = new float[9];
                if (SensorManager.getRotationMatrix(rotationMatrix, null, mGravity, mMagnetic))
                {
                    /* Compensate device orientation */
                    // http://android-developers.blogspot.de/2010/09/one-screen-turn-deserves-another.html
                    float[] remappedRotationMatrix = new float[9];
                    switch (getWindowManager().getDefaultDisplay()
                            .getRotation()) {
                        case Surface.ROTATION_0:
                            SensorManager.remapCoordinateSystem(rotationMatrix,
                                    SensorManager.AXIS_X, SensorManager.AXIS_Y,
                                    remappedRotationMatrix);
                            break;
                        case Surface.ROTATION_90:
                            SensorManager.remapCoordinateSystem(rotationMatrix,
                                    SensorManager.AXIS_Y,
                                    SensorManager.AXIS_MINUS_X,
                                    remappedRotationMatrix);
                            break;
                        case Surface.ROTATION_180:
                            SensorManager.remapCoordinateSystem(rotationMatrix,
                                    SensorManager.AXIS_MINUS_X,
                                    SensorManager.AXIS_MINUS_Y,
                                    remappedRotationMatrix);
                            break;
                        case Surface.ROTATION_270:
                            SensorManager.remapCoordinateSystem(rotationMatrix,
                                    SensorManager.AXIS_MINUS_Y,
                                    SensorManager.AXIS_X, remappedRotationMatrix);
                            break;
                    }

                    /* Calculate Orientation */
                    float results[] = new float[3];
                    SensorManager.getOrientation(remappedRotationMatrix, results);

                    /* Get measured value */
                    float current_measured_bearing = (float) (results[0] * 180 / Math.PI);
                    if (current_measured_bearing < 0) {
                        current_measured_bearing += 360;
                    }

                    /* Smooth values using a 'Low Pass Filter' */
                    //current_measured_bearing = current_measured_bearing + SMOOTHING_FACTOR_COMPASS * (current_measured_bearing - compass_last_measured_bearing);

                    /* Update normal output */
                    //visual_compass_value.setText(String.valueOf(Math.round(current_bearing)) + getString(R.string.degrees));

                    /*
                    * Update variables for next use (Required for Low Pass
                    * Filter)
                    */
                    //compass_last_measured_bearing = current_measured_bearing;
                    //Math.round(current_bearing);

                    mMagneticOrientation = current_measured_bearing;

                    draw(mMagneticOrientation);

                }
            }
        }
    };

    private class PlayerEngineThread extends Thread
    {
        private boolean mIsEngineRunning = true;

        public void quit()
        {
            mIsEngineRunning = false;
        }

        @Override
        public void run()
        {
            while(mIsEngineRunning == true)
            {
                switch(playerState)
                {
                    case NOT_STARTED:
                    {
                        //int result = loadGUI(routeIndex, spotIndex, eventIndex, lineIndex);
                        int result = loadGUI(0, spotIndex, eventIndex, lineIndex);
                        if(result == 0)
                        {
                            playerState = TRYING_TO_PLAY;
                            Log.d(TAG, String.format("playerState = TRYING_TO_PLAY"));

                            initEvent();
                        }
                        else
                        {
                            playerState = ERROR;
                        }
                        break;
                    }

                    case TRYING_TO_PLAY:
                    {
                        playerState = PLAYING;
                        Log.d(TAG, String.format("playerState = PLAYING"));

                        if(TtsPlayerState == TTS_STARTED)
                        {
                        }
                        else if((TtsPlayerState == TTS_STOPPED) || (TtsPlayerState == TTS_NOT_STARTED))
                        {
                            speakOut(null);
                        }
                        break;
                    }

                    case PLAYING:
                        if(TtsPlayerState == TTS_STOPPED)
                        {
                            playerState = TRYING_TO_PLAY_ETC_MEDIA;
                        }
                        break;

                    case TRYING_TO_PLAY_ETC_MEDIA:
                        playerState = ETC_MEDIA_PLAYING;
                        Log.d(TAG, String.format("playerState = ETC_MEDIA_PLAYING"));

                        if(MediaPlayerState == PLAYER_STARTED)
                        {

                        }
                        else if((MediaPlayerState == PLAYER_STOPPED) || (MediaPlayerState == PLAYER_NOT_STARTED))
                        {
                            //if audio or video exist, play audio/video
                            boolean ret = isPlayAudioPlanned();
                            if(ret == true)
                            {
                                //let's play audio
                                MediaPlayerState = PLAYER_STARTED;      //set fake state to prevent execute multiple times

                                Message msg = playerHandler.obtainMessage();
                                Bundle b = new Bundle();
                                b.putString(HANDLER_HEADER, "refresh_audio_media");
                                msg.setData(b);
                                playerHandler.sendMessage(msg);
                            }
                            else
                            {
                                boolean vid_ret = isPlayVideoPlanned();
                                if(vid_ret == true)
                                {
                                    //let's play video
                                    MediaPlayerState = PLAYER_STARTED;      //set fake state to prevent execute multiple times

                                    Message msg = playerHandler.obtainMessage();
                                    Bundle b = new Bundle();
                                    b.putString(HANDLER_HEADER, "refresh_video_media");
                                    msg.setData(b);
                                    playerHandler.sendMessage(msg);
                                }
                                else
                                {
                                    //for passig at the next state(ETC_MEDIA_PLAYING)
                                    MediaPlayerState = PLAYER_STOPPED;
                                }
                            }
                        }
                        break;

                    case ETC_MEDIA_PLAYING:
                        if(MediaPlayerState == PLAYER_STOPPED)
                        {
                            if(totalLineCount-1 > lineIndex)
                            {
                                playerState = TRYING_TO_MOVE_NEXT;
                                Log.d(TAG, String.format("playerState = TRYING_TO_MOVE_NEXT"));
                            }
                            else if(
                                    (totalLineCount-1 == lineIndex) &&
                                            (totalEventCount-1 == eventIndex) &&
                                            (totalSpotCount-1 == spotIndex) &&
                                            (totalRouteCount-1 == 0)
                                            //(totalRouteCount-1 == routeIndex)
                                    )
                            {
                                playerState = TRYING_TO_SHOW_FINISH_ALARM;
                                Log.d(TAG, String.format("playerState = TRYING_TO_SHOW_FINISH_ALARM"));
                            }
                            else
                            {
                                if(mAutoNextSwitchOn == true)
                                {
                                    playerState = TRYING_TO_MOVE_NEXT;
                                    Log.d(TAG, String.format("playerState = TRYING_TO_MOVE_NEXT"));
                                }
                            }
                        }
                        break;

                    case TRYING_TO_PAUSE:
                    {
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            mTTS.stop();
                        }
                        if(MediaPlayerState == PLAYER_STARTED)
                        {
                            if (mMediaPlayer.isPlaying())
                            {
                                mMediaPlayer.stop();
                            }
                        }
                        break;
                    }

                    case PAUSED:
                    {

                        break;
                    }

                    case TRYING_TO_STOP:
                    {
                        break;
                    }

                    case STOPPED:
                    {
                        break;
                    }

                    case TRYING_TO_MOVE_GOTO:
                    {
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            mTTS.stop();
                        }

                        if(MediaPlayerState == PLAYER_STARTED)
                        {
                            if (mMediaPlayer.isPlaying())
                            {
                                mMediaPlayer.stop();
                            }
                        }

                        int result = gotoNode(gotoNodeSpotIndex, gotoNodeEventIndex);

                        if(result != NO_ITEM)
                        {
                            playerState = MOVING_GOTO;
                            Log.d(TAG, String.format("playerState = MOVING_GOTO"));

                            Message msg = playerHandler.obtainMessage();
                            Bundle b = new Bundle();
                            b.putString(HANDLER_HEADER, "refresh_event");
                            b.putInt("event_count", result);
                            msg.setData(b);
                            playerHandler.sendMessage(msg);
                        }

                        break;
                    }

                    case MOVING_GOTO:
                    {
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            playerState = PLAYING;
                            Log.d(TAG, String.format("playerState = PLAYING"));
                        }

                        if(MediaPlayerState == PLAYER_STARTED)
                        {
                            playerState = PLAYING;
                            Log.d(TAG, String.format("playerState = PLAYING"));
                        }
                        break;
                    }

                    case TRYING_TO_MOVE_NEXT:
                    {
                        Log.d(TAG, "next()");
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            mTTS.stop();
                        }
                        if(MediaPlayerState == PLAYER_STARTED)
                        {
                            if (mMediaPlayer.isPlaying())
                            {
                                mMediaPlayer.stop();
                            }
                        }
                        int result = next(true);

                        if(result == NEED_TO_SELECT)
                        {
                            selectingSpotIndexForOption = spotIndex;
                            playerState = TRYING_TO_SELECT;
                            Log.d(TAG, String.format("playerState = TRYING_TO_SELECT"));
                        }
                        /*
                        else if(result == END_OF_ROUTE)
                        {
                            playerState = TRYING_TO_SHOW_FINISH_ALARM;
                            Log.d(TAG, String.format("playerState = TRYING_TO_FINISH"));
                        }
                        */
                        else if(result != NO_ITEM)
                        {
                            playerState = MOVING_NEXT;
                            Log.d(TAG, String.format("playerState = MOVING_NEXT"));

                            Message msg = playerHandler.obtainMessage();
                            Bundle b = new Bundle();
                            b.putString(HANDLER_HEADER, "refresh_event");
                            b.putInt("event_count", result);
                            msg.setData(b);
                            playerHandler.sendMessage(msg);
                        }

                        break;
                    }

                    case MOVING_NEXT:
                    {
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            playerState = PLAYING;
                            Log.d(TAG, String.format("playerState = PLAYING"));
                        }

                        if(MediaPlayerState == PLAYER_STARTED)  //this is strange case?
                        {
                            playerState = PLAYING;
                            Log.d(TAG, String.format("playerState = PLAYING"));
                        }
                        break;
                    }

                    case TRYING_TO_MOVE_PREV:
                    {
                        Log.d(TAG, "previous()");
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            mTTS.stop();
                        }
                        if(MediaPlayerState == PLAYER_STARTED)
                        {
                            if (mMediaPlayer.isPlaying())
                            {
                                mMediaPlayer.stop();
                            }
                        }
                        int result = previous();

                        if(result != NO_ITEM)
                        {
                            playerState = MOVING_PREV;
                            Log.d(TAG, String.format("playerState = MOVING_PREV"));

                            Message msg = playerHandler.obtainMessage();
                            Bundle b = new Bundle();
                            b.putString(HANDLER_HEADER, "refresh_event");
                            b.putInt("event_count", result);
                            msg.setData(b);
                            playerHandler.sendMessage(msg);
                        }

                        break;
                    }

                    case MOVING_PREV:
                    {
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            playerState = PLAYING;
                        }

                        if(MediaPlayerState == PLAYER_STARTED)  //this is strange case?
                        {
                            playerState = PLAYING;
                        }
                        break;
                    }

                    case TRYING_TO_SELECT:
                    {
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            mTTS.stop();
                        }
                        if(MediaPlayerState == PLAYER_STARTED)
                        {
                            if (mMediaPlayer.isPlaying())
                            {
                                mMediaPlayer.stop();
                            }
                        }

                        playerState = SELECTING;
                        Log.d(TAG, String.format("playerState = SELECTING"));

                        Message msg = playerHandler.obtainMessage();
                        Bundle b = new Bundle();
                        b.putString(HANDLER_HEADER, "show_option");
                        msg.setData(b);
                        playerHandler.sendMessage(msg);
                        //showOptionDialog(spotIndex);

                        break;
                    }

                    case SELECTING:
                    {
                        if(
                                (TtsPlayerState == TTS_STOPPED)
                            && (MediaPlayerState == PLAYER_STOPPED)
                                )
                        {
                            playSelectingComment();
                        }

                        break;
                    }

                    case TRYING_TO_SHOW_FINISH_ALARM:
                    {
                        if(TtsPlayerState == TTS_STARTED)
                        {
                            mTTS.stop();
                        }
                        if(MediaPlayerState == PLAYER_STARTED)
                        {
                            if (mMediaPlayer.isPlaying())
                            {
                                mMediaPlayer.stop();
                            }
                        }

                        playerState = FINISH_ALARMING;
                        Log.d(TAG, String.format("playerState = FINISH_ALARMING"));

                        break;
                    }

                    case FINISH_ALARMING:
                    {
                        if(
                                (TtsPlayerState == TTS_STOPPED)
                                && (MediaPlayerState == PLAYER_STOPPED)
                                )
                        {
                            playFinishedComment();
                        }

                        break;
                    }
                }

                printCurrentState();

                try
                {
                    sleep(30);
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
            }

            /*
            runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
                    //doButtonStuff();
                }
            });
            */
        }
    }

    private void printCurrentState()
    {
        if(prevPlayerState != playerState)
        {
            switch (playerState)
            {
                case NOT_STARTED:
                    Log.d(TAG, String.format("NOT_STARTED"));
                    break;
                case TRYING_TO_PLAY:
                    Log.d(TAG, String.format("TRYING_TO_PLAY"));
                    break;
                case PLAYING:
                    Log.d(TAG, String.format("PLAYING"));
                    break;
                case TRYING_TO_PAUSE:
                    Log.d(TAG, String.format("TRYING_TO_PAUSE"));
                    break;
                case PAUSED:
                    Log.d(TAG, String.format("PAUSED"));
                    break;
                case TRYING_TO_STOP:
                    Log.d(TAG, String.format("TRYING_TO_STOP"));
                    break;
                case STOPPED:
                    Log.d(TAG, String.format("STOPPED"));
                    break;
                case TRYING_TO_MOVE_GOTO:
                    Log.d(TAG, String.format("TRYING_TO_MOVE_GOTO"));
                    break;
                case MOVING_GOTO:
                    Log.d(TAG, String.format("MOVING_GOTO"));
                    break;
                case TRYING_TO_MOVE_PREV:
                    Log.d(TAG, String.format("TRYING_TO_MOVE_PREV"));
                    break;
                case MOVING_PREV:
                    Log.d(TAG, String.format("MOVING_PREV"));
                    break;
                case TRYING_TO_PLAY_ETC_MEDIA:
                    Log.d(TAG, String.format("TRYING_TO_PLAY_ETC_MEDIA"));
                    break;
                case ETC_MEDIA_PLAYING:
                    Log.d(TAG, String.format("ETC_MEDIA_PLAYING"));
                    break;
                case TRYING_TO_MOVE_NEXT:
                    Log.d(TAG, String.format("TRYING_TO_MOVE_NEXT"));
                    break;
                case MOVING_NEXT:
                    Log.d(TAG, String.format("MOVING_NEXT"));
                    break;
                case TRYING_TO_SELECT:
                    Log.d(TAG, String.format("TRYING_TO_SELECT"));
                    break;
                case SELECTING:
                    Log.d(TAG, String.format("SELECTING"));
                    break;
                case TRYING_TO_SHOW_FINISH_ALARM:
                    Log.d(TAG, String.format("TRYING_TO_SHOW_FINISH_ALARM"));
                    break;
                case FINISH_ALARMING:
                    Log.d(TAG, String.format("FINISH_ALARMING"));
                    break;
                case ERROR:
                    Log.d(TAG, String.format("ERROR"));
                    break;
                default:
                    Log.d(TAG, String.format("??"));
                    break;
            }
        }
        prevPlayerState = playerState;
    }

    public class soundPlayThread extends Thread
    {
        private SoundPool mSoundPool;
        private float mVolume;

        public void setVolume(SoundPool soundPool, float tmpVolume)
        {
            mSoundPool = soundPool;
            mVolume = tmpVolume;
        }

        @Override
        public void run()
        {
            if(mIsPlayerRunning == true)
            {
                //Log.d(TAG, "mIsPlayerRunning == true, return thread");
                return;
            }

            mIsPlayerRunning = true;
            //Log.d(TAG, "mIsPlayerRunning = true");

            soundPool.play(soundID, mVolume, mVolume, 1, 0, 1f);

            int i = 0;
            while((i < 14) && (mPlayerStarted == true))
            {
                try
                {
                    Thread.sleep(100);
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
                i++;
            }

            if(mPlayerStarted)
            {
                Message new_msg = playerHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putString(HANDLER_HEADER, "refresh_event_etc1");
                new_msg.setData(b);
                playerHandler.sendMessage(new_msg);
            }
        }
    }

    /*
    public BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context arg0, Intent intent)
        {
            int  msg_id = intent.getExtras().getInt(GENERAL_APP_ID);

            switch(msg_id)
            {
                case MY_LOCATION_CHANGED:
                    if(playerHandler != null)
                    {
                        Message msg = playerHandler.obtainMessage();
                        Bundle b = new Bundle();
                        b.putString(HANDLER_HEADER, "my_new_location");
                        msg.setData(b);
                        playerHandler.sendMessage(msg);
                    }
                    break;

                case LOCATION_DETECTION:
                    if(playerHandler != null)
                    {
                        Message msg = playerHandler.obtainMessage();
                        Bundle b = new Bundle();
                        b.putString(HANDLER_HEADER, "location_detection");
                        msg.setData(b);
                        playerHandler.sendMessage(msg);
                    }
                    break;
            }
        }
    };
    */

    private Runnable updateSeekBarTimeRunnable = new Runnable()
    {
        public void run()
        {
            //get current position
            if(mPlayerStarted == true)
            {
                float totalDuration = mMediaPlayer.getDuration();
                long timeElapsed = mMediaPlayer.getCurrentPosition();

                int newPos = (int)(timeElapsed * 100 / totalDuration);

                //set seekbar progress using time played
                mMediaSeekBar.setProgress((int) newPos);

                //set time remaining in minutes and seconds
                //timeRemaining = finalTime - timeElapsed;
                //duration.setText(String.format("%d min, %d sec", TimeUnit.MILLISECONDS.toMinutes((long) timeRemaining), TimeUnit.MILLISECONDS.toSeconds((long) timeRemaining) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) timeRemaining))));

                //holding time for 100 miliseconds
                //if(mMediaScalableLayout.getVisibility() == View.VISIBLE)
                if(mContollerMode == CONTOLLER_MODE_MEDIA)
                {
                    mPlayerSeekBarHandler.postDelayed(this, 100);
                }
            }
        }
    };

    Runnable mControlPanelDisplayRunnable = new Runnable()
    {
        @Override
        public void run()
        {
            if(mIsGoogleMapMode == false)
            {
                long currentTime = System.currentTimeMillis();
                if(mLastContolPanelVisibleEventTime + 5000 < currentTime)
                {
                    //mPlayerControlPanelLayout.setVisibility(View.GONE);
                    hideControlPanel();

                    mIsControlPanelVisible = false;
                }
                else
                {
                    //mDisplayHandler = new Handler();
                    mDisplayHandler.postDelayed(this, 1000);
                }
            }
        }
    };

    private void showControlPanel()
    {
        mPlayerControlPanelLayout.animate()
                .translationY(0)
                .alpha(1.0f)
                .setListener(new AnimatorListenerAdapter()
                {
                    @Override
                    public void onAnimationEnd(Animator animation)
                    {
                        super.onAnimationEnd(animation);
                        mPlayerControlPanelLayout.setVisibility(View.VISIBLE);

                        mIsControlPanelVisible = true;
                    }
                });
    }

    private void hideControlPanel()
    {
        mPlayerControlPanelLayout.animate()
                .translationY(mPlayerControlPanelLayout.getY())
                .alpha(0.0f)
                .setListener(new AnimatorListenerAdapter()
                {
                    @Override
                    public void onAnimationEnd(Animator animation)
                    {
                        super.onAnimationEnd(animation);
                        mPlayerControlPanelLayout.setVisibility(View.GONE);

                        mIsControlPanelVisible = false;
                    }
                });
    }

    //Video Player
    @Override
    public void start() {

    }

    @Override
    public void pause() {

    }

    @Override
    public int getDuration() {
        return 0;
    }

    @Override
    public int getCurrentPosition() {
        return 0;
    }

    @Override
    public void seekTo(int pos) {

    }

    @Override
    public boolean isPlaying() {
        return false;
    }

    @Override
    public int getBufferPercentage() {
        return 0;
    }

    @Override
    public boolean canPause() {
        return false;
    }

    @Override
    public boolean canSeekBackward() {
        return false;
    }

    @Override
    public boolean canSeekForward() {
        return false;
    }

    @Override
    public int getAudioSessionId() {
        return 0;
    }


    @Override
    public void surfaceCreated(SurfaceHolder holder)
    {

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
    {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder)
    {

    }

    private void createLocation()
    {
        //initialize LocationEequest accuract/freq
        mLocationRequest =  new LocationRequest();
        mLocationRequest.setInterval(15 *1000);
        mLocationRequest.setFastestInterval(1*1000);
        //mLocationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        //mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        //mLocationRequest.setPriority(LocationRequest.PRIORITY_LOW_POWER);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(new GoogleApiClient.ConnectionCallbacks()
                {
                    @Override
                    public void onConnected(@Nullable Bundle bundle)
                    {
                        requestLocationUpdates();
                    }

                    @Override
                    public void onConnectionSuspended(int i)
                    {

                    }
                })
                .addOnConnectionFailedListener(new GoogleApiClient.OnConnectionFailedListener()
                {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult)
                    {

                    }
                })
                .build();

        mGoogleApiClient.connect();
    }


    public void requestLocationUpdates()
    {
        if ( Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission( PlayerActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission( PlayerActivity.this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            return  ;
        }

        Location location = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        //if (location == null)
        {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, new LocationListener()
            {
                @Override
                public void onLocationChanged(Location location)
                {
                    mLocation = location;

                    if (mLocation != null)
                    {
                        double lat = mLocation.getLatitude();
                        double lng = mLocation.getLongitude();

                        mGeneralApplication = (generalApplication)getApplicationContext();
                        if(mGeneralApplication == null)
                        {
                            //앱이 종료되어 있음 <--- 이상하게 일로 들어오지 못함
                        }
                        else
                        {
                            if (isPlayerActivityResumed == true)
                            {
                                Message msg = playerHandler.obtainMessage();
                                Bundle b = new Bundle();
                                b.putString(HANDLER_HEADER, "my_new_location");
                                msg.setData(b);
                                playerHandler.sendMessage(msg);
                            }
                            else
                            {
                                if (isPlayerActivityDestroyed == false)
                                {
                                    //앱이 화면에 떠있다.
                                    Message msg = playerHandler.obtainMessage();
                                    Bundle b = new Bundle();
                                    b.putString(HANDLER_HEADER, "my_new_location");
                                    msg.setData(b);
                                    playerHandler.sendMessage(msg);
                                }
                                else
                                {
                                    //player dialog closed
                                    //should not send loc info
                                }
                            }
                        }

                        if(mIsDetectionEventEnabled == true)
                        {
                            double tmpDistance = getDistance(lat, lng, mLatitudeForDetection, mLongitudeForDetection);
                            //double maxLatLngForOneMeter = 0.000014274;
                            //double maxLatLngForOneMeter = 0.00000014274;
                            //double maxMetersForDistance = tmpDistance/maxLatLngForOneMeter;
                            double R = 6371e3;
                            double var1 = Math.toRadians(lat);
                            double var2 = Math.toRadians(mLatitudeForDetection);
                            double lat_diff = Math.toRadians(mLatitudeForDetection - lat);
                            double lng_diff = Math.toRadians(mLongitudeForDetection - lng);

                            double var_a = Math.sin(lat_diff/2) * Math.sin(lat_diff/2) + Math.cos(var1) * Math.cos(var2) * Math.sin(lng_diff/2) * Math.sin(lng_diff/2);
                            double var_c = 2*Math.atan2(Math.sqrt(var_a), Math.sqrt(1-var_a));
                            double var_d = R*var_c;

                            if(var_d < mDistanceForDetection)
                            {
                                if(mGeneralApplication == null)
                                {
                                    //앱이 종료되어 있음
                                    mIsDetectionEventEnabled = false;

                                    return;
                                }
                                else
                                {
                                    if(isPlayerActivityResumed == true)
                                    {
                                        Message msg = playerHandler.obtainMessage();
                                        Bundle b = new Bundle();
                                        b.putString(HANDLER_HEADER, "location_detection");
                                        msg.setData(b);
                                        playerHandler.sendMessage(msg);
                                    }
                                    else
                                    {
                                        if(isPlayerActivityDestroyed == false)
                                        {
                                            /*
                                            Intent intent = new Intent(mGeneralApplication, PlayerActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_PREVIOUS_IS_TOP);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                            startActivity(intent);
                                            */
                                            Intent i = new Intent(mGeneralApplication, PlayerActivity.class);
                                            i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                            //i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                            startActivity(i);

                                            resetDetectionLocation();

                                            Message msg = playerHandler.obtainMessage();
                                            Bundle b = new Bundle();
                                            b.putString(HANDLER_HEADER, "location_detection");
                                            msg.setData(b);
                                            playerHandler.sendMessage(msg);

                                        }
                                        else
                                        {
                                            //앱이 다른창에 가있다.
                                            mIsDetectionEventEnabled = false;
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            });
        }
    }

    private void destroyLocation()
    {
        if (mGoogleApiClient.isConnected())
        {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, new LocationListener()
            {
                @Override
                public void onLocationChanged(Location location)
                {

                }
            });
            mGoogleApiClient.disconnect();
        }
    }

    private double getDistance(double lat1, double lon1, double lat2, double lon2)
    {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        return (dist);
    }

    private double deg2rad(double deg)
    {
        return (deg * Math.PI / 180.0);
    }
    private double rad2deg(double rad)
    {
        return (rad * 180.0 / Math.PI);
    }

    public static void resetDetectionLocation()
    {
        mLatitudeForDetection = 0;
        mLongitudeForDetection = 0;
        mDistanceForDetection = 0;

        mIsDetectionEventEnabled = false;
    }

    public static void addDetectionLocation(double lat, double lng, int distance, String title)
    {
        mLatitudeForDetection = lat;
        mLongitudeForDetection = lng;
        mDistanceForDetection = distance;

        mIsDetectionEventEnabled = true;
    }
}

