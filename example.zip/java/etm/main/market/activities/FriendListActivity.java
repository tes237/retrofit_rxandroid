package etm.main.market.activities;

import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.baseDefine;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.CustomItemDecoration;
import etm.main.market.lists.FriendListAdapter;
import etm.main.market.lists.FriendListListener;
import etm.main.market.vo.Friend;
import etm.main.market.vo.FriendItem;
import etm.main.market.vo.Friends;
import etm.main.market.vo.ResponseFriendsData;
import etm.main.market.widgets.swipyLayout.SwipyRefreshLayout;
import etm.main.market.widgets.swipyLayout.SwipyRefreshLayoutDirection;

import etm.main.market.R;

public class FriendListActivity extends BaseActivity implements baseDefine, FriendListListener, View.OnClickListener
{
    private static final String TAG = FriendListActivity.class.getSimpleName();
    public static final String FRIEND_NAME = "friend_name";
    public static final String SERVER_TIME = "server_time";
    public static final String FRIEND_ID = "friend_id";

    RecyclerView mMessageListRecyclerView;
    LinearLayoutManager mLayoutManager;
    FriendListAdapter mFriendListAdapter;
    SwipyRefreshLayout mSwipyRefreshLayout;
    ImageButton mBackButton;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private DBAdapter mDBAdapter;

    private List<FriendItem> mDataList;

    private CompositeDisposable disposables = new CompositeDisposable();

    private long mTimerCount = 0;
    private boolean isInPauseState = false;

    LinkedHashMap<String, FriendsTime> mFriendsUpdateTime = new LinkedHashMap<String, FriendsTime>();

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_list);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        mSwipyRefreshLayout = (SwipyRefreshLayout)findViewById(R.id.message_list_swipy_layout);

        mMessageListRecyclerView = (RecyclerView)findViewById(R.id.message_list_recycler_view);

        mMessageListRecyclerView.addItemDecoration(new CustomItemDecoration(getResources().getDrawable(R.drawable.abc_list_divider_mtrl_alpha)));

        mMessageListRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mMessageListRecyclerView.setLayoutManager(mLayoutManager);
        mMessageListRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mBackButton = (ImageButton)findViewById(R.id.message_list_activity_back_button);
        mBackButton.setOnClickListener(this);


        mDataList = new ArrayList<FriendItem>();
        mFriendListAdapter = new FriendListAdapter(FriendListActivity.this, mDataList, this, mWeb);
        mMessageListRecyclerView.setAdapter(mFriendListAdapter);

        /*
        mSwipyRefreshLayout.setDirection(SwipyRefreshLayoutDirection.BOTH);

        mSwipyRefreshLayout.setOnRefreshListener(new SwipyRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(SwipyRefreshLayoutDirection direction)
            {
                refreshItems();
            }
        });
        */

        mFriendsListMainHandler.postDelayed(mGetMessageRunnable, 10000);

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        get_friends();
    }

    private void get_friends()
    {
        mWeb.getFriends(
                new Consumer<ResponseFriendsData>()
                {
                    @Override
                    public void accept(ResponseFriendsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Friends serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mDataList.clear();

                            for(int x = 0; x < serverData.getFriends().size(); x++)
                            {
                                Friend tmpData = serverData.getFriends().get(x);

                                long from_id = tmpData.getFrom_id();
                                long to_id = tmpData.getTo_id();
                                String from_name = tmpData.getFrom_name();
                                String to_name = tmpData.getTo_name();
                                String last_msg_date = tmpData.getLast_msg_date();
                                long is_blocked = tmpData.getIs_blocked();
                                long is_deleted = tmpData.getIs_deleted();

                                String tmpFriendPhotoUrl = tmpData.getFriendPhotoUrl();
                                if(tmpFriendPhotoUrl != null)
                                {
                                    tmpFriendPhotoUrl = URLDecoder.decode(tmpFriendPhotoUrl, "utf-8");
                                }

                                String tmpUserNumStr = mGeneralApplication.getNumString();
                                long tmpUserNum = Long.valueOf(tmpUserNumStr);

                                //printAllFriends();

                                mDBAdapter.putOneServerFriend(from_id, to_id, from_name, to_name, last_msg_date, is_blocked, is_deleted);

                                Cursor localCursor = mDBAdapter.getOneFriend(from_id, to_id);

                                String local_time = "0";
                                //long server_time = 0;
                                if(localCursor.moveToFirst())
                                {
                                    for (int i = 0; i < localCursor.getCount(); i++)
                                    {
                                        local_time = localCursor.getString(localCursor.getColumnIndex(DBAdapter.LOCAL_TIME));
                                        //server_time = localCursor.getLong(localCursor.getColumnIndex(DBAdapter.SERVER_TIME));

                                        if(local_time == null)
                                        {
                                            local_time = "0";
                                        }
                                        /*
                                        if(server_time > local_time)
                                        {
                                            itHaveNewMessage = true;
                                        }
                                        */
                                        break;
                                    }
                                }
                                else
                                {
                                    //itHaveNewMessage = true;
                                    //printAllFriends();
                                }

                                if(tmpUserNum == from_id)
                                {
                                    //send time
                                    FriendsTime tmpTime = mFriendsUpdateTime.get(String.valueOf(to_id));
                                    if(tmpTime != null)
                                    {
                                        tmpTime.mServerSendTime = last_msg_date;
                                        tmpTime.mLocalSendTime = local_time;
                                        tmpTime.mUserName = to_name;
                                        tmpTime.mUserId = String.valueOf(to_id);
                                        tmpTime.mFriendPhotoUrl = tmpFriendPhotoUrl;
                                        mFriendsUpdateTime.put(String.valueOf(to_id), tmpTime);
                                    }
                                    else
                                    {
                                        //public FriendsTime(long local_send_time, long server_send_time, long local_receive_time, long server_receive_time)
                                        FriendsTime newTime = new FriendsTime();
                                        newTime.mServerSendTime = last_msg_date;
                                        newTime.mLocalSendTime = local_time;
                                        newTime.mUserName = to_name;
                                        newTime.mUserId = String.valueOf(to_id);
                                        newTime.mFriendPhotoUrl = tmpFriendPhotoUrl;
                                        mFriendsUpdateTime.put(String.valueOf(to_id), newTime);
                                    }
                                }
                                else if(tmpUserNum == to_id)
                                {
                                    //receive time
                                    FriendsTime tmpTime = mFriendsUpdateTime.get(String.valueOf(from_id));
                                    if(tmpTime != null)
                                    {
                                        tmpTime.mServerReceiveTime = last_msg_date;
                                        tmpTime.mLocalReceiveTime = local_time;
                                        tmpTime.mUserName = from_name;
                                        tmpTime.mUserId = String.valueOf(from_id);
                                        tmpTime.mFriendPhotoUrl = tmpFriendPhotoUrl;
                                        mFriendsUpdateTime.put(String.valueOf(from_id), tmpTime);
                                    }
                                    else
                                    {
                                        //public FriendsTime(long local_send_time, long server_send_time, long local_receive_time, long server_receive_time)
                                        FriendsTime newTime = new FriendsTime();
                                        newTime.mServerReceiveTime = last_msg_date;
                                        newTime.mLocalReceiveTime = local_time;
                                        newTime.mUserName = from_name;
                                        newTime.mUserId = String.valueOf(from_id);
                                        newTime.mFriendPhotoUrl = tmpFriendPhotoUrl;
                                        mFriendsUpdateTime.put(String.valueOf(from_id), newTime);
                                    }
                                }
                            }

                            Iterator it = mFriendsUpdateTime.entrySet().iterator();
                            while (it.hasNext())
                            {
                                Map.Entry pair = (Map.Entry)it.next();

                                FriendsTime tmpTime = (FriendsTime)pair.getValue();

                                boolean itHasNewReceiveMessage = false;
                                boolean itHasNewSendMessage = false;
                                boolean itNeedNewAlarm = false;

                                if (Double.valueOf(tmpTime.mServerReceiveTime) > Double.valueOf(tmpTime.mLocalReceiveTime))
                                {
                                    itHasNewReceiveMessage = true;
                                    itNeedNewAlarm = true;
                                }

                                if (Double.valueOf(tmpTime.mServerSendTime) > Double.valueOf(tmpTime.mLocalSendTime))
                                {
                                    itHasNewSendMessage = true;
                                }

                                /*
                                if (Double.valueOf(tmpTime.mServerSendTime) < Double.valueOf(tmpTime.mServerReceiveTime))
                                {
                                    itNeedNewAlarm = true;
                                }
                                */

                                mDataList.add(new FriendItem(tmpTime.mUserName, tmpTime.mUserId, tmpTime.mFriendPhotoUrl, tmpTime.mServerReceiveTime, tmpTime.mLocalReceiveTime, itHasNewReceiveMessage, itHasNewSendMessage, itNeedNewAlarm));
                            }

                            Message msg = mFriendsListMainHandler.obtainMessage();
                            Bundle b = new Bundle();
                            b.putString("type", "refresh_all");
                            msg.setData(b);
                            mFriendsListMainHandler.sendMessage(msg);
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    get_friends();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            get_friends();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    get_friends();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            get_friends();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        FriendItem tmpItem = mDataList.get(index);
        String serverReceiveTimeStr = tmpItem.getServerReceiveTime();
        String friendIdStr = tmpItem.getUserId();
        tmpItem.setItNeedNewAlarm(false);

        Intent i = new Intent(FriendListActivity.this, MessageActivity.class);

        i.putExtra(FRIEND_NAME, tmpItem.getUserName());
        //i.putExtra(SERVER_TIME, serverReceiveTimeStr);
        i.putExtra(FRIEND_ID, friendIdStr);
        startActivity(i);

        Message msg = mFriendsListMainHandler.obtainMessage();
        Bundle b = new Bundle();
        b.putString("type", "refresh_all");
        msg.setData(b);
        mFriendsListMainHandler.sendMessage(msg);
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.message_list_activity_back_button)
        {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }

    @Override
    public void onDestroy()
    {
        mFriendsListMainHandler.removeCallbacks(mGetMessageRunnable);

        disposables.dispose();

        mDBAdapter.close();

        super.onDestroy();
    }

    @Override
    public void onResume()
    {
        //get_friends();

        isInPauseState = false;

        super.onResume();
    }

    @Override
    public void onPause()
    {
        isInPauseState = true;

        super.onPause();
    }

    private void printAllFriends()
    {
        /*
        Cursor localCursor = mDBAdapter.fetchAllVersions();
        if(localCursor.moveToFirst())
        {
            for (int i = 0; i < localCursor.getCount(); i++)
            {
                String tmp_sku_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FIELD_SKU));
                String tmp_version_index_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.VERSION_INDEX));
                String tmp_updated_date_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.UPDATED_DATE));

                Log.d(TAG, String.format("sku = %s, version index = %s. updated date = %s", tmp_sku_str, tmp_version_index_str, tmp_updated_date_str));
                localCursor.moveToNext();
            }
        }
        */
    }

    public class FriendsTime
    {
        public String mLocalSendTime = "0";
        public String mServerSendTime = "0";
        public String mLocalReceiveTime = "0";
        public String mServerReceiveTime = "0";

        public String mUserName = "";
        public String mUserId = "";
        public String mFriendPhotoUrl = "";


        public FriendsTime()
        {
            /*
            mLocalSendTime = "0";
            mServerSendTime = "0";
            mLocalReceiveTime = "0";
            mServerReceiveTime = "0";
            mUserName = "";
            */
        }
    }

    final Runnable mGetMessageRunnable = new Runnable()
    {
        @Override
        public void run()
        {
            Log.d(TAG, "timer schedule");

            mTimerCount++;

            if(mTimerCount %3 == 0)
            {
                if(isInPauseState == false)
                {
                    get_friends();
                }
            }

            mFriendsListMainHandler.postDelayed(mGetMessageRunnable, 10000);

        }
    };


    final Handler mFriendsListMainHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

            String type_str = msg.getData().getString("type");
            int targetIndex;
            int targetPercent;
            int targetStatus;

            switch (type_str)
            {
                case "refresh_all":
                    mFriendListAdapter.notifyDataSetChanged();
                    break;

                default:
                    break;
            }
        }
    };


}
