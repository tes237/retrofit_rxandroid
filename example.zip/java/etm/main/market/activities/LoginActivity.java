package etm.main.market.activities;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;

import com.facebook.AccessToken;
import com.facebook.FacebookSdk;
import com.facebook.GraphResponse;
import com.google.android.gms.plus.model.people.Person;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.LocalFirebaseMessagingService;
import etm.main.market.baseDefine;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.FilterButtonListener;
import etm.main.market.dialog.FilterDialog;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.dialog.GeneralProgressDialog;
import etm.main.market.generalApplication;
import etm.main.market.social.FacebookHelper;
import etm.main.market.social.GooglePlusHelper;
import etm.main.market.vo.CustomerInfo;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.ResponseLoginData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponseRegisterData;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, baseDefine,  FacebookHelper.OnFbSignInListener, GooglePlusHelper.OnGoogleSignInListener
{
    private static final String TAG = LoginActivity.class.getSimpleName();

    public static final int LOGIN_REGISTER = 101;
    //public static final int LOGIN_HOME = 102;
    public static final int LOGIN_RESET_PASSWORD = 102;

    public static final String LOGIN_TYPE_TGM = "0";
    public static final String LOGIN_TYPE_FB = "1";
    public static final String LOGIN_TYPE_GG = "2";

    public static final String AUTO_LOGIN_TRUE = "1";
    public static final String AUTO_LOGIN_FALSE = "0";

    private ScalableLayout mLoginSelectChoiceAct;
    private ScalableLayout mLoginAct;
    private ScalableLayout mRegisterAct;

    private Button mLoginActButton;
    private Button mRegisterActButton;

    private Button mLoginButton;
    private Button mFindIdPasswdButton;
    private Button mRegisterButton;

    private EditText mLoginIdEdit;
    private EditText mLoginPasswdEdit;

    private EditText mFirstNameEdit;
    private EditText mLastNameEdit;
    private EditText mRegisterEmailEdit;
    private EditText mRegisterPasswdEdit;
    private EditText mRegisterPasswdConfirmEdit;

    private CheckBox mKeepLogin;

    private Button mFacebookButton;

    private FacebookHelper fbConnectHelper;
    private GooglePlusHelper gSignInHelper;

    private GeneralAlarmDialog mGeneralAlarmDialog;

    private boolean isFbLogin = false;
    private boolean isKeepLogin = false;

    protected generalApplication mGeneralApplication = null;

    private DBAdapter mDBAdapter;

    private WebManager mWeb;
    private GeneralProgressDialog pd;

    private boolean mIsLoginSuccessful = false;

    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        pd = new GeneralProgressDialog(this, R.drawable.spinner);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        mLoginSelectChoiceAct = (ScalableLayout)findViewById(R.id.tgmarket_login_select_act);
        mLoginAct = (ScalableLayout)findViewById(R.id.tgmarket_login_act);
        mRegisterAct = (ScalableLayout)findViewById(R.id.tgmarket_register_act);

        mLoginSelectChoiceAct.setVisibility(View.VISIBLE);
        mLoginAct.setVisibility(View.GONE);
        mRegisterAct.setVisibility(View.GONE);

        mLoginActButton = (Button)findViewById(R.id.login_choice_button);
        mRegisterActButton = (Button)findViewById(R.id.signup_choice_button);

        mLoginButton = (Button)findViewById(R.id.login_submit_button);
        mFindIdPasswdButton = (Button) findViewById(R.id.login_find_id_passwd_text);
        mRegisterButton = (Button) findViewById(R.id.register_submit_button);

        //sign in
        mLoginIdEdit = (EditText)findViewById(R.id.login_id_edit);
        mLoginPasswdEdit = (EditText)findViewById(R.id.login_passwd_edit);

        //sign up
        mFirstNameEdit = (EditText)findViewById(R.id.register_first_name_edit);
        mLastNameEdit = (EditText)findViewById(R.id.register_last_name_edit);
        mRegisterEmailEdit = (EditText)findViewById(R.id.register_email_edit);
        mRegisterPasswdEdit = (EditText)findViewById(R.id.register_password_edit);
        mRegisterPasswdConfirmEdit = (EditText)findViewById(R.id.register_password_confirm_edit);

        mKeepLogin = (CheckBox)findViewById(R.id.keep_login);

        mLoginIdEdit.setHintTextColor(0xff707070);
        mLoginPasswdEdit.setHintTextColor(0xff707070);

        mFirstNameEdit.setHintTextColor(0xff707070);
        mLastNameEdit.setHintTextColor(0xff707070);
        mRegisterEmailEdit.setHintTextColor(0xff707070);
        mRegisterPasswdEdit.setHintTextColor(0xff707070);
        mRegisterPasswdConfirmEdit.setHintTextColor(0xff707070);

        //mGoogleplusButton = (Button) findViewById(R.id.googleplus_login_button);
        mFacebookButton = (Button) findViewById(R.id.facebook_login_button);

        mLoginActButton.setOnClickListener(this);
        mRegisterActButton.setOnClickListener(this);
        mLoginButton.setOnClickListener(this);
        mFindIdPasswdButton.setOnClickListener(this);
        mRegisterButton.setOnClickListener(this);
        //mGoogleplusButton.setOnClickListener(this);
        mFacebookButton.setOnClickListener(this);

        mLoginIdEdit.setText("techsync@naver.com");
        mLoginPasswdEdit.setText("tmzkffk0");

        //mTwitterHelper = new TwitterHelper(this, this); // Twitter Initialization
        FacebookSdk.sdkInitialize(getApplicationContext()); // Facebook SDK Initialization

        //--------------------------------Facebook login--------------------------------------//
        //generateKey(this);
        fbConnectHelper = new FacebookHelper(this, this);

        //----------------------------------Google +Sign in-----------------------------------//
        gSignInHelper = new GooglePlusHelper(this, this);

        LoadKeepLoginFromDB();

        mKeepLogin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                isKeepLogin = isChecked;

                if(isKeepLogin == false)
                {
                    mLoginIdEdit.setText("");
                    mLoginPasswdEdit.setText("");

                    showGeneralPopup(getString(R.string.auto_login_cancelled), "");
                    return;
                }
                else
                {
                    showGeneralPopup(getString(R.string.auto_login_setted_up), "");
                }
            }
        });
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.login_choice_button)
        {
            mLoginSelectChoiceAct.setVisibility(View.GONE);
            mLoginAct.setVisibility(View.VISIBLE);
            mRegisterAct.setVisibility(View.GONE);
        }
        else if(v.getId() == R.id.signup_choice_button)
        {
            mLoginSelectChoiceAct.setVisibility(View.GONE);
            mLoginAct.setVisibility(View.GONE);
            mRegisterAct.setVisibility(View.VISIBLE);
        }
        else if(v.getId() == R.id.login_submit_button)
        {
            final String tmpIdStr = mLoginIdEdit.getText().toString();
            final String tmpPasswdStr = mLoginPasswdEdit.getText().toString();
            final String refreshedToken = FirebaseInstanceId.getInstance().getToken();

            if("".equals(tmpIdStr) == true)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled));
                return;
            }
            if("".equals(tmpPasswdStr) == true)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled));
                return;
            }

            if(isEmailValid(tmpIdStr) == false)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.please_fill_valid_email_id));
                return;
            }

            pd.show();
            mWeb.login(tmpIdStr, tmpPasswdStr, DEV_AND, refreshedToken,
                new Consumer<ResponseLoginData>()
                {
                    @Override
                    public void accept(ResponseLoginData loginDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = loginDatas.getResult();
                        CustomerInfo serverData = loginDatas.getData();

                        pd.dismiss();
                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mWeb.setCookieState(false);
                            mGeneralApplication.setIdString(tmpIdStr);
                            mGeneralApplication.setNumString(serverData.getCustomer_id());

                            if( "1".equals(serverData.getTerms_agree()) )
                            {
                                mGeneralApplication.setIsTermsAgreed(true);
                            }
                            else
                            {
                                mGeneralApplication.setIsTermsAgreed(false);
                            }

                            if( "1".equals(serverData.getPrivacy_agree()) )
                            {
                                mGeneralApplication.setIsPrivacyAgreed(true);
                            }
                            else
                            {
                                mGeneralApplication.setIsPrivacyAgreed(false);
                            }

                            if(isKeepLogin == true)
                            {
                                DeleteKeepLogin();
                                SetAutoLoginOfTGM(AUTO_LOGIN_TRUE);
                                SaveKeepLoginToDB(tmpIdStr, tmpPasswdStr);
                            }
                            else
                            {
                                DeleteKeepLogin();
                                SetAutoLoginOfTGM(AUTO_LOGIN_FALSE);
                            }

                            mGeneralApplication.setLoggedIn(true);

                            LocalFirebaseMessagingService.setMyId(serverData.getCustomer_id());

                            //Intent i = new Intent(LoginActivity.this, HomeActivity.class);
                            //startActivity(i);
                            mIsLoginSuccessful = true;
                            setResult(LOGIN_RESULT_SUCCESS);
                            finish();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(loginDatas.getResultCode()));
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        pd.dismiss();
                        mWeb.setCookieState(false);
                    }
                }, disposables
            );
        }
        else if(v.getId() == R.id.register_submit_button)
        {
            final String tmpFirstNameStr = mFirstNameEdit.getText().toString();
            final String tmpLastNameStr = mLastNameEdit.getText().toString();
            final String tmpEmailStr = mRegisterEmailEdit.getText().toString();
            final String tmpPasswdStr = mRegisterPasswdEdit.getText().toString();
            final String tmpPasswdConfirmStr = mRegisterPasswdConfirmEdit.getText().toString();


            if("".equals(tmpFirstNameStr) == true)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled));
                return;
            }
            if("".equals(tmpLastNameStr) == true)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled));
                return;
            }
            if("".equals(tmpEmailStr) == true)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled));
                return;
            }
            if("".equals(tmpPasswdStr) == true)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled));
                return;
            }
            if("".equals(tmpPasswdConfirmStr) == true)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled));
                return;
            }

            if(isEmailValid(tmpEmailStr) == false)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.please_fill_valid_email_id));
                return;
            }

            if(tmpPasswdStr.equals(tmpPasswdConfirmStr) == false)
            {
                showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.passwords_are_not_same));
                return;
            }

            if(tmpPasswdStr.length() < 8 )
            {
                showGeneralPopup(getString(R.string.error_title), getString(R.string.password_length_should_be_at_least_8));
                return;
            }

            if(isValidPassword(tmpPasswdStr) == false)
            {
                showGeneralPopup(getString(R.string.error_title), getString(R.string.password_should_contain_alphabet_digit_special_characters));
                return;
            }
            final String refreshedToken = FirebaseInstanceId.getInstance().getToken();

            mWeb.register(tmpFirstNameStr, tmpLastNameStr, tmpEmailStr, tmpPasswdStr, DEV_AND, refreshedToken,
                    new Consumer<ResponseRegisterData>()
                    {
                        @Override
                        public void accept(ResponseRegisterData registerDatas) throws Exception
                        {
                            // TODO: Handle response.
                            String serverResult = registerDatas.getResult();
                            String serverData = registerDatas.getData();

                            if(serverResult.equals(JSON_SUCCESS))
                            {
                                mGeneralApplication.setIdString(tmpEmailStr);
                                mGeneralApplication.setNumString(serverData);

                                FragmentManager fm = getFragmentManager();
                                if(mGeneralAlarmDialog != null)
                                {
                                    mGeneralAlarmDialog.dismiss();
                                    mGeneralAlarmDialog = null;
                                }
                                mGeneralAlarmDialog = new GeneralAlarmDialog();
                                mGeneralAlarmDialog.setTitleText(getString(R.string.register_popup_title));
                                mGeneralAlarmDialog.setMessageText(getString(R.string.register_popup_message));
                                mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
                                mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
                                {
                                    @Override
                                    public void onButtonClickListener(View v, int id, int button)
                                    {
                                        mLoginSelectChoiceAct.setVisibility(View.GONE);
                                        mLoginAct.setVisibility(View.VISIBLE);
                                        mRegisterAct.setVisibility(View.GONE);

                                        mLoginIdEdit.setText("");
                                        mLoginPasswdEdit.setText("");
                                    }
                                });
                                mGeneralAlarmDialog.show(fm, "tag");
                            }
                            else if(serverResult.equals(JSON_FAIL))
                            {
                                showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(registerDatas.getResultCode()));
                            }
                        }
                    }
                    ,new Consumer<Throwable>()
                    {
                        @Override
                        public void accept(@NonNull Throwable throwable) throws Exception
                        {
                            // TODO: Handle error.

                        }
                    }, disposables
            );

        }
        else if(v.getId() == R.id.login_find_id_passwd_text)
        {
            Intent i = new Intent(LoginActivity.this, ResetPasswordActivity.class);
            startActivityForResult(i, LOGIN_RESET_PASSWORD);
        }
        /*
        else if(v.getId() == R.id.googleplus_login_button)
        {
            gSignInHelper.connect();
            isFbLogin = true;
        }
        */
        else if(v.getId() == R.id.facebook_login_button)
        {
            fbConnectHelper.connect();
            isFbLogin = true;
        }
    }

    @Override
    protected void onDestroy()
    {
        //recycleBitmap(mLoginLogo);
        disposables.dispose();

        mDBAdapter.close();

        if(mIsLoginSuccessful == false)
        {
            setResult(LOGIN_RESULT_CANCEL);
        }

        super.onDestroy();
    }

    private static void recycleBitmap(ImageView iv)
    {
        Drawable d = iv.getDrawable();
        if (d instanceof BitmapDrawable)
        {
            Bitmap b = ((BitmapDrawable)d).getBitmap();
            b.recycle();
        } // 현재로서는 BitmapDrawable 이외의 drawable 들에 대한 직접적인 메모리 해제는 불가능하다.

        d.setCallback(null);
    }

    public static boolean isValidPassword(String pswd)
    {
        //String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,16})";
        String PASSWORD_PATTERN = "(?=.*\\d)(?=.*[$@$!%*?&#^])([A-Za-z\\d$@$!%*?&#^]{8,})";
        Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
        Matcher matcher = pattern.matcher(pswd);
        return matcher.matches();
    }

    @Override
    public void OnFbSignInComplete(GraphResponse graphResponse, String error)
    {
        if (error == null)
        {
            try
            {
                SetAutoLoginOfFB(AUTO_LOGIN_TRUE);

                JSONObject jsonObject = graphResponse.getJSONObject();
                final String nameStr = jsonObject.getString("name");
                final String firstNameStr = jsonObject.getString("first_name");
                final String lastNameStr = jsonObject.getString("last_name");
                final String emailStr = jsonObject.getString("email");
                final String fb_id = jsonObject.getString("id");
                final String profileImg = "http://graph.facebook.com/" + fb_id + "/picture?type=large";

                AccessToken tmpAccessToken = AccessToken.getCurrentAccessToken();
                String tmpFBTokenStr = tmpAccessToken.getToken();

                final String refreshedToken = FirebaseInstanceId.getInstance().getToken();

                mWeb.facebook_login(tmpFBTokenStr, fb_id, firstNameStr, lastNameStr, emailStr, DEV_AND, refreshedToken,
                        new Consumer<ResponseLoginData>()
                        {
                            @Override
                            public void accept(ResponseLoginData loginDatas) throws Exception
                            {
                                // TODO: Handle response.
                                String serverResult = loginDatas.getResult();
                                CustomerInfo serverData = loginDatas.getData();

                                if(serverResult.equals(JSON_SUCCESS))
                                {
                                    mWeb.setCookieState(false);
                                    mGeneralApplication.setIdString(emailStr);
                                    mGeneralApplication.setNumString(serverData.getCustomer_id());

                                    if( "1".equals(serverData.getTerms_agree()) )
                                    {
                                        mGeneralApplication.setIsTermsAgreed(true);
                                    }
                                    else
                                    {
                                        mGeneralApplication.setIsTermsAgreed(false);
                                    }

                                    if( "1".equals(serverData.getPrivacy_agree()) )
                                    {
                                        mGeneralApplication.setIsPrivacyAgreed(true);
                                    }
                                    else
                                    {
                                        mGeneralApplication.setIsPrivacyAgreed(false);
                                    }


                                    LocalFirebaseMessagingService.setMyId(serverData.getCustomer_id());

                                    mGeneralApplication.setLoggedIn(true);
                                    mIsLoginSuccessful = true;
                                    setResult(LOGIN_RESULT_SUCCESS);
                                    finish();
                                }
                                else if(serverResult.equals(JSON_FAIL))
                                {
                                    showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(loginDatas.getResultCode()));
                                }
                            }
                        }
                        ,new Consumer<Throwable>()
                        {
                            @Override
                            public void accept(@NonNull Throwable throwable) throws Exception
                            {
                                // TODO: Handle error.
                                mWeb.setCookieState(false);
                            }
                        }, disposables
                );

            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void OnGSignInComplete(Person mPerson, String emailAddress, String error)
    {
        //progressBar.setVisibility(View.GONE);
        if (mPerson != null)
        {
            String displayName = mPerson.getDisplayName();
        }

        if (emailAddress != null)
        {
            String emailName = emailAddress;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (isFbLogin)
        {
            //progressBar.setVisibility(View.VISIBLE);
            gSignInHelper.onActivityResult(requestCode, resultCode, data);
            fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            //mTwitterHelper.onActivityResult(requestCode, resultCode, data);

            isFbLogin = false;
            return;
        }

        switch (requestCode)
        {
            case LOGIN_REGISTER:
                String returnIdValue = data.getStringExtra("id");
                String returnPassValue = data.getStringExtra("pass");

                mLoginIdEdit.setText(returnIdValue);
                mLoginPasswdEdit.setText(returnPassValue);

                break;

            case LOGIN_RESET_PASSWORD:
                break;

            default:
                break;
        }
    }

    private void LoadKeepLoginFromDB()
    {
        Cursor search_cursor = mDBAdapter.getAutoLoginCheck();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String id_var = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.ID_TEXT));
            if(id_var != null && "".equals(id_var) == false)
            {
                mKeepLogin.setChecked(true);
                isKeepLogin = true;
            }
            else
            {
                mKeepLogin.setChecked(false);
                isKeepLogin = false;
            }
        }
        else
        {
            mKeepLogin.setChecked(false);
            isKeepLogin = false;
        }
    }

    private void SaveKeepLoginToDB(String idStr, String passwdStr)
    {
        mDBAdapter.putLoginInfo(idStr, passwdStr);
    }

    private void SetAutoLoginOfTGM(String flag)
    {
        mDBAdapter.putLoginType(LOGIN_TYPE_TGM, flag);
    }

    private void SetAutoLoginOfFB(String flag)
    {
        mDBAdapter.putLoginType(LOGIN_TYPE_FB, flag);
    }

    private void DeleteKeepLogin()
    {
        mDBAdapter.deleLoginInfo();
        mDBAdapter.deleLoginInfo();
    }


    private void showGeneralPopup(String title, String message)
    {
        FragmentManager fm = getFragmentManager();
        if(mGeneralAlarmDialog != null)
        {
            mGeneralAlarmDialog.dismiss();
            mGeneralAlarmDialog = null;
        }
        mGeneralAlarmDialog = new GeneralAlarmDialog();
        mGeneralAlarmDialog.setTitleText(title);
        mGeneralAlarmDialog.setMessageText(message);
        mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
        {
            @Override
            public void onButtonClickListener(View v, int id, int button)
            {

            }
        });
        mGeneralAlarmDialog.show(fm, "tag");
        return;
    }

    private void LoginRequiredPopup()
    {
        FragmentManager fm = getFragmentManager();
        if(mGeneralAlarmDialog != null)
        {
            mGeneralAlarmDialog.dismiss();
            mGeneralAlarmDialog = null;
        }
        mGeneralAlarmDialog = new GeneralAlarmDialog();
        mGeneralAlarmDialog.setTitleText(getString(R.string.login_is_needed));
        mGeneralAlarmDialog.setMessageText(getString(R.string.lets_go_to_login_dialog));
        mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
        {
            @Override
            public void onButtonClickListener(View v, int id, int button)
            {
                if(button == GeneralAlarmDialog.CANCEL_BUTTON)
                {

                }
                else
                {
                    Intent login_intent = new Intent(LoginActivity.this, LoginActivity.class);
                    startActivity(login_intent);
                }
            }
        });
        mGeneralAlarmDialog.show(fm, "tag");
    }

    public final static boolean isEmailValid(CharSequence target)
    {
        if (target == null)
            return false;

        return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    @Override
    public void onBackPressed()
    {

    }
}
