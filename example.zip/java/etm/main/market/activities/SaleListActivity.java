package etm.main.market.activities;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.InfoAdapter;
import etm.main.market.lists.InfoListListener;
import etm.main.market.lists.PurchasedInfoAdapter;
import etm.main.market.lists.PurchasedInfoListListener;
import etm.main.market.lists.SaleInfoAdapter;
import etm.main.market.lists.SaleInfoListListener;
import etm.main.market.vo.FriendItem;
import etm.main.market.vo.MapFile;
import etm.main.market.vo.MapFiles;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.ResponseMapFilesData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponseSalesData;
import etm.main.market.vo.Sale;
import etm.main.market.vo.Sales;
import etm.main.market.widgets.swipyLayout.*;

import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

public class SaleListActivity extends BaseActivity implements baseDefine, SaleInfoListListener, View.OnClickListener
{
    private static final String TAG = SaleListActivity.class.getSimpleName();

    public static final String FRIEND_NAME = "friend_name";
    public static final String SERVER_TIME = "server_time";
    public static final String FRIEND_ID = "friend_id";

    private  String APP_DIRECTORY;
    public String mUserDir = "";

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private SaleInfoAdapter mSaleInfoAdapter;
    private SwipyRefreshLayout mSwipyRefreshLayout;
    private TextView mTextView;
    private ImageButton mBackButton;

    private GeneralAlarmDialog mGeneralAlarmDialog;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private DBAdapter mDBAdapter;

    private List<Sale> mSaleList;

    private int mCurrentPageIndex = 1;
    private int mTotalPageCount = 1;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_sale_list);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();

        String tmpUserIdStr = mGeneralApplication.getIdString();
        mUserDir = Base64.mod_encode(tmpUserIdStr);

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        mSwipyRefreshLayout = (SwipyRefreshLayout)findViewById(R.id.tourguide_swipy_layout);
        mRecyclerView = (RecyclerView)findViewById(R.id.tourguide_recycler_view);
        mTextView = (TextView)findViewById(R.id.list_activity_title_textview);
        mBackButton = (ImageButton)findViewById(R.id.list_activity_back_button);
        mBackButton.setOnClickListener(this);

        DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics();
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        int fontSize = width/43;

        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mSaleList = new ArrayList<Sale>();
        mSaleInfoAdapter = new SaleInfoAdapter(SaleListActivity.this, mSaleList, this, mWeb);
        mRecyclerView.setAdapter(mSaleInfoAdapter);

        mSwipyRefreshLayout.setDirection(SwipyRefreshLayoutDirection.BOTTOM);
        mSwipyRefreshLayout.setOnRefreshListener(new SwipyRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(SwipyRefreshLayoutDirection direction)
            {
                if(mTotalPageCount < mCurrentPageIndex + 1)
                {
                    mSwipyRefreshLayout.setRefreshing(false);
                    return;
                }

                mCurrentPageIndex++;

                getSaleItemsFunc(DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex));
                mSwipyRefreshLayout.setRefreshing(false);
            }
        });

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        mSaleList.clear();
        getSaleItemsFunc(DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex));
    }

    private void getSaleItemsFunc(String items_per_page, String page_index)
    {
        mWeb.getSaleItems(items_per_page, page_index,
                new Consumer<ResponseSalesData>()
                {
                    @Override
                    public void accept(ResponseSalesData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Sales serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            for(int x = 0; x < serverData.getSales().size(); x++)
                            {
                                Sale tmpData = serverData.getSales().get(x);
                                String dateStr = tmpData.getSale_date();
                                dateStr = new Date(Long.valueOf(dateStr)*1000).toLocaleString();

                                String titleStr = tmpData.getSale_title();
                                String customerStr = tmpData.getSale_customer();
                                String idStr = tmpData.getSale_customer_id();

                                String photoUrl = tmpData.getCustomerPhotoUrl();

                                mSaleList.add(new Sale(dateStr, titleStr, customerStr, idStr, photoUrl));
                            }
                            mSaleInfoAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getSaleItemsFunc(items_per_page, page_index);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getSaleItemsFunc(items_per_page, page_index);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getSaleItemsFunc(items_per_page, page_index);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getSaleItemsFunc(items_per_page, page_index);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        Sale tmpData = mSaleList.get(index);
        String customer_id_str = tmpData.getSale_customer_id();
        String myIdStr = mGeneralApplication.getNumString();

        if(myIdStr != null && myIdStr.equals(customer_id_str) == true)
        {
            FragmentManager fm = getFragmentManager();
            if(mGeneralAlarmDialog != null)
            {
                mGeneralAlarmDialog.dismiss();
                mGeneralAlarmDialog = null;
            }
            mGeneralAlarmDialog = new GeneralAlarmDialog();
            mGeneralAlarmDialog.setTitleText(getString(R.string.chatting_is_not_possible));
            mGeneralAlarmDialog.setMessageText(getString(R.string.chatting_is_only_possible_to_others));
            mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
            mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
            {
                @Override
                public void onButtonClickListener(View v, int id, int button)
                {

                }
            });
            mGeneralAlarmDialog.show(fm, "tag");
        }
        else
        {
            Intent i = new Intent(SaleListActivity.this, MessageActivity.class);
            i.putExtra(FRIEND_NAME, tmpData.getSale_customer());
            //i.putExtra(SERVER_TIME, 0);
            i.putExtra(FRIEND_ID, tmpData.getSale_customer_id());
            startActivity(i);
        }
    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.list_activity_back_button)
        {
            finish();
        }
    }

    public static String convertToUTF8(String inputStr)
    {
        String outStr = null;
        try
        {
            outStr = new String(inputStr.getBytes("UTF-8"), "ISO-8859-1");
        }
        catch (java.io.UnsupportedEncodingException e)
        {
            return null;
        }
        return outStr;
    }

    @Override
    public void onDestroy()
    {
        disposables.dispose();

        mDBAdapter.close();

        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }

}
