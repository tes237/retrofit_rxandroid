package etm.main.market.activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.LocalFirebaseMessagingService;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.IntegerWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.ChatAdapter;
import etm.main.market.lists.ChatDateButtonListener;
import etm.main.market.vo.ChatMessage;
import etm.main.market.vo.ChatMessageGroup;
import etm.main.market.vo.FriendMessage;
import etm.main.market.vo.FriendMessages;
import etm.main.market.vo.ResponseFriendMessagesData;
import etm.main.market.vo.ResponseSendReturnData;
import etm.main.market.vo.SendReturn;

public class MessageActivity extends BaseActivity implements baseDefine, View.OnClickListener, ChatDateButtonListener
{
    private static final String TAG = FriendListActivity.class.getSimpleName();

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private DBAdapter mDBAdapter;

    private ImageButton mBackButton;
    private ListView mMessagesContainer;
    private EditText mChatText;
    private TextView mReceiverText;
    private TextView mChatButton;
    private ImageView mProgressSpinnerView;
    private RotateAnimation mRotateAnim;

    private ChatAdapter adapter;
    private ArrayList<ChatMessage> chatHistory = new ArrayList<ChatMessage>();

    private ArrayList<ChatMessageGroup> chatGroupList = new ArrayList<ChatMessageGroup>();

    private String mFriendName;
    //private String mServerTime;
    private String mFriendId;

    private int mFirstChatYear = 0;
    private int mFirstChatMonth = 0;
    private int mFirstChatDate = 0;

    private int mCurrentMessageContainerPos = -1;
    private Parcelable listViewState;

    private boolean mIsBroadcastReceiverEnabled = false;
    public boolean isInitialized = false;
    private boolean mIsProgressStarted = false;

    private GetMessageThread mGetMessageThread;

    private CompositeDisposable disposables = new CompositeDisposable();
    private static Object syncObj = new Object();

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private GeneralAlarmDialog mGeneralAlarmDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mFriendName = bd.getString(FriendListActivity.FRIEND_NAME);
            //mServerTime = bd.getString(FriendListActivity.SERVER_TIME);
            mFriendId = bd.getString(FriendListActivity.FRIEND_ID);
        }

        mBackButton = (ImageButton)findViewById(R.id.message_activity_back_button);
        mBackButton.setOnClickListener(this);

        mMessagesContainer = (ListView) findViewById(R.id.messagesContainer);

        mReceiverText = (TextView) findViewById(R.id.message_activity_title_textview);
        mChatText = (EditText) findViewById(R.id.chat_text);

        mChatButton = (TextView) findViewById(R.id.send_button);
        mChatButton.setOnClickListener(this);

        mProgressSpinnerView = (ImageView) findViewById(R.id.progress_image);

        String APP_DIRECTORY = mGeneralApplication.getAppDirectory();

        String tmpUserIdStr = mGeneralApplication.getIdString();
        String tmpUserDir = Base64.mod_encode(tmpUserIdStr);

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        /*
        String iconPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + tmpUserDir + "/profile.jpg";
        File tmpCheck = new File(iconPathStr);
        if(tmpCheck.exists() == false)
        {
            iconPathStr = null;
        }
        if(tmpCheck.length() == 0)
        {
            iconPathStr = null;
        }
        */
        String iconPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + tmpUserDir + "/profile.jpg";
        if(mGeneralApplication.isProfileLoaded() == false)
        {
            iconPathStr = null;
        }

        adapter = new ChatAdapter(MessageActivity.this, chatHistory, iconPathStr, MessageActivity.this);
        mMessagesContainer.setAdapter(adapter);
        if(mFriendName != null)
        {
            mReceiverText.setText(mFriendName);
        }

        mGetMessageThread = new GetMessageThread();
        mGetMessageThread.start();

        mGetMessageThread.setReqflag(true);

        LocalFirebaseMessagingService.setMessageActivityDestroyed(false, mFriendId);

        if(mIsBroadcastReceiverEnabled == false)
        {
            // TODO Auto-generated method stub
            IntentFilter filter = new IntentFilter (GENERAL_APP_ID);
            filter.addAction(GENERAL_MESSAGE_ID);
            registerReceiver(mBroadcastReceiver, new IntentFilter(filter));
            mIsBroadcastReceiverEnabled = true;
        }
    }

    @Override
    public void onResume()
    {
        super.onResume();
        LocalFirebaseMessagingService.setMessageActivityResumed(true, mFriendId);

        mChatText.requestFocus();

        mChatText.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                // TODO Auto-generated method stub
                InputMethodManager keyboard = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                keyboard.showSoftInput(mChatText, 0);
            }
        },200); //use 300 to make it run when coming back from lock screen
    }

    @Override
    public void onPause()
    {
        LocalFirebaseMessagingService.setMessageActivityResumed(false, mFriendId);
        super.onPause();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }

    @Override
    public void onDestroy()
    {
        LocalFirebaseMessagingService.setMessageActivityDestroyed(true, mFriendId);

        stopProgress();
        //mFriendMessageMainHandler.removeCallbacks(mGetMessageRunnable);
        mGetMessageThread.setReqflag(false);
        mGetMessageThread.quit();

        disposables.dispose();

        mDBAdapter.close();

        super.onDestroy();
    }


    @Override
    public void finish()
    {
        if(mIsBroadcastReceiverEnabled == true)
        {
            unregisterReceiver(mBroadcastReceiver);
            mIsBroadcastReceiverEnabled = false;
        }
        super.finish();
    }


    private void get_messages()
    {
        final String my_id = mGeneralApplication.getNumString();
        final String friend_id = mFriendId;
        boolean isNewMessageArrived = false;

        Cursor firstCursor = null;
        try
        {
            firstCursor = mDBAdapter.getLastRequestTime(my_id, friend_id);
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }

        long milli_time = System.currentTimeMillis();
        long sec_time = milli_time/1000;
        final String micro_time_str = String.format("%d.000000", sec_time);

        String prev_last_time_req = "0000000000";
        if(firstCursor != null)
        {
            if(firstCursor.moveToFirst())
            {
                prev_last_time_req = firstCursor.getString(firstCursor.getColumnIndex(DBAdapter.LAST_TIME));
            }
        }
        firstCursor.close();

        final String startTime = prev_last_time_req;

        ResponseFriendMessagesData objDatas = mWeb.Blocking_getFriendMessages(friend_id, startTime);
        if(objDatas != null)
        {
            String serverResult = objDatas.getResult();
            FriendMessages serverData = objDatas.getData();

            if(serverResult.equals(JSON_SUCCESS))
            {
                //update msg recv time
                String sentTime = serverData.getSent_time_from_me();
                String recvTime = serverData.getRecv_time_from_friend();

                mDBAdapter.putOneLocalAndServerFriend(Long.valueOf(friend_id), Long.valueOf(my_id), recvTime);

                //insert latest server messages to sqlite db

                for(int x = 0; x < serverData.getMessages().size(); x++)
                {
                    FriendMessage tmpData = serverData.getMessages().get(x);
                    String messageFromId = tmpData.getMsgFromId();
                    String messageToId = tmpData.getMsgToId();
                    String messageStr = tmpData.getMsgBody();
                    String messageTimeStr = tmpData.getMsgTime();

                    int insertRet = mDBAdapter.putOneMessage(messageFromId, messageToId, messageStr, messageTimeStr);
                    if(insertRet == DBAdapter.NEW_MESSAGE_INSERTED)
                    {
                        isNewMessageArrived = true;
                        //Log.d(TAG, "############ new receive");
                    }
                }

                printAllMessages();

                if(chatGroupList.size() == 0)
                {
                    //add chat messages from the first time
                    //chatGroupList.clear();

                    Cursor localCursor = mDBAdapter.fetchAllMessages(my_id, friend_id);
                    if(localCursor.moveToFirst())
                    {
                        for (int i = 0; i < localCursor.getCount(); i++)
                        {
                            String tmp_from_id = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FROM_ID));
                            String tmp_to_id = localCursor.getString(localCursor.getColumnIndex(DBAdapter.TO_ID));
                            String tmp_msg = localCursor.getString(localCursor.getColumnIndex(DBAdapter.MSG));
                            String tmp_time = localCursor.getString(localCursor.getColumnIndex(DBAdapter.TIME));

                            if(tmp_from_id == null || tmp_from_id.equals("null") == true || tmp_to_id == null || tmp_to_id.equals("null") == true
                                    || tmp_msg == null || tmp_msg.equals("null") == true || tmp_time == null || tmp_time.equals("null") == true)
                            {
                                continue;
                            }
                            IntegerWrapper tmpYear = new IntegerWrapper(0);
                            IntegerWrapper tmpMonth = new IntegerWrapper(0);
                            IntegerWrapper tmpDate = new IntegerWrapper(0);

                            getYearMonthDay(tmp_time, tmpYear, tmpMonth, tmpDate);

                            int retIndex = isSameDateGroupExist(tmpYear.getInteger(), tmpMonth.getInteger(), tmpDate.getInteger());

                            ChatMessageGroup tmpGrp = null;
                            if(retIndex == -1)
                            {
                                //no same date exist
                                tmpGrp = new ChatMessageGroup(tmpYear.getInteger(), tmpMonth.getInteger(), tmpDate.getInteger());
                            }
                            else
                            {
                                //same date exist
                                tmpGrp = chatGroupList.get(retIndex);
                            }

                            if(tmp_from_id.equals(my_id) == true)
                            {
                                //chatHistory.add(new ChatMessage(0, true, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));
                                tmpGrp.getChatList().add(new ChatMessage(0, true, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));
                            }
                            else
                            {
                                //chatHistory.add(new ChatMessage(0, false, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));
                                tmpGrp.getChatList().add(new ChatMessage(0, false, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));
                            }

                            if(retIndex == -1)
                            {
                                chatGroupList.add(tmpGrp);
                            }

                            localCursor.moveToNext();
                        }
                    }

                    if(chatGroupList.size() > 0)
                    {
                        ChatMessageGroup tmpGrp = chatGroupList.get(chatGroupList.size() -1);
                        //mCurrentDateGrpIndex = chatGroupList.size() -1;
                        mFirstChatYear = tmpGrp.getYear();
                        mFirstChatMonth = tmpGrp.getMonth();
                        mFirstChatDate = tmpGrp.getDate();
                    }
                }
                else
                {
                    //add chat messages from the prev_last_time_req(end time)
                    //chatGroupList.clear();

                    Cursor localCursor = mDBAdapter.fetchAllMessagesSinceTime(startTime, my_id, friend_id);
                    if(localCursor.moveToFirst())
                    {
                        for (int i = 0; i < localCursor.getCount(); i++)
                        {
                            String tmp_from_id = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FROM_ID));
                            String tmp_to_id = localCursor.getString(localCursor.getColumnIndex(DBAdapter.TO_ID));
                            String tmp_msg = localCursor.getString(localCursor.getColumnIndex(DBAdapter.MSG));
                            String tmp_time = localCursor.getString(localCursor.getColumnIndex(DBAdapter.TIME));

                            if(tmp_from_id == null || tmp_from_id.equals("null") == true || tmp_to_id == null || tmp_to_id.equals("null") == true
                                    || tmp_msg == null || tmp_msg.equals("null") == true || tmp_time == null || tmp_time.equals("null") == true)
                            {
                                continue;
                            }

                            IntegerWrapper tmpYear = new IntegerWrapper(0);
                            IntegerWrapper tmpMonth = new IntegerWrapper(0);
                            IntegerWrapper tmpDate = new IntegerWrapper(0);

                            getYearMonthDay(tmp_time, tmpYear, tmpMonth, tmpDate);

                            int retIndex = isSameDateGroupExist(tmpYear.getInteger(), tmpMonth.getInteger(), tmpDate.getInteger());

                            ChatMessageGroup tmpGrp = null;
                            if(retIndex == -1)
                            {
                                //no same date exist
                                tmpGrp = new ChatMessageGroup(tmpYear.getInteger(), tmpMonth.getInteger(), tmpDate.getInteger());
                            }
                            else
                            {
                                //same date exist
                                tmpGrp = chatGroupList.get(retIndex);
                            }

                            if(tmp_from_id.equals(my_id) == true)
                            {
                                //chatHistory.add(new ChatMessage(0, true, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));
                                tmpGrp.getChatList().add(new ChatMessage(0, true, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));
                            }
                            else
                            {
                                //chatHistory.add(new ChatMessage(0, false, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));
                                tmpGrp.getChatList().add(new ChatMessage(0, false, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));
                            }

                            if(retIndex == -1)
                            {
                                chatGroupList.add(tmpGrp);
                            }

                            localCursor.moveToNext();
                        }
                    }
                }

                chatHistory.clear();

                boolean isFirstItem = true;
                for(int m = 0; m <chatGroupList.size(); m++)
                {
                    ChatMessageGroup tmpObj = chatGroupList.get(m);

                    if(mFirstChatYear <= tmpObj.getYear())
                    {
                        if
                                (
                                (mFirstChatMonth <= tmpObj.getMonth() && mFirstChatYear == tmpObj.getYear()) ||
                                        (mFirstChatYear < tmpObj.getYear())
                                )
                        {
                            if
                                    (
                                    (mFirstChatDate <= tmpObj.getDate() && mFirstChatMonth == tmpObj.getMonth()) ||
                                            (mFirstChatMonth < tmpObj.getMonth())
                                    )
                            {
                                ArrayList<ChatMessage> tmpList = tmpObj.getChatList();
                                chatHistory.addAll(tmpList);

                                if(isFirstItem == true)
                                {
                                    isFirstItem = false;

                                    if(m != 0)
                                    {
                                        //there is one previous date or more.
                                        ChatMessage firstMsg = chatHistory.get(0);
                                        firstMsg.setType(ChatMessage.MORE_DATE_TYPE);

                                        ChatMessageGroup tmpPrevObj = chatGroupList.get(m-1);
                                        firstMsg.setPreviousDate(tmpPrevObj.getYear(), tmpPrevObj.getMonth(), tmpPrevObj.getDate());
                                    }
                                    //mCurrentDateGrpIndex = m;
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                    else
                    {
                        continue;
                    }
                }

                int compare_ret = compareTwoMicroTime(startTime, micro_time_str);
                if(compare_ret <= 0 )
                {
                    //micro time is higher
                    compare_ret = compareTwoMicroTime(micro_time_str, recvTime);
                    if(compare_ret <= 0 )
                    {
                        //recv time is higher
                        compare_ret = compareTwoMicroTime(recvTime, sentTime);
                        if(compare_ret <= 0 )
                        {
                            //send time is higher
                            isNewMessageArrived = true;
                            mDBAdapter.putLastRequestTime(my_id, friend_id, sentTime);
                            Log.d(TAG, String.format("%s : last req sendTime save", sentTime));
                        }
                        else
                        {
                            //recv time is higher
                            isNewMessageArrived = true;
                            mDBAdapter.putLastRequestTime(my_id, friend_id, recvTime);
                            Log.d(TAG, String.format("%s : last req recvTime save", recvTime));
                        }
                    }
                    else
                    {
                        //micro time is higher
                        compare_ret = compareTwoMicroTime(micro_time_str, sentTime);
                        if(compare_ret <= 0 )
                        {
                            //send time is higher
                            isNewMessageArrived = true;
                            mDBAdapter.putLastRequestTime(my_id, friend_id, sentTime);
                            Log.d(TAG, String.format("%s : last req sentTime save", sentTime));
                        }
                        else
                        {
                            //micro time is
                            mDBAdapter.putLastRequestTime(my_id, friend_id, micro_time_str);
                            Log.d(TAG, String.format("%s : last req micro_time_str save", micro_time_str));
                        }
                    }
                }
                else
                {
                    //start time is higher
                    compare_ret = compareTwoMicroTime(startTime, recvTime);
                    if(compare_ret <= 0 )
                    {
                        //recv time is higher
                        compare_ret = compareTwoMicroTime(recvTime, sentTime);
                        if(compare_ret <= 0 )
                        {
                            //send time is higher
                            isNewMessageArrived = true;
                            mDBAdapter.putLastRequestTime(my_id, friend_id, sentTime);
                            Log.d(TAG, String.format("%s : last req sentTime save", sentTime));
                        }
                        else
                        {
                            //recv time is higher
                            isNewMessageArrived = true;
                            mDBAdapter.putLastRequestTime(my_id, friend_id, recvTime);
                            Log.d(TAG, String.format("%s : last req recvTime save", recvTime));
                        }
                    }
                    else
                    {
                        //start time is higher
                        compare_ret = compareTwoMicroTime(startTime, sentTime);
                        if(compare_ret <= 0 )
                        {
                            //send time is higher
                            isNewMessageArrived = true;
                            mDBAdapter.putLastRequestTime(my_id, friend_id, sentTime);
                            Log.d(TAG, String.format("%s : last req sentTime save", sentTime));
                        }
                        else
                        {
                            //start time is higher
                            mDBAdapter.putLastRequestTime(my_id, friend_id, startTime);
                            Log.d(TAG, String.format("%s : last req startTime save", startTime));
                        }
                    }
                }

                Message msg = mFriendMessageMainHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putString("type", "refresh_all");
                if(isNewMessageArrived == true)
                {
                    b.putString("scroll", "true");
                }
                else if(isNewMessageArrived == false)
                {
                    if(isInitialized == false)
                    {
                        isInitialized = true;
                        b.putString("scroll", "true");
                    }
                    else
                    {
                        b.putString("scroll", "false");
                    }
                }
                msg.setData(b);
                mFriendMessageMainHandler.sendMessage(msg);
                stopProgress();
            }
            else if(serverResult.equals(JSON_FAIL))
            {
                stopProgress();
                BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
            }
            else if (serverResult.equals(JSON_LOGOUT))
            {
                mGeneralApplication.setIdString("");
                mGeneralApplication.setNumString("");
                mGeneralApplication.setLoggedIn(false);

                LoginProcessPopup(new AutoLoginListener()
                {
                    @Override
                    public void onAutoLoginSuccess()
                    {
                        //this is main thread, so must not call get_messages
                        //get_messages();
                    }

                    @Override
                    public void onAutoLoginFail()
                    {
                        startManualLogin(new LoginListener()
                        {
                            @Override
                            public void onLoginSuccess()
                            {
                                //this is main thread, so must not call get_messages
                                //get_messages();
                            }

                            @Override
                            public void onLoginCancel()
                            {
                                BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                            }
                        });
                    }
                });
            }
        }
        else
        {
            Log.d(TAG, "get message null");

            mGeneralApplication.setIdString("");
            mGeneralApplication.setNumString("");
            mGeneralApplication.setLoggedIn(false);

            LoginProcessPopup(new AutoLoginListener()
            {
                @Override
                public void onAutoLoginSuccess()
                {
                    //this is main thread, so must not call get_messages
                    //get_messages();
                }

                @Override
                public void onAutoLoginFail()
                {
                    startManualLogin(new LoginListener()
                    {
                        @Override
                        public void onLoginSuccess()
                        {
                            //this is main thread, so must not call get_messages
                            //get_messages();
                        }

                        @Override
                        public void onLoginCancel()
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                        }
                    });
                }
            });
        }

        /*
        mWeb.getFriendMessages(friend_id, startTime,
                new Consumer<ResponseFriendMessagesData>()
                {
                    @Override
                    public void accept(ResponseFriendMessagesData objDatas) throws Exception
                    {
                        // TODO: Handle response.


                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.

                    }
                }, disposables
        );
        */
    }

    private int compareTwoMicroTime(String one1, String one2)
    {
        String one1Arr[] = one1.split("\\.");

        String one2Arr[] = one2.split("\\.");

        if( Long.valueOf(one1Arr[0]) > Long.valueOf(one2Arr[0]) )
        {
                return 1;
        }
        else if(Long.valueOf(one1Arr[0]) < Long.valueOf(one2Arr[0]))
        {
                return -1;
        }
        else
        {
            if( Long.valueOf(one1Arr[1]) > Long.valueOf(one2Arr[1]) )
            {
                return 1;
            }
            else if(Long.valueOf(one1Arr[1]) < Long.valueOf(one2Arr[1]))
            {
                return -1;
            }
            else
            {
                //same number
                return 0;
            }
        }
    }


    public void addAndDisplayMessage(ChatMessage message)
    {
        //adapter.add(message);
        chatHistory.add(message);
        adapter.notifyDataSetChanged();
        scroll();
    }

    private void scroll() {
        mMessagesContainer.setSelection(mMessagesContainer.getCount() - 1);
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.message_activity_back_button)
        {
            finish();
        }
        else if(v.getId() == R.id.send_button)
        {
            //mTimerTick = SystemClock.elapsedRealtime();

            Log.d(TAG, "############ new send");

            String messageText = mChatText.getText().toString();
            if (TextUtils.isEmpty(messageText))
            {
                return;
            }

            startProgress();

            final String my_id = mGeneralApplication.getNumString();

            //tmpGrp.getChatList().add(new ChatMessage(0, true, tmp_msg, Long.valueOf(tmp_from_id), tmp_time));

            //ChatMessage chatMessage = new ChatMessage(0, true, messageText, Long.valueOf(my_id), DateFormat.getDateTimeInstance().format(new Date()));
            //mChatText.setText("");
            //addAndDisplayMessage(chatMessage);

            mChatText.setText("");

            mCurrentMessageContainerPos = adapter.getCount()-1;
            mMessagesContainer.setSelection(mCurrentMessageContainerPos);

            sendMessageFunc(my_id, mFriendId, messageText);

        }
    }

    private void sendMessageFunc(String my_id, String tmpFriendId, String messageText)
    {
        mWeb.sendMessage(tmpFriendId, messageText,
                new Consumer<ResponseSendReturnData>()
                {
                    @Override
                    public void accept(ResponseSendReturnData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        SendReturn serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            //insert latest server messages to sqlite db
                            String sentTime = serverData.getSend_update_time();
                            String receivedTime = serverData.getRecv_update_time();

                            mDBAdapter.putOneMessage(my_id, mFriendId, messageText, sentTime);

                            mDBAdapter.putOneLocalAndServerFriend(Long.valueOf(mFriendId), Long.valueOf(my_id), receivedTime);

                            Cursor search_cursor = mDBAdapter.getOneFriend(Long.valueOf(my_id), Long.valueOf(mFriendId));
                            if(search_cursor != null && search_cursor.moveToFirst())
                            {
                                String tmp_time = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.LOCAL_TIME));

                                if(receivedTime != tmp_time)
                                {
                                    //get_messages();
                                    mGetMessageThread.setReqflag(true);
                                }

                                //same time exist
                            }
                            else
                            {
                                //get_messages();
                                mGetMessageThread.setReqflag(true);
                            }
                            search_cursor.close();

                            stopProgress();
                            /*
                            Message msg = mFriendMessageMainHandler.obtainMessage();
                            Bundle b = new Bundle();
                            b.putString("type", "refresh_all");
                            msg.setData(b);
                            mFriendMessageMainHandler.sendMessage(msg);
                            */
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            stopProgress();
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            stopProgress();

                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    sendMessageFunc(my_id, tmpFriendId, messageText);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            sendMessageFunc(my_id, tmpFriendId, messageText);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        stopProgress();
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    sendMessageFunc(my_id, tmpFriendId, messageText);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            sendMessageFunc(my_id, tmpFriendId, messageText);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void getYearMonthDay(String microtime, IntegerWrapper year, IntegerWrapper month, IntegerWrapper day)
    {
        String microtimeStr[] = microtime.split("\\.");
        String secondsTime = microtimeStr[0];

        long timestamp = Long.valueOf(secondsTime);
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestamp*1000);
        cal.setTimeZone(TimeZone.getDefault());

        year.setInteger(cal.get(Calendar.YEAR));
        month.setInteger(cal.get(Calendar.MONTH) + 1);
        day.setInteger(cal.get(Calendar.DATE));
    }

    private int isSameDateGroupExist(int year, int month, int date)
    {
        for(int x = chatGroupList.size()-1; x >= 0; x--)
        {
            ChatMessageGroup tmpGrp = chatGroupList.get(x);
            if(year <= tmpGrp.getYear())
            {
                if(year < tmpGrp.getYear())
                {
                    continue;
                }
                else
                {
                    if(month <= tmpGrp.getMonth())
                    {
                        if(month < tmpGrp.getMonth())
                        {
                            continue;
                        }
                        else
                        {
                            if(date <= tmpGrp.getDate())
                            {
                                if(date < tmpGrp.getDate())
                                {
                                    continue;
                                }
                                else
                                {
                                    return x;
                                }
                            }
                            else
                            {
                                return -1;
                            }
                        }
                    }
                    else
                    {
                        return -1;
                    }
                }
            }
            else
            {
                return -1;
            }
        }
        return -1;
    }

    final Handler mFriendMessageMainHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

            String type_str = msg.getData().getString("type");

            switch (type_str)
            {
                case "refresh_all":

                    String flag_str = msg.getData().getString("scroll");
                    adapter.notifyDataSetChanged();
                    if("true".equals(flag_str))
                    {
                        mMessagesContainer.setSelection(mMessagesContainer.getCount() - 1);
                    }
                    break;

                case "new_message":
                    //mCurrentMessageContainerPos = adapter.getCount()-1;
                    //mMessagesContainer.setSelection(mCurrentMessageContainerPos);

                    //get_messages();
                    mGetMessageThread.setReqflag(true);
                    break;

                default:
                    break;
            }
        }
    };

    @Override
    public void onDateClickListener(int index, int year, int month, int date)
    {
        chatHistory.clear();

        mFirstChatYear = year;
        mFirstChatMonth = month;
        mFirstChatDate = date;

        boolean isFirstItem = true;
        for(int m = 0; m <chatGroupList.size(); m++)
        {
            ChatMessageGroup tmpObj = chatGroupList.get(m);
            if(year <= tmpObj.getYear())
            {
                if
                    (
                        (month <= tmpObj.getMonth() && year == tmpObj.getYear()) ||
                                (year < tmpObj.getYear())
                    )
                {
                    if
                        (
                            (date <= tmpObj.getDate() && month == tmpObj.getMonth()) ||
                                    (month < tmpObj.getMonth())
                        )
                    {
                        ArrayList<ChatMessage> tmpList = tmpObj.getChatList();
                        ChatMessage tmpFirst = tmpList.get(0);
                        tmpFirst.setType(ChatMessage.CHAT_MESSAGE_TYPE);    //reset every first message type
                        chatHistory.addAll(tmpList);

                        if(isFirstItem == true)
                        {
                            isFirstItem = false;

                            if(m != 0)
                            {
                                //there is one previous date or more.
                                ChatMessage firstMsg = chatHistory.get(0);
                                firstMsg.setType(ChatMessage.MORE_DATE_TYPE);

                                ChatMessageGroup tmpPrevObj = chatGroupList.get(m-1);
                                firstMsg.setPreviousDate(tmpPrevObj.getYear(), tmpPrevObj.getMonth(), tmpPrevObj.getDate());
                            }
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    continue;
                }
            }
            else
            {
                continue;
            }
        }
        //mCurrentMessageContainerPos = mMessagesContainer.getFirstVisiblePosition();
        adapter.notifyDataSetChanged();
        //mMessagesContainer.requestFocusFromTouch();
        //mMessagesContainer.setSelection(mCurrentMessageContainerPos);
    }

    /*
    final Runnable mGetMessageRunnable = new Runnable()
    {
        @Override
        public void run()
        {
            Log.d(TAG, "timer schedule");

            mTimerCount++;

            long currentTick = SystemClock.elapsedRealtime();
            if(currentTick - mTimerTick < 15000)
            {
                Log.d(TAG, "############ get message");
                get_messages();
            }
            else
            {
                if(mTimerCount %3 == 0)
                {
                    get_messages();
                }
            }

            mFriendMessageMainHandler.postDelayed(mGetMessageRunnable, 10000);

        }
    };
    */

    private class GetMessageThread extends Thread
    {
        private boolean mIsReqThreadRunning = true;
        private boolean reqState = false;
        private long reqReadyCount = 0;

        public void setReqflag(boolean flag)
        {
            reqState = flag;
        }

        public void quit()
        {
            mIsReqThreadRunning = false;
        }

        @Override
        public void run()
        {
            while(mIsReqThreadRunning == true)
            {
                if(reqState == true)
                {
                    reqState = false;
                    reqReadyCount = 0;
                    get_messages();
                }
                else
                {
                    reqReadyCount++;

                    if(reqReadyCount % 300 == 0)
                    {
                        reqState = true;
                        continue;
                    }

                    try
                    {
                        Thread.sleep(100);
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }
    }


    private void printAllMessages()
    {

        Cursor localCursor = mDBAdapter.fetchAllMessagesFromEveryone();
        if(localCursor.moveToFirst())
        {
            for (int i = 0; i < localCursor.getCount(); i++)
            {
                String tmp_from_id = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FROM_ID));
                String tmp_to_id = localCursor.getString(localCursor.getColumnIndex(DBAdapter.TO_ID));
                String tmp_msg = localCursor.getString(localCursor.getColumnIndex(DBAdapter.MSG));
                String tmp_time = localCursor.getString(localCursor.getColumnIndex(DBAdapter.TIME));

                Log.d(TAG, String.format("time = %s, from = %s, to = %s. updated msg = %s", tmp_time, tmp_from_id, tmp_to_id, tmp_msg));
                localCursor.moveToNext();
            }
        }
        localCursor.close();

    }

    public BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context arg0, Intent intent)
        {
            int  msg_id = intent.getExtras().getInt(GENERAL_APP_ID);

            switch(msg_id)
            {
                case NEW_MESSAGE_RECEIVED:
                    if(mFriendMessageMainHandler != null)
                    {
                        Message msg = mFriendMessageMainHandler.obtainMessage();
                        Bundle b = new Bundle();
                        b.putString("type", "new_message");
                        msg.setData(b);
                        mFriendMessageMainHandler.sendMessage(msg);
                    }
                    break;
            }
        }
    };

    public void startProgress()
    {
        mMessagesContainer.post(new Runnable()
        {
            @Override
            public void run()
            {
                mIsProgressStarted = true;

                mChatButton.setVisibility(View.GONE);
                mProgressSpinnerView.setVisibility(View.VISIBLE);

                mRotateAnim = new RotateAnimation(0.0f, 360.0f , Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);
                mRotateAnim.setInterpolator(new LinearInterpolator());
                mRotateAnim.setRepeatCount(Animation.INFINITE);
                mRotateAnim.setDuration(500);
                mProgressSpinnerView.setAnimation(mRotateAnim);
                mProgressSpinnerView.startAnimation(mRotateAnim);
            }
        });
    }

    public void stopProgress()
    {
        if(mIsProgressStarted == true)
        {
            mMessagesContainer.post(new Runnable()
            {
                @Override
                public void run()
                {
                    mIsProgressStarted = false;

                    mProgressSpinnerView.clearAnimation();
                    mChatButton.setVisibility(View.VISIBLE);
                    mProgressSpinnerView.setVisibility(View.GONE);
                }
            });
        }
    }

}
