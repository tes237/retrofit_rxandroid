package etm.main.market.activities;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.InfoAdapter;
import etm.main.market.lists.InfoListListener;
import etm.main.market.lists.PurchasedInfoAdapter;
import etm.main.market.lists.PurchasedInfoListListener;
import etm.main.market.vo.MapFile;
import etm.main.market.vo.MapFiles;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.ResponseMapFilesData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.widgets.swipyLayout.*;

import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteException;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

public class PurchasedListActivity extends BaseActivity implements baseDefine, PurchasedInfoListListener, View.OnClickListener
{
    private static final String TAG = PurchasedListActivity.class.getSimpleName();

    public String mUserDir = "";
    private  String APP_DIRECTORY;

    RecyclerView mRecyclerView;
    //SwipeRefreshLayout mSwipeRefreshLayout;
    LinearLayoutManager mLayoutManager;
    PurchasedInfoAdapter mPurchasedInfoAdapter;
    SwipyRefreshLayout mSwipyRefreshLayout;
    TextView mTextView;
    ImageButton mBackButton;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private GeneralAlarmDialog mGeneralAlarmDialog = null;

    private DBAdapter mDBAdapter;

    private List<PurchasedItem> mDataList;
    private List<Integer> mDownloadStatusList;
    private boolean mIsDownloadStarted = false;

    private boolean mIsDownloadStop = false;

    LinkedHashMap<String, Long> tmpPrevWholeReceivedFileSizeMap = new LinkedHashMap<String, Long>();
    LinkedHashMap<String, Long> tmpPrevWholeReceivedFilePercentMap = new LinkedHashMap<String, Long>();

    private int mCurrentPageIndex = 1;
    private int mTotalPageCount = 1;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_purchased_list);

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();

        String tmpUserIdStr = mGeneralApplication.getIdString();
        mUserDir = Base64.mod_encode(tmpUserIdStr);

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        mSwipyRefreshLayout = (SwipyRefreshLayout)findViewById(R.id.tourguide_swipy_layout);
        mRecyclerView = (RecyclerView)findViewById(R.id.tourguide_recycler_view);
        mTextView = (TextView)findViewById(R.id.list_activity_title_textview);
        mBackButton = (ImageButton)findViewById(R.id.list_activity_back_button);
        mBackButton.setOnClickListener(this);

        DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics();
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        int fontSize = width/43;

        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mDataList = new ArrayList<PurchasedItem>();
        mDownloadStatusList = new ArrayList<Integer>();
        mPurchasedInfoAdapter = new PurchasedInfoAdapter(PurchasedListActivity.this, mDataList, this);
        mRecyclerView.setAdapter(mPurchasedInfoAdapter);

        tmpPrevWholeReceivedFileSizeMap.clear();
        tmpPrevWholeReceivedFilePercentMap.clear();

        mSwipyRefreshLayout.setDirection(SwipyRefreshLayoutDirection.BOTTOM);
        mSwipyRefreshLayout.setOnRefreshListener(new SwipyRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(SwipyRefreshLayoutDirection direction)
            {
                if(mTotalPageCount < mCurrentPageIndex + 1)
                {
                    mSwipyRefreshLayout.setRefreshing(false);
                    return;
                }

                mCurrentPageIndex++;

                getPurchasedProductsFunc(DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex));
                mSwipyRefreshLayout.setRefreshing(false);
            }
        });

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        mDataList.clear();
        mDownloadStatusList.clear();
        getPurchasedProductsFunc(DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex));
    }

    private void getPurchasedProductsFunc(String item_per_page, String page_index)
    {
        mWeb.getPurchasedProducts(item_per_page, page_index,
                new Consumer<ResponseProductsData>()
                {
                    @Override
                    public void accept(ResponseProductsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Products serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            for(int x = 0; x < serverData.getProducts().size(); x++)
                            {
                                Product tmpData = serverData.getProducts().get(x);
                                String skuStr = tmpData.getSku();
                                String nameStr = tmpData.getName();
                                String imageUrlStr = tmpData.getImage1();
                                String priceStr = tmpData.getPrice();

                                long transactionIndex = tmpData.getModifyTransactionIndex();
                                long updateTimne = tmpData.getUpdateTime();
                                String tmpUserIdStr = mGeneralApplication.getIdString();

                                //printAllMapVersions();

                                Cursor localCursor = mDBAdapter.getOneVersion(skuStr, mUserDir);

                                boolean itNeedToDownload = false;
                                if(localCursor.moveToFirst())
                                {
                                    //for (int i = 0; i < localCursor.getCount(); i++)
                                    {
                                        String tmp_sku = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FIELD_SKU));
                                        long local_update_time_stamp = localCursor.getLong(localCursor.getColumnIndex(DBAdapter.UPDATED_DATE));
                                        long local_version_index = localCursor.getLong(localCursor.getColumnIndex(DBAdapter.VERSION_INDEX));

                                        //if(transactionIndex > local_version_index)
                                        //{
                                        //    itNeedToDownload = true;
                                        //}

                                        if(updateTimne > local_update_time_stamp)
                                        {
                                            itNeedToDownload = true;
                                        }
                                    }
                                }
                                else
                                {

                                    itNeedToDownload = true;

                                    //printAllMapVersions();

                                }

                                mDataList.add(new PurchasedItem(skuStr, imageUrlStr, nameStr, priceStr, itNeedToDownload, transactionIndex, updateTimne));
                                mDownloadStatusList.add(PurchasedItem.DOWNLOAD_NOT_STARTED);
                            }
                            mPurchasedInfoAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getPurchasedProductsFunc(item_per_page, page_index);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getPurchasedProductsFunc(item_per_page, page_index);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.

                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getPurchasedProductsFunc(item_per_page, page_index);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getPurchasedProductsFunc(item_per_page, page_index);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                        //logout redirect 301


                    }
                }, disposables
        );
    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        PurchasedItem tmpData = mDataList.get(index);
        if( tmpData.getNeedToBeDownloaded() == false)
        {
            String skuStr = tmpData.getSku();
            String imageUrl = tmpData.getImage1();
            String title = tmpData.getName();

            mGeneralApplication.setTick("Purchased list click");

            Intent i = new Intent(PurchasedListActivity.this, RouteListActivity.class);
            i.putExtra(MAP_SKU, skuStr);
            i.putExtra(MAP_TITLE, title);
            i.putExtra(IS_TEST_MAP, TYPE_PURCHASED_MAP);
            i.putExtra(MAP_IMAGE_URL, imageUrl);
            startActivity(i);
        }
        else
        {
            //Toast.makeText(this, "Downloading", Toast.LENGTH_SHORT);
        }
    }

    @Override
    public void onReviewClickListener(View v, int index, int status)
    {
        PurchasedItem tmpData = mDataList.get(index);
        if( tmpData.getNeedToBeDownloaded() == false)
        {
            String skuStr = tmpData.getSku();
            String tmpTitleStr = tmpData.getName();

            Intent i = new Intent(PurchasedListActivity.this, RatingListActivity.class);
            i.putExtra(MAP_SKU, skuStr);
            i.putExtra(CategoryListActivity.MAP_TITLE, tmpTitleStr);
            startActivity(i);
        }
    }

    @Override
    public void onDownloadClickListener(View v, int index, int status)
    {
        PurchasedItem tmpData = mDataList.get(index);
        final String skuStr = tmpData.getSku();

        if(skuStr == null)
        {
            return;
        }

        String skuArr[] = skuStr.split("_");

        if(skuArr.length != 2)
        {
            return;
        }

        final String mapIdStr = skuArr[1];

        mDownloadStatusList.set(index, PurchasedItem.DOWNLOAD_STARTED);
        mIsDownloadStarted = true;

        Message msg = mPurchasedListMainHandler.obtainMessage();
        Bundle b = new Bundle();
        b.putString("type", "refresh_status");
        b.putInt("index", index);
        b.putInt("status", (int)PurchasedItem.DOWNLOAD_STARTED);
        msg.setData(b);
        mPurchasedListMainHandler.sendMessage(msg);

        getDownloadableFiles(mapIdStr, skuStr, index);
    }

    private void getDownloadableFiles(String mapIdStr, String skuStr, int index)
    {
        mWeb.get_downloadable_files(mapIdStr, skuStr,
                new Consumer<ResponseMapFilesData>()
                {
                    @Override
                    public void accept(ResponseMapFilesData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        final String localMapIdStr = mapIdStr;
                        final String localSkuStr = skuStr;
                        final int localIndex = index;

                        String serverResult = objDatas.getResult();
                        MapFiles serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            long tmpTotalSize = 0;
                            for(int x = 0; x < serverData.getMapFiles().size(); x++)
                            {
                                MapFile tmpFile = serverData.getMapFiles().get(x);

                                boolean ret = isThisServerFileHasToBeDownloaded(localSkuStr, tmpFile.getFileKey(), tmpFile.getFileName());
                                if(ret == true)
                                {
                                    tmpTotalSize += (tmpFile.getFileSize()/1000);   // KBytes
                                }
                            }

                            if(tmpTotalSize == 0)
                            {
                                //finish, we don't need to download any file.
                                PurchasedItem tmpItem = mDataList.get(localIndex);
                                tmpItem.setNeedToBeDownloaded(false);

                                String tmpUserIdStr = mGeneralApplication.getIdString();
                                String tmpVersionStr = String.valueOf(tmpItem.getVersionIndex());
                                String tmpUpdatedTimeStr = String.valueOf(tmpItem.getUpdatedTimeStamp());

                                try
                                {
                                    //mDBAdapter.putOneVersion(localSkuStr, tmpUserIdStr, tmpVersionStr, mUserDir);
                                    mDBAdapter.putOneVersion(localSkuStr, tmpUserIdStr, tmpVersionStr, tmpUpdatedTimeStr);
                                }
                                catch(SQLiteException sqe)
                                {

                                }

                                /*
                                Message msg = mPurchasedListMainHandler.obtainMessage();
                                Bundle b = new Bundle();
                                b.putString("type", "refresh_all");
                                msg.setData(b);
                                mPurchasedListMainHandler.sendMessage(msg);
                                */

                                mDownloadStatusList.set(index, PurchasedItem.DOWNLOAD_FINISHED);

                                checkEveryDownloadStatus();

                                Message msg = mPurchasedListMainHandler.obtainMessage();
                                Bundle b = new Bundle();
                                b.putString("type", "refresh_status");
                                b.putInt("index", localIndex);
                                b.putInt("status", (int)PurchasedItem.DOWNLOAD_FINISHED);
                                msg.setData(b);
                                mPurchasedListMainHandler.sendMessage(msg);

                                return;
                            }

                            final long totalSize = tmpTotalSize;
                            LinkedHashMap<String, Long> tmpFileInfoMap = new LinkedHashMap<String, Long>();

                            tmpPrevWholeReceivedFilePercentMap.put(localMapIdStr, 0L);
                            tmpPrevWholeReceivedFileSizeMap.put(localMapIdStr, 0L);

                            for(int x = 0; x < serverData.getMapFiles().size(); x++)
                            {
                                MapFile tmpFile = serverData.getMapFiles().get(x);

                                boolean ret = isThisServerFileHasToBeDownloaded(localSkuStr, tmpFile.getFileKey(), tmpFile.getFileName());
                                if(ret == true)
                                {
                                    final String tmpName = tmpFile.getFileName();
                                    final String tmpKey = tmpFile.getFileKey();

                                    final String destPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" + localSkuStr + "/" + tmpName;

                                    mWeb.map_download(localMapIdStr, localSkuStr, tmpKey, destPathStr, new DownloadProgressListener()
                                    {
                                        @Override
                                        public void update(String fileKey, long bytesRead, long contentLength, boolean done)
                                        {
                                            long wholeReceivedFileSize = 0;
                                            synchronized(tmpFileInfoMap)
                                            {
                                                tmpFileInfoMap.put(fileKey, bytesRead);

                                                for (Iterator hashitr = tmpFileInfoMap.values().iterator(); hashitr.hasNext(); )
                                                {
                                                    long tmpSize = (Long) hashitr.next();
                                                    wholeReceivedFileSize += (tmpSize/1000);    // KBytes
                                                }
                                            }

                                            long currentPercent = (wholeReceivedFileSize*100)/totalSize;

                                            final long prevWholeReceivedFilePercent = tmpPrevWholeReceivedFilePercentMap.get(localMapIdStr);
                                            final long prevWholeReceivedFileSize = tmpPrevWholeReceivedFileSizeMap.get(localMapIdStr);

                                            if(currentPercent != prevWholeReceivedFilePercent)
                                            {
                                                Message msg = mPurchasedListMainHandler.obtainMessage();
                                                Bundle b = new Bundle();
                                                b.putString("type", "refresh_progress");
                                                b.putInt("index", localIndex);
                                                b.putInt("percent", (int)currentPercent);
                                                msg.setData(b);
                                                mPurchasedListMainHandler.sendMessage(msg);

                                                Log.d(TAG, String.format("sku = %s, percent = %d, cur bytes = %d, prev bytes = %d, totalSize = %d", localSkuStr, currentPercent, wholeReceivedFileSize, prevWholeReceivedFileSize, totalSize));

                                                //prevWholeReceivedFilePercent = currentPercent;
                                                tmpPrevWholeReceivedFilePercentMap.put(localMapIdStr, currentPercent);

                                                //prevWholeReceivedFileSize = wholeReceivedFileSize;
                                                tmpPrevWholeReceivedFileSizeMap.put(localMapIdStr, wholeReceivedFileSize);
                                            }

                                            if(currentPercent == 100)
                                            {
                                                //download finished!
                                                PurchasedItem tmpItem = mDataList.get(localIndex);
                                                tmpItem.setNeedToBeDownloaded(false);

                                                String tmpUserIdStr = mGeneralApplication.getIdString();
                                                String tmpVersionStr = String.valueOf(tmpItem.getVersionIndex());
                                                String tmpUpdatedTimeStr = String.valueOf(tmpItem.getUpdatedTimeStamp());

                                                mDBAdapter.putOneVersion(localSkuStr, mUserDir, tmpVersionStr, tmpUpdatedTimeStr);

                                                mDownloadStatusList.set(localIndex, PurchasedItem.DOWNLOAD_FINISHED);

                                                checkEveryDownloadStatus();

                                                Message msg = mPurchasedListMainHandler.obtainMessage();
                                                Bundle b = new Bundle();
                                                b.putString("type", "refresh_status");
                                                b.putInt("index", localIndex);
                                                b.putInt("status", (int)PurchasedItem.DOWNLOAD_FINISHED);
                                                msg.setData(b);
                                                mPurchasedListMainHandler.sendMessage(msg);
                                            }
                                        }
                                    }, disposables);

                                    long downloaded_size = 0;
                                    long serverSize = tmpFile.getFileSize();
                                    do
                                    {
                                        //synchronized(tmpFileInfoMap)
                                        {
                                            Long tmpSize = tmpFileInfoMap.get(tmpKey);
                                            if(tmpSize != null)     //why sometimes null is returned?
                                            {
                                                downloaded_size = tmpSize.longValue();
                                            }
                                        }

                                        Thread.sleep(300);
                                    }
                                    while((downloaded_size < serverSize) && (mIsDownloadStop == false));

                                    try
                                    {
                                        mDBAdapter.updateDownloadedNewFileInfo(localSkuStr, tmpKey, tmpName, mUserDir);
                                    }
                                    catch(SQLException sqe)
                                    {
                                        sqe.printStackTrace();
                                    }
                                    //printKeyFileMap();
                                }
                            }
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getDownloadableFiles(mapIdStr, skuStr, index);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getDownloadableFiles(mapIdStr, skuStr, index);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true) {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener() {
                                @Override
                                public void onAutoLoginSuccess() {
                                    getDownloadableFiles(mapIdStr, skuStr, index);
                                }

                                @Override
                                public void onAutoLoginFail() {
                                    startManualLogin(new LoginListener() {
                                        @Override
                                        public void onLoginSuccess() {
                                            getDownloadableFiles(mapIdStr, skuStr, index);
                                        }

                                        @Override
                                        public void onLoginCancel() {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }


    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.list_activity_back_button)
        {
            if(mIsDownloadStarted == false)
            {
                finish();
            }
            else
            {
                BaseLib().showGeneralPopup(getString(R.string.download_warning_title), getString(R.string.please_wait_for_download), null);
            }
        }
    }

    @Override
    public void onBackPressed()
    {
        if(mIsDownloadStarted == false)
        {
            finish();
        }
        else
        {
            BaseLib().showGeneralPopup(getString(R.string.download_warning_title), getString(R.string.please_wait_for_download), null);
        }
    }

    public static String convertToUTF8(String inputStr)
    {
        String outStr = null;
        try
        {
            outStr = new String(inputStr.getBytes("UTF-8"), "ISO-8859-1");
        }
        catch (java.io.UnsupportedEncodingException e)
        {
            return null;
        }
        return outStr;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }

    @Override
    public void onDestroy()
    {
        mIsDownloadStop = true;

        disposables.dispose();

        mDBAdapter.close();

        super.onDestroy();
    }

    private boolean isThisServerFileHasToBeDownloaded(String skuStr, String fileKey, String fileName)
    {
        //printKeyFileMap();
        if(fileName.contains(".json") == true)
        {
            //let's download json file all the time, because we don't have file size diff checking or content hash cjecking
            return true;
        }

        Cursor localCursor = null;
        try
        {
            localCursor = mDBAdapter.getFileName(skuStr, fileKey, mUserDir);
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }

        if(localCursor.moveToFirst())
        {
            String tmp_file_name = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FILE_NAME));

            String localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  skuStr + "/" + tmp_file_name;

            if(tmp_file_name.equals(fileName))
            {
                return false;
            }
            else
            {
                File tmpCheck = new File(localPathStr);
                if(tmpCheck.exists())
                {
                    tmpCheck.delete();
                }
                return true;
            }
        }
        else
        {
            //no such file key
            return true;
        }

    }

    private void printKeyFileMap()
    {
        Cursor localCursor = mDBAdapter.fetchAllKeyFileMap();
        if(localCursor.moveToFirst())
        {
            for (int i = 0; i < localCursor.getCount(); i++)
            {
                String tmp_sku_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FIELD_SKU));
                String tmp_file_key = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FILE_KEY));
                String tmp_file_name = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FILE_NAME));

                Log.d(TAG, String.format("sku = %s, key = %s. name = %s", tmp_sku_str, tmp_file_key, tmp_file_name));
                localCursor.moveToNext();
            }
        }
    }

    private void printAllMapVersions()
    {
        Cursor localCursor = mDBAdapter.fetchAllVersions();
        if(localCursor.moveToFirst())
        {
            for (int i = 0; i < localCursor.getCount(); i++)
            {
                String tmp_sku_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FIELD_SKU));
                String tmp_version_index_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.VERSION_INDEX));
                String tmp_updated_date_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.UPDATED_DATE));

                Log.d(TAG, String.format("sku = %s, version index = %s. updated date = %s", tmp_sku_str, tmp_version_index_str, tmp_updated_date_str));
                localCursor.moveToNext();
            }
        }
    }

    private void checkEveryDownloadStatus()
    {
        boolean downloadStarted = false;
        for(int x = 0; x < mDownloadStatusList.size(); x++)
        {
            int status = mDownloadStatusList.get(x);
            if(status == PurchasedItem.DOWNLOAD_STARTED)
            {
                downloadStarted = true;
            }
        }
        if(downloadStarted == true)
        {
            mIsDownloadStarted = true;
        }
        else
        {
            mIsDownloadStarted = false;
        }

    }

    final Handler mPurchasedListMainHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

            String type_str = msg.getData().getString("type");
            int targetIndex;
            int targetPercent;
            int targetStatus;

            switch (type_str)
            {
                case "refresh_all":
                    mPurchasedInfoAdapter.notifyDataSetChanged();
                    break;

                case "refresh_progress":
                    targetIndex = msg.getData().getInt("index");
                    targetPercent = msg.getData().getInt("percent");
                    mPurchasedInfoAdapter.refreshProgress(targetIndex, targetPercent);
                    mPurchasedInfoAdapter.notifyDataSetChanged();
                    break;

                case "refresh_status":
                    targetIndex = msg.getData().getInt("index");
                    targetStatus = msg.getData().getInt("status");
                    mPurchasedInfoAdapter.refreshStatus(targetIndex, targetStatus);
                    mPurchasedInfoAdapter.notifyDataSetChanged();
                    break;

                default:
                    break;
            }
        }
    };

}
