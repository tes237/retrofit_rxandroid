package etm.main.market.activities;

import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.baseDefine;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.FilterButtonListener;
import etm.main.market.dialog.FilterDialog;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.dialog.GeneralProgressDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.RatingListAdapter;
import etm.main.market.lists.RatingListListener;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.ResponseGetMyReviewData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponseReviewsData;
import etm.main.market.vo.ResponseSetMyReviewData;
import etm.main.market.vo.Review;
import etm.main.market.vo.Reviews;
import etm.main.market.widgets.ratingbar.ColoredRatingBar;
import etm.main.market.widgets.swipyLayout.SwipyRefreshLayout;
import etm.main.market.widgets.swipyLayout.SwipyRefreshLayoutDirection;

import etm.main.market.R;

public class RatingActivity extends BaseActivity implements baseDefine, RatingListListener, View.OnClickListener
{
    private static final String TAG = RatingActivity.class.getSimpleName();
    public static final int WRITING_FINISHED = 101;
    public static final int WRITING_CANCELLED = 102;
    public static final int WRITING_ERROR = 103;
    public static final int DID_NOTHING = 104;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;

    private ImageButton mBackButton;
    private TextView mTitleText, mNoText;

    private EditText mTitleEdit;
    private EditText mBodyEdit;

    private ColoredRatingBar mRating1;
    //private ColoredRatingBar mRating2;

    private Button mOkButton;
    private Button mCancelButton;

    private GeneralAlarmDialog mGeneralAlarmDialog;

    private ArrayList<Review> mRatingList = null;

    private String mSkuStr = null;
    private String mTitleStr = null;

    private DBAdapter mDBAdapter = null;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_rating);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mSkuStr = bd.getString(CategoryListActivity.MAP_SKU);
            String tmpCheck = bd.getString(CategoryListActivity.IS_TEST_MAP);
        }

        mBackButton = (ImageButton)findViewById(R.id.rating_activity_back_button);
        mBackButton.setOnClickListener(this);

        mOkButton = (Button)findViewById(R.id.rating_activity_review_submit_button);
        mOkButton.setOnClickListener(this);

        mCancelButton = (Button)findViewById(R.id.rating_activity_review_cancel_button);
        mCancelButton.setOnClickListener(this);

        mTitleText = (TextView)findViewById(R.id.rating_activity_title_textview);
        mNoText = (TextView)findViewById(R.id.rating_no_list);

        mRating1 = (ColoredRatingBar)findViewById(R.id.ratingbar1);
        //mRating2 = (ColoredRatingBar)findViewById(R.id.ratingbar2);

        mTitleEdit = (EditText)findViewById(R.id.rating_activity_review_title_edittext);
        mBodyEdit = (EditText)findViewById(R.id.rating_activity_review_message_edittext);

        //mTitleText.setText(mTitleStr);

        mRating1.setNumStars(5);
        //mRating2.setNumStars(5);

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        getMyReviewFunc(mSkuStr);

    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        //Intent i = new Intent(RatingActivity.this, ProfileViewActivity.class);
        //startActivity(i);
    }


    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.rating_activity_back_button)
        {
            setResult(DID_NOTHING);
            finish();
        }
        else if(v.getId() == R.id.rating_activity_review_submit_button)
        {
            String ratingStr1 = String.valueOf(mRating1.getRating());
            //String ratingStr2 = String.valueOf(mRating2.getRating());

            String titleStr = mTitleEdit.getText().toString();
            String bodyStr = mBodyEdit.getText().toString();

            if("".equals(titleStr) == true)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled), null);
                return;
            }
            if("".equals(bodyStr) == true)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled), null);
                return;
            }
            if(titleStr.length() > 60)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.title_cannot_be_longer_than_60), null);
                return;
            }
            if(bodyStr.length() > 300)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.body_cannot_be_longer_than_300), null);
                return;
            }

            setMyReviewFunc(mSkuStr, ratingStr1, titleStr, bodyStr);
        }
        else if(v.getId() == R.id.rating_activity_review_cancel_button)
        {
            setResult(WRITING_CANCELLED);
            finish();
        }
    }

    @Override
    public void onDestroy()
    {
        disposables.dispose();

        super.onDestroy();
    }

    private void getMyReviewFunc(String tmpSkuStr)
    {
        mWeb.getMyReview(tmpSkuStr,
                new Consumer<ResponseGetMyReviewData>()
                {
                    @Override
                    public void accept(ResponseGetMyReviewData objDatas) throws Exception
                    {
                        // TODO: Handle response.

                        String serverResult = objDatas.getResult();
                        Review serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            Review tmpData = serverData;
                            String idStr = tmpData.getReviewId();
                            String rating1Str = tmpData.getRating1();
                            //String rating2Str = tmpData.getRating2();
                            String titleStr = tmpData.getTitle();
                            String detailStr = tmpData.getDetail();
                            String nickStr = tmpData.getNickname();
                            String createdStr = tmpData.getCreatedAt();

                            mTitleEdit.setText(titleStr);
                            mBodyEdit.setText(detailStr);

                            mRating1.setRating(Float.valueOf(rating1Str));
                            //mRating2.setRating(Float.valueOf(rating2Str));
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if(serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getMyReviewFunc(tmpSkuStr);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getMyReviewFunc(tmpSkuStr);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true) {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener() {
                                @Override
                                public void onAutoLoginSuccess() {
                                    getMyReviewFunc(tmpSkuStr);
                                }

                                @Override
                                public void onAutoLoginFail() {
                                    startManualLogin(new LoginListener() {
                                        @Override
                                        public void onLoginSuccess() {
                                            getMyReviewFunc(tmpSkuStr);
                                        }

                                        @Override
                                        public void onLoginCancel() {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void setMyReviewFunc(String tmpSkuStr, String ratingStr1, String titleStr, String bodyStr)
    {
        mWeb.setMyReview(tmpSkuStr, ratingStr1, "", titleStr, bodyStr,
                new Consumer<ResponseSetMyReviewData>()
                {
                    @Override
                    public void accept(ResponseSetMyReviewData objDatas) throws Exception
                    {
                        // TODO: Handle response.

                        String serverResult = objDatas.getResult();
                        String serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            FragmentManager fm = getFragmentManager();
                            if(mGeneralAlarmDialog != null)
                            {
                                mGeneralAlarmDialog.dismiss();
                                mGeneralAlarmDialog = null;
                            }
                            mGeneralAlarmDialog = new GeneralAlarmDialog();
                            mGeneralAlarmDialog.setTitleText(getString(R.string.completed));
                            mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
                            mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
                            {
                                @Override
                                public void onButtonClickListener(View v, int id, int button)
                                {
                                    setResult(WRITING_FINISHED);
                                    finish();
                                }
                            });
                            mGeneralAlarmDialog.show(fm, "tag");
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if(serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    setMyReviewFunc(tmpSkuStr, ratingStr1, titleStr, bodyStr);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            setMyReviewFunc(tmpSkuStr, ratingStr1, titleStr, bodyStr);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true) {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener() {
                                @Override
                                public void onAutoLoginSuccess() {
                                    setMyReviewFunc(tmpSkuStr, ratingStr1, titleStr, bodyStr);
                                }

                                @Override
                                public void onAutoLoginFail() {
                                    startManualLogin(new LoginListener() {
                                        @Override
                                        public void onLoginSuccess() {
                                            setMyReviewFunc(tmpSkuStr, ratingStr1, titleStr, bodyStr);
                                        }

                                        @Override
                                        public void onLoginCancel() {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }
}
