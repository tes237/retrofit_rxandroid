package etm.main.market.activities;

import io.reactivex.Completable;
import io.reactivex.CompletableObserver;
import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.common.BlurTransformation;
import etm.main.market.common.CircleTransformation;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.generalApplication;
import etm.main.market.lists.CustomItemDecoration;
import etm.main.market.lists.InfoAdapter;
import etm.main.market.lists.InfoListListener;
import etm.main.market.lists.PurchasedInfoAdapter;
import etm.main.market.lists.PurchasedInfoListListener;
import etm.main.market.lists.RouteInfoAdapter;
import etm.main.market.lists.SaleInfoAdapter;
import etm.main.market.lists.SaleInfoListListener;
import etm.main.market.parser.json.JsonParser;
import etm.main.market.vo.MapFile;
import etm.main.market.vo.MapFiles;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.ResponseMapFilesData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponseSalesData;
import etm.main.market.vo.ResponseUploadImageData;
import etm.main.market.vo.Route;
import etm.main.market.vo.Sale;
import etm.main.market.vo.Sales;
import etm.main.market.vo.ServerMapData;
import etm.main.market.vo.ServerMapRouteData;
import etm.main.market.widgets.roundedImage.MLRoundedImageView;
import etm.main.market.widgets.swipyLayout.*;

import android.annotation.SuppressLint;
import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Message;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.Callable;

public class RouteListActivity extends BaseActivity implements baseDefine, SaleInfoListListener, View.OnClickListener
{
    private static final String TAG = RouteListActivity.class.getSimpleName();

    private  String APP_DIRECTORY;

    private GeneralAlarmDialog mGeneralAlarmDialog;

    private RecyclerView mRecyclerView;
    //SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayoutManager mLayoutManager;
    private RouteInfoAdapter mRouteInfoAdapter;
    private SwipyRefreshLayout mSwipyRefreshLayout;
    private TextView mTextView;
    private ImageButton mBackButton;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private DBAdapter mDBAdapter;
    private ImageView mTopBackgroundImage;
    private ImageView mRoundImageView;

    private List<Route> mRouteList;
    public String mUserDir = "";
    private String mSkuStr = "";
    private String mTitleStr = "";

    ServerMapData mapData = null;

    private int mIsTestMap = 0;
    private String mMapImageUrl = "";

    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mGeneralApplication.setTick("---------- RouteList first");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_route_list);

        mGeneralApplication.setTick("RouteList setContentView");

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();

        String tmpUserIdStr = mGeneralApplication.getIdString();
        mUserDir = Base64.mod_encode(tmpUserIdStr);


        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mSkuStr = bd.getString(CategoryListActivity.MAP_SKU);
            mIsTestMap = bd.getInt(CategoryListActivity.IS_TEST_MAP);
            mMapImageUrl = bd.getString(CategoryListActivity.MAP_IMAGE_URL);
            mTitleStr = bd.getString(CategoryListActivity.MAP_TITLE);
        }

        mGeneralApplication.setTick("RouteList getIntent");

        mSwipyRefreshLayout = (SwipyRefreshLayout)findViewById(R.id.tourguide_swipy_layout);
        mRecyclerView = (RecyclerView)findViewById(R.id.tourguide_recycler_view);
        mTextView = (TextView)findViewById(R.id.list_activity_title_textview);
        mBackButton = (ImageButton)findViewById(R.id.list_activity_back_button);
        mBackButton.setOnClickListener(this);

        mTopBackgroundImage = (ImageView)findViewById(R.id.top_background_image);
        mRoundImageView = (ImageView)findViewById(R.id.map_photo);

        DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics();
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        int fontSize = width/43;

        mTextView.setText(mTitleStr);

        mRecyclerView.setHasFixedSize(true);

        mRecyclerView.addItemDecoration(new CustomItemDecoration(getResources().getDrawable(R.drawable.abc_list_divider_mtrl_alpha)));
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mRouteList = new ArrayList<Route>();
        mRouteInfoAdapter = new RouteInfoAdapter(RouteListActivity.this, mRouteList, this);
        mRecyclerView.setAdapter(mRouteInfoAdapter);

        mGeneralApplication.setTick("RouteList ui var init");

        Completable.fromCallable(new Callable<Void>()
        {
            @Override
            public Void call() throws Exception
            {
                mDBAdapter = new DBAdapter(RouteListActivity.this);
                mDBAdapter.create();
                mDBAdapter.install();
                mDBAdapter.open();

                int ret = loadMapArray();
                if(ret < 0)
                {
                    Message msg = mRouteListMainHandler.obtainMessage();
                    Bundle b = new Bundle();
                    b.putString("type", "map_open_error");
                    msg.setData(b);
                    mRouteListMainHandler.sendMessage(msg);

                    return null;
                }

                List<ServerMapRouteData> tmpRouteLists = mapData.getRoute();

                for(int x = 0; x < tmpRouteLists.size(); x++)
                {
                    ServerMapRouteData tmpRoute = tmpRouteLists.get(x);

                    String titleStr = tmpRoute.getTitle();
                    //titleStr = URLDecoder.decode(titleStr, "UTF-8");
                    mRouteList.add(new Route(titleStr));
                }

                clearMapArray();

                mGeneralApplication.setTick("RouteList load map");

                Message msg = mRouteListMainHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putString("type", "refresh_all");
                msg.setData(b);
                mRouteListMainHandler.sendMessage(msg);

                return null;
            }
        })
        .subscribeOn(Schedulers.io())
        .observeOn(Schedulers.io())
        .subscribe(new CompletableObserver()
        {
            @Override
            public void onSubscribe(Disposable d) {}

            @Override
            public void onComplete()
            {
            }

            @Override
            public void onError(Throwable error)
            {
            }
        });

    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        Intent i = new Intent(RouteListActivity.this, PlayerActivity.class);
        i.putExtra(MAP_SKU, mSkuStr);
        i.putExtra(ROUTE_INDEX, index);
        i.putExtra(IS_TEST_MAP, mIsTestMap);

        startActivity(i);
    }


    void refreshItems()
    {
        // Load items
        // ...

        // Load complete
        onItemsLoadComplete();
    }

    void onItemsLoadComplete()
    {
        // Update the adapter and notify data set changed
        // ...

        // Stop refresh animation
        mSwipyRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.list_activity_back_button)
        {
            finish();
        }
    }

    public static String convertToUTF8(String inputStr)
    {
        String outStr = null;
        try
        {
            outStr = new String(inputStr.getBytes("UTF-8"), "ISO-8859-1");
        }
        catch (java.io.UnsupportedEncodingException e)
        {
            return null;
        }
        return outStr;
    }

    @Override
    public void onDestroy()
    {
        disposables.dispose();

        mDBAdapter.close();

        super.onDestroy();
    }

    public void clearMapArray()
    {
        mapData = null;
    }

    public int loadMapArray()
    {
        FileInputStream tmpInput = null;
        try
        {
            Cursor localCursor = null;
            try
            {
                if(mIsTestMap == TYPE_TEST_MAP)
                {
                    localCursor = mDBAdapter.getFileNameForTestMap(mSkuStr, "map", mUserDir);
                }
                else
                {
                    localCursor = mDBAdapter.getFileName(mSkuStr, "map", mUserDir);
                }
            }
            catch(SQLException sqe)
            {
                sqe.printStackTrace();
                return -1;
            }

            String tmpJsonFile = "";
            if(localCursor.moveToFirst())
            {
                tmpJsonFile = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FILE_NAME));
            }
            String localPathStr = "";

            if(mIsTestMap == TYPE_TEST_MAP)
            {
                localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + tmpJsonFile;
            }
            else
            {
                localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/" +  mSkuStr + "/" + tmpJsonFile;
            }

            //tmpInput = new FileInputStream(new File("/storage/sdcard0/tourguide_001.json"));
            tmpInput = new FileInputStream(new File(localPathStr));
            JsonParser jsonParser = new JsonParser();
            try
            {
                mapData = jsonParser.parse(tmpInput);
            }
            catch (IOException e)
            {
                e.printStackTrace();
                return -1;
            }
            catch (JSONException je)
            {
                je.printStackTrace();
                Log.e(TAG, je.getMessage());
                return -2;
            }
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            return -1;
        }
        finally
        {
            if (tmpInput != null)
            {
                try
                {
                    tmpInput.close();
                }
                catch (IOException e)
                {
                }
                tmpInput = null;
            }
        }
        return 0;
    }


    final Handler mRouteListMainHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

            String type_str = msg.getData().getString("type");

            switch (type_str)
            {
                case "refresh_all":

                    if(mIsTestMap == TYPE_TEST_MAP)
                    {
                        //Picasso.with(RouteListActivity.this)
                        Picasso.get()
                                .load(R.drawable.test_map_photo)
                                .transform(new BlurTransformation(RouteListActivity.this, 15))
                                .into(mTopBackgroundImage);

                        //Picasso.with(RouteListActivity.this).load(R.drawable.test_map_photo).transform(new CircleTransformation()).into(mRoundImageView);
                        Picasso.get().load(R.drawable.test_map_photo).transform(new CircleTransformation()).into(mRoundImageView);
                    }
                    else
                    {
                        //Picasso.with(RouteListActivity.this)
                        Picasso.get()
                                .load(mMapImageUrl)
                                .transform(new BlurTransformation(RouteListActivity.this, 15))
                                .into(mTopBackgroundImage);

                        //Picasso.with(RouteListActivity.this).load(mMapImageUrl).transform(new CircleTransformation()).into(mRoundImageView);
                        Picasso.get().load(mMapImageUrl).transform(new CircleTransformation()).into(mRoundImageView);
                    }

                    mRouteInfoAdapter.notifyDataSetChanged();


                    mGeneralApplication.setTick("RouteList background drawing");

                    break;

                case "map_open_error":
                    BaseLib().showGeneralPopup(getString(R.string.map_open_error), getString(R.string.map_open_error_desc),
                            new GeneralAlarmButtonListener()
                            {
                                @Override
                                public void onButtonClickListener(View v, int id, int button)
                                {
                                    finish();
                                }
                            });
                    return;

                default:
                    break;
            }
        }
    };
}
