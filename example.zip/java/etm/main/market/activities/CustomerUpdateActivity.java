package etm.main.market.activities;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.Callable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.reactivex.Completable;
import io.reactivex.CompletableObserver;
import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.social.FacebookHelper;
import etm.main.market.social.GooglePlusHelper;
import etm.main.market.vo.Customer;
import etm.main.market.vo.ResponseCustomerData;
import etm.main.market.vo.ResponseSendReturnData;
import etm.main.market.vo.ResponseUpdateCustomerData;
import etm.main.market.vo.ResponseUploadImageData;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class CustomerUpdateActivity extends BaseActivity implements baseDefine, View.OnClickListener
{
    private static final String TAG = CustomerUpdateActivity.class.getSimpleName();

    public static final String ACCOUNT_TYPE = "account";
    public static final String USER_NAME_TYPE = "user_name";
    public static final String PASSWORD_TYPE = "password";
    public static final String PAYOUT_TYPE = "payout";

    private static final int USER_NAME = 0;
    private static final int PASSWORD = 1;
    private static final int PAYOUT = 2;

    private ScalableLayout mSettingNameLayout;
    private ScalableLayout mSettingPasswordLayout;
    private ScalableLayout mSettingPayoutLayout;

    private Button mUpdateNameButton;
    private Button mUpdatePasswordButton;
    private Button mUpdatePayoutButton;

    private EditText mFirstNameEdit;
    private EditText mLastNameEdit;
    private EditText mNickNameEdit;

    private EditText mUpdatePasswdEdit;
    private EditText mUpdatePasswdConfirmEdit;
    private EditText mUpdatePayoutEmailEdit;
    private EditText mUpdatePayoutMinMoneyEdit;
    private ImageButton mBackButton;
    private ImageView mPaypalCheckButton;
    private ImageView mSkrillCheckButton;

    private ImageView mPaypalImage;
    private ImageView mSkrillImage;

    private boolean isPaypalChecked = true;
    private boolean isSkrillChecked = false;

    protected generalApplication mGeneralApplication = null;
    private WebManager mWeb;
    private GeneralAlarmDialog mGeneralAlarmDialog = null;

    public String mUserDir = "";
    private  String APP_DIRECTORY;

    private Bitmap mProfileImage = null;
    private int mAccountType = 0;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private DBAdapter mDBAdapter = null;

    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();
        String tmpUserIdStr = mGeneralApplication.getIdString();
        mUserDir = etm.main.market.common.Base64.mod_encode(tmpUserIdStr);

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_customer);

        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            String tmpAccountType = bd.getString(CustomerUpdateActivity.ACCOUNT_TYPE);
            if(USER_NAME_TYPE.equals(tmpAccountType) == true)
            {
                mAccountType = USER_NAME;
            }
            else if(PASSWORD_TYPE.equals(tmpAccountType) == true)
            {
                mAccountType = PASSWORD;
            }
            else //if(PAYOUT_TYPE.equals(tmpAccountType) == true)
            {
                mAccountType = PAYOUT;
            }
        }

        mSettingNameLayout = (ScalableLayout)findViewById(R.id.setting_name_layout);
        mSettingPasswordLayout = (ScalableLayout)findViewById(R.id.setting_password_layout);
        mSettingPayoutLayout = (ScalableLayout)findViewById(R.id.setting_payout_layout);

        //mProfileImageView = (ImageView)findViewById(R.id.update_customer_title_text);
        mFirstNameEdit = (EditText)findViewById(R.id.update_first_name_edit);
        mLastNameEdit = (EditText)findViewById(R.id.update_last_name_edit);
        mNickNameEdit = (EditText)findViewById(R.id.update_nick_name_edit);
        mUpdatePasswdEdit = (EditText)findViewById(R.id.update_passwd_edit);
        mUpdatePasswdConfirmEdit = (EditText)findViewById(R.id.update_passwd_confirm_edit);
        mUpdatePayoutEmailEdit = (EditText)findViewById(R.id.update_payout_email_edit);
        mUpdatePayoutMinMoneyEdit = (EditText)findViewById(R.id.update_payout_min_money_edit);

        mUpdateNameButton = (Button) findViewById(R.id.update_name_submit_button);
        mUpdatePasswordButton = (Button) findViewById(R.id.update_password_submit_button);
        mUpdatePayoutButton = (Button) findViewById(R.id.update_payout_submit_button);

        mBackButton = (ImageButton)findViewById(R.id.user_info_activity_back_button);
        mPaypalCheckButton = (ImageView)findViewById(R.id.update_paypal_check_button);
        mSkrillCheckButton = (ImageView)findViewById(R.id.update_skrill_check_button);

        mPaypalImage = (ImageView)findViewById(R.id.update_paypal_check_text);
        mSkrillImage = (ImageView)findViewById(R.id.update_skrill_check_text);

        if(mAccountType == USER_NAME)
        {
            mSettingNameLayout.setVisibility(View.VISIBLE);
            mSettingPasswordLayout.setVisibility(View.GONE);
            mSettingPayoutLayout.setVisibility(View.GONE);
        }
        else if(mAccountType == PASSWORD)
        {
            mSettingNameLayout.setVisibility(View.GONE);
            mSettingPasswordLayout.setVisibility(View.VISIBLE);
            mSettingPayoutLayout.setVisibility(View.GONE);
        }
        else //if(mAccountType == PAYOUT)
        {
            mSettingNameLayout.setVisibility(View.GONE);
            mSettingPasswordLayout.setVisibility(View.GONE);
            mSettingPayoutLayout.setVisibility(View.VISIBLE);
        }

        mBackButton.setOnClickListener(this);
        mUpdateNameButton.setOnClickListener(this);
        mUpdatePasswordButton.setOnClickListener(this);
        mUpdatePayoutButton.setOnClickListener(this);
        //mProfileImageView.setOnClickListener(this);

        mPaypalCheckButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                isPaypalChecked = true;
                isSkrillChecked = false;

                mPaypalCheckButton.setImageResource(R.drawable.radio_on_button);
                mSkrillCheckButton.setImageResource(R.drawable.radio_off_button);

                mPaypalImage.setBackgroundResource(R.drawable.paypal_on);
                mSkrillImage.setBackgroundResource(R.drawable.skrill_off);
            }
        });

        mSkrillCheckButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                isPaypalChecked = false;
                isSkrillChecked = true;

                mPaypalCheckButton.setImageResource(R.drawable.radio_off_button);
                mSkrillCheckButton.setImageResource(R.drawable.radio_on_button);

                mPaypalImage.setBackgroundResource(R.drawable.paypal_off);
                mSkrillImage.setBackgroundResource(R.drawable.skrill_on);
            }
        });

        getWindow().setSoftInputMode(
                //WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        );

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        getCustomerFunc();
    }

    private void getCustomerFunc()
    {
        mWeb.get_customer(
                new Consumer<ResponseCustomerData>()
                {
                    @Override
                    public void accept(ResponseCustomerData registerDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = registerDatas.getResult();
                        Customer serverData = registerDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mFirstNameEdit.setText(serverData.getFirst_name());
                            mLastNameEdit.setText(serverData.getLast_name());
                            mNickNameEdit.setText(serverData.getNick_name());
                            mUpdatePasswdEdit.setText(serverData.getPasswd());
                            mUpdatePasswdConfirmEdit.setText("");

                            mUpdatePayoutEmailEdit.setText(serverData.getPaymeny_email());
                            mUpdatePayoutMinMoneyEdit.setText(serverData.getMinimum_payout());

                            if(serverData.getPayment_method() == 0)
                            {
                                isPaypalChecked = true;
                                isSkrillChecked = false;
                                mPaypalCheckButton.setImageResource(R.drawable.radio_on_button);
                                mSkrillCheckButton.setImageResource(R.drawable.radio_off_button);

                                mPaypalImage.setBackgroundResource(R.drawable.paypal_on);
                                mSkrillImage.setBackgroundResource(R.drawable.skrill_off);
                            }
                            else
                            {
                                isPaypalChecked = false;
                                isSkrillChecked = true;
                                mPaypalCheckButton.setImageResource(R.drawable.radio_off_button);
                                mSkrillCheckButton.setImageResource(R.drawable.radio_on_button);

                                mPaypalImage.setBackgroundResource(R.drawable.paypal_off);
                                mSkrillImage.setBackgroundResource(R.drawable.skrill_on);
                            }
                        }
                        else if(serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getCustomerFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getCustomerFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(registerDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getCustomerFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getCustomerFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void showAlarmDialogWithFinish(String title, String message)
    {
        FragmentManager fm = getFragmentManager();
        if(mGeneralAlarmDialog != null)
        {
            mGeneralAlarmDialog.dismiss();
            mGeneralAlarmDialog = null;
        }
        mGeneralAlarmDialog = new GeneralAlarmDialog();
        mGeneralAlarmDialog.setTitleText(title);
        mGeneralAlarmDialog.setMessageText(message);
        mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
        {
            @Override
            public void onButtonClickListener(View v, int id, int button)
            {
                finish();
            }
        });
        mGeneralAlarmDialog.show(fm, "tag");
    }

    private void saveName(String firstName, String lastName, String nickName)
    {
        mWeb.update_customer_name(firstName, lastName, nickName,
                new Consumer<ResponseUpdateCustomerData>()
                {
                    @Override
                    public void accept(ResponseUpdateCustomerData registerDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = registerDatas.getResult();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            showAlarmDialogWithFinish(getString(R.string.setting_succcess_title), getString(R.string.update_setting_message));
                        }
                        else if(serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    saveName(firstName, lastName, nickName);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            saveName(firstName, lastName, nickName);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            //showAlarmDialog(getString(R.string.setting_error_title), getString(R.string.setting_failed));
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(registerDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        //BaseLib().showGeneralPopup(getString(R.string.setting_error_title), getString(R.string.setting_failed), null);
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    saveName(firstName, lastName, nickName);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            saveName(firstName, lastName, nickName);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void savePassword(String password)
    {
        mWeb.update_customer_password(password,
                new Consumer<ResponseUpdateCustomerData>()
                {
                    @Override
                    public void accept(ResponseUpdateCustomerData registerDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = registerDatas.getResult();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            showAlarmDialogWithFinish(getString(R.string.setting_succcess_title), getString(R.string.update_setting_message));
                        }
                        else if(serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    savePassword(password);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            savePassword(password);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            //showAlarmDialog(getString(R.string.setting_error_title), getString(R.string.setting_failed));
                            showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(registerDatas.getResultCode()),
                                    new GeneralAlarmButtonListener()
                                    {
                                        @Override
                                        public void onButtonClickListener(View v, int id, int button)
                                        {

                                        }
                                    });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        //BaseLib().showGeneralPopup(getString(R.string.setting_error_title), getString(R.string.setting_failed), null);
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    savePassword(password);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            savePassword(password);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void savePayout(String method, String payout_email, String min)
    {
        mWeb.update_customer_payout(method, payout_email, min,
                new Consumer<ResponseUpdateCustomerData>()
                {
                    @Override
                    public void accept(ResponseUpdateCustomerData registerDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = registerDatas.getResult();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            showAlarmDialogWithFinish(getString(R.string.setting_succcess_title), getString(R.string.update_setting_message));
                        }
                        else if(serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    savePayout(method, payout_email, min);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            savePayout(method, payout_email, min);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            //showAlarmDialog(getString(R.string.setting_error_title), getString(R.string.setting_failed));
                            showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(registerDatas.getResultCode()),
                                    new GeneralAlarmButtonListener()
                                    {
                                        @Override
                                        public void onButtonClickListener(View v, int id, int button)
                                        {

                                        }
                                    });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        //BaseLib().showGeneralPopup(getString(R.string.setting_error_title), getString(R.string.setting_failed), null);
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    savePayout(method, payout_email, min);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            savePayout(method, payout_email, min);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }

    public static boolean isValidPassword(String pswd)
    {
        //String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,16})";
        String PASSWORD_PATTERN = "(?=.*\\d)(?=.*[$@$!%*?&#^])([A-Za-z\\d$@$!%*?&#^]{8,})";
        Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
        Matcher matcher = pattern.matcher(pswd);
        return matcher.matches();
    }

    @Override
    protected void onDestroy()
    {
        disposables.dispose();

        super.onDestroy();
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.user_info_activity_back_button)
        {
            finish();
        }
        else if(v.getId() == R.id.update_name_submit_button)
        {
            String tmpFirstName = mFirstNameEdit.getText().toString();
            String tmpLastName = mLastNameEdit.getText().toString();
            String tmpNickName = mNickNameEdit.getText().toString();

            if(
                    ("".equals(tmpFirstName) == true) ||
                            ("".equals(tmpLastName) == true) ||
                            ("".equals(tmpNickName) == true)
                    )
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled), null);
                return;
            }

            if(tmpFirstName.length() > 30)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.first_name_should_be_less_than_30), null);
                return;
            }

            if(tmpLastName.length() > 30)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.last_name_should_be_less_than_30), null);
                return;
            }

            if(tmpNickName.length() > 30)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.nick_name_should_be_less_than_30), null);
                return;
            }

            saveName(tmpFirstName, tmpLastName, tmpNickName);
        }
        else if(v.getId() == R.id.update_password_submit_button)
        {
            mUpdatePasswdEdit = (EditText)findViewById(R.id.update_passwd_edit);
            mUpdatePasswdConfirmEdit = (EditText)findViewById(R.id.update_passwd_confirm_edit);

            String password1 = mUpdatePasswdEdit.getText().toString();
            String password2 = mUpdatePasswdConfirmEdit.getText().toString();

            if("".equals(password1) == true)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled), null);
                return;
            }

            if(password1.equals(password2) == false)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.passwords_are_not_same), null);
                return;
            }

            if(password1.length() < 8 )
            {
                BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.password_length_should_be_at_least_8), null);
                return;
            }

            if(isValidPassword(password1) == false)
            {
                BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.password_should_contain_alphabet_digit_special_characters), null);
                return;
            }


            savePassword(password1);
        }
        else if(v.getId() == R.id.update_payout_submit_button)
        {
            String mathod = "";
            String tmpEmail = mUpdatePayoutEmailEdit.getText().toString();
            String tmpMin = mUpdatePayoutMinMoneyEdit.getText().toString();

            if(
                    ("".equals(tmpEmail) == true) ||
                            ("".equals(tmpMin) == true)
                    )
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.setting_should_be_filled), null);
                return;
            }

            int tmpMinVal = 0;
            try
            {
                tmpMinVal = Integer.parseInt(tmpMin);
            }
            catch (Exception e)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.min_payout_should_be_number), null);
                return;
            }

            if(tmpMinVal < 35 || tmpMinVal > 2000)
            {
                BaseLib().showGeneralPopup(getString(R.string.setting_input_error_title), getString(R.string.min_payout_should_be_between_35_and_2000), null);
                return;
            }

            //private boolean isPaypalChecked = true;
            //private boolean isSkrillChecked = false;
            if(isPaypalChecked == true)
            {
                mathod = "paypal";
            }
            else
            {
                mathod = "skrill";
            }

            savePayout(mathod, tmpEmail, tmpMin);
        }
    }

}
