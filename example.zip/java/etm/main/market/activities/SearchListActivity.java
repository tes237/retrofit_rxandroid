package etm.main.market.activities;

import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.connects.WebManager;
import etm.main.market.dialog.FilterButtonListener;
import etm.main.market.dialog.FilterDialog;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.dialog.GeneralProgressDialog;
import etm.main.market.dialog.SearchFilterDialog;
import etm.main.market.dialog.SearchFilterListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.InfoAdapter;
import etm.main.market.lists.InfoListListener;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.widgets.swipyLayout.*;
import etm.main.market.widgets.tagview.Tag;
import etm.main.market.widgets.tagview.TagView;


import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SearchListActivity extends BaseActivity implements baseDefine, InfoListListener, View.OnClickListener
{
    private static final String TAG = SearchListActivity.class.getSimpleName();
    public static final String MAP_SKU = "map_sku";
    public static final String MAP_TITLE = "map_title";

    public static final int TRANSPORTATION_TYPE = 0;
    public static final int SPECIAL_MEALS_TYPE = 1;
    public static final int THEME_TYPE = 2;
    public static final int DURATION_TYPE = 3;

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private InfoAdapter mInfoAdapter;
    private SwipyRefreshLayout mSwipyRefreshLayout;
    private TextView mTextView;
    private ImageButton mBackButton;
    private Button mSearchFilterButton;

    private ImageButton mTransportationButton;
    private ImageButton mMealsButton;
    private ImageButton mThemesButton;
    private ImageButton  mDurationButton;

    private GeneralProgressDialog pd;
    private GeneralAlarmDialog mGeneralAlarmDialog;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;

    private List<Product> mDataList;
    private String []mSearchKeywordArr = null;

    //private FilterDialog mFilterDialog;
    private SearchFilterDialog mTGSearchFilterDialog;

    private String mExclusiveFoodArrStr = "", mTransArrStr = "", mThemeArrStr = "", mDurationArrStr = "";

    private int mCurrentPageIndex = 1;
    private int mTotalPageCount = 1;

    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        pd = new GeneralProgressDialog(this, R.drawable.spinner);
        pd.show();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_search_list);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        //String keywordsStr[] = null;
        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mSearchKeywordArr = bd.getStringArray(SearchActivity.KEYWORDS);
        }

        mSwipyRefreshLayout = (SwipyRefreshLayout)findViewById(R.id.tourguide_swipy_layout);
        mRecyclerView = (RecyclerView)findViewById(R.id.tourguide_recycler_view);
        //mSearchFilterView = (TagView)findViewById(R.id.search_filter_tagview);
        mTextView = (TextView)findViewById(R.id.list_activity_title_textview);
        mBackButton = (ImageButton)findViewById(R.id.list_activity_back_button);

        mTransportationButton = (ImageButton)findViewById(R.id.list_activity_transportation_button);
        mMealsButton = (ImageButton)findViewById(R.id.list_activity_special_meals_button);
        mThemesButton = (ImageButton)findViewById(R.id.list_activity_trip_themes_button);
        mDurationButton = (ImageButton)findViewById(R.id.list_activity_trip_duration_button);

        mBackButton.setOnClickListener(this);

        mTransportationButton.setOnClickListener(this);
        mMealsButton.setOnClickListener(this);
        mThemesButton.setOnClickListener(this);
        mDurationButton.setOnClickListener(this);

        mTextView.setText(mSearchKeywordArr[0]);

        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mDataList = new ArrayList<Product>();
        mInfoAdapter = new InfoAdapter(SearchListActivity.this, mDataList, this);
        mRecyclerView.setAdapter(mInfoAdapter);

        if(mSearchKeywordArr[0] == null)
        {
            mSearchKeywordArr[0] = "";
        }


        mDataList.clear();

        mSwipyRefreshLayout.setDirection(SwipyRefreshLayoutDirection.BOTTOM);

        mSwipyRefreshLayout.setOnRefreshListener(new SwipyRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(SwipyRefreshLayoutDirection direction)
            {
                if(mTotalPageCount < mCurrentPageIndex + 1)
                {
                    mSwipyRefreshLayout.setRefreshing(false);
                    return;
                }

                mCurrentPageIndex++;

                loadSearchKeyword();

                mSwipyRefreshLayout.setRefreshing(false);
            }
        });

        loadSearchKeyword();
    }

    private void loadSearchKeyword()
    {
        //mExclusiveFoodArrStr, mTransArrStr, mThemeArrStr, mDurationArrStr);
        mWeb.searchProductsByKeywords(mSearchKeywordArr[0], mExclusiveFoodArrStr, mTransArrStr, mThemeArrStr, mDurationArrStr,  DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex),
                new Consumer<ResponseProductsData>()
                {
                    @Override
                    public void accept(ResponseProductsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Products serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            for(int x = 0; x < serverData.getProducts().size(); x++)
                            {
                                Product tmpData = serverData.getProducts().get(x);
                                String skuStr = tmpData.getSku();
                                String nameStr = tmpData.getName();
                                String imageUrlStr = tmpData.getImage1();
                                String priceStr = tmpData.getPrice();
                                int rating1 = tmpData.getRating1();
                                mDataList.add(new Product(skuStr, imageUrlStr, nameStr, priceStr, 0, 0, rating1, ""));
                            }
                            mInfoAdapter.notifyDataSetChanged();
                            pd.dismiss();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            pd.dismiss();
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        pd.dismiss();
                    }
                }, disposables
        );
    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        Product tmpData = mDataList.get(index);
        String idStr = tmpData.getSku();
        String storeId = tmpData.getStoreLanaguage();



        Intent i = new Intent(SearchListActivity.this, IntroActivity.class);
        i.putExtra(MAP_SKU, idStr);
        i.putExtra(IntroActivity.FROM, IntroActivity.SEARCH_RESULT);
        startActivityForResult(i, 0);
    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.list_activity_back_button)
        {
            finish();
        }
        else if(v.getId() == R.id.list_activity_transportation_button)
        {
            showFilterDialog(TRANSPORTATION_TYPE);
        }
        else if(v.getId() == R.id.list_activity_special_meals_button)
        {
            showFilterDialog(SPECIAL_MEALS_TYPE);
        }
        else if(v.getId() == R.id.list_activity_trip_themes_button)
        {
            showFilterDialog(THEME_TYPE);
        }
        else if(v.getId() == R.id.list_activity_trip_duration_button)
        {
            showFilterDialog(DURATION_TYPE);
        }
    }

    public static String convertToUTF8(String inputStr)
    {
        String outStr = null;
        try
        {
            outStr = new String(inputStr.getBytes("UTF-8"), "ISO-8859-1");
        }
        catch (java.io.UnsupportedEncodingException e)
        {
            return null;
        }
        return outStr;
    }

    @Override
    public void onDestroy()
    {
        disposables.dispose();

        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == PAYMENT_FINISHED)
        {
            setResult(PAYMENT_FINISHED);
            finish();
        }
    }

    private void showErrorPopyp()
    {
        FragmentManager fm = getFragmentManager();
        if(mGeneralAlarmDialog != null)
        {
            mGeneralAlarmDialog.dismiss();
            mGeneralAlarmDialog = null;
        }
        mGeneralAlarmDialog = new GeneralAlarmDialog();
        mGeneralAlarmDialog.setTitleText(getString(R.string.filter_error_title));
        mGeneralAlarmDialog.setMessageText(getString(R.string.please_select_any_filter));
        mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
        {
            @Override
            public void onButtonClickListener(View v, int id, int button)
            {

            }
        });
        mGeneralAlarmDialog.show(fm, "tag");
        return;
    }

    private void showFilterDialog(int type)
    {
        FragmentManager fm = getFragmentManager();
        if(mTGSearchFilterDialog != null)
        {
            mTGSearchFilterDialog.dismiss();
            mTGSearchFilterDialog = null;
        }
        mTGSearchFilterDialog = new SearchFilterDialog();

        if(type == TRANSPORTATION_TYPE)
        {
            mTGSearchFilterDialog.setTitle(getString(R.string.transportation_filter_title));
            mTGSearchFilterDialog.setType(TRANSPORTATION_TYPE);
        }
        else if(type == SPECIAL_MEALS_TYPE)
        {
            mTGSearchFilterDialog.setTitle(getString(R.string.meal_filter_title));
            mTGSearchFilterDialog.setType(SPECIAL_MEALS_TYPE);
        }
        else if(type == THEME_TYPE)
        {
            mTGSearchFilterDialog.setTitle(getString(R.string.theme_filter_title));
            mTGSearchFilterDialog.setType(THEME_TYPE);
        }
        else if(type == DURATION_TYPE)
        {
            mTGSearchFilterDialog.setTitle(getString(R.string.duration_filter_title));
            mTGSearchFilterDialog.setType(DURATION_TYPE);
        }

        mTGSearchFilterDialog.setFilter(mExclusiveFoodArrStr, mTransArrStr, mThemeArrStr, mDurationArrStr);
        mTGSearchFilterDialog.setOptionListener(new SearchFilterListener()
        {
            @Override
            public void onButtonClickListener(View v, String exclusive_food_filters, String trans_arr_str, String theme_arr_str, String duration_arr_str)
            {
                if(type == TRANSPORTATION_TYPE)
                {
                    mTransArrStr = trans_arr_str;

                    if("".equals(trans_arr_str) == true)
                    {
                        showErrorPopyp();
                        return;
                    }
                }
                else if(type == SPECIAL_MEALS_TYPE)
                {
                    mExclusiveFoodArrStr = exclusive_food_filters;
                }
                else if(type == THEME_TYPE)
                {
                    mThemeArrStr = theme_arr_str;

                    if("".equals(theme_arr_str) == true)
                    {
                        showErrorPopyp();
                        return;
                    }
                }
                else if(type == DURATION_TYPE)
                {
                    mDurationArrStr = duration_arr_str;

                    if("".equals(duration_arr_str) == true)
                    {
                        showErrorPopyp();
                        return;
                    }
                }

                pd = new GeneralProgressDialog(SearchListActivity.this, R.drawable.spinner);
                pd.show();

                mDataList.clear();
                loadSearchKeyword();

                mTGSearchFilterDialog.dismiss();
            }
        });
        mTGSearchFilterDialog.show(fm, "tag");
    }


}
