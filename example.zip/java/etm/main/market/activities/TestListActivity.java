package etm.main.market.activities;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.MapInfoListAdapter;
import etm.main.market.lists.PurchasedInfoListListener;
import etm.main.market.vo.MapFile;
import etm.main.market.vo.MapFiles;
import etm.main.market.vo.MapItem;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.ResponseMapFilesData;
import etm.main.market.vo.ResponseTestMapsData;
import etm.main.market.vo.TestMap;
import etm.main.market.vo.TestMaps;
import etm.main.market.widgets.swipyLayout.*;

import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteException;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

public class TestListActivity extends BaseActivity implements baseDefine, PurchasedInfoListListener, View.OnClickListener
{
    private static final String TAG = CategoryListActivity.class.getSimpleName();

    public String mUserDir = "";
    private  String APP_DIRECTORY;

    RecyclerView mRecyclerView;
    //SwipeRefreshLayout mSwipeRefreshLayout;
    LinearLayoutManager mLayoutManager;
    MapInfoListAdapter mMapInfoListAdapter;
    SwipyRefreshLayout mSwipyRefreshLayout;
    TextView mTextView;
    ImageButton mBackButton;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private GeneralAlarmDialog mGeneralAlarmDialog = null;

    private DBAdapter mDBAdapter;

    private List<MapItem> mDataList;
    private List<Integer> mDownloadStatusList;
    private boolean mIsDownloadStarted = false;

    private boolean mIsDownloadStop = false;

    LinkedHashMap<String, Long> tmpPrevWholeReceivedFileSizeMap = new LinkedHashMap<String, Long>();
    LinkedHashMap<String, Long> tmpPrevWholeReceivedFilePercentMap = new LinkedHashMap<String, Long>();

    private int mCurrentPageIndex = 1;
    private int mTotalPageCount = 1;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_map_test_list);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();

        String tmpUserIdStr = mGeneralApplication.getIdString();
        mUserDir = Base64.mod_encode(tmpUserIdStr);

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        mSwipyRefreshLayout = (SwipyRefreshLayout)findViewById(R.id.tourguide_swipy_layout);
        mRecyclerView = (RecyclerView)findViewById(R.id.tourguide_recycler_view);
        mTextView = (TextView)findViewById(R.id.list_activity_title_textview);
        mBackButton = (ImageButton)findViewById(R.id.list_activity_back_button);
        mBackButton.setOnClickListener(this);

        DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics();
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        int fontSize = width/43;

        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mDataList = new ArrayList<MapItem>();
        mDownloadStatusList = new ArrayList<Integer>();
        mMapInfoListAdapter = new MapInfoListAdapter(TestListActivity.this, mDataList, this);
        mRecyclerView.setAdapter(mMapInfoListAdapter);

        tmpPrevWholeReceivedFileSizeMap.clear();
        tmpPrevWholeReceivedFilePercentMap.clear();

        mSwipyRefreshLayout.setDirection(SwipyRefreshLayoutDirection.BOTTOM);
        mSwipyRefreshLayout.setOnRefreshListener(new SwipyRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(SwipyRefreshLayoutDirection direction)
            {
                if(mTotalPageCount < mCurrentPageIndex + 1)
                {
                    mSwipyRefreshLayout.setRefreshing(false);
                    return;
                }

                mCurrentPageIndex++;

                getTestMapListFunc();

                mSwipyRefreshLayout.setRefreshing(false);
            }
        });

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        mDataList.clear();
        mDownloadStatusList.clear();

        getTestMapListFunc();
    }

    private void getTestMapListFunc()
    {
        mWeb.getTestMapList(DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex),
                new Consumer<ResponseTestMapsData>()
                {
                    @Override
                    public void accept(ResponseTestMapsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        TestMaps serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            if(serverData.getMaps() == null)
                            {
                                return;
                            }

                            for(int x = 0; x < serverData.getMaps().size(); x++)
                            {
                                TestMap tmpData = serverData.getMaps().get(x);
                                String idStr = tmpData.getMapId();
                                String titleStr = tmpData.getTitle();
                                int verified = tmpData.getVerified();

                                long transactionIndex = tmpData.getModifyTransactionIndex();
                                long updateTimne = tmpData.getUpdateTime();
                                String tmpUserIdStr = mGeneralApplication.getIdString();

                                //titleStr = URLDecoder.decode(titleStr, "utf-8");

                                //printAllMapVersionsForTestMap();

                                Cursor localCursor = mDBAdapter.getOneVersionForTestMap(idStr, mUserDir);

                                boolean itNeedToDownload = false;
                                if(localCursor.moveToFirst())
                                {
                                    //for (int i = 0; i < localCursor.getCount(); i++)
                                    {
                                        String tmp_id = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FIELD_MAP_ID));
                                        long local_update_time_stamp = localCursor.getLong(localCursor.getColumnIndex(DBAdapter.UPDATED_DATE));
                                        long local_version_index = localCursor.getLong(localCursor.getColumnIndex(DBAdapter.VERSION_INDEX));

                                        //if(transactionIndex > local_version_index)
                                        //{
                                        //    itNeedToDownload = true;
                                        //}

                                        if(updateTimne > local_update_time_stamp)
                                        {
                                            itNeedToDownload = true;
                                        }
                                    }
                                }
                                else
                                {
                                    itNeedToDownload = true;

                                    printAllMapVersionsForTestMap();
                                }

                                mDataList.add(new MapItem(idStr, titleStr, verified, itNeedToDownload, transactionIndex, updateTimne));
                                mDownloadStatusList.add(PurchasedItem.DOWNLOAD_NOT_STARTED);
                            }

                            //printAllMapVersionsForTestMap();
                            //printAllKeyFileForTestMap();

                            //final String destPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" + localMapIdStr + "/" + tmpName;
                            final String testMapRootPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir;

                            File tmpDirs = new File(testMapRootPathStr);
                            File[] files = tmpDirs.listFiles();

                            if (files != null)
                            {
                                for(int i = 0;i < files.length;i++)
                                {
                                    if (files[i].isDirectory())
                                    {
                                        String dirName = files[i].getName();
                                        //Log.v(TAG, "Directory : " + dirName);

                                        boolean isDirFound = false;
                                        for(int x = 0; x < mDataList.size(); x++)
                                        {
                                            MapItem tmpMap = mDataList.get(x);
                                            String tmpId = tmpMap.getId();
                                            if(tmpId.equals(dirName) == true)
                                            {
                                                //Log.v(TAG, "Exist" + tmpId);
                                                isDirFound = true;
                                            }
                                        }

                                        if(isDirFound == false)
                                        {
                                            final String testMapDirPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" + dirName;
                                            deleteRecursive(new File(testMapDirPathStr));
                                            mDBAdapter.deleteDownloadedFileInfoForTestMap(dirName, mUserDir);
                                            mDBAdapter.deleteOneVersionForTestMap(dirName, mUserDir);
                                            //mDBAdapter.updateDownloadedNewFileInfoForTestMap(String idStr, String keyStr, String fileName)
                                            //mDBAdapter.putOneVersionForTestMap(localMapIdStr, tmpVersionStr, tmpUpdatedTimeStr);
                                        }
                                    }
                                }
                            }
                            //printAllMapVersionsForTestMap();
                            //printAllKeyFileForTestMap();
                            //deleteUnsubmittedTestList();

                            mMapInfoListAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getTestMapListFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getTestMapListFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getTestMapListFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getTestMapListFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        MapItem tmpData = mDataList.get(index);
        if( tmpData.getNeedToBeDownloaded() == false)
        {
            String idStr = tmpData.getId();

            Intent i = new Intent(TestListActivity.this, RouteListActivity.class);
            i.putExtra(MAP_SKU, idStr);
            i.putExtra(IS_TEST_MAP, TYPE_TEST_MAP);
            startActivity(i);
        }
        else
        {
            //Toast.makeText(this, "Downloading", Toast.LENGTH_SHORT);
        }
    }

    @Override
    public void onReviewClickListener(View v, int index, int status)
    {

    }

    @Override
    public void onDownloadClickListener(View v, int index, int status)
    {
        MapItem tmpData = mDataList.get(index);
        final String idStr = tmpData.getId();

        if(idStr == null)
        {
            return;
        }

        final String mapIdStr = idStr;

        mDownloadStatusList.set(index, PurchasedItem.DOWNLOAD_STARTED);
        mIsDownloadStarted = true;

        Message msg = mTestMapListMainHandler.obtainMessage();
        Bundle b = new Bundle();
        b.putString("type", "refresh_status");
        b.putInt("index", index);
        b.putInt("status", (int)PurchasedItem.DOWNLOAD_STARTED);
        msg.setData(b);
        mTestMapListMainHandler.sendMessage(msg);

        getTestDownloadableFiles(mapIdStr, index);
    }

    void refreshItems()
    {
        onItemsLoadComplete();
    }

    void onItemsLoadComplete()
    {
        mSwipyRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.list_activity_back_button)
        {
            if(mIsDownloadStarted == false)
            {
                finish();
            }
            else
            {
                BaseLib().showGeneralPopup(getString(R.string.download_warning_title), getString(R.string.please_wait_for_download), null);
            }
        }
    }

    @Override
    public void onBackPressed()
    {
        if(mIsDownloadStarted == false)
        {
            finish();
        }
        else
        {
            BaseLib().showGeneralPopup(getString(R.string.download_warning_title), getString(R.string.please_wait_for_download), null);
        }
    }

    private void getTestDownloadableFiles(String mapIdStr, int index)
    {
        mWeb.get_test_downloadable_files(mapIdStr,
                new Consumer<ResponseMapFilesData>()
                {
                    @Override
                    public void accept(ResponseMapFilesData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        final String localMapIdStr = mapIdStr;
                        //final String localSkuStr = skuStr;
                        final int localIndex = index;

                        String serverResult = objDatas.getResult();
                        MapFiles serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            long tmpTotalSize = 0;
                            for(int x = 0; x < serverData.getMapFiles().size(); x++)
                            {
                                MapFile tmpFile = serverData.getMapFiles().get(x);

                                boolean ret = isThisServerTestMapFileHasToBeDownloaded(localMapIdStr, tmpFile.getFileKey(), tmpFile.getFileName());
                                if(ret == true)
                                {
                                    tmpTotalSize += (tmpFile.getFileSize()/1000);   // KBytes
                                }
                            }

                            if(tmpTotalSize == 0)
                            {
                                //finish, we don't need to download any file.
                                MapItem tmpItem = mDataList.get(localIndex);
                                tmpItem.setNeedToBeDownloaded(false);

                                String tmpUserIdStr = mGeneralApplication.getIdString();
                                String tmpVersionStr = String.valueOf(tmpItem.getVersionIndex());
                                String tmpUpdatedTimeStr = String.valueOf(tmpItem.getUpdatedTimeStamp());

                                try
                                {
                                    mDBAdapter.putOneVersionForTestMap(localMapIdStr, tmpVersionStr, tmpUpdatedTimeStr, mUserDir);
                                }
                                catch(SQLiteException sqe)
                                {

                                }

                                Message msg = mTestMapListMainHandler.obtainMessage();
                                Bundle b = new Bundle();
                                b.putString("type", "refresh_all");
                                msg.setData(b);
                                mTestMapListMainHandler.sendMessage(msg);

                                return;
                            }

                            final long totalSize = tmpTotalSize;
                            LinkedHashMap<String, Long> tmpFileInfoMap = new LinkedHashMap<String, Long>();

                            tmpPrevWholeReceivedFilePercentMap.put(localMapIdStr, 0L);
                            tmpPrevWholeReceivedFileSizeMap.put(localMapIdStr, 0L);

                            for(int x = 0; x < serverData.getMapFiles().size(); x++)
                            {
                                MapFile tmpFile = serverData.getMapFiles().get(x);

                                boolean ret = isThisServerTestMapFileHasToBeDownloaded(localMapIdStr, tmpFile.getFileKey(), tmpFile.getFileName());

                                if(ret == true)
                                {
                                    final String tmpName = tmpFile.getFileName();
                                    final String tmpKey = tmpFile.getFileKey();

                                    final String destPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" + localMapIdStr + "/" + tmpName;

                                    mWeb.test_map_download(localMapIdStr, tmpKey, destPathStr, new DownloadProgressListener()
                                    {
                                        @Override
                                        public void update(String fileKey, long bytesRead, long contentLength, boolean done)
                                        {
                                            long wholeReceivedFileSize = 0;
                                            synchronized(tmpFileInfoMap)
                                            {
                                                tmpFileInfoMap.put(fileKey, bytesRead);

                                                for (Iterator hashitr = tmpFileInfoMap.values().iterator(); hashitr.hasNext(); )
                                                {
                                                    long tmpSize = (Long) hashitr.next();
                                                    wholeReceivedFileSize += (tmpSize/1000);    // KBytes
                                                }
                                            }

                                            long currentPercent = (wholeReceivedFileSize*100)/totalSize;

                                            final long prevWholeReceivedFilePercent = tmpPrevWholeReceivedFilePercentMap.get(localMapIdStr);
                                            final long prevWholeReceivedFileSize = tmpPrevWholeReceivedFileSizeMap.get(localMapIdStr);

                                            if(currentPercent != prevWholeReceivedFilePercent)
                                            {
                                                Message msg = mTestMapListMainHandler.obtainMessage();
                                                Bundle b = new Bundle();
                                                b.putString("type", "refresh_progress");
                                                b.putInt("index", localIndex);
                                                b.putInt("percent", (int)currentPercent);
                                                msg.setData(b);
                                                mTestMapListMainHandler.sendMessage(msg);

                                                Log.d(TAG, String.format("id = %s, percent = %d, cur bytes = %d, prev bytes = %d, totalSize = %d", localMapIdStr, currentPercent, wholeReceivedFileSize, prevWholeReceivedFileSize, totalSize));

                                                //prevWholeReceivedFilePercent = currentPercent;
                                                tmpPrevWholeReceivedFilePercentMap.put(localMapIdStr, currentPercent);

                                                //prevWholeReceivedFileSize = wholeReceivedFileSize;
                                                tmpPrevWholeReceivedFileSizeMap.put(localMapIdStr, wholeReceivedFileSize);
                                            }

                                            if(currentPercent == 100)
                                            {
                                                //download finished!
                                                MapItem tmpItem = mDataList.get(localIndex);
                                                tmpItem.setNeedToBeDownloaded(false);

                                                String tmpUserIdStr = mGeneralApplication.getIdString();
                                                String tmpVersionStr = String.valueOf(tmpItem.getVersionIndex());
                                                String tmpUpdatedTimeStr = String.valueOf(tmpItem.getUpdatedTimeStamp());

                                                mDBAdapter.putOneVersionForTestMap(localMapIdStr, tmpVersionStr, tmpUpdatedTimeStr, mUserDir);

                                                mDownloadStatusList.set(localIndex, PurchasedItem.DOWNLOAD_FINISHED);

                                                checkEveryDownloadStatus();

                                                Message msg = mTestMapListMainHandler.obtainMessage();
                                                Bundle b = new Bundle();
                                                b.putString("type", "refresh_status");
                                                b.putInt("index", localIndex);
                                                b.putInt("status", (int)PurchasedItem.DOWNLOAD_FINISHED);
                                                msg.setData(b);
                                                mTestMapListMainHandler.sendMessage(msg);
                                            }
                                        }
                                    }, disposables);

                                    long downloaded_size = 0;
                                    long serverSize = tmpFile.getFileSize();
                                    do
                                    {
                                        //synchronized(tmpFileInfoMap)
                                        {
                                            Long tmpSize = tmpFileInfoMap.get(tmpKey);
                                            if(tmpSize != null)     //why sometimes null is returned?
                                            {
                                                downloaded_size = tmpSize.longValue();
                                            }
                                        }

                                        Thread.sleep(300);
                                    }
                                    while((downloaded_size < serverSize) && (mIsDownloadStop == false));

                                    try
                                    {
                                        mDBAdapter.updateDownloadedNewFileInfoForTestMap(localMapIdStr, tmpKey, tmpName, mUserDir);
                                    }
                                    catch(SQLException sqe)
                                    {
                                        sqe.printStackTrace();
                                    }
                                    //printKeyFileMap();
                                }
                            }
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getTestMapListFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getTestMapListFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getTestMapListFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getTestMapListFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }




    public static String convertToUTF8(String inputStr)
    {
        String outStr = null;
        try
        {
            outStr = new String(inputStr.getBytes("UTF-8"), "ISO-8859-1");
        }
        catch (java.io.UnsupportedEncodingException e)
        {
            return null;
        }
        return outStr;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }

    @Override
    public void onDestroy()
    {
        mIsDownloadStop = true;

        disposables.dispose();

        mDBAdapter.close();

        super.onDestroy();
    }


    private boolean isThisServerTestMapFileHasToBeDownloaded(String idStr, String fileKey, String fileName)
    {
        //printKeyFileMap();

        Cursor localCursor = null;
        try
        {
            localCursor = mDBAdapter.getFileNameForTestMap(idStr, fileKey, mUserDir);
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }

        if(localCursor.moveToFirst())
        {
            String tmp_file_name = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FILE_NAME));

            String localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir + "/" +  idStr + "/" + tmp_file_name;

            if(tmp_file_name.equals(fileName))
            {
                return false;
            }
            else
            {
                File tmpCheck = new File(localPathStr);
                if(tmpCheck.exists())
                {
                    tmpCheck.delete();
                }
                return true;
            }
        }
        else
        {
            //no such file key
            return true;
        }
    }

    private void deleteRecursive(File fileOrDirectory)
    {
        if (fileOrDirectory.isDirectory())
        {
            for (File child : fileOrDirectory.listFiles())
            {
                deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }

    private void printAllMapVersionsForTestMap()
    {
        Cursor localCursor = mDBAdapter.fetchAllVersionsFromTestMap();
        if(localCursor.moveToFirst())
        {
            for (int i = 0; i < localCursor.getCount(); i++)
            {
                String tmp_id_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FIELD_MAP_ID));
                String tmp_version_index_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.VERSION_INDEX));
                String tmp_updated_date_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.UPDATED_DATE));
                String tmp_userid_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.USER_ID));

                Log.d(TAG, String.format("id = %s, version index = %s. updated date = %s, user id = %s", tmp_id_str, tmp_version_index_str, tmp_updated_date_str, tmp_userid_str));
                localCursor.moveToNext();
            }
        }
    }

    private void printAllKeyFileForTestMap()
    {
        Cursor localCursor = mDBAdapter.fetchAllTestKeyFileMap();
        if(localCursor.moveToFirst())
        {
            for (int i = 0; i < localCursor.getCount(); i++)
            {
                String tmp_id_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FIELD_MAP_ID));
                String tmp_file_key = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FILE_KEY));
                String tmp_file_name = localCursor.getString(localCursor.getColumnIndex(DBAdapter.FILE_NAME));
                String tmp_userid_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.USER_ID));

                Log.d(TAG, String.format("id = %s, file_key = %s. file_name = %s, user id = %s", tmp_id_str, tmp_file_key, tmp_file_name, tmp_userid_str));
                localCursor.moveToNext();
            }
        }
    }

    private void checkEveryDownloadStatus()
    {
        boolean downloadStarted = false;
        for(int x = 0; x < mDownloadStatusList.size(); x++)
        {
            int status = mDownloadStatusList.get(x);
            if(status == PurchasedItem.DOWNLOAD_STARTED)
            {
                downloadStarted = true;
            }
        }
        if(downloadStarted == true)
        {
            mIsDownloadStarted = true;
        }
        else
        {
            mIsDownloadStarted = false;
        }

    }

    final Handler mTestMapListMainHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

            String type_str = msg.getData().getString("type");
            int targetIndex;
            int targetPercent;
            int targetStatus;

            switch (type_str)
            {
                case "refresh_all":
                    mMapInfoListAdapter.notifyDataSetChanged();
                    break;

                case "refresh_progress":
                    targetIndex = msg.getData().getInt("index");
                    targetPercent = msg.getData().getInt("percent");
                    mMapInfoListAdapter.refreshProgress(targetIndex, targetPercent);
                    mMapInfoListAdapter.notifyDataSetChanged();
                    break;

                case "refresh_status":
                    targetIndex = msg.getData().getInt("index");
                    targetStatus = msg.getData().getInt("status");
                    mMapInfoListAdapter.refreshStatus(targetIndex, targetStatus);
                    mMapInfoListAdapter.notifyDataSetChanged();
                    break;

                default:
                    break;
            }
        }
    };

}
