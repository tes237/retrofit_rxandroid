package etm.main.market.activities;

import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.IntegerWrapper;
import etm.main.market.generalApplication;
import etm.main.market.lists.KeywordRecommendationAdapter;
import etm.main.market.lists.KeywordRecommendationListener;
import etm.main.market.vo.ChatMessage;
import etm.main.market.vo.ChatMessageGroup;

import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity implements View.OnClickListener, KeywordRecommendationListener, baseDefine
{
    public static final String KEYWORDS = "keywords";

    private ArrayList<String> mKeyWordRecommendationList;
    private KeywordRecommendationAdapter mKeywordRecommendationAdapter;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private DBAdapter mDBAdapter;

    private  String APP_DIRECTORY;
    //public String mUserDir = "";

    private GeneralAlarmDialog mGeneralAlarmDialog;

    private ListView mKeyWordRecommendationListview;
    private ImageButton mBackButton;
    private EditText mSearchEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_search);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();

        //String tmpUserIdStr = mGeneralApplication.getIdString();
        //mUserDir = Base64.mod_encode(tmpUserIdStr);

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        mKeyWordRecommendationListview = (ListView)findViewById(R.id.lv_keyword_recommendation);
        mBackButton = (ImageButton)findViewById(R.id.search_activity_back_button);
        mSearchEdit = (EditText) findViewById(R.id.search_edit);

        mBackButton.setOnClickListener(this);

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(mSearchEdit, InputMethodManager.SHOW_IMPLICIT);

        mSearchEdit.setOnKeyListener(new View.OnKeyListener()
        {
            public boolean onKey(View v, int keyCode, KeyEvent event)
            {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER))
                {
                    // Perform action on key press
                    String tmpKeywordStr = mSearchEdit.getText().toString();

                    if("".equals(tmpKeywordStr) == true)
                    {
                        showAlarmDialog(getString(R.string.setting_input_error_title), getString(R.string.search_keyword_needed));
                        return true;
                    }

                    if(tmpKeywordStr.length() > 50)
                    {
                        showAlarmDialog(getString(R.string.setting_input_error_title), getString(R.string.search_keyword_cannot_be_longer_than_50));
                        return true;
                    }

                    Intent i = new Intent(SearchActivity.this, SearchListActivity.class);
                    i.putExtra(KEYWORDS, new String[] {tmpKeywordStr});
                    startActivityForResult(i, 0);

                    if(mKeyWordRecommendationList.size() > 0)
                    {
                        if(mKeyWordRecommendationList.size() < 5)
                        {
                            mKeyWordRecommendationList.add(0, tmpKeywordStr);
                            mKeywordRecommendationAdapter.notifyDataSetChanged();
                            mDBAdapter.putSearchKeyword(mKeyWordRecommendationList);
                        }
                        else
                        {
                            mKeyWordRecommendationList.remove(mKeyWordRecommendationList.size()-1);
                            mKeyWordRecommendationList.add(0, tmpKeywordStr);
                            mKeywordRecommendationAdapter.notifyDataSetChanged();
                            mDBAdapter.putSearchKeyword(mKeyWordRecommendationList);
                        }
                    }
                    else
                    {
                        mKeyWordRecommendationList.clear();
                        mKeyWordRecommendationList.add(tmpKeywordStr);
                        mKeywordRecommendationAdapter.notifyDataSetChanged();
                        mDBAdapter.putSearchKeyword(mKeyWordRecommendationList);
                    }

                    return true;
                }
                return false;
            }
        });

        mKeyWordRecommendationList = new ArrayList<String>();

        Cursor localCursor = mDBAdapter.getSearchKeyword();
        if(localCursor != null && localCursor.moveToFirst())
        {
            for (int i = 0; i < localCursor.getCount(); i++)
            {
                String keyword_str = localCursor.getString(localCursor.getColumnIndex(DBAdapter.KEYWORD_TEXT));

                if(keyword_str == null || keyword_str.equals("null") == true )
                {
                    continue;
                }
                mKeyWordRecommendationList.add(keyword_str);

                localCursor.moveToNext();
            }
        }
        localCursor.close();

        String entry_array[] = null;
        if(mKeyWordRecommendationList.size() == 0)
        {
            entry_array = getResources().getStringArray(R.array.keyword_recommendation_list);

            for(String title : entry_array)
            {
                mKeyWordRecommendationList.add(title);
            }
        }

        mKeywordRecommendationAdapter = new KeywordRecommendationAdapter(this, mKeyWordRecommendationListview, mKeyWordRecommendationList, this);
        mKeyWordRecommendationListview.setAdapter(mKeywordRecommendationAdapter);


        mKeyWordRecommendationListview.setClickable(true);
        mKeyWordRecommendationListview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> arg0, android.view.View tmpView, int position, long id)
            {
                Intent i = new Intent(SearchActivity.this, SearchListActivity.class);
                i.putExtra(KEYWORDS, new String[] {mKeyWordRecommendationList.get(position)});
                startActivity(i);

                mDBAdapter.putSearchKeyword(mKeyWordRecommendationList);
            }
        });

    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.search_activity_back_button)
        {
            finish();
        }
    }

    @Override
    public void onKeywordListClickListener(int listType, View v, int position, int status)
    {
        Intent i = new Intent(SearchActivity.this, SearchListActivity.class);
        i.putExtra(KEYWORDS, new String[] {mKeyWordRecommendationList.get(position)});
        startActivity(i);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == PAYMENT_FINISHED)
        {
            setResult(PAYMENT_FINISHED);
            finish();
        }
    }

    @Override
    public void onDestroy()
    {

        mDBAdapter.close();

        super.onDestroy();
    }

    private void showAlarmDialog(String title, String message)
    {
        FragmentManager fm = getFragmentManager();
        if(mGeneralAlarmDialog != null)
        {
            mGeneralAlarmDialog.dismiss();
            mGeneralAlarmDialog = null;
        }
        mGeneralAlarmDialog = new GeneralAlarmDialog();
        mGeneralAlarmDialog.setTitleText(title);
        mGeneralAlarmDialog.setMessageText(message);
        mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
        {
            @Override
            public void onButtonClickListener(View v, int id, int button)
            {
            }
        });
        mGeneralAlarmDialog.show(fm, "tag");
    }
}
