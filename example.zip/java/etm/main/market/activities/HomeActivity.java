package etm.main.market.activities;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.GraphResponse;
import com.google.android.gms.plus.model.people.Person;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.LocalFirebaseMessagingService;
import etm.main.market.common.Base64;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.dialog.GeneralOptionDialog;
import etm.main.market.dialog.GeneralOptionListener;
import etm.main.market.dialog.GeneralProgressDialog;
import etm.main.market.dialog.SpotOptionDialog;
import etm.main.market.dialog.LanguageOptionDialog;
import etm.main.market.dialog.LanguageOptionListener;
import etm.main.market.dialog.TermsDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.baseDefine;
import etm.main.market.pages.LocalPagerAdapter;
import etm.main.market.social.FacebookHelper;
import etm.main.market.social.GooglePlusHelper;
import etm.main.market.vo.CustomerStats;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.ResponseCustomerStatsData;
import etm.main.market.vo.ResponseDummyData;
import etm.main.market.vo.ResponseLoginData;
import etm.main.market.vo.ResponseLogoutData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponseSendSessionData;
import etm.main.market.vo.ResponseStoresData;
import etm.main.market.vo.Stores;
import etm.main.market.widgets.roundedImage.MLRoundedImageView;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class HomeActivity extends BaseActivity implements baseDefine, View.OnClickListener
{
    private static final String TAG = HomeActivity.class.getSimpleName();

    public static final String HOME_CATEGORY_TYPE = "type";
    public static final String POPULAR_TYPE = "0";
    public static final String VIEWED_TYPE = "1";
    public static final String WISHLIST_TYPE = "2";
    public static final String EUROPE_TYPE = "3";
    public static final String ASIA_TYPE = "4";
    public static final String NORTH_AMERICA_TYPE = "5";
    public static final String SOUTH_AMERICA_TYPE = "6";
    public static final String AFRICA_TYPE = "7";
    public static final String OCEANIA_TYPE = "8";
    public static final String ETC_TYPE = "9";

    public String mUserDir = "";
    private  String APP_DIRECTORY;
    //drawerLayout
    private DrawerLayout mWholeDrawerLayout;
    private NavigationView mNavigationView;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private DBAdapter mDBAdapter;

    private MLRoundedImageView mMLRoundedImageView;
    private TextView mUserNameTextView;
    private TextView mSoldMapCountTextView;
    private TextView mEarnedMoneyTextView;
    private TextView mUnreadMessagesTextView;

    private TextView mMessageMenuView;
    private TextView mPurchasedMenuView;
    private TextView mSoldMenuView;
    private TextView mTestMenuView;
    private TextView mSettingMenuView;

    private ImageView mLogoutIconView;
    private TextView mLogoutTextView;
    private TextView mLanguageTextView;

    private ScalableLayout mCategoryPopular;
    //private ScalableLayout mCategoryViewed;
    private ScalableLayout mCategoryWishlist;
    private ScalableLayout mCategoryEurope;
    private ScalableLayout mCategoryAsia;
    private ScalableLayout mCategoryNorthAmerica;
    private ScalableLayout mCategoryAfrica;
    private ScalableLayout mCategorySouthAmerica;
    private ScalableLayout mCategoryOceania;
    private ScalableLayout mCategoryEtc;

    private Bitmap mProfileImage = null;
    private ImageButton mSerarchButton = null;
    private GeneralProgressDialog pd;
    private LanguageOptionDialog mTGLanguageOptionDialog;

    //private boolean mIsLoggedIn = false;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);

    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        //pd = new GeneralProgressDialog(this, R.drawable.spinner);
        //pd.show();

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();
        APP_DIRECTORY = mGeneralApplication.getAppDirectory();

        mGeneralApplication.setTick("------------- Home first");

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        mGeneralApplication.setTick("Home db open");

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);

        mGeneralApplication.setTick("Home setContentView");

        mWholeDrawerLayout = (DrawerLayout) findViewById(R.id.dl_activity_main);
        mNavigationView = (NavigationView) findViewById(R.id.navigationView);

        mMLRoundedImageView = (MLRoundedImageView)findViewById(R.id.profile_photo);
        mUserNameTextView = (TextView)findViewById(R.id.user_name);
        mSoldMapCountTextView = (TextView)findViewById(R.id.sold_map_count);
        mEarnedMoneyTextView = (TextView)findViewById(R.id.earned_money);
        mUnreadMessagesTextView = (TextView)findViewById(R.id.unread_messages);

        mMessageMenuView = (TextView)findViewById(R.id.menu_message_text);
        mPurchasedMenuView = (TextView)findViewById(R.id.menu_purchsed_text);
        mSoldMenuView = (TextView)findViewById(R.id.menu_sold_text);
        mTestMenuView = (TextView)findViewById(R.id.menu_test_text);
        mSettingMenuView = (TextView)findViewById(R.id.menu_setting_text);

        mLogoutIconView = (ImageView)findViewById(R.id.menu_logout_icon);
        mLogoutTextView = (TextView)findViewById(R.id.menu_logout_text);

        mLanguageTextView = (TextView)findViewById(R.id.store_language);

        mSerarchButton = (ImageButton)findViewById(R.id.menu_search);

        mCategoryPopular = (ScalableLayout)findViewById(R.id.home_category_popular);
        //mCategoryViewed = (ScalableLayout)findViewById(R.id.home_category_viewed);
        mCategoryWishlist = (ScalableLayout)findViewById(R.id.home_category_wishlist);
        mCategoryEurope = (ScalableLayout)findViewById(R.id.home_category_europe);
        mCategoryAsia = (ScalableLayout)findViewById(R.id.home_category_asia);
        mCategoryNorthAmerica = (ScalableLayout)findViewById(R.id.home_category_america);
        mCategoryAfrica = (ScalableLayout)findViewById(R.id.home_category_africa);
        mCategorySouthAmerica = (ScalableLayout)findViewById(R.id.home_category_south_america);
        mCategoryOceania = (ScalableLayout)findViewById(R.id.home_category_oceania);
        mCategoryEtc = (ScalableLayout)findViewById(R.id.home_category_etc);

        if(mGeneralApplication.IsLoggedIn() == false)
        {
            //mLogoutIconView.setVisibility(View.INVISIBLE);
            //mLogoutTextView.setVisibility(View.INVISIBLE);
        }

        ImageButton home_button = (ImageButton) findViewById(R.id.menu_button);
        home_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if(mGeneralApplication.IsLoggedIn() == true)
                {
                    openCurrentSideMenu();
                }
                else
                {
                    LoginProcessPopup(new AutoLoginListener()
                    {
                        @Override
                        public void onAutoLoginSuccess()
                        {
                            openCurrentSideMenu();
                        }

                        @Override
                        public void onAutoLoginFail()
                        {
                            startManualLogin(new LoginListener()
                            {
                                @Override
                                public void onLoginSuccess()
                                {
                                    openCurrentSideMenu();
                                }

                                @Override
                                public void onLoginCancel()
                                {
                                    BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                }
                            });
                        }
                    });
                }
            }
        });

        mCategoryPopular.setOnClickListener(this);
        //mCategoryViewed.setOnClickListener(this);
        mCategoryWishlist.setOnClickListener(this);
        mCategoryEurope.setOnClickListener(this);
        mCategoryAsia.setOnClickListener(this);
        mCategoryNorthAmerica.setOnClickListener(this);
        mCategoryAfrica.setOnClickListener(this);
        mCategorySouthAmerica.setOnClickListener(this);
        mCategoryOceania.setOnClickListener(this);
        mCategoryEtc.setOnClickListener(this);

        mMessageMenuView.setOnClickListener(this);
        mPurchasedMenuView.setOnClickListener(this);
        mSoldMenuView.setOnClickListener(this);
        mTestMenuView.setOnClickListener(this);
        mSettingMenuView.setOnClickListener(this);
        mLogoutTextView.setOnClickListener(this);

        mSerarchButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(HomeActivity.this, SearchActivity.class);
                startActivityForResult(i, 0);
            }
        });

        mGeneralApplication.setTick("Home ui var init");

        loadStoreLanguage();

        mGeneralApplication.setTick("Home store language");

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

    }

    public void openCurrentSideMenu()
    {
        mWholeDrawerLayout.openDrawer(Gravity.LEFT);
        //mWholeDrawerLayout.openDrawer(Gravity.RIGHT);
    }

    public void closeCurrentSideMenu()
    {
        mWholeDrawerLayout.closeDrawers();
    }

    private void loadStoreLanguage()
    {
        Cursor search_cursor = mDBAdapter.getStoreLang();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String language = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.LANGUAGE));

            mWeb.setLanguage(language);

            setStoreTitle(language);

            mWeb.getStorelist(
                    new Consumer<ResponseStoresData>()
                    {
                        @Override
                        public void accept(ResponseStoresData objDatas) throws Exception
                        {
                            // TODO: Handle response.
                            String serverResult = objDatas.getResult();
                            Stores serverStoreData = objDatas.getData();

                            if(serverResult.equals(JSON_SUCCESS))
                            {
                                //clearProgressDialog();

                                ArrayList<String> store_names = serverStoreData.getStores();
                                ArrayList<String> store_urls = serverStoreData.getUrls();

                                String savedServerUrl = null;
                                for(int x = 0; x < store_names.size(); x++)
                                {
                                    if(language.equals(store_names.get(x)) == true)
                                    {
                                        savedServerUrl = store_urls.get(x);
                                        break;
                                    }
                                }

                                if(
                                        (language == null || "".equals(language) == true)
                                                || (savedServerUrl == null) )
                                {
                                    //pd = new GeneralProgressDialog(HomeActivity.this, R.drawable.spinner);
                                    //pd.show();

                                    FragmentManager fm = getFragmentManager();
                                    mTGLanguageOptionDialog = new LanguageOptionDialog();
                                    mTGLanguageOptionDialog.setTitle(getString(R.string.language_select_title));
                                    mTGLanguageOptionDialog.setLists(store_names);
                                    mTGLanguageOptionDialog.setCancelable(false);
                                    mTGLanguageOptionDialog.setOptionListener(new LanguageOptionListener()
                                    {
                                        @Override
                                        public void onListClickListener(View v, int index)
                                        {
                                            if(index != -1)
                                            {
                                                String tmpUrl = store_urls.get(index);
                                                //String completeUrl = "http://" + tmpUrl;
                                                String completeUrl = tmpUrl;
                                                String currentServer = mWeb.getServer();
                                                if(currentServer.equals(completeUrl) == false)
                                                {
                                                    mDBAdapter.putStoreLang(store_names.get(index));

                                                    setStoreTitle(store_names.get(index));

                                                    mWeb.setLanguage(store_names.get(index));

                                                    mWeb.setServer(completeUrl);

                                                    if(mGeneralApplication.IsLoggedIn() == true)
                                                    {
                                                        mWeb.sendSessionData(
                                                                new Consumer<ResponseSendSessionData>()
                                                                {
                                                                    @Override
                                                                    public void accept(ResponseSendSessionData objDatas) throws Exception
                                                                    {
                                                                        // TODO: Handle response.

                                                                        //loadFrontList();
                                                                    }
                                                                }
                                                                ,new Consumer<Throwable>()
                                                                {
                                                                    @Override
                                                                    public void accept(@NonNull Throwable throwable) throws Exception
                                                                    {
                                                                        // TODO: Handle error.
                                                                    }
                                                                }, disposables
                                                        );
                                                    }
                                                }
                                            }
                                        }
                                    });
                                    mTGLanguageOptionDialog.show(fm, "tag");
                                }
                                else
                                {
                                    //String completeUrl = "http://" + savedServerUrl;
                                    //String completeUrl = "https://" + savedServerUrl;
                                    String completeUrl = savedServerUrl;
                                    String currentServer = mWeb.getServer();
                                    if(currentServer.equals(completeUrl) == false)
                                    {
                                        mWeb.setServer(completeUrl);
                                    }
                                    //loadFrontList();
                                }

                            }
                            else if(serverResult.equals(JSON_FAIL))
                            {
                                //showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()));
                                BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                                //mPopularLoaded = false;
                                //clearProgressDialog();
                            }
                        }
                    }
                    ,new Consumer<Throwable>()
                    {
                        @Override
                        public void accept(@NonNull Throwable throwable) throws Exception
                        {
                            // TODO: Handle error.
                            //mPopularLoaded = false;
                            //clearProgressDialog();
                        }
                    }, disposables
            );

            search_cursor.close();
        }
        else
        {
            mWeb.getStorelist(
                    new Consumer<ResponseStoresData>()
                    {
                        @Override
                        public void accept(ResponseStoresData objDatas) throws Exception
                        {
                            // TODO: Handle response.
                            String serverResult = objDatas.getResult();
                            Stores serverStoreData = objDatas.getData();

                            if(serverResult.equals(JSON_SUCCESS))
                            {
                                ArrayList<String> store_names = serverStoreData.getStores();
                                ArrayList<String> store_urls = serverStoreData.getUrls();

                                FragmentManager fm = getFragmentManager();
                                mTGLanguageOptionDialog = new LanguageOptionDialog();
                                mTGLanguageOptionDialog.setTitle(getString(R.string.language_select_title));
                                mTGLanguageOptionDialog.setLists(store_names);
                                mTGLanguageOptionDialog.setCancelable(false);
                                mTGLanguageOptionDialog.setOptionListener(new LanguageOptionListener()
                                {
                                    @Override
                                    public void onListClickListener(View v, int index)
                                    {
                                        if(index != -1)
                                        {
                                            String tmpUrl = store_urls.get(index);
                                            //String completeUrl = "https://" + tmpUrl;
                                            String completeUrl = tmpUrl;
                                            String currentServer = mWeb.getServer();
                                            if(currentServer.equals(completeUrl) == false)
                                            {
                                                mDBAdapter.putStoreLang(store_names.get(index));

                                                mWeb.setLanguage(store_names.get(index));

                                                mWeb.setServer(completeUrl);

                                                setStoreTitle(store_names.get(index));
                                                //pd = new GeneralProgressDialog(HomeActivity.this, R.drawable.spinner);
                                                //pd.show();

                                                if(mGeneralApplication.IsLoggedIn() == true)
                                                {
                                                    mWeb.sendSessionData(
                                                            new Consumer<ResponseSendSessionData>()
                                                            {
                                                                @Override
                                                                public void accept(ResponseSendSessionData objDatas) throws Exception
                                                                {
                                                                    // TODO: Handle response.

                                                                    //loadFrontList();
                                                                }
                                                            }
                                                            ,new Consumer<Throwable>()
                                                            {
                                                                @Override
                                                                public void accept(@NonNull Throwable throwable) throws Exception
                                                                {
                                                                    // TODO: Handle error.
                                                                }
                                                            }, disposables
                                                    );
                                                }
                                            }
                                        }
                                    }
                                });
                                mTGLanguageOptionDialog.show(fm, "tag");
                            }
                            else if(serverResult.equals(JSON_FAIL))
                            {
                                //clearProgressDialog();
                                BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                            }
                        }
                    }
                    ,new Consumer<Throwable>()
                    {
                        @Override
                        public void accept(@NonNull Throwable throwable) throws Exception
                        {
                            // TODO: Handle error.
                            //mPopularLoaded = false;
                            //clearProgressDialog();
                        }
                    }, disposables
            );
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
        else if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(resultCode == PAYMENT_FINISHED)
        {
            Intent i = new Intent(HomeActivity.this, PurchasedListActivity.class);
            startActivity(i);
        }
    }

    @Override
    public void onDestroy()
    {
        disposables.dispose();

        mDBAdapter.close();

        super.onDestroy();
    }

    @Override
    public void onResume()
    {
        resumeStoreTitle();

        if(mGeneralApplication.IsLoggedIn() == true)
        {
            String tmpUserIdStr = mGeneralApplication.getIdString();
            mUserDir = Base64.mod_encode(tmpUserIdStr);

            mLogoutIconView.setVisibility(View.VISIBLE);
            mLogoutTextView.setVisibility(View.VISIBLE);

            getCustomerStatsFunc();

            final String tmpKey = "1";
            final String destPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/profile.jpg";

            mWeb.image_download(tmpKey, destPathStr, new DownloadProgressListener()
            {
                @Override
                public void update(String fileKey, long bytesRead, long contentLength, boolean done)
                {
                    //download finished!
                    if(contentLength != -1)
                    {
                        if(done == true)
                        {
                            mProfileImage = BitmapFactory.decodeFile(destPathStr);

                            if(mProfileImage == null)
                            {
                                mGeneralApplication.setProfileLoaded(false);
                                //mProfileImage = BitmapFactory.decodeResource(R.drawable.sample_photo);
                                Resources res = getResources();
                                int id = R.drawable.sample_photo;
                                mProfileImage = BitmapFactory.decodeResource(res, id);
                            }
                            else
                            {
                                mGeneralApplication.setProfileLoaded(true);
                            }

                            Message msg = mHomeMessageMainHandler.obtainMessage();
                            Bundle b = new Bundle();
                            b.putString("type", "profile_refresh");
                            msg.setData(b);
                            mHomeMessageMainHandler.sendMessage(msg);

                        }
                    }
                    else
                    {
                        File imageTrashFile = new File(destPathStr);
                        if(imageTrashFile.exists())
                        {
                            imageTrashFile.delete();
                        }
                        mGeneralApplication.setProfileLoaded(false);
                        mProfileImage = BitmapFactory.decodeResource(getResources(), R.drawable.sample_photo);

                        Message msg = mHomeMessageMainHandler.obtainMessage();
                        Bundle b = new Bundle();
                        b.putString("type", "profile_refresh");
                        msg.setData(b);
                        mHomeMessageMainHandler.sendMessage(msg);
                    }
                }
            }, disposables);
        }
        else    //no logged in
        {
            //mLogoutIconView.setVisibility(View.INVISIBLE);
            //mLogoutTextView.setVisibility(View.INVISIBLE);
        }

        super.onResume();
    }

    @Override
    public void onPause()
    {

        super.onPause();
    }

    private void logout()
    {
        mWeb.logout(
                new Consumer<ResponseLogoutData>()
                {
                    @Override
                    public void accept(ResponseLogoutData loginDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = loginDatas.getResult();
                        String serverData = loginDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            //let's clear session

                            Intent i = new Intent(HomeActivity.this, LoginActivity.class);
                            startActivity(i);
                            //finish();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(loginDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                    }
                }, disposables
        );

    }

    private void getCustomerStatsFunc()
    {
        mWeb.getCustomerStats(
                new Consumer<ResponseCustomerStatsData>()
                {
                    @Override
                    public void accept(ResponseCustomerStatsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        CustomerStats serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mUserNameTextView.setText(String.valueOf(serverData.getCustomer_name()));
                            mSoldMapCountTextView.setText(String.valueOf(serverData.getTotal_sold_map_count()));
                            mEarnedMoneyTextView.setText(String.valueOf(serverData.getTotal_earn_money()));
                            mUnreadMessagesTextView.setText(String.valueOf(serverData.getUnread_message_count()));

                            String termsFlag = serverData.isTermsAgreed();
                            String privacyFlag = serverData.isPrivacyAgreed();

                            if("1".equals(termsFlag))
                            {
                                mGeneralApplication.setIsTermsAgreed(true);
                            }
                            else
                            {
                                mGeneralApplication.setIsTermsAgreed(false);
                            }

                            if("1".equals(privacyFlag))
                            {
                                mGeneralApplication.setIsPrivacyAgreed(true);
                            }
                            else
                            {
                                mGeneralApplication.setIsPrivacyAgreed(false);
                            }

                            if(mGeneralApplication.isTermsAgreed() == false)
                            {
                                getTerms();
                            }
                            else
                            {
                                if(mGeneralApplication.isPrivacyAgreed() == false)
                                {
                                    getPrivacyPolicy();
                                }
                            }

                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getCustomerStatsFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getCustomerStatsFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener() {
                                @Override
                                public void onAutoLoginSuccess() {
                                    getCustomerStatsFunc();
                                }

                                @Override
                                public void onAutoLoginFail() {
                                    startManualLogin(new LoginListener() {
                                        @Override
                                        public void onLoginSuccess() {
                                            getCustomerStatsFunc();
                                        }

                                        @Override
                                        public void onLoginCancel() {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    final Handler mHomeMessageMainHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

            String type_str = msg.getData().getString("type");

            switch (type_str)
            {
                case "profile_refresh":

                    mMLRoundedImageView.setImageBitmap(mProfileImage);
                    break;

                default:
                    break;
            }
        }
    };

    private static Boolean isJPEG(File filename) throws Exception
    {
        DataInputStream ins = new DataInputStream(new BufferedInputStream(new FileInputStream(filename)));
        try
        {
            int first4Bytes = ins.readInt();
            if (first4Bytes == 0xffd8ffe0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        finally
        {
            ins.close();
        }
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.menu_message_text)
        {
            Intent i;
            i = new Intent(HomeActivity.this, FriendListActivity.class);
            startActivity(i);

            closeCurrentSideMenu();
        }
        else if(v.getId() == R.id.menu_purchsed_text)
        {
            Intent i;
            i = new Intent(HomeActivity.this, PurchasedListActivity.class);
            startActivity(i);

            closeCurrentSideMenu();
        }
        else if(v.getId() == R.id.menu_sold_text)
        {
            Intent i;
            i = new Intent(HomeActivity.this, SaleListActivity.class);
            startActivity(i);

            closeCurrentSideMenu();
        }
        else if(v.getId() == R.id.menu_test_text)
        {
            Intent i;
            i = new Intent(HomeActivity.this, TestListActivity.class);
            startActivity(i);

            closeCurrentSideMenu();
        }
        else if(v.getId() == R.id.menu_setting_text)
        {
            Intent i;
            i = new Intent(HomeActivity.this, SettingActivity.class);
            startActivity(i);

            closeCurrentSideMenu();
        }
        else if(v.getId() == R.id.menu_logout_text)
        {
            logout();

            closeCurrentSideMenu();
        }
        else if(v.getId() == R.id.home_category_popular)
        {
            Intent i;
            i = new Intent(HomeActivity.this, CategoryListActivity.class);
            i.putExtra(HOME_CATEGORY_TYPE, POPULAR_TYPE);
            startActivity(i);
        }
        /*
        else if(v.getId() == R.id.home_category_viewed)
        {
            if(mGeneralApplication.IsLoggedIn() == true)
            {
                Intent i;
                i = new Intent(HomeActivity.this, CategoryListActivity.class);
                i.putExtra(HOME_CATEGORY_TYPE, VIEWED_TYPE);
                startActivity(i);
            }
            else
            {
                LoginRequiredPopup();
            }
        }
        */
        else if(v.getId() == R.id.home_category_wishlist)
        {
            if(mGeneralApplication.IsLoggedIn() == true)
            {
                Intent i;
                i = new Intent(HomeActivity.this, CategoryListActivity.class);
                i.putExtra(HOME_CATEGORY_TYPE, WISHLIST_TYPE);
                startActivity(i);
            }
            else
            {
                BaseLib().LoginProcessPopup(new AutoLoginListener()
                {
                    @Override
                    public void onAutoLoginSuccess()
                    {
                        Intent i;
                        i = new Intent(HomeActivity.this, CategoryListActivity.class);
                        i.putExtra(HOME_CATEGORY_TYPE, WISHLIST_TYPE);
                        startActivity(i);
                    }

                    @Override
                    public void onAutoLoginFail()
                    {
                        startManualLogin(new LoginListener()
                        {
                            @Override
                            public void onLoginSuccess()
                            {
                                Intent i;
                                i = new Intent(HomeActivity.this, CategoryListActivity.class);
                                i.putExtra(HOME_CATEGORY_TYPE, WISHLIST_TYPE);
                                startActivity(i);
                            }

                            @Override
                            public void onLoginCancel()
                            {
                                BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                            }
                        });
                    }
                });
            }
        }
        else if(v.getId() == R.id.home_category_europe)
        {
            Intent i;
            i = new Intent(HomeActivity.this, CategoryListActivity.class);
            i.putExtra(HOME_CATEGORY_TYPE, EUROPE_TYPE);
            startActivity(i);
        }
        else if(v.getId() == R.id.home_category_asia)
        {
            Intent i;
            i = new Intent(HomeActivity.this, CategoryListActivity.class);
            i.putExtra(HOME_CATEGORY_TYPE, ASIA_TYPE);
            startActivity(i);
        }
        else if(v.getId() == R.id.home_category_america)
        {
            Intent i;
            i = new Intent(HomeActivity.this, CategoryListActivity.class);
            i.putExtra(HOME_CATEGORY_TYPE, NORTH_AMERICA_TYPE);
            startActivity(i);
        }
        else if(v.getId() == R.id.home_category_africa)
        {
            Intent i;
            i = new Intent(HomeActivity.this, CategoryListActivity.class);
            i.putExtra(HOME_CATEGORY_TYPE, AFRICA_TYPE);
            startActivity(i);
        }
        else if(v.getId() == R.id.home_category_south_america)
        {
            Intent i;
            i = new Intent(HomeActivity.this, CategoryListActivity.class);
            i.putExtra(HOME_CATEGORY_TYPE, SOUTH_AMERICA_TYPE);
            startActivity(i);
        }
        else if(v.getId() == R.id.home_category_oceania)
        {
            Intent i;
            i = new Intent(HomeActivity.this, CategoryListActivity.class);
            i.putExtra(HOME_CATEGORY_TYPE, OCEANIA_TYPE);
            startActivity(i);
        }
        else if(v.getId() == R.id.home_category_etc)
        {
            Intent i;
            i = new Intent(HomeActivity.this, CategoryListActivity.class);
            i.putExtra(HOME_CATEGORY_TYPE, ETC_TYPE);
            startActivity(i);
        }
    }

    private void setStoreTitle(String storeLang)
    {
        String welcomeText = "";
        switch(storeLang)
        {
            case "English":
                welcomeText = "Welcome to English market";
                break;

            case "Korean":
                welcomeText = "한국어 마켓에 오신걸 환영합니다";
                break;

            case "Japanese":
                welcomeText = "日本市場へようこそ";
                break;

            case "German":
                welcomeText = "Willkommen auf dem deutschen Markt";
                break;

            case "Russian":
                welcomeText = "Добро пожаловать на российский рынок";
                break;

            case "Spanish":
                welcomeText = "Bienvenido al mercado español";
                break;

            case "Portuguese":
                welcomeText = "Bem vindo ao mercado Português";
                break;

            case "Italian":
                welcomeText = "Benvenuti nel mercato italiano";
                break;

            case "Arabic":
                welcomeText = "مرحبا بك في السوق العربي";
                break;

            case "French":
                welcomeText = "Bienvenue sur le marché français";
                break;

            case "Chinese(Simplified)":
                welcomeText = "欢迎来到中国市场";
                break;

            case "Chinese(Traditional)":
                welcomeText = "歡迎來到中國市場";
                break;
        }
        mLanguageTextView.setText(welcomeText);
    }

    private void resumeStoreTitle()
    {
        Cursor search_cursor = mDBAdapter.getStoreLang();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String language = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.LANGUAGE));

            setStoreTitle(language);
        }
    }

}
