package etm.main.market.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.NavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import io.reactivex.Completable;
import io.reactivex.CompletableObserver;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import etm.main.market.BuildConfig;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.common.CircleTransformation;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.dialog.LanguageOptionDialog;
import etm.main.market.dialog.LanguageOptionListener;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.payment.util.IabHelper;
import etm.main.market.payment.util.IabResult;
import etm.main.market.payment.util.Inventory;
import etm.main.market.payment.util.TGMPurchase;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.ResponseDummyData;
import etm.main.market.vo.ResponseProductData;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponsePurchaseData;
import etm.main.market.vo.ResponseSendSessionData;
import etm.main.market.vo.ResponseSettingData;
import etm.main.market.vo.ResponseStoresData;
import etm.main.market.vo.ResponseUpdateCustomerData;
import etm.main.market.vo.ResponseUploadImageData;
import etm.main.market.vo.Route;
import etm.main.market.vo.Setting;
import etm.main.market.vo.Stores;
import etm.main.market.vo.ServerMapRouteData;

public class SettingActivity extends BaseActivity implements baseDefine, View.OnClickListener
{
    private static final String TAG = SettingActivity.class.getSimpleName();
    private static final int PICK_IMAGE = 101;

    //private Context mContext;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;
    private DBAdapter mDBAdapter;

    private ImageView mProfileImageView;

    private ImageButton mUserNameButton;
    private ImageButton mPasswordButton;
    private ImageButton mSelectButton;

    private ImageButton mBackButton;
    private TextView mDeleteAllTestTGButton;
    private TextView mDeleteAllTGButton;
    private TextView mDeleteLoginInfoButton;
    private ImageButton mShowTermButton;
    private ImageButton mShowPrivacyButton;
    private ImageButton mSelectLanguageButton;
    private TextView mLanguage;
    private TextView mSendMailButton;

    private Switch mMessageSwitch;
    private Switch mSellingSwitch;
    private Switch mBuyingSwitch;

    private TextView mUserNameText;
    private TextView mPasswordText;
    private TextView mPayoutText;
    private TextView mVersionText;
    private TextView mTermsOfUseText;
    private TextView mLanguageText;

    private LanguageOptionDialog mTGLanguageOptionDialog;

    public String mUserDir = "";
    private String APP_DIRECTORY;

    private String mAdminQuestionEmail;

    private Bitmap mProfileImage = null;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        APP_DIRECTORY = mGeneralApplication.getAppDirectory();
        String tmpUserIdStr = mGeneralApplication.getIdString();
        mUserDir = etm.main.market.common.Base64.mod_encode(tmpUserIdStr);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        mBackButton = (ImageButton) findViewById(R.id.setting_activity_back_button);
        mBackButton.setOnClickListener(this);

        mProfileImageView = (ImageView) findViewById(R.id.photo_click_icon);
        mProfileImageView.setOnClickListener(this);

        mUserNameButton = (ImageButton) findViewById(R.id.user_name_select);
        mUserNameButton.setOnClickListener(this);
        mPasswordButton = (ImageButton) findViewById(R.id.password_select);
        mPasswordButton.setOnClickListener(this);
        mSelectButton = (ImageButton) findViewById(R.id.payout_select);
        mSelectButton.setOnClickListener(this);

        mMessageSwitch = (Switch) findViewById(R.id.message_alarm_button);
        mSellingSwitch = (Switch) findViewById(R.id.selling_alarm_button);
        mBuyingSwitch = (Switch) findViewById(R.id.buying_alarm_button);

        mDeleteAllTGButton = (TextView) findViewById(R.id.delete_all_tourguide_button);
        mDeleteAllTGButton.setOnClickListener(this);

        mDeleteAllTestTGButton = (TextView) findViewById(R.id.delete_all_test_tourguide_button);
        mDeleteAllTestTGButton.setOnClickListener(this);

        mDeleteLoginInfoButton = (TextView) findViewById(R.id.delete_auto_login_button);
        mDeleteLoginInfoButton.setOnClickListener(this);

        mShowTermButton = (ImageButton) findViewById(R.id.show_term_of_use_data);
        mShowTermButton.setOnClickListener(this);

        mShowPrivacyButton = (ImageButton) findViewById(R.id.show_privacy_data);
        mShowPrivacyButton.setOnClickListener(this);

        mSelectLanguageButton = (ImageButton) findViewById(R.id.show_language_popup);
        mSelectLanguageButton.setOnClickListener(this);

        mLanguage = (TextView) findViewById(R.id.tour_guide_language_data);
        mLanguage.setOnClickListener(this);

        mUserNameText = (TextView) findViewById(R.id.user_name_text);
        mUserNameText.setOnClickListener(this);
        mPasswordText = (TextView) findViewById(R.id.password_text);
        mPasswordText.setOnClickListener(this);
        mPayoutText = (TextView) findViewById(R.id.payout_text);
        mPayoutText.setOnClickListener(this);

        mVersionText = (TextView) findViewById(R.id.vision_data);
        mVersionText.setText(BuildConfig.VERSION_NAME.toString());

        mTermsOfUseText = (TextView) findViewById(R.id.term_of_use_title);
        mTermsOfUseText.setOnClickListener(this);
        mLanguageText = (TextView) findViewById(R.id.tour_guide_language);
        mLanguageText.setOnClickListener(this);

        Cursor search_cursor = mDBAdapter.getStoreLang();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String language = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.LANGUAGE));
            mLanguage.setText(language);
        }

        mSendMailButton = (TextView) findViewById(R.id.question_send_button);
        mSendMailButton.setOnClickListener(this);

        final String tmpKey = "1";
        final String destPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/profile.jpg";

        mWeb.image_download(tmpKey, destPathStr, new DownloadProgressListener()
        {
            @Override
            public void update(String fileKey, long bytesRead, long contentLength, boolean done)
            {
                //download finished!
                if(done == true)
                {
                    mProfileImage = BitmapFactory.decodeFile(destPathStr);

                    Message msg = mCustomerUpdateHandler.obtainMessage();
                    Bundle b = new Bundle();
                    b.putString("type", "profile_refresh");
                    msg.setData(b);
                    mCustomerUpdateHandler.sendMessage(msg);

                }
            }
        }, disposables);

        mMessageSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked)
            {
                String flag = "1";
                if(isChecked == true)
                    flag = "0";

                setMessageAlarmDisableFunc(flag);

            }
        });

        mSellingSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked)
            {
                String flag = "1";
                if(isChecked == true)
                    flag = "0";

                setSellingAlarmDisableFunc(flag);
            }
        });

        mBuyingSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked)
            {
                String flag = "1";
                if(isChecked == true)
                    flag = "0";

                setBuyingAlarmDisableFunc(flag);

            }
        });

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);

        getSettingFunc();
    }

    private void setMessageAlarmDisableFunc(String flag)
    {
        mWeb.setMessageAlarmDisable(flag,
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            if(flag == "0")
                            {
                                mGeneralApplication.setMessageAlarm(true);
                            }
                            else
                            {
                                mGeneralApplication.setMessageAlarm(false);
                            }
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    setMessageAlarmDisableFunc(flag);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            setMessageAlarmDisableFunc(flag);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true) {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener() {
                                @Override
                                public void onAutoLoginSuccess() {
                                    setMessageAlarmDisableFunc(flag);
                                }

                                @Override
                                public void onAutoLoginFail() {
                                    startManualLogin(new LoginListener() {
                                        @Override
                                        public void onLoginSuccess() {
                                            setMessageAlarmDisableFunc(flag);
                                        }

                                        @Override
                                        public void onLoginCancel() {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void setSellingAlarmDisableFunc(String flag)
    {
        mWeb.setSellingAlarmDisable(flag,
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            if(flag == "0")
                            {
                                mGeneralApplication.setSellingAlarm(true);
                            }
                            else
                            {
                                mGeneralApplication.setSellingAlarm(false);
                            }
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {

                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    setSellingAlarmDisableFunc(flag);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            setSellingAlarmDisableFunc(flag);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    setSellingAlarmDisableFunc(flag);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            setSellingAlarmDisableFunc(flag);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void setBuyingAlarmDisableFunc(String flag)
    {
        mWeb.setBuyingAlarmDisable(flag,
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            if(flag == "0")
                            {
                                mGeneralApplication.setSellingAlarm(true);
                            }
                            else
                            {
                                mGeneralApplication.setSellingAlarm(false);
                            }
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getSettingFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getSettingFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getSettingFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getSettingFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void getSettingFunc()
    {
        mWeb.getSettingData(
                new Consumer<ResponseSettingData>()
                {
                    @Override
                    public void accept(ResponseSettingData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Setting serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mAdminQuestionEmail = serverData.getAdmin_mail();
                            String messageDisable = serverData.getMessage_disable();
                            String sellingDisable = serverData.getSelling_disable();
                            String buyingDisable = serverData.getBuying_disable();

                            if("1".equals(messageDisable) == true)
                            {
                                mMessageSwitch.setChecked(false);
                                mGeneralApplication.setMessageAlarm(false);
                            }
                            else
                            {
                                mMessageSwitch.setChecked(true);
                                mGeneralApplication.setMessageAlarm(true);
                            }

                            if("1".equals(sellingDisable) == true)
                            {
                                mSellingSwitch.setChecked(false);
                                mGeneralApplication.setSellingAlarm(false);
                            }
                            else
                            {
                                mSellingSwitch.setChecked(true);
                                mGeneralApplication.setSellingAlarm(true);
                            }

                            if("1".equals(buyingDisable) == true)
                            {
                                mBuyingSwitch.setChecked(false);
                                mGeneralApplication.setBuyingAlarm(false);
                            }
                            else
                            {
                                mBuyingSwitch.setChecked(true);
                                mGeneralApplication.setBuyingAlarm(true);
                            }
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    getSettingFunc();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            getSettingFunc();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true) {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener() {
                                @Override
                                public void onAutoLoginSuccess() {
                                    getSettingFunc();
                                }

                                @Override
                                public void onAutoLoginFail() {
                                    startManualLogin(new LoginListener() {
                                        @Override
                                        public void onLoginSuccess() {
                                            getSettingFunc();
                                        }

                                        @Override
                                        public void onLoginCancel() {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    private void getTermOfUse()
    {
        mWeb.getTermOfUse(
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            String decodedStr = URLDecoder.decode(objDatas.getData(), "utf-8");

                            showScrollDialog(getString(R.string.agree_terms), decodedStr, new GeneralAlarmButtonListener()
                            {
                                @Override
                                public void onButtonClickListener(View v, int id, int button)
                                {
                                }
                            });
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.

                    }
                }, disposables
        );
    }


    public void getPrivacyPolicy()
    {
        mWeb.getPrivacyPolicy(
                new Consumer<ResponseDummyData>()
                {
                    @Override
                    public void accept(ResponseDummyData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            String decodedStr = URLDecoder.decode(objDatas.getData(), "utf-8");

                            showScrollDialog(getString(R.string.agree_privacy_policy), decodedStr, new GeneralAlarmButtonListener()
                            {
                                @Override
                                public void onButtonClickListener(View v, int id, int button)
                                {
                                }
                            });
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.

                    }
                }, disposables
        );
    }

    private boolean recursiveRemove(File file)
    {
        if(file == null  || !file.exists()) {
            return false;
        }

        if(file.isDirectory()) {
            File[] list = file.listFiles();

            if(list != null) {

                for(File item : list) {
                    recursiveRemove(item);
                }

            }
        }

        if(file.exists()) {
            file.delete();
        }

        return !file.exists();
    }

    private void deleteAllTG()
    {
        Completable.fromCallable(new Callable<Void>()
        {
            @Override
            public Void call() throws Exception
            {
                DBAdapter tmpDBAdapter = new DBAdapter(SettingActivity.this);
                tmpDBAdapter.create();
                tmpDBAdapter.install();
                tmpDBAdapter.open();

                tmpDBAdapter.deleteAllMap();

                String APP_DIRECTORY = mGeneralApplication.getAppDirectory();

                String tmpUserIdStr = mGeneralApplication.getIdString();
                String mUserDir = Base64.mod_encode(tmpUserIdStr);

                String localPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir;

                recursiveRemove(new File(localPathStr));

                new File(localPathStr).mkdirs();

                Message msg = mCustomerUpdateHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putString("type", "delete_successful");
                msg.setData(b);
                mCustomerUpdateHandler.sendMessage(msg);

                return null;
            }
        })
        .subscribeOn(Schedulers.io())
        .observeOn(Schedulers.io())
        .subscribe(new CompletableObserver()
        {
            @Override
            public void onSubscribe(Disposable d)
            {
            }

            @Override
            public void onComplete()
            {
            }

            @Override
            public void onError(Throwable error)
            {
            }
        });
    }

    private void deleteAllTestTG()
    {
        Completable.fromCallable(new Callable<Void>()
        {
            @Override
            public Void call() throws Exception
            {
                DBAdapter tmpDBAdapter = new DBAdapter(SettingActivity.this);
                tmpDBAdapter.create();
                tmpDBAdapter.install();
                tmpDBAdapter.open();

                tmpDBAdapter.deleteAllTestMap();

                String APP_DIRECTORY = mGeneralApplication.getAppDirectory();

                String tmpUserIdStr = mGeneralApplication.getIdString();
                String mUserDir = Base64.mod_encode(tmpUserIdStr);

                String localPathStr = APP_DIRECTORY + "/" + MAP_TEST_DIR + "/" + mUserDir;

                recursiveRemove(new File(localPathStr));

                new File(localPathStr).mkdirs();

                Message msg = mCustomerUpdateHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putString("type", "delete_successful");
                msg.setData(b);
                mCustomerUpdateHandler.sendMessage(msg);

                return null;
            }
        })
        .subscribeOn(Schedulers.io())
        .observeOn(Schedulers.io())
        .subscribe(new CompletableObserver()
        {
            @Override
            public void onSubscribe(Disposable d)
            {
            }

            @Override
            public void onComplete()
            {
            }

            @Override
            public void onError(Throwable error)
            {
            }
        });
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        disposables.dispose();
    }

    private int resizeProfileImage(Uri tmpPic)
    {
        InputStream inputStream = null;
        try
        {
            inputStream = getContentResolver().openInputStream(tmpPic);

            byte[] buffer = null;
            try
            {
                buffer = new byte[inputStream.available()];

                inputStream.read(buffer);
            } catch (IOException e)
            {
                e.printStackTrace();
                return -1;
            }

            final String srcPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/profile.jpg";
            File targetFile = new File(srcPathStr);
            OutputStream outStream = null;
            try
            {
                outStream = new FileOutputStream(targetFile);
                outStream.write(buffer);
            }
            catch (IOException e)
            {
                e.printStackTrace();
                return -1;
            }

            try
            {
                inputStream.close();
                outStream.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
                return -1;
            }

            Bitmap tmpRawImage = BitmapFactory.decodeFile(srcPathStr);
            mProfileImage = Bitmap.createScaledBitmap(tmpRawImage, 300, 300, false);

            FileOutputStream out = null;
            try
            {
                out = new FileOutputStream(srcPathStr);
                mProfileImage.compress(Bitmap.CompressFormat.JPEG, 100, out); // bmp is your Bitmap instance
            }
            catch (Exception e)
            {
                e.printStackTrace();
                return -1;
            }
            finally
            {
                try
                {
                    if (out != null)
                    {
                        out.close();
                    }
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            return -1;
        }
        return 0;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK)
        {
            if (data == null)
            {
                //Display an error
                return;
            }

            final Uri tmpPic = data.getData();

            Completable.fromCallable(new Callable<Void>()
            {
                @Override
                public Void call() throws Exception
                {
                    int ret = resizeProfileImage(tmpPic);

                    if(ret < 0)
                    {
                        Message msg = mCustomerUpdateHandler.obtainMessage();
                        Bundle b = new Bundle();
                        b.putString("type", "error_fail");
                        msg.setData(b);
                        mCustomerUpdateHandler.sendMessage(msg);
                        return null;
                    }

                    final String srcPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/profile.jpg";

                    File tmpFile = new File(srcPathStr);

                    RequestBody requestFile =
                            RequestBody.create(
                                    //MediaType.parse(getContentResolver().getType(tmpUri)),
                                    MediaType.parse("image/*"),
                                    tmpFile
                            );

                    //profile image upload
                    mWeb.image_upload("profile_image_path", "profile.jpg", requestFile, new Consumer<ResponseUploadImageData>()
                    {
                        @Override
                        public void accept(ResponseUploadImageData registerDatas) throws Exception
                        {
                            // TODO: Handle response.
                            String serverResult = registerDatas.getResult();
                            String serverData = registerDatas.getData();

                            if(serverResult.equals(JSON_SUCCESS))
                            {
                                Message msg = mCustomerUpdateHandler.obtainMessage();
                                Bundle b = new Bundle();
                                b.putString("type", "upload_successful");
                                msg.setData(b);
                                mCustomerUpdateHandler.sendMessage(msg);
                            }
                            else if(serverResult.equals(JSON_LOGOUT))
                            {
                                Message msg = mCustomerUpdateHandler.obtainMessage();
                                Bundle b = new Bundle();
                                b.putString("type", "error_logout");
                                msg.setData(b);
                                mCustomerUpdateHandler.sendMessage(msg);
                            }
                            else if(serverResult.equals(JSON_FAIL))
                            {
                                Message msg = mCustomerUpdateHandler.obtainMessage();
                                Bundle b = new Bundle();
                                b.putString("type", "error_fail");
                                b.putInt("code", registerDatas.getResultCode());
                                msg.setData(b);
                                mCustomerUpdateHandler.sendMessage(msg);
                            }
                        }
                    },new Consumer<Throwable>()
                    {
                        @Override
                        public void accept(@NonNull Throwable throwable) throws Exception
                        {
                            // TODO: Handle error.

                            Message msg = mCustomerUpdateHandler.obtainMessage();
                            Bundle b = new Bundle();
                            b.putString("type", "error_logout");
                            msg.setData(b);
                            mCustomerUpdateHandler.sendMessage(msg);
                        }
                    }, disposables);
                    return null;
                }
            })
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.io())
            .subscribe(new CompletableObserver()
            {
                @Override
                public void onSubscribe(Disposable d) {}

                @Override
                public void onComplete()
                {
                    Log.d(TAG, "Test RxJAVA, onComplete");
                }

                @Override
                public void onError(Throwable error)
                {
                    Log.d(TAG, "Test RxJAVA, onError");
                }
            });
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
        else if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
    }

    private void loadStoreLanguage()
    {
        Cursor search_cursor = mDBAdapter.getStoreLang();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String language = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.LANGUAGE));

            mWeb.setLanguage(language);

            mWeb.getStorelist(
                    new Consumer<ResponseStoresData>()
                    {
                        @Override
                        public void accept(ResponseStoresData objDatas) throws Exception
                        {
                            // TODO: Handle response.
                            String serverResult = objDatas.getResult();
                            Stores serverStoreData = objDatas.getData();

                            if(serverResult.equals(JSON_SUCCESS))
                            {
                                ArrayList<String> store_names = serverStoreData.getStores();
                                ArrayList<String> store_urls = serverStoreData.getUrls();

                                FragmentManager fm = getFragmentManager();
                                mTGLanguageOptionDialog = new LanguageOptionDialog();
                                mTGLanguageOptionDialog.setTitle(getString(R.string.language_select_title));
                                mTGLanguageOptionDialog.setLists(store_names);
                                mTGLanguageOptionDialog.setCancelable(false);
                                mTGLanguageOptionDialog.setOptionListener(new LanguageOptionListener()
                                {
                                    @Override
                                    public void onListClickListener(View v, int index)
                                    {
                                        if(index != -1)
                                        {
                                            String tmpUrl = store_urls.get(index);
                                            //String completeUrl = "https://" + tmpUrl;
                                            String completeUrl = tmpUrl;
                                            String currentServer = mWeb.getServer();
                                            if(currentServer.equals(completeUrl) == false)
                                            {
                                                mDBAdapter.putStoreLang(store_names.get(index));

                                                mWeb.setLanguage(store_names.get(index));

                                                mWeb.setServer(completeUrl);

                                                mWeb.sendSessionData(
                                                        new Consumer<ResponseSendSessionData>()
                                                        {
                                                            @Override
                                                            public void accept(ResponseSendSessionData objDatas) throws Exception
                                                            {
                                                                // TODO: Handle response.
                                                                Cursor new_cursor = mDBAdapter.getStoreLang();
                                                                if(new_cursor != null && new_cursor.moveToFirst())
                                                                {
                                                                    String language = new_cursor.getString(new_cursor.getColumnIndex(DBAdapter.LANGUAGE));
                                                                    mLanguage.setText(language);
                                                                    new_cursor.close();
                                                                }
                                                            }
                                                        }
                                                        ,new Consumer<Throwable>()
                                                        {
                                                            @Override
                                                            public void accept(@NonNull Throwable throwable) throws Exception
                                                            {
                                                                // TODO: Handle error.
                                                            }
                                                        }, disposables
                                                );
                                            }
                                        }
                                    }
                                });
                                mTGLanguageOptionDialog.show(fm, "tag");
                            }
                            else if(serverResult.equals(JSON_FAIL))
                            {
                                BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                            }
                        }
                    }
                    ,new Consumer<Throwable>()
                    {
                        @Override
                        public void accept(@NonNull Throwable throwable) throws Exception
                        {
                            // TODO: Handle error.
                        }
                    }, disposables
            );

            search_cursor.close();
        }
        else
        {
            mWeb.getStorelist(
                    new Consumer<ResponseStoresData>()
                    {
                        @Override
                        public void accept(ResponseStoresData objDatas) throws Exception
                        {
                            // TODO: Handle response.
                            String serverResult = objDatas.getResult();
                            Stores serverStoreData = objDatas.getData();

                            if(serverResult.equals(JSON_SUCCESS))
                            {
                                ArrayList<String> store_names = serverStoreData.getStores();
                                ArrayList<String> store_urls = serverStoreData.getUrls();

                                FragmentManager fm = getFragmentManager();
                                mTGLanguageOptionDialog = new LanguageOptionDialog();
                                mTGLanguageOptionDialog.setTitle(getString(R.string.language_select_title));
                                mTGLanguageOptionDialog.setLists(store_names);
                                mTGLanguageOptionDialog.setCancelable(false);
                                mTGLanguageOptionDialog.setOptionListener(new LanguageOptionListener()
                                {
                                    @Override
                                    public void onListClickListener(View v, int index)
                                    {
                                        if(index != -1)
                                        {
                                            String tmpUrl = store_urls.get(index);
                                            //String completeUrl = "https://" + tmpUrl;
                                            String completeUrl = tmpUrl;
                                            String currentServer = mWeb.getServer();
                                            if(currentServer.equals(completeUrl) == false)
                                            {
                                                mDBAdapter.putStoreLang(store_names.get(index));

                                                mWeb.setLanguage(store_names.get(index));

                                                mWeb.setServer(completeUrl);

                                                mWeb.sendSessionData(
                                                        new Consumer<ResponseSendSessionData>()
                                                        {
                                                            @Override
                                                            public void accept(ResponseSendSessionData objDatas) throws Exception
                                                            {
                                                                // TODO: Handle response.

                                                                Cursor new_cursor = mDBAdapter.getStoreLang();
                                                                if(new_cursor != null && new_cursor.moveToFirst())
                                                                {
                                                                    String language = new_cursor.getString(new_cursor.getColumnIndex(DBAdapter.LANGUAGE));
                                                                    mLanguage.setText(language);
                                                                    new_cursor.close();
                                                                }
                                                            }
                                                        }
                                                        ,new Consumer<Throwable>()
                                                        {
                                                            @Override
                                                            public void accept(@NonNull Throwable throwable) throws Exception
                                                            {
                                                                // TODO: Handle error.
                                                            }
                                                        }, disposables
                                                );
                                            }
                                        }
                                    }
                                });
                                mTGLanguageOptionDialog.show(fm, "tag");
                            }
                            else if(serverResult.equals(JSON_FAIL))
                            {
                                BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                            }
                        }
                    }
                    ,new Consumer<Throwable>()
                    {
                        @Override
                        public void accept(@NonNull Throwable throwable) throws Exception
                        {
                            // TODO: Handle error.
                        }
                    }, disposables
            );
        }
    }

    @Override
    public void onClick(View v)
    {
        Intent intent = null;
        switch(v.getId())
        {
            case R.id.setting_activity_back_button:
                finish();
                break;
            case R.id.user_name_select:
            case R.id.user_name_text:
                intent = new Intent(SettingActivity.this, CustomerUpdateActivity.class);
                intent.putExtra(CustomerUpdateActivity.ACCOUNT_TYPE, CustomerUpdateActivity.USER_NAME_TYPE);
                startActivity(intent);
                break;
            case R.id.password_select:
            case R.id.password_text:
                intent = new Intent(SettingActivity.this, CustomerUpdateActivity.class);
                intent.putExtra(CustomerUpdateActivity.ACCOUNT_TYPE, CustomerUpdateActivity.PASSWORD_TYPE);
                startActivity(intent);
                break;
            case R.id.payout_select:
            case R.id.payout_text:
                intent = new Intent(SettingActivity.this, CustomerUpdateActivity.class);
                intent.putExtra(CustomerUpdateActivity.ACCOUNT_TYPE, CustomerUpdateActivity.PAYOUT_TYPE);
                startActivity(intent);
                break;
            case R.id.delete_all_tourguide_button:
                deleteAllTG();
                break;
            case R.id.delete_all_test_tourguide_button:
                deleteAllTestTG();
                break;
            case R.id.delete_auto_login_button:
                //DeleteLoginInfoPopup();
                BaseLib().showGeneralPopup(getString(R.string.auto_login_cancelled), getString(R.string.login_info_required_after_next_login), null);

                mDBAdapter.deleLoginInfo();
                mDBAdapter.deleteLoginType();
                break;
            case R.id.show_term_of_use_data:
            case R.id.term_of_use_title:
                getTermOfUse();
                break;
            case R.id.show_privacy_data:
            case R.id.privacy_title:
                getPrivacyPolicy();
                break;
            case R.id.show_language_popup:
                loadStoreLanguage();
                break;
            case R.id.tour_guide_language_data:
            case R.id.tour_guide_language:
                loadStoreLanguage();
                break;
            case R.id.question_send_button:
                intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL  , new String[] { mAdminQuestionEmail });
                intent.putExtra(Intent.EXTRA_SUBJECT, "Question about TGM");
                startActivity(Intent.createChooser(intent, "Email via..."));
                break;
            case R.id.photo_click_icon:
                intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Profile Picture"), PICK_IMAGE);
                break;
        }
    }

    final Handler mCustomerUpdateHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

            final String destPathStr = APP_DIRECTORY + "/" + MAP_DIR + "/" + mUserDir + "/profile.jpg";
            String type_str = msg.getData().getString("type");
            int resultCode = 0;
            Bitmap tmpBitmap = null;

            switch (type_str)
            {
                case "profile_refresh":
                    //mProfileImageView.setImageBitmap(mProfileImage);
                    mProfileImageView.setBackground(null);
                    //Picasso.with(MapSettingActivity.this).load("file://" + destPathStr).transform(new CircleTransformation()).skipMemoryCache().into(mProfileImageView);
                    //Picasso.get().load("file://" + destPathStr).transform(new CircleTransformation()).memoryPolicy(MemoryPolicy.NO_CACHE).into(mProfileImageView);
                    //Picasso.get().load("file://" + destPathStr).memoryPolicy(MemoryPolicy.NO_CACHE).into(mProfileImageView);
                    if(destPathStr == null)
                    {
                        tmpBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.sample_photo);
                    }
                    else
                    {
                        tmpBitmap = BitmapFactory.decodeFile(destPathStr);
                    }
                    mProfileImageView.setImageBitmap(tmpBitmap);
                    break;

                case "upload_successful":
                    //mProfileImageView.setImageBitmap(mProfileImage);
                    mProfileImageView.setBackground(null);
                    //Picasso.with(MapSettingActivity.this).load("file://" + destPathStr).transform(new CircleTransformation()).skipMemoryCache().into(mProfileImageView);
                    //Picasso.get().load("file://" + destPathStr).memoryPolicy(MemoryPolicy.NO_CACHE).into(mProfileImageView);
                    if(destPathStr == null)
                    {
                        tmpBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.sample_photo);
                    }
                    else
                    {
                        tmpBitmap = BitmapFactory.decodeFile(destPathStr);
                    }
                    mProfileImageView.setImageBitmap(tmpBitmap);

                    BaseLib().showGeneralPopup(getString(R.string.setting_succcess_title), getString(R.string.upload_profile_image_message), null);
                    break;

                case "error_logout":
                    mGeneralApplication.setIdString("");
                    mGeneralApplication.setNumString("");
                    mGeneralApplication.setLoggedIn(false);

                    LoginProcessPopup(new AutoLoginListener()
                    {
                        @Override
                        public void onAutoLoginSuccess()
                        {
                        }

                        @Override
                        public void onAutoLoginFail()
                        {
                            startManualLogin(new LoginListener()
                            {
                                @Override
                                public void onLoginSuccess()
                                {
                                }

                                @Override
                                public void onLoginCancel()
                                {
                                    BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                }
                            });
                        }
                    });
                    break;

                case "error_fail":
                    //showAlarmDialog(getString(R.string.setting_error_title), getString(R.string.setting_failed));
                    resultCode = msg.getData().getInt("code");
                    BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(resultCode), null);
                    break;

                case "delete_successful":
                    BaseLib().showGeneralPopup(getString(R.string.setting_succcess_title), getString(R.string.delete_files_successful), null);
                    break;

                default:
                    break;
            }
        }
    };
}
