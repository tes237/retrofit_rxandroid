package etm.main.market.activities;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.design.widget.NavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.payment.util.IabHelper;
import etm.main.market.payment.util.IabResult;
import etm.main.market.payment.util.Inventory;
import etm.main.market.payment.util.TGMPurchase;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.PurchasedItem;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.vo.ResponsePurchaseData;

public class PaymentActivity extends BaseActivity implements baseDefine
{
    private static final String TAG = PaymentActivity.class.getSimpleName();

    private Context mContext;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;

    private String mProductKey = null;
    private String mSkuStr = null;
    private String mTitleStr = "";
    private String mPriceStr = "";
    private String mImageStr = "";
    private String mStoreLanguage = "";

    private TGMPurchase mTGMPurchase = null;
    private IabHelper.QueryInventoryFinishedListener mQueryFinishedListener = null;

    private Button mPaymentButton;
    private ImageButton mBackButton;
    private ImageView mProductImage;
    private TextView mProductTitle;
    private TextView mProductPrice;
    private TextView mTitlePrice;
    private TextView mCancelText;

    private TextView mTtsReadingTitle;
    private TextView mTtsExampleText;
    private Button mListenButton, mConfirmButton;

    TextToSpeech mTTS;

    private GeneralAlarmDialog mGeneralAlarmDialog = null;
    private DBAdapter mDBAdapter = null;

    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);
    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mProductKey = bd.getString(IntroActivity.PRODUCT_PURCHASE_KEY);
            mSkuStr = bd.getString(IntroActivity.MAP_SKU);

            mTitleStr = bd.getString(IntroActivity.MAP_TITLE);
            mPriceStr = bd.getString(IntroActivity.MAP_PRICE);
            mImageStr = bd.getString(IntroActivity.MAP_IMAGE);
            mStoreLanguage = bd.getString(IntroActivity.MAP_LANGUAGE);
        }

        mPaymentButton = (Button) findViewById(R.id.payment_button);
        mBackButton = (ImageButton)findViewById(R.id.intro_activity_back_button);
        mCancelText = (TextView) findViewById(R.id.payment_cancel_button);

        mProductImage = (ImageView) findViewById(R.id.product_image);
        mProductTitle = (TextView) findViewById(R.id.product_title);
        mProductPrice = (TextView) findViewById(R.id.product_price);
        mTitlePrice = (TextView) findViewById(R.id.payment_price);

        mTtsReadingTitle = (TextView) findViewById(R.id.tts_reading_test_title);
        mTtsExampleText = (TextView) findViewById(R.id.tts_example_text);
        mConfirmButton = (Button) findViewById(R.id.tts_confirm_button);
        mListenButton = (Button) findViewById(R.id.listen_button);

        //Picasso.with(mContext).load(mImageStr).placeholder(R.drawable.sample_photo).into(mProductImage);
        Picasso.get().load(mImageStr).placeholder(R.drawable.sample_photo).into(mProductImage);

        mProductTitle.setText(mTitleStr);
        mProductPrice.setText(mPriceStr);
        mTitlePrice.setText(mPriceStr);

        switch(mStoreLanguage)
        {
            case STORE_ENG:

                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_ENG_NAME));
                break;
            case STORE_KOR:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_KOR_NAME));
                break;
            case STORE_SPN:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_SPN_NAME));
                break;
            case STORE_POR:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_POR_NAME));
                break;
            case STORE_FRN:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_FRN_NAME));
                break;
            case STORE_ITL:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_ITL_NAME));
                break;
            case STORE_RUS:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_RUS_NAME));
                break;
            case STORE_TRDCHN:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_TRDCHN_NAME));
                break;
            case STORE_SIMCHN:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_SIMCHN_NAME));
                break;
            case STORE_ARB:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_ARB_NAME));
                break;
            case STORE_JPN:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_JPN_NAME));
                break;
            case STORE_GER:
                mTtsReadingTitle.setText(getString(R.string.please_try_tts_test, STORE_GER_NAME));
                break;
        }

        mCancelText.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });

        mBackButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });

        mListenButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mTTS = new TextToSpeech(PaymentActivity.this, new TextToSpeech.OnInitListener()
                {
                    @Override
                    public void onInit(int status)
                    {
                        int result = -1;

                        switch(mStoreLanguage)
                        {
                            case STORE_ENG:
                                result = mTTS.setLanguage(Locale.ENGLISH);
                                break;
                            case STORE_KOR:
                                result = mTTS.setLanguage(Locale.KOREAN);
                                break;
                            case STORE_SPN:
                                Locale locSpanish = new Locale("spa", "MEX");
                                result = mTTS.setLanguage(locSpanish);
                                break;
                            case STORE_POR:
                                Locale locPor = new Locale("pt", "POR");
                                result = mTTS.setLanguage(locPor);
                                break;
                            case STORE_FRN:
                                result = mTTS.setLanguage(Locale.FRENCH);
                                break;
                            case STORE_ITL:
                                result = mTTS.setLanguage(Locale.ITALIAN);
                                break;
                            case STORE_RUS:
                                Locale locRus = new Locale("ru");
                                result = mTTS.setLanguage(locRus);
                                break;
                            case STORE_TRDCHN:
                                result = mTTS.setLanguage(Locale.TRADITIONAL_CHINESE);
                                break;
                            case STORE_SIMCHN:
                                result = mTTS.setLanguage(Locale.SIMPLIFIED_CHINESE);
                                break;
                            case STORE_ARB:
                                Locale locArb = new Locale("ar");
                                result = mTTS.setLanguage(locArb);
                                break;
                            case STORE_JPN:
                                result = mTTS.setLanguage(Locale.JAPANESE);
                                break;
                            case STORE_GER:
                                result = mTTS.setLanguage(Locale.GERMAN);
                                break;
                        }

                        if (result == TextToSpeech.LANG_MISSING_DATA
                                || result == TextToSpeech.LANG_NOT_SUPPORTED)
                        {
                            Log.e("TTS", "This Language is not supported");

                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.your_device_does_not_support_this_language_voice),
                                    new GeneralAlarmButtonListener()
                                    {
                                        @Override
                                        public void onButtonClickListener(View v, int id, int button)
                                        {
                                            mConfirmButton.setEnabled(true);
                                            mPaymentButton.setEnabled(true);
                                        }
                                    });
                        }
                        else
                        {
                            //btnSpeak.setEnabled(true);
                            speakOut(null);
                        }
                    }
                });

                mTTS.setOnUtteranceProgressListener(new UtteranceProgressListener()
                {
                    @Override
                    public void onDone(String utteranceId)
                    {

                    }

                    @Override
                    public void onError(String utteranceId)
                    {

                    }

                    @Override
                    public void onStart(String utteranceId)
                    {

                    }
                });

            }
        });

        mConfirmButton.setEnabled(false);
        mConfirmButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mPaymentButton.setEnabled(true);
            }
        });

        mPaymentButton.setEnabled(false);
        mPaymentButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                purchaseProductFunc(mSkuStr);   //test purpose
                //mTGMPurchase.buy(mProductKey);    //real product code
            }
        });

        switch(mStoreLanguage)
        {
            case STORE_ENG:
                mTtsExampleText.setText("Hello. If you hear this sentence, please press the TTS OK");
                break;
            case STORE_KOR:
                mTtsExampleText.setText("안녕하세요. 이 문장이 들리시면 TTS 확인을 눌러주세요");
                break;
            case STORE_SPN:
                mTtsExampleText.setText("Hola. Si escucha esta oración, presione TTS OK");
                break;
            case STORE_POR:
                mTtsExampleText.setText("Olá. Se você ouvir esta frase, por favor, pressione o TTS OK");
                break;
            case STORE_FRN:
                mTtsExampleText.setText("Bonjour. Si vous entendez cette phrase, veuillez appuyer sur la touche TTS OK");
                break;
            case STORE_ITL:
                mTtsExampleText.setText("Ciao. Se senti questa frase, premi il tasto TTS OK");
                break;
            case STORE_RUS:
                mTtsExampleText.setText("Здравствуйте. Если вы услышите это предложение, нажмите кнопку TTS OK");
                break;
            case STORE_TRDCHN:
                mTtsExampleText.setText("你好. 如果您聽到這句話，請按TTS確定");
                break;
            case STORE_SIMCHN:
                mTtsExampleText.setText("早上好 如果您看到这句话，请按TTS确定");
                break;
            case STORE_ARB:
                mTtsExampleText.setText("你好. 如果您听到这句话，请按TTS确定TTS OK");
                break;
            case STORE_JPN:
                mTtsExampleText.setText("こんにちは。 この文が聞こえたら、TTS OKを押してください");
                break;
            case STORE_GER:
                mTtsExampleText.setText("Hallo. Wenn Sie diesen Satz hören, drücken Sie bitte die TTS OK");
                break;
        }

        mTGMPurchase = new TGMPurchase(this)
        {
            @Override
            public void addInventory()
            {
                purchaseProductFunc(mSkuStr);

                /*
                BaseLib().showGeneralPopup(getString(R.string.success_title), getString(R.string.successfully_purchased_this_product),
                        new GeneralAlarmButtonListener()
                        {
                            @Override
                            public void onButtonClickListener(View v, int id, int button)
                            {

                            }
                        });
                */

                /*
                String result = "구매완료";
                AlertDialog.Builder alert = new AlertDialog.Builder(PaymentActivity.this);
                alert.setPositiveButton("확인", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        dialog.dismiss();
                    }
                });
                alert.setMessage(result);
                alert.show();
                */
            }
        };

        mQueryFinishedListener = new IabHelper.QueryInventoryFinishedListener()
        {
            public void onQueryInventoryFinished(IabResult result, Inventory inventory)
            {
                if (result.isFailure())
                {
                    // handle error
                    return;
                }

                if(result.isSuccess())
                {
                    //isPremium = inventory.hasPurchase(Constants.SKU_PREMIUM);
                    //Log.d(Constants.TAG, "App is " + (isPremium ? "PREMIUM" : "NOT PREMIUM"));
                }

                //String redPrice = inventory.getSkuDetails("tourguidemarket_price_1000").getPrice();
                String redPrice = inventory.getSkuDetails(mProductKey).getPrice();
                //String yellowPrice = inventory.getSkuDetails(IAB.SKU_BG_YELLOW).getPrice();
            }
        };
        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);
    }

    private void purchaseProductFunc(String tmpSkuStr)
    {
        mWeb.purchaseProduct(tmpSkuStr,
                new Consumer<ResponsePurchaseData>()
                {
                    @Override
                    public void accept(ResponsePurchaseData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        String serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.success_title), getString(R.string.successfully_purchased_this_product),
                                    new GeneralAlarmButtonListener()
                                    {
                                        @Override
                                        public void onButtonClickListener(View v, int id, int button)
                                        {
                                            setResult(PAYMENT_FINISHED);
                                            finish();
                                        }
                                    });
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                                    /*
                                    String result = "구매완료";
                                    //Log.d(TAG, result);
                                    AlertDialog.Builder alert = new AlertDialog.Builder(PaymentActivity.this);
                                    alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();     //닫기
                                            setResult(PAYMENT_ERROR);
                                            finish();
                                        }
                                    });
                                    alert.setMessage(result);
                                    alert.show();
                                    */
                        }
                        else if (serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    purchaseProductFunc(tmpSkuStr);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            purchaseProductFunc(tmpSkuStr);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    purchaseProductFunc(tmpSkuStr);
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            purchaseProductFunc(tmpSkuStr);
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, disposables
        );
    }

    @Override
    public void onResume()
    {
        if(mGeneralApplication.IsLoggedIn() == true)
        {
            if(mGeneralApplication.isTermsAgreed() == false)
            {
                getTerms();
            }
            else
            {
                if(mGeneralApplication.isPrivacyAgreed() == false)
                {
                    getPrivacyPolicy();
                }
            }
        }
        super.onResume();
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        disposables.dispose();
        mTGMPurchase.destroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
        else
        {
            mTGMPurchase.activityResult(requestCode, resultCode, data);
        }
    }

    private void speakOut(String commentStr)
    {
        if((commentStr == null) || (commentStr.equals("") == true))
        {
            String text = mTtsExampleText.getText().toString();

            HashMap<String, String> map = new HashMap<String, String>();

            map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "tourguide_test");

            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, map);
        }
        else
        {
            HashMap<String, String> map = new HashMap<String, String>();

            map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "tourguide_test");

            mTTS.speak(commentStr, TextToSpeech.QUEUE_FLUSH, map);
        }

        mConfirmButton.setEnabled(true);
    }


    @Override
    public void finish()
    {

        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        super.finish();
    }
}
