package etm.main.market.activities;

import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import etm.main.market.R;
import etm.main.market.baseDefine;
import etm.main.market.common.Base64;
import etm.main.market.connects.DownloadProgressListener;
import etm.main.market.connects.WebManager;
import etm.main.market.db.DBAdapter;
import etm.main.market.dialog.FilterButtonListener;
import etm.main.market.dialog.FilterDialog;
import etm.main.market.dialog.GeneralAlarmButtonListener;
import etm.main.market.dialog.GeneralAlarmDialog;
import etm.main.market.dialog.GeneralProgressDialog;
import etm.main.market.dialog.SearchFilterDialog;
import etm.main.market.dialog.SearchFilterListener;
import etm.main.market.etc.AutoLoginListener;
import etm.main.market.etc.BooleanWrapper;
import etm.main.market.etc.LoginListener;
import etm.main.market.generalApplication;
import etm.main.market.lists.InfoAdapter;
import etm.main.market.lists.InfoListListener;
import etm.main.market.vo.Product;
import etm.main.market.vo.Products;
import etm.main.market.vo.ResponseProductsData;
import etm.main.market.widgets.swipyLayout.*;
import etm.main.market.widgets.tagview.Tag;
import etm.main.market.widgets.tagview.TagView;


import android.app.FragmentManager;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CategoryListActivity extends BaseActivity implements baseDefine, InfoListListener, View.OnClickListener
{
    private static final String TAG = CategoryListActivity.class.getSimpleName();
    public static final String MAP_SKU = "map_sku";
    public static final String MAP_TITLE = "map_title";

    public static final int TRANSPORTATION_TYPE = 0;
    public static final int SPECIAL_MEALS_TYPE = 1;
    public static final int THEME_TYPE = 2;
    public static final int DURATION_TYPE = 3;

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private InfoAdapter mInfoAdapter;
    private SwipyRefreshLayout mSwipyRefreshLayout;
    private TextView mTextView;
    private ImageButton mBackButton;
    private Button mSearchFilterButton;

    private ImageButton mTransportationButton;
    private ImageButton mMealsButton;
    private ImageButton mThemesButton;
    private ImageButton  mDurationButton;

    private GeneralProgressDialog pd;

    protected generalApplication mGeneralApplication = null;
    protected WebManager mWeb;

    private List<Product> mDataList;
    private String mCategoryStr = "";

    private DBAdapter mDBAdapter = null;
    private BooleanWrapper mIsFbLoginEvent = new BooleanWrapper(false);

    private int mCurrentPageIndex = 1;
    private int mTotalPageCount = 1;

    private CompositeDisposable disposables = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        pd = new GeneralProgressDialog(this, R.drawable.spinner);
        pd.show();

        mGeneralApplication = (generalApplication)getApplicationContext();
        mWeb = mGeneralApplication.getTGMWeb();

        mDBAdapter = new DBAdapter(this);
        mDBAdapter.create();
        mDBAdapter.install();
        mDBAdapter.open();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_guide_category_list);

        //String keywordsStr[] = null;
        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            mCategoryStr = bd.getString(HomeActivity.HOME_CATEGORY_TYPE);
        }

        mSwipyRefreshLayout = (SwipyRefreshLayout)findViewById(R.id.tourguide_swipy_layout);
        mRecyclerView = (RecyclerView)findViewById(R.id.tourguide_recycler_view);
        //mSearchFilterView = (TagView)findViewById(R.id.search_filter_tagview);
        mTextView = (TextView)findViewById(R.id.list_activity_title_textview);
        mBackButton = (ImageButton)findViewById(R.id.list_activity_back_button);

        //mTransportationButton = (ImageButton)findViewById(R.id.list_activity_transportation_button);
        //mMealsButton = (ImageButton)findViewById(R.id.list_activity_special_meals_button);
        //mThemesButton = (ImageButton)findViewById(R.id.list_activity_trip_themes_button);
        //mDurationButton = (ImageButton)findViewById(R.id.list_activity_trip_duration_button);

        mBackButton.setOnClickListener(this);

        //mTransportationButton.setOnClickListener(this);
        //mMealsButton.setOnClickListener(this);
        //mThemesButton.setOnClickListener(this);
        //mDurationButton.setOnClickListener(this);

        //mTextView.setText(mSearchKeywordArr[0]);

        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mDataList = new ArrayList<Product>();
        mInfoAdapter = new InfoAdapter(CategoryListActivity.this, mDataList, this);
        mRecyclerView.setAdapter(mInfoAdapter);

        if(mCategoryStr == null)
        {
            mCategoryStr = "";
        }

        mDataList.clear();

        switch(mCategoryStr)
        {
            case HomeActivity.POPULAR_TYPE:
                loadTitle(getString(R.string.popular_travel_guide_text));
                loadPopularList();
                break;
            //case HomeActivity.VIEWED_TYPE:
            //    loadViewedList();
            //    break;
            case HomeActivity.WISHLIST_TYPE:
                loadTitle(getString(R.string.wishlist_travel_guide_text));
                loadWishList();
                break;
            case HomeActivity.EUROPE_TYPE:
                loadTitle(getString(R.string.europe_text));
                loadRegionList("52");
                break;
            case HomeActivity.ASIA_TYPE:
                loadTitle(getString(R.string.asia_text));
                loadRegionList("51");
                break;
            case HomeActivity.NORTH_AMERICA_TYPE:
                loadTitle(getString(R.string.north_america_text));
                loadRegionList("49");
                break;
            case HomeActivity.SOUTH_AMERICA_TYPE:
                loadTitle(getString(R.string.south_america_text));
                loadRegionList("48");
                break;
            case HomeActivity.AFRICA_TYPE:
                loadTitle(getString(R.string.africa_text));
                loadRegionList("50");
                break;
            case HomeActivity.OCEANIA_TYPE:
                loadTitle(getString(R.string.oceania_text));
                loadRegionList("47");
                break;
            case HomeActivity.ETC_TYPE:
                loadTitle(getString(R.string.etc_area_text));
                loadRegionList("53");
                break;
            default:
                break;
        }

        mSwipyRefreshLayout.setDirection(SwipyRefreshLayoutDirection.BOTTOM);

        mSwipyRefreshLayout.setOnRefreshListener(new SwipyRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(SwipyRefreshLayoutDirection direction)
            {
                //private int mCurrentPageIndex = 1;
                //private int mTotalPageCount = 1;

                if(mTotalPageCount < mCurrentPageIndex + 1)
                {
                    mSwipyRefreshLayout.setRefreshing(false);
                    return;
                }

                mCurrentPageIndex++;

                switch(mCategoryStr)
                {
                    case HomeActivity.POPULAR_TYPE:
                        loadTitle(getString(R.string.popular_travel_guide_text));
                        loadPopularList();
                        break;
                    //case HomeActivity.VIEWED_TYPE:
                    //    loadViewedList();
                    //    break;
                    case HomeActivity.WISHLIST_TYPE:
                        loadTitle(getString(R.string.wishlist_travel_guide_text));
                        loadWishList();
                        break;
                    case HomeActivity.EUROPE_TYPE:
                        loadTitle(getString(R.string.europe_text));
                        loadRegionList("52");
                        break;
                    case HomeActivity.ASIA_TYPE:
                        loadTitle(getString(R.string.asia_text));
                        loadRegionList("51");
                        break;
                    case HomeActivity.NORTH_AMERICA_TYPE:
                        loadTitle(getString(R.string.north_america_text));
                        loadRegionList("49");
                        break;
                    case HomeActivity.SOUTH_AMERICA_TYPE:
                        loadTitle(getString(R.string.south_america_text));
                        loadRegionList("48");
                        break;
                    case HomeActivity.AFRICA_TYPE:
                        loadTitle(getString(R.string.africa_text));
                        loadRegionList("50");
                        break;
                    case HomeActivity.OCEANIA_TYPE:
                        loadTitle(getString(R.string.oceania_text));
                        loadRegionList("47");
                        break;
                    case HomeActivity.ETC_TYPE:
                        loadTitle(getString(R.string.etc_area_text));
                        loadRegionList("53");
                        break;
                    default:
                        break;
                }

                mSwipyRefreshLayout.setRefreshing(false);
            }
        });

        BaseLib().initBaseLib(this, mGeneralApplication, mDBAdapter, mWeb, disposables, mIsFbLoginEvent);
    }


    @Override
    public void onResume()
    {
        if(mGeneralApplication.IsLoggedIn() == true)
        {
            if(mGeneralApplication.isTermsAgreed() == false)
            {
                getTerms();
            }
            else
            {
                if(mGeneralApplication.isPrivacyAgreed() == false)
                {
                    getPrivacyPolicy();
                }
            }
        }
        super.onResume();
    }

    @Override
    public void onListClickListener(View v, int index, int status)
    {
        mGeneralApplication.setTick("CategoryList click");

        Product tmpData = mDataList.get(index);
        String idStr = tmpData.getSku();

        if(mCategoryStr.equals(HomeActivity.WISHLIST_TYPE))
        {
            boolean isStoreDifferent = false;
            String storeLanguageId = tmpData.getStoreLanaguage();

            Cursor search_cursor = mDBAdapter.getStoreLang();
            if (search_cursor != null && search_cursor.moveToFirst())
            {
                String languageName = search_cursor.getString(search_cursor.getColumnIndex(DBAdapter.LANGUAGE));

                switch(storeLanguageId)
                {
                    case STORE_ENG:
                        if(STORE_ENG_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_ENG_NAME, STORE_ENG_NAME), null);
                            return;
                        }
                        break;

                    case STORE_KOR:
                        if(STORE_KOR_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_KOR_NAME, STORE_KOR_NAME), null);
                            return;
                        }
                        break;

                    case STORE_JPN:
                        if(STORE_JPN_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_JPN_NAME, STORE_JPN_NAME), null);
                            return;
                        }
                        break;

                    case STORE_GER:
                        if(STORE_GER_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_GER_NAME, STORE_GER_NAME), null);
                            return;
                        }
                        break;

                    case STORE_RUS:
                        if(STORE_RUS_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_RUS_NAME, STORE_RUS_NAME), null);
                            return;
                        }
                        break;

                    case STORE_SPN:
                        if(STORE_SPN_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_SPN_NAME, STORE_SPN_NAME), null);
                            return;
                        }
                        break;

                    case STORE_POR:
                        if(STORE_POR_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_POR_NAME, STORE_POR_NAME), null);
                            return;
                        }
                        break;

                    case STORE_ITL:
                        if(STORE_ITL_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_ITL_NAME, STORE_ITL_NAME), null);
                            return;
                        }
                        break;

                    case STORE_ARB:
                        if(STORE_ARB_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_ARB_NAME, STORE_ARB_NAME), null);
                            return;
                        }
                        break;

                    case STORE_FRN:
                        if(STORE_FRN_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_FRN_NAME, STORE_FRN_NAME), null);
                            return;
                        }
                        break;

                    case STORE_SIMCHN:
                        if(STORE_SIMCHN_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_SIMCHN_NAME, STORE_SIMCHN_NAME), null);
                            return;
                        }
                        break;

                    case STORE_TRDCHN:
                        if(STORE_TRDCHN_NAME.equals(languageName) == false)
                        {
                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.please_change_store, STORE_TRDCHN_NAME, STORE_TRDCHN_NAME), null);
                            return;
                        }
                        break;

                    default:
                        break;
                }

            }
        }

        Intent i = new Intent(CategoryListActivity.this, IntroActivity.class);
        i.putExtra(MAP_SKU, idStr);
        i.putExtra(IntroActivity.FROM, IntroActivity.SEARCH_RESULT);
        startActivityForResult(i, 0);
    }


    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.list_activity_back_button)
        {
            finish();
        }
        /*
        else if(v.getId() == R.id.list_activity_transportation_button)
        {
            showFilterDialog(TRANSPORTATION_TYPE);
        }
        else if(v.getId() == R.id.list_activity_special_meals_button)
        {
            showFilterDialog(SPECIAL_MEALS_TYPE);
        }
        else if(v.getId() == R.id.list_activity_trip_themes_button)
        {
            showFilterDialog(THEME_TYPE);
        }
        else if(v.getId() == R.id.list_activity_trip_duration_button)
        {
            showFilterDialog(DURATION_TYPE);
        }
        */
    }

    public static String convertToUTF8(String inputStr)
    {
        String outStr = null;
        try
        {
            outStr = new String(inputStr.getBytes("UTF-8"), "ISO-8859-1");
        }
        catch (java.io.UnsupportedEncodingException e)
        {
            return null;
        }
        return outStr;
    }

    @Override
    public void onDestroy()
    {
        disposables.dispose();

        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == PAYMENT_FINISHED)
        {
            setResult(PAYMENT_FINISHED);
            finish();
        }
        else if (mIsFbLoginEvent.getBoolean() == true)
        {
            //gSignInHelper.onActivityResult(requestCode, resultCode, data);
            //fbConnectHelper.onActivityResult(requestCode, resultCode, data);
            BaseLib().baseFBOnActivityResult(requestCode, resultCode, data);

            mIsFbLoginEvent.setBoolean(false);
            return;
        }
        else if(requestCode == LOGIN_ACTIVITY_TYPE)
        {
            if(resultCode == LOGIN_RESULT_SUCCESS)
            {
                mBaseLibLoginListener.onLoginSuccess();
            }
            else //if(resultCode == LOGIN_RESULT_CANCEL)
            {
                mBaseLibLoginListener.onLoginCancel();
            }
        }
    }

    /*
    private void showFilterDialog(int type)
    {
        FragmentManager fm = getFragmentManager();
        if(mTGSearchFilterDialog != null)
        {
            mTGSearchFilterDialog.dismiss();
            mTGSearchFilterDialog = null;
        }
        mTGSearchFilterDialog = new TGSearchFilterDialog();

        if(type == TRANSPORTATION_TYPE)
        {
            mTGSearchFilterDialog.setTitle(getString(R.string.transportation_filter_title));
            mTGSearchFilterDialog.setType(TRANSPORTATION_TYPE);
        }
        else if(type == SPECIAL_MEALS_TYPE)
        {
            mTGSearchFilterDialog.setTitle(getString(R.string.special_meals_type));
            mTGSearchFilterDialog.setType(SPECIAL_MEALS_TYPE);
        }
        else if(type == THEME_TYPE)
        {
            mTGSearchFilterDialog.setTitle(getString(R.string.theme_filter_title));
            mTGSearchFilterDialog.setType(THEME_TYPE);
        }
        else if(type == DURATION_TYPE)
        {
            mTGSearchFilterDialog.setTitle(getString(R.string.duration_filter_title));
            mTGSearchFilterDialog.setType(DURATION_TYPE);
        }

        mTGSearchFilterDialog.setFilter(mExclusiveFoodArrStr, mTransArrStr, mThemeArrStr, mDurationArrStr);
        mTGSearchFilterDialog.setOptionListener(new TGSearchFilterListener()
        {
            @Override
            public void onButtonClickListener(View v, String exclusive_food_filters, String trans_arr_str, String theme_arr_str, String duration_arr_str)
            {
                if(type == TRANSPORTATION_TYPE)
                {
                    mTransArrStr = trans_arr_str;

                    if("".equals(mTransArrStr) == true)
                    {
                        showErrorPopyp();
                        return;
                    }
                }
                else if(type == SPECIAL_MEALS_TYPE)
                {
                    mExclusiveFoodArrStr = exclusive_food_filters;
                }
                else if(type == THEME_TYPE)
                {
                    mThemeArrStr = theme_arr_str;

                    if("".equals(mThemeArrStr) == true)
                    {
                        showErrorPopyp();
                        return;
                    }
                }
                else if(type == DURATION_TYPE)
                {
                    mDurationArrStr = duration_arr_str;

                    if("".equals(mDurationArrStr) == true)
                    {
                        showErrorPopyp();
                        return;
                    }
                }

                pd = new GeneralProgressDialog(CategoryListActivity.this, R.drawable.spinner);
                pd.show();

                mWeb.searchProductsByKeywords(mSearchKeywordArr[0], exclusive_food_filters, trans_arr_str, theme_arr_str, duration_arr_str, "10","0",
                        new Consumer<ResponseProductsData>()
                        {
                            @Override
                            public void accept(ResponseProductsData objDatas) throws Exception
                            {
                                // TODO: Handle response.
                                String serverResult = objDatas.getResult();
                                Products serverData = objDatas.getData();

                                if(serverResult.equals(JSON_SUCCESS))
                                {
                                    mDataList.clear();

                                    for(int x = 0; x < serverData.getProducts().size(); x++)
                                    {
                                        Product tmpData = serverData.getProducts().get(x);
                                        String skuStr = tmpData.getSku();
                                        String nameStr = tmpData.getName();
                                        String imageUrlStr = tmpData.getImage1();
                                        String priceStr = tmpData.getPrice();
                                        int rating1 = tmpData.getRating1();
                                        int rating2 = tmpData.getRating2();
                                        mDataList.add(new Product(skuStr, imageUrlStr, nameStr, priceStr, 0, 0, rating1, rating2));
                                    }
                                    mInfoAdapter.notifyDataSetChanged();

                                    pd.dismiss();
                                }
                                else if(serverResult.equals(JSON_FAIL))
                                {
                                    pd.dismiss();
                                }
                            }
                        }
                        ,new Consumer<Throwable>()
                        {
                            @Override
                            public void accept(@NonNull Throwable throwable) throws Exception
                            {
                                // TODO: Handle error.
                                pd.dismiss();
                            }
                        }, disposables
                );
                mTGSearchFilterDialog.dismiss();
            }
        });
        mTGSearchFilterDialog.show(fm, "tag");
    }
    */

    //load best seller products
    private void loadPopularList()
    {
        mWeb.getBestSeller(DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex),
                new Consumer<ResponseProductsData>()
                {
                    @Override
                    public void accept(ResponseProductsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Products serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            //mDataList.clear();

                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            for(int x = 0; x < serverData.getProducts().size(); x++)
                            {
                                Product tmpData = serverData.getProducts().get(x);
                                String skuStr = tmpData.getSku();
                                String nameStr = tmpData.getName();
                                String imageUrlStr = tmpData.getImage1();
                                String priceStr = tmpData.getPrice();
                                int rating1 = tmpData.getRating1();
                                //int rating2 = tmpData.getRating2();
                                //String videoLink = tmpData.getVideoLink();
                                mDataList.add(new Product(skuStr, imageUrlStr, nameStr, priceStr, 0, 0, rating1, ""));
                            }
                            clearProgressDialog();

                            mInfoAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            clearProgressDialog();
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        clearProgressDialog();
                    }
                }, disposables
        );
    }

    //load recently viewed products
    /*
    private void loadViewedList()
    {
        mWeb.getViewedProducts("10","0",
                new Consumer<ResponseProductsData>()
                {
                    @Override
                    public void accept(ResponseProductsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Products serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            mDataList.clear();

                            for(int x = 0; x < serverData.getProducts().size(); x++)
                            {
                                Product tmpData = serverData.getProducts().get(x);
                                String skuStr = tmpData.getSku();
                                String nameStr = tmpData.getName();
                                String imageUrlStr = tmpData.getImage1();
                                String priceStr = tmpData.getPrice();
                                mDataList.add(new Product(skuStr, imageUrlStr, nameStr, priceStr, 0, 0, -1));
                            }

                            clearProgressDialog();

                            mInfoAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            clearProgressDialog();
                            showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()));
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        clearProgressDialog();
                    }
                }, disposables
        );
    }
    */

    //load recently viewed products
    private void loadWishList()
    {
        mWeb.getWishlistProducts(DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex),
                new Consumer<ResponseProductsData>()
                {
                    @Override
                    public void accept(ResponseProductsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Products serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            //mDataList.clear();

                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            for(int x = 0; x < serverData.getProducts().size(); x++)
                            {
                                Product tmpData = serverData.getProducts().get(x);
                                String skuStr = tmpData.getSku();
                                String nameStr = tmpData.getName();
                                String imageUrlStr = tmpData.getImage1();
                                String priceStr = tmpData.getPrice();
                                String storeIdStr = tmpData.getStoreLanaguage();
                                mDataList.add(new Product(skuStr, imageUrlStr, nameStr, priceStr, 0, 0, -1, storeIdStr));
                            }

                            clearProgressDialog();

                            mInfoAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            clearProgressDialog();
                            showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()),
                            new GeneralAlarmButtonListener()
                            {
                                @Override
                                public void onButtonClickListener(View v, int id, int button)
                                {

                                }
                            });
                        }
                        else if(serverResult.equals(JSON_LOGOUT))
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    loadWishList();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            loadWishList();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        clearProgressDialog();
                        String resultStr = throwable.getMessage();
                        if(resultStr != null && resultStr.contains("302") == true)
                        {
                            mGeneralApplication.setIdString("");
                            mGeneralApplication.setNumString("");
                            mGeneralApplication.setLoggedIn(false);

                            LoginProcessPopup(new AutoLoginListener()
                            {
                                @Override
                                public void onAutoLoginSuccess()
                                {
                                    loadWishList();
                                }

                                @Override
                                public void onAutoLoginFail()
                                {
                                    startManualLogin(new LoginListener()
                                    {
                                        @Override
                                        public void onLoginSuccess()
                                        {
                                            loadWishList();
                                        }

                                        @Override
                                        public void onLoginCancel()
                                        {
                                            BaseLib().showGeneralPopup(getString(R.string.error_title), getString(R.string.login_was_not_successful_try_it_later), null);
                                        }
                                    });
                                }
                            });
                        }


                    }
                }, disposables
        );
    }

    private void loadTitle(String titleStr)
    {
        mTextView.setText(titleStr);
    }

    //load regions products
    private void loadRegionList(String regionNum)
    {
        mWeb.getProductsFromCategoryWithRegion(regionNum, DEFAULT_PAGE_ITEMS, String.valueOf(mCurrentPageIndex),
                new Consumer<ResponseProductsData>()
                {
                    @Override
                    public void accept(ResponseProductsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Products serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            //mDataList.clear();

                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            for(int x = 0; x < serverData.getProducts().size(); x++)
                            {
                                Product tmpData = serverData.getProducts().get(x);
                                String skuStr = tmpData.getSku();
                                String nameStr = tmpData.getName();
                                String imageUrlStr = tmpData.getImage1();
                                String priceStr = tmpData.getPrice();
                                int rating1 = tmpData.getRating1();
                                mDataList.add(new Product(skuStr, imageUrlStr, nameStr, priceStr, 0, 0, rating1, ""));
                            }

                            clearProgressDialog();

                            mInfoAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            clearProgressDialog();
                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        //mRecommendationList.add(new TourGuideData("1", "http://www.ruemsa.com/test/1.png", "즐거운 여행지로 오세요", "50,000"));
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        clearProgressDialog();
                    }
                }, disposables
        );
    }

    //load every products frm category
    /*
    private void loadFrontList()
    {
        mWeb.getProductsFromCategory(DEFAULT_PAGE_ITEMS,  String.valueOf(mCurrentPageIndex),
                new Consumer<ResponseProductsData>()
                {
                    @Override
                    public void accept(ResponseProductsData objDatas) throws Exception
                    {
                        // TODO: Handle response.
                        String serverResult = objDatas.getResult();
                        Products serverData = objDatas.getData();

                        if(serverResult.equals(JSON_SUCCESS))
                        {
                            //mDataList.clear();

                            mTotalPageCount = objDatas.getData().getTotal_page_count();

                            for(int x = 0; x < serverData.getProducts().size(); x++)
                            {
                                Product tmpData = serverData.getProducts().get(x);
                                String skuStr = tmpData.getSku();
                                String nameStr = tmpData.getName();
                                String imageUrlStr = tmpData.getImage1();
                                String priceStr = tmpData.getPrice();
                                int rating1 = tmpData.getRating1();
                                mDataList.add(new Product(skuStr, imageUrlStr, nameStr, priceStr, 0, 0, rating1));
                            }

                            clearProgressDialog();

                            mInfoAdapter.notifyDataSetChanged();
                        }
                        else if(serverResult.equals(JSON_FAIL))
                        {
                            clearProgressDialog();

                            BaseLib().showGeneralPopup(getString(R.string.error_title), mGeneralApplication.getResultString(objDatas.getResultCode()), null);
                        }
                        //mRecommendationList.add(new Data("1", "http://www.ruemsa.com/test/1.png", "즐거운 여행지로 오세요", "50,000"));
                    }
                }
                ,new Consumer<Throwable>()
                {
                    @Override
                    public void accept(@NonNull Throwable throwable) throws Exception
                    {
                        // TODO: Handle error.
                        clearProgressDialog();
                    }
                }, disposables
        );
    }
    */

    private void clearProgressDialog()
    {
        pd.dismiss();
    }
}
