package etm.main.market.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;

public class TouchImageView extends ImageView
{
    private static final String TAG = TouchImageView.class.getSimpleName();

    private static final long SHORT_CLICK_DURATION = 700;

    Paint greenPaint = new Paint();
    Paint bluePaint = new Paint();
    Paint redPaint = new Paint();

    Matrix matrix;

    // We can be in one of these 3 states
    static final int NONE = 0;
    static final int DRAG = 1;
    static final int ZOOM = 2;

    int mode = NONE;

    // Remember some things for zooming
    PointF last = new PointF();
    PointF start = new PointF();
    float minScale = 1f;
    float maxScale = 3f;
    float[] m;
    int viewWidth, viewHeight;
    static final int CLICK = 3;
    float saveScale = 1f;
    protected float origWidth, origHeight;
    int oldMeasuredWidth, oldMeasuredHeight;
    ScaleGestureDetector mScaleDetector;
    Context context;

    //float originalXShift = 0f;
    //float originalYShift = 0f;

    float left_top_x = 0.0f;
    float left_top_y = 0.0f;
    float right_bottom_x = 0.0f;
    float right_bottom_y = 0.0f;
    boolean isRectangleVisible = false;

    long mLastTouchTime = 0;
    int mTouchCount = 0;
    private TouchViewListener mTouchImageViewListener = null;

    public TouchImageView(Context context)
    {
        super(context);
        sharedConstructing(context);

        greenPaint.setDither(true);
        greenPaint.setColor(0xFFFFFFFF);  // alpha.r.g.b
        greenPaint.setStyle(Paint.Style.STROKE);
        greenPaint.setStrokeJoin(Paint.Join.ROUND);
        greenPaint.setStrokeCap(Paint.Cap.ROUND);
        greenPaint.setStrokeWidth(4);

        bluePaint.setDither(true);
        bluePaint.setColor(0xFF0000CC);  // alpha.r.g.b
        bluePaint.setStyle(Paint.Style.STROKE);
        bluePaint.setStrokeJoin(Paint.Join.ROUND);
        bluePaint.setStrokeCap(Paint.Cap.ROUND);
        bluePaint.setStrokeWidth(4);

        redPaint.setDither(true);
        redPaint.setColor(0xFFCC0000);  // alpha.r.g.b
        redPaint.setStyle(Paint.Style.STROKE);
        redPaint.setStrokeJoin(Paint.Join.ROUND);
        redPaint.setStrokeCap(Paint.Cap.ROUND);
        redPaint.setStrokeWidth(4);
    }

    public TouchImageView(Context context, AttributeSet attrs)
    {
        super(context, attrs);

        greenPaint.setDither(true);
        greenPaint.setColor(0xFFFFFFFF);  // alpha.r.g.b
        greenPaint.setStyle(Paint.Style.STROKE);
        greenPaint.setStrokeJoin(Paint.Join.ROUND);
        greenPaint.setStrokeCap(Paint.Cap.ROUND);
        greenPaint.setStrokeWidth(4);

        bluePaint.setDither(true);
        bluePaint.setColor(0xFF0000CC);  // alpha.r.g.b
        bluePaint.setStyle(Paint.Style.STROKE);
        bluePaint.setStrokeJoin(Paint.Join.ROUND);
        bluePaint.setStrokeCap(Paint.Cap.ROUND);
        bluePaint.setStrokeWidth(4);

        redPaint.setDither(true);
        redPaint.setColor(0xFFCC0000);  // alpha.r.g.b
        redPaint.setStyle(Paint.Style.STROKE);
        redPaint.setStrokeJoin(Paint.Join.ROUND);
        redPaint.setStrokeCap(Paint.Cap.ROUND);
        redPaint.setStrokeWidth(4);

        sharedConstructing(context);
    }

    public void setVisibleRect(boolean flag)
    {
        isRectangleVisible = flag;

        if(flag == false)
        {
            left_top_x = 0.0f;
            left_top_y = 0.0f;
            right_bottom_x = 0.0f;
            right_bottom_y = 0.0f;
        }

        invalidate();
    }

    public void setRect(float left_top_x_percent, float left_top_y_percent, float right_bottom_x_percent, float right_bottom_y_percent)
    {
        left_top_x = left_top_x_percent;
        left_top_y = left_top_y_percent;
        right_bottom_x = right_bottom_x_percent;
        right_bottom_y = right_bottom_y_percent;
    }

    public float[] getRect()
    {
        float rec[] = new float[4];
        rec[0] = left_top_x;
        rec[1] = left_top_y;
        rec[2] = right_bottom_x;
        rec[3] = right_bottom_y;

        return rec;
    }

    @Override
    public void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);

        if(isRectangleVisible == false)
        {
            return;
        }

        float tmp_left_top_x = origWidth * saveScale*left_top_x;
        float tmp_left_top_y = origHeight * saveScale*left_top_y;
        float tmp_right_bottom_x = origWidth * saveScale*right_bottom_x;
        float tmp_right_bottom_y = origHeight * saveScale*right_bottom_y;

        float tmp_rectangle_width = tmp_right_bottom_x - tmp_left_top_x;
        float tmp_rectangle_height = tmp_right_bottom_y - tmp_left_top_y;

        matrix.getValues(m);

        float transX = m[Matrix.MTRANS_X];
        float transY = m[Matrix.MTRANS_Y];

        tmp_left_top_x -= -transX;
        tmp_left_top_y -= -transY;
        tmp_right_bottom_x = tmp_left_top_x + tmp_rectangle_width;
        tmp_right_bottom_y = tmp_left_top_y + tmp_rectangle_height;

        canvas.drawRect(tmp_left_top_x-3, tmp_left_top_y-3, tmp_right_bottom_x+3, tmp_right_bottom_y+3, greenPaint);
        canvas.drawRect(tmp_left_top_x, tmp_left_top_y, tmp_right_bottom_x, tmp_right_bottom_y, redPaint);
        canvas.drawRect(tmp_left_top_x+3, tmp_left_top_y+3, tmp_right_bottom_x-3, tmp_right_bottom_y-3, bluePaint);
    }

    private void sharedConstructing(Context context)
    {
        super.setClickable(true);

        this.context = context;
        mScaleDetector = new ScaleGestureDetector(context, new ScaleListener());
        matrix = new Matrix();

        m = new float[9];
        setImageMatrix(matrix);

        setScaleType(ScaleType.MATRIX);
        setOnTouchListener(new OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                mScaleDetector.onTouchEvent(event);

                PointF curr = new PointF(event.getX(), event.getY());

                switch (event.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                        last.set(curr);
                        start.set(last);
                        mode = DRAG;

                        mLastTouchTime = System.currentTimeMillis();
                        mTouchCount++;

                        break;

                    case MotionEvent.ACTION_MOVE:
                        if (mode == DRAG)
                        {
                            float deltaX = curr.x - last.x;
                            float deltaY = curr.y - last.y;

                            float fixTransX = getFixDragTrans(deltaX, viewWidth, origWidth * saveScale);
                            float fixTransY = getFixDragTrans(deltaY, viewHeight, origHeight * saveScale);

                            //이미지 외각으로 왔을 때는 더이상 누적시키지 않게 해야 한다.
                            matrix.postTranslate(fixTransX, fixTransY);

                            fixTrans();
                            last.set(curr.x, curr.y);
                        }
                        break;

                    case MotionEvent.ACTION_UP:
                        mode = NONE;

                        long currentClickTime = System.currentTimeMillis();
                        if(mTouchCount == 1)
                        {
                            if(currentClickTime - mLastTouchTime < SHORT_CLICK_DURATION)
                            {
                                if(mTouchImageViewListener != null)
                                {
                                    mTouchImageViewListener.onShortTouchClick();
                                }
                            }
                            mTouchCount = 0;
                            break;
                        }

                        int xDiff = (int) Math.abs(curr.x - start.x);
                        int yDiff = (int) Math.abs(curr.y - start.y);

                        if (xDiff < CLICK && yDiff < CLICK)
                        {
                            performClick();
                        }
                        break;

                    case MotionEvent.ACTION_POINTER_UP:
                        mode = NONE;
                        break;
                }
                setImageMatrix(matrix);
                invalidate();
                return true; // indicate event was handled
            }
        });
    }

    public void setMaxZoom(float x)
    {
        maxScale = x;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener
    {
        @Override
       public boolean onScaleBegin(ScaleGestureDetector detector)
        {
            mode = ZOOM;
            return true;
        }
        @Override
       public boolean onScale(ScaleGestureDetector detector)
        {
            float mScaleFactor = detector.getScaleFactor();
            float origScale = saveScale;

            saveScale *= mScaleFactor;

            if (saveScale > maxScale)
            {
                saveScale = maxScale;
                mScaleFactor = maxScale / origScale;
            }
            else if (saveScale < minScale)
            {
                saveScale = minScale;
                mScaleFactor = minScale / origScale;
            }

            if (origWidth * saveScale <= viewWidth || origHeight * saveScale <= viewHeight)
            {
                matrix.postScale(mScaleFactor, mScaleFactor, viewWidth / 2, viewHeight / 2);
            }
            else
            {
                matrix.postScale(mScaleFactor, mScaleFactor, detector.getFocusX(), detector.getFocusY());
            }

            fixTrans();
            return true;
        }
    }

    void fixTrans()
    {
        matrix.getValues(m);

        float transX = m[Matrix.MTRANS_X];
        float transY = m[Matrix.MTRANS_Y];

        float fixTransX = getFixTrans(transX, viewWidth, origWidth * saveScale);
        float fixTransY = getFixTrans(transY, viewHeight, origHeight * saveScale);

        if (fixTransX != 0 || fixTransY != 0)
        {
            matrix.postTranslate(fixTransX, fixTransY);
        }
    }

    float getFixTrans(float trans, float viewSize, float contentSize)
    {
        float minTrans, maxTrans;

        if (contentSize <= viewSize)    //이미지내용물 <= 화면 (축소된 경우)
        {
            minTrans = 0;
            maxTrans = viewSize - contentSize;
        }
        else    //이미지내용물 > 화면  (확대된 경우)
        {
            minTrans = viewSize - contentSize;
            maxTrans = 0;
        }

        if (trans < minTrans)
            return -trans + minTrans;

        if (trans > maxTrans)
            return -trans + maxTrans;

        return 0;
    }

    float getFixDragTrans(float delta, float viewSize, float contentSize)
    {
        if (contentSize <= viewSize)
        {
            return 0;
        }
        return delta;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        viewWidth = MeasureSpec.getSize(widthMeasureSpec);
        viewHeight = MeasureSpec.getSize(heightMeasureSpec);
        //
        // Rescales image on rotation
        //
        if (oldMeasuredHeight == viewWidth && oldMeasuredHeight == viewHeight
                || viewWidth == 0 || viewHeight == 0)
            return;

        oldMeasuredHeight = viewHeight;
        oldMeasuredWidth = viewWidth;

        if (saveScale == 1) {
            //Fit to screen.
            float scale;
            Drawable drawable = getDrawable();
            if (drawable == null || drawable.getIntrinsicWidth() == 0 || drawable.getIntrinsicHeight() == 0)
                return;
            int bmWidth = drawable.getIntrinsicWidth();
            int bmHeight = drawable.getIntrinsicHeight();
            Log.d("bmSize", "bmWidth: " + bmWidth + " bmHeight : " + bmHeight);
            float scaleX = (float) viewWidth / (float) bmWidth;
            float scaleY = (float) viewHeight / (float) bmHeight;
            scale = Math.min(scaleX, scaleY);
            matrix.setScale(scale, scale);

            // Center the image
            float redundantYSpace = (float) viewHeight - (scale * (float) bmHeight);
            float redundantXSpace = (float) viewWidth - (scale * (float) bmWidth);
            redundantYSpace /= (float) 2;
            redundantXSpace /= (float) 2;

            //originalXShift += redundantXSpace;
            //originalYShift += redundantYSpace;

            matrix.postTranslate(redundantXSpace, redundantYSpace);
            origWidth = viewWidth - 2 * redundantXSpace;
            origHeight = viewHeight - 2 * redundantYSpace;
            setImageMatrix(matrix);
        }

        fixTrans();
    }

    public void setShortTouchListener(TouchViewListener tmpListener)
    {
        mTouchImageViewListener = tmpListener;
    }
}