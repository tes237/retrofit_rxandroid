package etm.main.market.widgets;

import android.content.Context;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.widget.ProgressBar;


public class RoundProgressBar extends ProgressBar {
    public RoundProgressBar(Context context) {
        super(context);
        this.setIndeterminate(true);
        this.getIndeterminateDrawable().setColorFilter(0xff7d7dff, PorterDuff.Mode.MULTIPLY);
    }

    public RoundProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.getIndeterminateDrawable().setColorFilter(0xff7d7dff, PorterDuff.Mode.MULTIPLY);
    }

    public RoundProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}