package etm.main.market.widgets;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

public class BlinkingToggleButton extends ImageView
{
    private static final int MAX_BLINK_COUNT = 9999;

    Context context;
    Runnable mRunnable;
    Handler mHandler;
    int totalSeconds;
    int currentCount;
    int totalCount;

    int onImageId;
    int offImageId;

    boolean isButtonUp = true;

    final Animation mAnimation = new AlphaAnimation(1, 0);

    public BlinkingToggleButton(Context context)
    {
        super(context);
    }

    public BlinkingToggleButton(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    public void setBlink(int seconds)
    {
        currentCount = 0;
        totalSeconds = seconds;
        totalCount = totalSeconds*5;

        mAnimation.setDuration(100);
        mAnimation.setInterpolator(new LinearInterpolator());
        mAnimation.setRepeatCount(Animation.INFINITE);
        mAnimation.setRepeatMode(Animation.REVERSE);
        startAnimation(mAnimation);

        mHandler = new Handler();

        mRunnable = new Runnable()
        {
            @Override
            public void run()
            {
                currentCount++;
                if(totalCount < currentCount)
                {
                    stopBlink();
                }
                else
                {
                    startAnimation(mAnimation);

                    mHandler.postDelayed(mRunnable, 200);
                }
            }
        };

        mHandler.postDelayed(mRunnable, 200);
    }

    public void stopBlink()
    {
        currentCount = MAX_BLINK_COUNT;
        clearAnimation();
    }

    public void setButtonDown()
    {
        isButtonUp = false;
        setImageResource(onImageId);
        setBackgroundColor(0xffefefef);
    }

    public void setButtonUp()
    {
        isButtonUp = true;
        setImageResource(offImageId);
        setBackgroundColor(0xff505050);
    }

    public boolean isButtonUp()
    {
        return isButtonUp;
    }

    public void setOnImage(int id)
    {
        onImageId = id;
    }

    public void setOffImage(int id)
    {
        offImageId = id;
    }
}