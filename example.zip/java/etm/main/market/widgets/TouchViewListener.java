package etm.main.market.widgets;

public interface TouchViewListener
{
    void onShortTouchClick();
    void onControlPanelClick();
}