package etm.main.market.widgets.tagview;

/**
 * listener for tag delete
 */
public interface OnTagClickListener {
	void onTagClick(Tag tag, int position);
}