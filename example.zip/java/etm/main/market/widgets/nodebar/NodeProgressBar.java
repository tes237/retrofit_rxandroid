package etm.main.market.widgets.nodebar;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import etm.main.market.R;


public class NodeProgressBar extends View
{
    public static final int NODE_OPTIONAL = 999;
    public static final int NODE_SINGLE = 1;
    public static final int NODE_MULTI = 2;
    public static final int NODE_INTRO = 3;

    private static final String TAG = "NodeProgressBar";
    private static final int MAX_MOVEMENT_DURATION = 50;

    private static final int GENERAL_ON_IMAGE_INDEX = 0;
    private static final int GENERAL_OFF_IMAGE_INDEX = 1;
    private static final int MULTI_ON_IMAGE_INDEX = 2;
    private static final int MULTI_OFF_IMAGE_INDEX = 3;
    private static final int OPTIONAL_IMAGE_INDEX = 4;
    private static final int INTRO_ON_IMAGE_INDEX = 5;
    private static final int INTRO_OFF_IMAGE_INDEX = 6;
    private static final int PIPE_INDEX = 7;

    Bitmap[] drawables = null;

    Context mContext;
    Paint mPaint;
    Rect mTextBounds;

    private int mOnImageBarResourceId;
    private int mOffImageBarResourceId;
    private int mOnMultiImageBarResourceId;
    private int mOffMultiImageBarResourceId;
    private int mOptionalImageBarResourceId;
    private int mOnIntroImageBarResourceId;
    private int mOffIntroImageBarResourceId;
    private int mPipeResourceId;

    private int mNodeImageWidth;
    private int mNodeImageHeight;
    private int mNodeMarginWidth;
    private float mNodeMarginWidthPercent;

    private int mNumOfNodes = 5;
    private float mSelectedIndex = 0;
    //private boolean mIndicator;
    private float slidePosition;
    //private int mType;
    private int mLeftPixel = 0;
    private int mStartLeftPixel = 0;
    private boolean mIsMoved = false;
    private int mGraphWidth = 0;
    private int mGraphHeight = 0;
    private int mMaxNumberOfNodesToBeShown = 5;

    private float downPositionX = 0;
    private float downPositionY = 0;

    private int mProperties[] = null;

    final Handler NodeProgressBarHandler = new Handler();
    Runnable nodeProgressBarRunnable = null;
    long mStartTime = SystemClock.uptimeMillis();
    final long mDuration = 300L;
    static boolean isRunnableWorking = false;

    public interface OnNodeProgressBarChangeListener
    {
        void onNodeProgressChanged(NodeProgressBar nodeBar, int rating, boolean fromUser);
    }

    private OnNodeProgressBarChangeListener mOnNodeProgressBarChangeListener;

    public NodeProgressBar(Context context) {
        this(context, null);
    }

    public NodeProgressBar(Context context, AttributeSet attrs)
    {
        this(context, attrs, 0);
    }

    public NodeProgressBar(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.NodeProgressBar, defStyle, 0);
        //final boolean indicator = a.getBoolean(R.styleable.ColoredRatingBar_indicator, false);
        final int maxNode = a.getInteger(R.styleable.NodeProgressBar_nodeTotalNumber, -1);
        final int selectedNode = a.getInteger(R.styleable.NodeProgressBar_nodeSelectedIndex, -1);

        mNodeMarginWidthPercent = a.getFloat(R.styleable.NodeProgressBar_nodeMarginPercent, -1);
        mOnImageBarResourceId = a.getResourceId(R.styleable.NodeProgressBar_nodeOnImageBar, R.drawable.blank);
        mOffImageBarResourceId = a.getResourceId(R.styleable.NodeProgressBar_nodeOffImageBar, R.drawable.blank);
        mOnMultiImageBarResourceId = a.getResourceId(R.styleable.NodeProgressBar_multiNodeOnImageBar, R.drawable.blank);
        mOffMultiImageBarResourceId = a.getResourceId(R.styleable.NodeProgressBar_multiNodeOffImageBar, R.drawable.blank);
        mOnIntroImageBarResourceId = a.getResourceId(R.styleable.NodeProgressBar_introNodeOnImageBar, R.drawable.blank);
        mOffIntroImageBarResourceId = a.getResourceId(R.styleable.NodeProgressBar_introNodeOffImageBar, R.drawable.blank);
        mOptionalImageBarResourceId = a.getResourceId(R.styleable.NodeProgressBar_nodeOptionalImageBar, R.drawable.blank);
        mPipeResourceId = a.getResourceId(R.styleable.NodeProgressBar_pipe, R.drawable.blank);

        a.recycle();

        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setTextAlign(Paint.Align.CENTER);
        mPaint.setColor(Color.rgb(255, 255, 255));
        mPaint.setShadowLayer(1f, 0f, 1f, Color.BLACK);

        mTextBounds = new Rect();
        mNumOfNodes = (int)maxNode;

        //setIndicator(indicator);
        setIndex(selectedNode);    //selected index
        //setType(type);
        init(context);
    }



    private void init(Context context)
    {
        mContext = context;
    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
        //draw empty stars bg

        if(drawables != null)
        {
            int maxDraw = 0;

            int startIndex = calculateFirstNodeIndex();
            int tmpEndIndex = startIndex + mMaxNumberOfNodesToBeShown;
            //int endIndex = (tmpEndIndex < mNumOfNodes) ? tmpEndIndex : mNumOfNodes;

            int endIndex = 0;
            if(tmpEndIndex < mNumOfNodes)
            {
                endIndex = tmpEndIndex;
            }
            else
            {
                //endIndex = tmpEndIndex;
                //endIndex = (mNumOfNodes-1) - startIndex;
                endIndex = (mNumOfNodes-1);
                if(endIndex >  (startIndex + mMaxNumberOfNodesToBeShown -1))
                {
                    endIndex = startIndex + mMaxNumberOfNodesToBeShown -1;
                }
            }

            drawPipe(canvas, startIndex, endIndex);

            for (int i = startIndex; i <= endIndex; i++)
            {
                drawNodes(canvas, i);
            }
        }
    }

    private void drawPipe(Canvas canvas, int startIndex, int endIndex)
    {
        Bitmap pipeBitmap = drawables[PIPE_INDEX];

        int tmpWidth = mGraphHeight;
        int tmpLeft = 0;
        int tmpRight = 0;

        if(startIndex == 0)
        {
            tmpLeft = mLeftPixel + mNodeMarginWidth + (startIndex * (tmpWidth + (mNodeMarginWidth*2) ));
            tmpLeft += mGraphHeight/3;  //little right shifiting for first node
        }
        else
        {
            tmpLeft = 0;
        }

        tmpRight = mLeftPixel + mNodeMarginWidth + (endIndex * (tmpWidth + (mNodeMarginWidth*2) ));
        tmpRight += mGraphHeight/3; // little right shifting for last node

        if(tmpRight > mGraphWidth)
        {
            tmpRight = mGraphWidth;
        }

        int vertical_center_y = mGraphHeight/2 - mGraphHeight/10;

        int LEFT_MARGIN = 30;

        for(int x = tmpLeft; x < tmpRight; x++)
        {
            canvas.drawBitmap(pipeBitmap, x, vertical_center_y, null);
        }

    }

    private void drawNodes(Canvas canvas, int position)
    {
        float fraction = mSelectedIndex -(position);
        Bitmap nodeBitmap = null;

        //if ((drawables == null) || (progressBackground == null))
        if (drawables == null)
        {
            return;
        }

        if(mSelectedIndex == position)
        {
            if(mProperties != null)
            {
                if(mProperties[position] == NODE_SINGLE)
                {
                    nodeBitmap = drawables[GENERAL_ON_IMAGE_INDEX];
                }
                else if(mProperties[position] == NODE_OPTIONAL)
                {
                    nodeBitmap = drawables[OPTIONAL_IMAGE_INDEX];
                }
                else if(mProperties[position] == NODE_INTRO)
                {
                    nodeBitmap = drawables[INTRO_ON_IMAGE_INDEX];
                }
                else
                {
                    nodeBitmap = drawables[MULTI_ON_IMAGE_INDEX];
                }
            }
            else
            {
                nodeBitmap = drawables[GENERAL_ON_IMAGE_INDEX];
            }
        }
        else
        {
            if(mProperties != null)
            {
                if(mProperties[position] == NODE_SINGLE)
                {
                    nodeBitmap = drawables[GENERAL_OFF_IMAGE_INDEX];
                }
                else if(mProperties[position] == NODE_OPTIONAL)
                {
                    nodeBitmap = drawables[OPTIONAL_IMAGE_INDEX];
                }
                else if(mProperties[position] == NODE_INTRO)
                {
                    nodeBitmap = drawables[INTRO_OFF_IMAGE_INDEX];
                }
                else
                {
                    nodeBitmap = drawables[MULTI_OFF_IMAGE_INDEX];
                }
            }
            else
            {
                nodeBitmap = drawables[GENERAL_OFF_IMAGE_INDEX];
            }
        }

        int sourceWidth = nodeBitmap.getWidth();
        int sourceHeight = nodeBitmap.getHeight();

        int tmpLeft = mLeftPixel + mNodeMarginWidth + (position * (sourceWidth + (mNodeMarginWidth*2) ));

        mPaint.getTextBounds(String.format("%d", position), 0, String.format("%d", position).length(), mTextBounds);

        int x = (nodeBitmap.getWidth() - mTextBounds.width())/2 + mTextBounds.width()/4 + mTextBounds.width()/8;        //Someone please tell me why i need to do "mTextBounds.width()/4 + mTextBounds.width()/8"
        int y = (nodeBitmap.getHeight() + mTextBounds.height())/2;

        canvas.drawBitmap(nodeBitmap, tmpLeft, 0, null);
        canvas.drawText(String.format("%d", position), tmpLeft + x, y, mPaint);
    }

    public int getNumOfNodes() {
        return mNumOfNodes;
    }

    public void setNumOfNodex(int numNodex) {
        this.mNumOfNodes = numNodex;
        invalidate();
    }

    public float getIndex()
    {
        return mSelectedIndex;
    }

    public void setIndex(float index)
    {
        setIndex(index, false);
    }

    void setIndex(float index, final boolean fromUser)
    {
        if(fromUser == true)
        {
            if(isRunnableWorking == true)
            {
                isRunnableWorking = false;
                if(nodeProgressBarRunnable != null)
                {
                    NodeProgressBarHandler.removeCallbacks(nodeProgressBarRunnable);    //cancel previous runnable
                }
            }
        }
        else
        {
            //isRunnableWorking = false;
        }

        if(index > mNumOfNodes)
        {
            this.mSelectedIndex = mNumOfNodes;
        }
        this.mSelectedIndex = index;

        int sourceWidth = mGraphHeight;
        int tmpLeft = mLeftPixel + mNodeMarginWidth + ((int)index * (sourceWidth + (mNodeMarginWidth*2) ));

        int center_horizontal = mGraphWidth/2;
        if(tmpLeft > center_horizontal)
        {
            if(fromUser == true)
            {
                final int firstLeftPixel = mLeftPixel;
                //mLeftPixel = (center_horizontal - mNodeMarginWidth - ((int) index * (sourceWidth + (mNodeMarginWidth * 2))));
                final int destinationPixel =  (center_horizontal - mNodeMarginWidth - ((int) index * (sourceWidth + (mNodeMarginWidth * 2))));

                mStartTime = SystemClock.uptimeMillis();

                nodeProgressBarRunnable = new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if(isRunnableWorking == false)
                            return;

                        long elapsed = SystemClock.uptimeMillis() - mStartTime;
                        float change_percent = Math.min((float) elapsed / mDuration, 1f);
                        //float currentPixel = destinationPixel * change_percent;
                        float currentPixel = firstLeftPixel + (destinationPixel - firstLeftPixel)*change_percent;
                        mLeftPixel = (int)currentPixel;

                        invalidate();

                        if(isRunnableWorking == false)
                            return;

                        if(mLeftPixel > destinationPixel)
                        {
                            if(isRunnableWorking == false)
                                return;

                            NodeProgressBarHandler.postDelayed(this, 15L);
                        }
                        else
                        {
                            //finish
                            isRunnableWorking = false;
                        }
                    }
                };

                isRunnableWorking = true;
                NodeProgressBarHandler.postDelayed(nodeProgressBarRunnable, 15L);
            }
            else
            {
                mLeftPixel = (center_horizontal - mNodeMarginWidth - ((int) index * (sourceWidth + (mNodeMarginWidth * 2))));
                invalidate();
            }
        }
        invalidate();

        dispatchIndexChange(fromUser);
    }

    public void setProperty(int properties[])
    {
        mProperties = properties;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        mGraphWidth = getWidth();
        mGraphHeight = getHeight();

        if( (mGraphWidth != 0 ) && (mGraphHeight != 0))
        {
            Resources res = getResources();

            //int oneNodeSize = mGraphWidth/mNumOfNodes;
            int oneNodeSize;

            //oneNodeSize = mGraphWidth/ (MAX_NUM_OF_EVENT_NODE_SHOWN);
            oneNodeSize = mGraphHeight;

            Bitmap tmpBitmap1 = BitmapFactory.decodeResource(res, mOnImageBarResourceId);
            Bitmap tmpBitmap2 = BitmapFactory.decodeResource(res, mOffImageBarResourceId);
            Bitmap tmpBitmap3 = BitmapFactory.decodeResource(res, mOnMultiImageBarResourceId);
            Bitmap tmpBitmap4 = BitmapFactory.decodeResource(res, mOffMultiImageBarResourceId);
            Bitmap tmpBitmap5 = BitmapFactory.decodeResource(res, mOptionalImageBarResourceId);
            Bitmap tmpBitmap6 = BitmapFactory.decodeResource(res, mOnIntroImageBarResourceId);
            Bitmap tmpBitmap7 = BitmapFactory.decodeResource(res, mOffIntroImageBarResourceId);
            Bitmap tmpBitmap8 = BitmapFactory.decodeResource(res, mPipeResourceId);

            drawables = new Bitmap[]
            {
                Bitmap.createScaledBitmap(tmpBitmap1, oneNodeSize, oneNodeSize, false),
                Bitmap.createScaledBitmap(tmpBitmap2, oneNodeSize, oneNodeSize, false),
                Bitmap.createScaledBitmap(tmpBitmap3, oneNodeSize, oneNodeSize, false),
                Bitmap.createScaledBitmap(tmpBitmap4, oneNodeSize, oneNodeSize, false),
                Bitmap.createScaledBitmap(tmpBitmap5, oneNodeSize, oneNodeSize, false),
                Bitmap.createScaledBitmap(tmpBitmap6, oneNodeSize, oneNodeSize, false),
                Bitmap.createScaledBitmap(tmpBitmap7, oneNodeSize, oneNodeSize, false),
                Bitmap.createScaledBitmap(tmpBitmap8, 1, oneNodeSize/5, false)
            };

            mNodeImageWidth = drawables[GENERAL_ON_IMAGE_INDEX].getWidth();
            mNodeImageHeight = drawables[GENERAL_ON_IMAGE_INDEX].getHeight();

            mNodeMarginWidth = (int)(mNodeImageWidth * mNodeMarginWidthPercent);

            mMaxNumberOfNodesToBeShown = mGraphWidth/(oneNodeSize + mNodeMarginWidth*2) + 2;
            //let's add both edge balls

            int fontSize = mGraphWidth/43;

            mPaint.setTextSize((int) (fontSize));
        }
    }

    public void resetFirstLocation()
    {
        mLeftPixel = 0;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        double distance_from_down;

        float tmpX = event.getX();
        float tmpY = event.getY();

        int action = event.getAction();
        switch (action)
        {
            case MotionEvent.ACTION_DOWN:
                mIsMoved = false;
                downPositionX = tmpX;
                downPositionY = tmpY;

                mStartLeftPixel = mLeftPixel;
                break;

            case MotionEvent.ACTION_MOVE:
                distance_from_down = Math.sqrt( (downPositionX - tmpX)*(downPositionX - tmpX) );
                //일정 역치값 이상 이동했을 경우 이동으로 인정

                if(distance_from_down > MAX_MOVEMENT_DURATION)
                {
                    mIsMoved = true;

                    int tmpLeft = (int)(tmpX - downPositionX);
                    if(tmpLeft >= 0)
                    {
                        if(mLeftPixel >= 0)
                        {
                            mLeftPixel = 0;
                        }
                        else
                        {
                            mLeftPixel = mStartLeftPixel + tmpLeft;
                        }
                    }
                    else
                    {
                        int totalWidthOfGraph = 0;
                        int tmpTotalWidthOfGraph = 0;
                        //int nodeWidth = drawables[0].getWidth();

                        int maxLeft = 0;
                        maxLeft = -1 * ((mNumOfNodes * (mNodeImageWidth + (mNodeMarginWidth * 2))) - mGraphWidth);
                        //calculate max left sliding distance for this widget


                        //Log.e(TAG, String.format("maxLeft = %d", maxLeft));

                        if(mLeftPixel > maxLeft)
                        {
                            if(maxLeft <= tmpLeft)
                            {
                                if(mLeftPixel < maxLeft)
                                {
                                    mLeftPixel = maxLeft;
                                }
                                else
                                {
                                    mLeftPixel = mStartLeftPixel + tmpLeft;
                                }
                            }
                        }
                    }

                    //Log.d(TAG, String.format("left : %d", mLeftPixel));
                }
                else
                {
                    mIsMoved = false;
                }
                invalidate();
                break;

            case MotionEvent.ACTION_UP:
                if(mIsMoved == false)
                {
                    distance_from_down = Math.sqrt(((downPositionX - tmpX) * (downPositionX - tmpX)) + ((downPositionY - tmpY) * (downPositionY - tmpY)));

                    slidePosition = getRelativePosition(event.getX());
                    //int newIndex = (int) slidePosition + 1;
                    int newIndex = (int) slidePosition;

                    if(mProperties != null)
                    {
                        if (mProperties[newIndex] != NodeProgressBar.NODE_OPTIONAL)
                        {
                            if (newIndex != mSelectedIndex)
                            {
                                setIndex(newIndex, true);
                            }
                        }
                        else
                        {
                            setIndex(newIndex, true);
                        }
                    }
                    else
                    {
                        setIndex(newIndex, true);
                    }
                }
                downPositionX = 0;
                downPositionY = 0;
                break;

            case MotionEvent.ACTION_CANCEL:
                mIsMoved = false;

                downPositionX = 0;
                downPositionY = 0;
                break;

            default:
                break;
        }

        return true;
    }

    private float getRelativePosition(float x)
    {
        float position = 0;

        //int nodeWidth = drawables[0].getWidth();
        int relativeStartPos = (int)x - mLeftPixel;

        position = relativeStartPos / (mNodeImageWidth + (mNodeMarginWidth*2) );
       // position = x / nodeWidth;

        position = Math.max(position, 0);

        return Math.min(position, mNumOfNodes - 1);
    }

    private int calculateFirstNodeIndex()
    {
        //int nodeWidth = drawables[0].getWidth();

        int leftNodeCount = (mLeftPixel / (mNodeImageWidth + (mNodeMarginWidth * 2)));

        if(leftNodeCount < 0)
        {
            leftNodeCount = leftNodeCount * -1;
        }

        return leftNodeCount;
    }

    /**
     * Sets the listener to be called when the rating changes.
     *
     * @param listener The listener.
     */
    public void setOnRatingBarChangeListener(OnNodeProgressBarChangeListener listener)
    {
        mOnNodeProgressBarChangeListener = listener;
    }

    /**
     * @return The listener (may be null) that is listening for rating change
     *         events.
     */
    public OnNodeProgressBarChangeListener getOnRatingBarChangeListener()
    {
        return mOnNodeProgressBarChangeListener;
    }

    void dispatchIndexChange(boolean fromUser)
    {
        if (mOnNodeProgressBarChangeListener != null)
        {
            mOnNodeProgressBarChangeListener.onNodeProgressChanged(this, (int)getIndex(), fromUser);
        }
    }

    /*
    final Handler NodeProgressBarHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);

        }
    };
    */
}
