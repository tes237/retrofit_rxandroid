package etm.main.market.widgets.nodebar;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

import etm.main.market.R;
import etm.main.market.widgets.TouchViewListener;

public class BalloonImageGalleryBar extends View
{
    public static final int NODE_OPTIONAL = 999;
    public static final int NODE_SINGLE = 1;
    public static final int NODE_MULTI = 2;
    public static final int NODE_INTRO = 3;

    private static final String TAG = "BalloonImageGalleryBar";
    private static final int MAX_MOVEMENT_DURATION = 50;

    private static final int GENERAL_ON_IMAGE_INDEX = 0;
    private static final int GENERAL_OFF_IMAGE_INDEX = 1;
    private static final int OPTIONAL_IMAGE_INDEX = 2;
    private static final int INTRO_ON_IMAGE_INDEX_FOR_GALLERY = 9;
    private static final int INTRO_OFF_IMAGE_INDEX_FOR_GALLERY = 10;
    private static final int INTRO_ON_IMAGE_INDEX_FOR_BALLOON = 5;
    private static final int INTRO_OFF_IMAGE_INDEX_FOR_BALLOON = 6;
    private static final int PIPE_INDEX = 7;
    private static final int BLANK_PHOTO = 8;

    private static final float TOP_MARGIN_PERCENT_FOR_IMAGE_GALLERY = (0.0833f);//(1/12);
    private static final float BOTTOM_MARGIN_PERCENT_FOR_IMAGE_GALLERY = (0.0833f);//(1/12);
    private static final float CENTER_MARGIN_PERCENT_BETWEEN_IMAGE_GALLERY_AND_BALLOON = (0.1666f);//(2/12);
    private static final float HEIGHT_PERCENT_FOR_IMAGE_GALLERY_AND_BALLOON = (0.3333f);//(1/3);
    private static final float INSIDE_PADDING_PERCENT_FOR_BALLOON = (0.0416f);//(1/24);

    private static final int WHITE_BORDER_SIZE = 5;
    //private static final float BALLOON_MARGIN = 100f;


    public static final int AREA_NO = 0;
    public static final int AREA_IMAGE_GALLERY = 1;
    public static final int AREA_BALLOON = 2;

    private static final long BLINKING_TIME = 100L;

    private static final int EXTENDED_IMAGE_LOADING_COUNT = 1;

    private float mBalloonMargin = 0;

    private Bitmap[] drawables = null;
    //private Bitmap[] mGalleryImages = null;

    Context mContext;
    Paint mPaint;
    Paint mBalloonPaint;
    Paint mWallPaint;
    TextPaint mTitlePaint;
    Paint mPipePaint;

    Rect mTextBounds;

    private int mOnImageBarResourceId;
    private int mOffImageBarResourceId;
    private int mOnMultiImageBarResourceId;
    private int mOffMultiImageBarResourceId;
    private int mOptionalImageBarResourceId;
    private int mOnIntroImageBarResourceId;
    private int mOffIntroImageBarResourceId;
    private int mPipeResourceId;

    private int mNodeImageWidthForImageGallery;
    private int mNodeImageHeightForImageGallery;
    private int mNodeMarginWidthForImageGallery;
    private float mNodeMarginWidthPercentForImageGallery;

    private int mNodeImageWidthForBalloon;
    private int mNodeImageHeightForBalloon;
    private int mNodeMarginWidthForBalloon;
    private float mNodeMarginWidthPercentForBalloon;

    private int mNumOfImageGalleryNodes = 5;
    private int mNumOfBalloonNodes = 5;
    private float mSelectedImageGalleryIndex = 0;
    private float mSelectedBalloonIndex = 0;

    //private boolean mIndicator;
    //private float slidePosition;
    //private int mType;
    private int mLeftPixelForImageGallery = 0;
    private int mStartLeftPixelForImageGallery = 0;
    private int mLeftPixelForBalloon = 0;
    private int mStartLeftPixelForBalloon = 0;
    private boolean mIsMoved = false;
    private int mGraphWidth = 0;
    private int mGraphHeight = 0;
    private int mMaxNumberOfNodesToBeShownForImageGallery = 5;
    private int mMaxNumberOfNodesToBeShownForBalloon = 5;


    private float mTopMarginForImageGallery = 0;
    private float mCenterMarginBetweenImageGalleryAndBalloon = 0;
    private float mHeightForImageGalleryAndBalloon = 0;
    private float mYBottomOffsetForImageGallery = 0;
    private float mInsidePaddingForBalloon = 0;
    private float mYOffsetForBalloon = 0;
    private float mYOffsetForSpeaker = 0;

    private float downPositionX = 0;
    private float downPositionY = 0;
    private int mTouchedArea = 0;
    private static boolean mIsInShortBlank = false;

    private int mImageGalleryProperties[] = null;
    private int mBalloonProperties[] = null;

    //private String mImageGalleryFilePaths[] = null;
    //private String mImageGalleryTitles[] = null;


    final Handler NodeProgressBarHandler = new Handler();
    Runnable nodeProgressBarRunnableForImageGallery = null;
    Runnable nodeProgressBarRunnableForBalloon = null;
    Runnable balloonBlinkingRunnable = null;
    Runnable nodeImageLoadRunnableForImageGallery = null;
    long mStartTimeForImageGallery = SystemClock.uptimeMillis();
    long mStartTimeForBalloon = SystemClock.uptimeMillis();
    final long mDurationForImageGallery = 300L;
    final long mDurationForBalloon = 300L;
    static boolean isRunnableWorkingForImageGallery = false;
    static boolean isRunnableWorkingForBalloon = false;

    long blinkingUITime = SystemClock.uptimeMillis();

    private TouchViewListener mTouchViewListener = null;

    public interface OnNodeProgressBarChangeListener
    {
        void onNodeProgressChanged(BalloonImageGalleryBar nodeBar, int index, int rating, boolean fromUser);
    }

    ArrayList<ImageGalleryImageInfo> mArrays = null;
    class ImageGalleryImageInfo
    {
        public String mFilePath;
        public String mTitles;
        public boolean mImageLoaded;
        public Bitmap mBitmap;
    }

    private OnNodeProgressBarChangeListener mOnNodeProgressBarChangeListener;

    public BalloonImageGalleryBar(Context context) {
        this(context, null);
    }

    public BalloonImageGalleryBar(Context context, AttributeSet attrs)
    {
        this(context, attrs, 0);
    }

    public BalloonImageGalleryBar(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.BalloonImageGalleryBar, defStyle, 0);
        //final boolean indicator = a.getBoolean(R.styleable.ColoredRatingBar_indicator, false);
        final int maxNode = a.getInteger(R.styleable.BalloonImageGalleryBar_BIGnodeTotalNumber, -1);
        final int selectedNode = a.getInteger(R.styleable.BalloonImageGalleryBar_BIGnodeSelectedIndex, -1);

        mNodeMarginWidthPercentForImageGallery = a.getFloat(R.styleable.BalloonImageGalleryBar_BIGnodeMarginPercentForImageGallery, -1);
        mNodeMarginWidthPercentForBalloon = a.getFloat(R.styleable.BalloonImageGalleryBar_BIGnodeMarginPercentForBalloon, -1);

        mOnImageBarResourceId = a.getResourceId(R.styleable.BalloonImageGalleryBar_BIGnodeOnImageBar, R.drawable.blank);
        mOffImageBarResourceId = a.getResourceId(R.styleable.BalloonImageGalleryBar_BIGnodeOffImageBar, R.drawable.blank);
        mOnMultiImageBarResourceId = a.getResourceId(R.styleable.BalloonImageGalleryBar_BIGmultiNodeOnImageBar, R.drawable.blank);
        mOffMultiImageBarResourceId = a.getResourceId(R.styleable.BalloonImageGalleryBar_BIGmultiNodeOffImageBar, R.drawable.blank);
        mOnIntroImageBarResourceId = a.getResourceId(R.styleable.BalloonImageGalleryBar_BIGintroNodeOnImageBar, R.drawable.blank);
        mOffIntroImageBarResourceId = a.getResourceId(R.styleable.BalloonImageGalleryBar_BIGintroNodeOffImageBar, R.drawable.blank);
        mOptionalImageBarResourceId = a.getResourceId(R.styleable.BalloonImageGalleryBar_BIGnodeOptionalImageBar, R.drawable.blank);
        mPipeResourceId = a.getResourceId(R.styleable.BalloonImageGalleryBar_BIGpipe, R.drawable.blank);

        a.recycle();

        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setTextAlign(Paint.Align.CENTER);
        mPaint.setColor(Color.rgb(255, 255, 255));
        mPaint.setShadowLayer(1f, 0f, 1f, Color.BLACK);

        mTitlePaint = new TextPaint();
        mTitlePaint.setTextAlign(Paint.Align.CENTER);
        mTitlePaint.setColor(Color.rgb(225, 225, 225));
        mTitlePaint.setAntiAlias(true);
        mTitlePaint.setTextSize(18);
        mTitlePaint.setStyle(Paint.Style.FILL);
        mTitlePaint.setLinearText(true);

        mWallPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mWallPaint.setTextAlign(Paint.Align.CENTER);
        mWallPaint.setColor(Color.rgb(27, 37, 37));  //ff1B2525
        //mWallPaint.setShadowLayer(1f, 0f, 1f, Color.BLACK);

        mPipePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPipePaint.setTextAlign(Paint.Align.CENTER);
        mPipePaint.setColor(Color.rgb(255, 0, 0));  //ff1B2525

        mBalloonPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBalloonPaint.setColor(Color.rgb(168, 94, 94));
        mBalloonPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mBalloonPaint.setShadowLayer(5f, 1f, 7f, Color.BLACK);

        mTextBounds = new Rect();
        mNumOfImageGalleryNodes = (int)maxNode;
        mNumOfBalloonNodes = (int)maxNode;

        //setIndicator(indicator);
        setImageGalleryIndex(selectedNode);    //selected index
        //setType(type);
        init(context);
    }

    private void init(Context context)
    {
        mContext = context;
    }

    private void drawTriangle(Canvas canvas, float x1, float y1, float x2, float y2, float x3, float y3)
    {
        Path path = new Path();

        path.setFillType(Path.FillType.EVEN_ODD);
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.lineTo(x1, y1);
        path.close();

        canvas.drawPath(path, mBalloonPaint);
    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);

        if(drawables != null)
        {
            int maxDraw = 0;

            int startIndex = calculateFirstNodeIndexForImageGallery();
            int tmpEndIndex = startIndex + mMaxNumberOfNodesToBeShownForImageGallery;

            int endIndex = 0;
            if(tmpEndIndex < mNumOfImageGalleryNodes)
            {
                endIndex = tmpEndIndex;
            }
            else
            {
                endIndex = (mNumOfImageGalleryNodes-1);
                if(endIndex >  (startIndex + mMaxNumberOfNodesToBeShownForImageGallery -1))
                {
                    endIndex = startIndex + mMaxNumberOfNodesToBeShownForImageGallery -1;
                }
            }

            drawImageGalleryPipe(canvas, startIndex, endIndex);

            for (int i = startIndex; i <= endIndex; i++)
            {
                drawImageGalleryNodes(canvas, i);
            }

            //int BalloonOffset = (int)(mTopMarginForImageGallery + mHeightForImageGalleryAndBalloon + mCenterMarginBetweenImageGalleryAndBalloon);

            if(mIsInShortBlank == false)
            {
                RectF r = new RectF(mBalloonMargin, mYOffsetForBalloon, mGraphWidth-mBalloonMargin, mYOffsetForBalloon + (int)mHeightForImageGalleryAndBalloon + 2*mInsidePaddingForBalloon);
                canvas.drawRoundRect(r, 25f, 25f, mBalloonPaint);

                startIndex = calculateFirstNodeIndexForBalloon();
                tmpEndIndex = startIndex + mMaxNumberOfNodesToBeShownForBalloon;

                endIndex = 0;
                if(tmpEndIndex < mNumOfBalloonNodes)
                {
                    endIndex = tmpEndIndex;
                }
                else
                {
                    endIndex = (mNumOfBalloonNodes-1);
                    if(endIndex >  (startIndex + mMaxNumberOfNodesToBeShownForBalloon -1))
                    {
                        endIndex = startIndex + mMaxNumberOfNodesToBeShownForBalloon -1;
                    }
                }

                //balloon's left right side
                //drawLeftAndRightWallForBallon(canvas);

                float tmpLeft = mLeftPixelForImageGallery + mNodeMarginWidthForImageGallery + (mSelectedImageGalleryIndex * (mNodeImageWidthForImageGallery + (mNodeMarginWidthForImageGallery*2) ));
                float widthOfTriangle = mNodeImageWidthForImageGallery/6;
                //float heightOfTriangle = mTopMarginForImageGallery + mNodeImageHeightForImageGallery;
                float centerXp = tmpLeft + mNodeImageWidthForImageGallery/2;

                float secondx = centerXp - widthOfTriangle;
                //float secondy = mYOffsetForBalloon + 10;
                float secondy = mYOffsetForSpeaker -1;
                float thirdx = centerXp + widthOfTriangle;
                //float thirdy = mYOffsetForBalloon + 10;
                float thirdy = mYOffsetForSpeaker -1;
                if(secondx < mBalloonMargin)
                {
                    float difference = mBalloonMargin-secondx;
                    secondx = mBalloonMargin +5;
                    thirdx += (difference+5);
                    secondy += difference;
                    if(secondy > mYOffsetForBalloon + mNodeImageHeightForImageGallery/2)
                    {
                        secondy = mYOffsetForBalloon + mNodeImageHeightForImageGallery/2;
                    }
                }

                if(thirdx > mGraphWidth - mBalloonMargin)
                {
                    float difference = thirdx - (mGraphWidth - mBalloonMargin);
                    thirdx = mGraphWidth - mBalloonMargin -5;
                    secondx -= (difference-5);
                    thirdy += difference;

                    if(thirdy > mYOffsetForBalloon + mNodeImageHeightForImageGallery/2)
                    {
                        thirdy = mYOffsetForBalloon + mNodeImageHeightForImageGallery/2;
                    }
                }
                drawTriangle(canvas, centerXp, mTopMarginForImageGallery + mNodeImageHeightForImageGallery, secondx, secondy, thirdx, thirdy);

                drawBalloonPipe(canvas, startIndex, endIndex);

                for (int i = startIndex; i <= endIndex; i++)
                {
                    drawBalloonNodes(canvas, i);
                }

            }
        }
    }

    private void drawImageGalleryPipe(Canvas canvas, int startIndex, int endIndex)
    {
        //Bitmap pipeBitmap = drawables[PIPE_INDEX];

        //int tmpWidth = mGraphHeight;
        int tmpWidth = (int)mHeightForImageGalleryAndBalloon*2; //image gallery node width is twice of the ballon node width
        int tmpLeft = 0;
        int tmpRight = 0;

        if(startIndex == 0)
        {
            tmpLeft = mLeftPixelForImageGallery + mNodeMarginWidthForImageGallery + (startIndex * (tmpWidth + (mNodeMarginWidthForImageGallery*2) ));
            tmpLeft += mGraphHeight/5;  //little right shifiting for first node
        }
        else
        {
            tmpLeft = 0;
        }

        tmpRight = mLeftPixelForImageGallery + mNodeMarginWidthForImageGallery + (endIndex * (tmpWidth + (mNodeMarginWidthForImageGallery*2) ));
        tmpRight += mHeightForImageGalleryAndBalloon/3; // little right shifting for last node

        if(tmpRight > mGraphWidth)
        {
            tmpRight = mGraphWidth;
        }

        //int vertical_center_y = (int)mTopMarginForImageGallery + (int)(mHeightForImageGalleryAndBalloon/2 - mHeightForImageGalleryAndBalloon/10);
        int vertical_center_y = (int)mTopMarginForImageGallery + (int)(mHeightForImageGalleryAndBalloon/2);

        canvas.drawRect(tmpLeft, vertical_center_y, tmpRight, vertical_center_y + mHeightForImageGalleryAndBalloon/20, mPipePaint);

        /*
        for(int x = tmpLeft; x < tmpRight; x++)
        {
            canvas.drawBitmap(pipeBitmap, x, vertical_center_y, null);
        }
        */
    }

    private void drawBalloonPipe(Canvas canvas, int startIndex, int endIndex)
    {
        Bitmap pipeBitmap = drawables[PIPE_INDEX];

        //int tmpWidth = mGraphHeight;
        //int tmpWidth = (int)(mHeightForImageGalleryAndBalloon + 2*mInsidePaddingForBalloon);
        int tmpWidth = (int)(mHeightForImageGalleryAndBalloon);
        int tmpLeft = 0;
        int tmpRight = 0;

        if(startIndex == 0)
        {
            tmpLeft = mLeftPixelForBalloon + mNodeMarginWidthForBalloon + (startIndex * (tmpWidth + (mNodeMarginWidthForBalloon*2) ));
            tmpLeft += mGraphHeight/5;  //little right shifiting for first node
        }
        else
        {
            tmpLeft = 0;
        }

        if(tmpLeft < mBalloonMargin)
        {
            tmpLeft = (int)mBalloonMargin;
        }

        tmpRight = mLeftPixelForBalloon + mNodeMarginWidthForBalloon + (endIndex * (tmpWidth + (mNodeMarginWidthForBalloon*2) ));
        tmpRight += mHeightForImageGalleryAndBalloon/5; // little right shifting for last node

        if(tmpRight > mGraphWidth)
        {
            tmpRight = mGraphWidth;
        }

        if(tmpRight > mGraphWidth-mBalloonMargin)
        {
            tmpRight = mGraphWidth - (int)mBalloonMargin;
        }

        //int vertical_center_y = (int)mYOffsetForSpeaker + (int)(mHeightForImageGalleryAndBalloon/2 - mHeightForImageGalleryAndBalloon/10);
        int vertical_center_y = (int)mYOffsetForSpeaker + (int)(mHeightForImageGalleryAndBalloon/2);

        canvas.drawRect(tmpLeft, vertical_center_y, tmpRight, vertical_center_y + mHeightForImageGalleryAndBalloon/20, mPipePaint);

        /*
        for(int x = tmpLeft; x < tmpRight; x++)
        {
            canvas.drawBitmap(pipeBitmap, x, vertical_center_y, null);
        }
        */
    }

    private void drawImageGalleryNodes(Canvas canvas, int position)
    {
        float fraction = mSelectedImageGalleryIndex -(position);
        Bitmap nodeBitmap = null;
        String title = null;

        //if ((drawables == null) || (progressBackground == null))
        if (drawables == null)
        {
            return;
        }

        if(mSelectedImageGalleryIndex == position)
        {
            if(mImageGalleryProperties != null)
            {
                if((mImageGalleryProperties[position] == NODE_SINGLE) || (mImageGalleryProperties[position] == NODE_INTRO))
                {
                    ImageGalleryImageInfo oneInfo = mArrays.get(position);
                    nodeBitmap = oneInfo.mBitmap;

                    if(nodeBitmap == null)
                    {
                        nodeBitmap = drawables[BLANK_PHOTO];
                    }
                }
                else if(mImageGalleryProperties[position] == NODE_OPTIONAL)
                {
                    nodeBitmap = drawables[OPTIONAL_IMAGE_INDEX];
                }
                /*
                else if(mImageGalleryProperties[position] == NODE_INTRO)
                {
                    nodeBitmap = drawables[INTRO_ON_IMAGE_INDEX_FOR_GALLERY];
                }
                */
                else if(mImageGalleryProperties[position] == NODE_MULTI)
                {
                    ImageGalleryImageInfo oneInfo = mArrays.get(position);
                    nodeBitmap = oneInfo.mBitmap;

                    if(nodeBitmap == null)
                    {
                        nodeBitmap = drawables[BLANK_PHOTO];
                    }
                }
                else
                {
                    nodeBitmap = drawables[BLANK_PHOTO];
                }
            }
            else
            {
                nodeBitmap = drawables[GENERAL_ON_IMAGE_INDEX];
            }
        }
        else
        {
            if(mImageGalleryProperties != null)
            {
                if((mImageGalleryProperties[position] == NODE_SINGLE) || (mImageGalleryProperties[position] == NODE_INTRO))
                {
                    //nodeBitmap = mGalleryImages[position];

                    ImageGalleryImageInfo oneInfo = mArrays.get(position);
                    nodeBitmap = oneInfo.mBitmap;

                    if(nodeBitmap == null)
                    {
                        nodeBitmap = drawables[BLANK_PHOTO];
                    }
                }
                else if(mImageGalleryProperties[position] == NODE_OPTIONAL)
                {
                    nodeBitmap = drawables[OPTIONAL_IMAGE_INDEX];
                }
                /*
                else if(mImageGalleryProperties[position] == NODE_INTRO)
                {
                    nodeBitmap = drawables[INTRO_OFF_IMAGE_INDEX_FOR_GALLERY];
                }
                */
                else if(mImageGalleryProperties[position] == NODE_MULTI)
                {
                    ImageGalleryImageInfo oneInfo = mArrays.get(position);
                    nodeBitmap = oneInfo.mBitmap;

                    if(nodeBitmap == null)
                    {
                        nodeBitmap = drawables[BLANK_PHOTO];
                    }
                }
                else
                {
                    nodeBitmap = drawables[BLANK_PHOTO];
                }
            }
            else
            {
                nodeBitmap = drawables[GENERAL_OFF_IMAGE_INDEX];
            }
        }

        if(mArrays != null)
        {
            ImageGalleryImageInfo tmpInfo = mArrays.get(position);
            title = tmpInfo.mTitles;
            //title = mImageGalleryTitles[position];
        }

        int sourceWidth = nodeBitmap.getWidth();
        int sourceHeight = nodeBitmap.getHeight();

        int tmpLeft = mLeftPixelForImageGallery + mNodeMarginWidthForImageGallery + (position * (sourceWidth + (mNodeMarginWidthForImageGallery*2) ));

        mPaint.getTextBounds(String.format("%d", position), 0, String.format("%d", position).length(), mTextBounds);

        if(mSelectedImageGalleryIndex == position)
        {
            canvas.drawRect(tmpLeft - WHITE_BORDER_SIZE, mTopMarginForImageGallery - WHITE_BORDER_SIZE, tmpLeft + sourceWidth + WHITE_BORDER_SIZE, mTopMarginForImageGallery + sourceHeight + WHITE_BORDER_SIZE, mPaint);
        }

        //canvas.drawBitmap(nodeBitmap, tmpLeft, mTopMarginForImageGallery, null);
        Rect origRect = new Rect(0, 0, sourceWidth, sourceHeight);
        Rect destRect = new Rect(tmpLeft, (int)mTopMarginForImageGallery, (int)tmpLeft + sourceWidth, (int)mTopMarginForImageGallery + sourceHeight);
        canvas.drawBitmap(nodeBitmap, origRect, destRect, null);

        if(title != null)
        {
            int x = (nodeBitmap.getWidth() - mTextBounds.width())/2 + mTextBounds.width()/4 + mTextBounds.width()/8;        //Someone please tell me why i need to do "mTextBounds.width()/4 + mTextBounds.width()/8"
            int y = (nodeBitmap.getHeight() + mTextBounds.height())/2;

            int width = sourceWidth - 10; //10 to keep some space on the right for the "..."
            CharSequence txt = TextUtils.ellipsize(String.format("%s", title), mTitlePaint, width, TextUtils.TruncateAt.END);

            canvas.drawText(txt, 0, txt.length(), tmpLeft + x , mTopMarginForImageGallery + mHeightForImageGalleryAndBalloon + y/3, mTitlePaint);

            //canvas.drawText(String.format("%s", title), tmpLeft + x, mTopMarginForImageGallery + mHeightForImageGalleryAndBalloon, mTitlePaint);
        }
    }

    private void drawBalloonNodes(Canvas canvas, int position)
    {
        float fraction = mSelectedBalloonIndex -(position);
        Bitmap nodeBitmap = null;

        //if ((drawables == null) || (progressBackground == null))
        if (drawables == null)
        {
            return;
        }

        if(mSelectedBalloonIndex == position)
        {
            if(mBalloonProperties != null)
            {
                if((mBalloonProperties[position] == NODE_SINGLE) || (mBalloonProperties[position] == NODE_INTRO))
                {
                    nodeBitmap = drawables[GENERAL_ON_IMAGE_INDEX];
                }
                else if(mBalloonProperties[position] == NODE_OPTIONAL)
                {
                    nodeBitmap = drawables[OPTIONAL_IMAGE_INDEX];
                }
                /*
                else if(mBalloonProperties[position] == NODE_INTRO)
                {
                    nodeBitmap = drawables[INTRO_ON_IMAGE_INDEX_FOR_BALLOON];
                }
                */
            }
            else
            {
                nodeBitmap = drawables[GENERAL_ON_IMAGE_INDEX];
            }
        }
        else
        {
            if(mBalloonProperties != null)
            {
                if((mBalloonProperties[position] == NODE_SINGLE) || (mBalloonProperties[position] == NODE_INTRO))
                {
                    nodeBitmap = drawables[GENERAL_OFF_IMAGE_INDEX];
                }
                else if(mBalloonProperties[position] == NODE_OPTIONAL)
                {
                    nodeBitmap = drawables[OPTIONAL_IMAGE_INDEX];
                }
                /*
                else if(mBalloonProperties[position] == NODE_INTRO)
                {
                    nodeBitmap = drawables[INTRO_OFF_IMAGE_INDEX_FOR_BALLOON];
                }
                */
            }
            else
            {
                nodeBitmap = drawables[GENERAL_OFF_IMAGE_INDEX];
            }
        }

        int sourceWidth = nodeBitmap.getWidth();
        int sourceHeight = nodeBitmap.getHeight();

        int tmpLeft = mLeftPixelForBalloon + mNodeMarginWidthForBalloon + (position * (sourceWidth + (mNodeMarginWidthForBalloon*2) ));
        int tmpRight = tmpLeft + sourceWidth;

        if(tmpLeft <= mBalloonMargin - sourceWidth)
        {
            //should not draw, because it is on the left side of wall.
        }
        else if( (tmpLeft <= mBalloonMargin) && (tmpRight > mBalloonMargin))
        {
            //we should draw part of node
            int leftOffset = (int)mBalloonMargin - tmpLeft;

            Rect sourceRect = new Rect(leftOffset, 0, sourceWidth, sourceHeight);
            //Rect sourceRect = new Rect(0, 0, sourceWidth, sourceHeight);
            //Rect destRect = new Rect((int)mBalloonMargin, (int)mYOffsetForSpeaker, sourceWidth - leftOffset,(int)mYOffsetForSpeaker + sourceHeight);
            Rect destRect = new Rect((int)mBalloonMargin, (int)mYOffsetForSpeaker, tmpLeft + sourceWidth,(int)mYOffsetForSpeaker + sourceHeight);

            mPaint.getTextBounds(String.format("%d", position), 0, String.format("%d", position).length(), mTextBounds);

            int x = (nodeBitmap.getWidth() - mTextBounds.width())/2 + mTextBounds.width()/4 + mTextBounds.width()/8;        //Someone please tell me why i need to do "mTextBounds.width()/4 + mTextBounds.width()/8"
            int y = (nodeBitmap.getHeight() + mTextBounds.height())/2 + (int)mYOffsetForSpeaker;

            //canvas.drawBitmap(nodeBitmap, tmpLeft, mYOffsetForSpeaker, null);
            canvas.drawBitmap(nodeBitmap, sourceRect, destRect, null);

            if(tmpLeft + x > mBalloonMargin)
            {
                canvas.drawText(String.format("%d", position), tmpLeft + x, y, mPaint);
            }
        }
        else if(tmpLeft > (mGraphWidth - mBalloonMargin) )
        {
            //should not draw, because it is on the right side of wall.
        }
        else if( (tmpLeft <= (mGraphWidth - mBalloonMargin)) && (tmpRight > (mGraphWidth - mBalloonMargin)))
        {
            //we should draw part of node
            int rightOffset = tmpRight - (int)(mGraphWidth - mBalloonMargin);

            Rect sourceRect = new Rect(0, 0, sourceWidth - rightOffset, sourceHeight);
            //Rect sourceRect = new Rect(0, 0, sourceWidth, sourceHeight);
            //Rect destRect = new Rect((int)mBalloonMargin, (int)mYOffsetForSpeaker, sourceWidth - leftOffset,(int)mYOffsetForSpeaker + sourceHeight);
            Rect destRect = new Rect(tmpLeft, (int)mYOffsetForSpeaker, (int)(mGraphWidth - mBalloonMargin), (int)mYOffsetForSpeaker + sourceHeight);

            //mPaint.getTextBounds(String.format("%d", position), 0, String.format("%d", position).length(), mTextBounds);

            //int x = (nodeBitmap.getWidth() - mTextBounds.width())/2 + mTextBounds.width()/4 + mTextBounds.width()/8;        //Someone please tell me why i need to do "mTextBounds.width()/4 + mTextBounds.width()/8"
            //int y = (nodeBitmap.getHeight() + mTextBounds.height())/2 + (int)mYOffsetForSpeaker;

            //canvas.drawBitmap(nodeBitmap, tmpLeft, mYOffsetForSpeaker, null);
            canvas.drawBitmap(nodeBitmap, sourceRect, destRect, null);

            //if(tmpLeft + x < mGraphWidth - mBalloonMargin)
            //{
            //    canvas.drawText(String.format("%d", position), tmpLeft + x, y, mPaint);
            //}
        }
        else
        {
            //we should draw whole part of node
            //mPaint.getTextBounds(String.format("%d", position), 0, String.format("%d", position).length(), mTextBounds);

            //int x = (nodeBitmap.getWidth() - mTextBounds.width())/2 + mTextBounds.width()/4 + mTextBounds.width()/8;        //Someone please tell me why i need to do "mTextBounds.width()/4 + mTextBounds.width()/8"
            //int y = (nodeBitmap.getHeight() + mTextBounds.height())/2 + (int)mYOffsetForSpeaker;

            canvas.drawBitmap(nodeBitmap, tmpLeft, mYOffsetForSpeaker, null);

            //canvas.drawText(String.format("%d", position), tmpLeft + x, y, mPaint);
        }
    }

    private void drawLeftAndRightWallForBallon(Canvas canvas)
    {
        //ff1B2525
        canvas.drawRect(0, mYOffsetForBalloon, mBalloonMargin, mYOffsetForBalloon + mHeightForImageGalleryAndBalloon + 2*mInsidePaddingForBalloon, mWallPaint);
        canvas.drawRect(mGraphWidth-mBalloonMargin, mYOffsetForBalloon, mGraphWidth, mYOffsetForBalloon + mHeightForImageGalleryAndBalloon+ 2*mInsidePaddingForBalloon, mWallPaint);
    }

    public int getNumOfImageNodes()
    {
        return mNumOfImageGalleryNodes;
    }

    public void setNumOfImageNodex(int numNodex)
    {
        this.mNumOfImageGalleryNodes = numNodex;
        //invalidate();     //from javascript 2016/11/17 issue
    }

    public int getNumOfBalloonNodes()
    {
        return mNumOfBalloonNodes;
    }

    public void setNumOfBalloonNodex(int numNodex, boolean isInvalidate)
    {
        this.mNumOfBalloonNodes = numNodex;
        if(isInvalidate == true)
        {
            invalidate();
        }
    }

    public float getImageGalleryIndex()
    {
        return mSelectedImageGalleryIndex;
    }

    public void setImageGalleryIndex(final float index)
    {
        /*
        if(balloonBlinkingRunnable != null)
        {
            NodeProgressBarHandler.removeCallbacks(balloonBlinkingRunnable);
        }
        */

        //final int firstLeftPixel = mLeftPixelForImageGallery;
        setActualImageGalleryIndex(index, false);

        /*
        blinkingUITime = SystemClock.uptimeMillis();

        balloonBlinkingRunnable = new Runnable()
        {
            @Override
            public void run()
            {
                long elapsed = SystemClock.uptimeMillis() - blinkingUITime;

                if(elapsed > BLINKING_TIME)
                {
                    mIsInShortBlank = false;
                    setActualImageGalleryIndex(index, false);
                }
                else
                {
                    mIsInShortBlank = true;
                    invalidate();
                    NodeProgressBarHandler.postDelayed(this, 15L);
                }
            }
        };

        NodeProgressBarHandler.postDelayed(balloonBlinkingRunnable, 15L);
        */
    }

    void setImageGalleryIndex(final float index, final boolean fromUser)
    {
        /*
        if(balloonBlinkingRunnable != null)
        {
            NodeProgressBarHandler.removeCallbacks(balloonBlinkingRunnable);
        }
        */

        //final int firstLeftPixel = mLeftPixelForImageGallery;
        setActualImageGalleryIndex(index, fromUser);
        /*
        blinkingUITime = SystemClock.uptimeMillis();

        balloonBlinkingRunnable = new Runnable()
        {
            @Override
            public void run()
            {
                long elapsed = SystemClock.uptimeMillis() - blinkingUITime;

                if(elapsed > BLINKING_TIME)
                {
                    mIsInShortBlank = false;
                    setActualImageGalleryIndex(index, fromUser);
                }
                else
                {
                    mIsInShortBlank = true;
                    invalidate();
                    NodeProgressBarHandler.postDelayed(this, 15L);
                }
            }
        };

        NodeProgressBarHandler.postDelayed(balloonBlinkingRunnable, 15L);
        */
    }

    void setActualImageGalleryIndex(float index, final boolean fromUser)
    {
        if(fromUser == true)
        {
            if(isRunnableWorkingForImageGallery == true)
            {
                isRunnableWorkingForImageGallery = false;
                if(nodeProgressBarRunnableForImageGallery != null)
                {
                    NodeProgressBarHandler.removeCallbacks(nodeProgressBarRunnableForImageGallery);    //cancel previous runnable
                }
            }
        }
        else
        {
            //isRunnableWorking = false;
        }

        if(index > mNumOfImageGalleryNodes)
        {
            this.mSelectedImageGalleryIndex = mNumOfImageGalleryNodes;
        }
        this.mSelectedImageGalleryIndex = index;

        int sourceWidth = mNodeImageHeightForImageGallery;
        int tmpLeft = mLeftPixelForImageGallery + mNodeMarginWidthForImageGallery + ((int)index * (sourceWidth + (mNodeMarginWidthForImageGallery*2) ));

        int center_horizontal = mGraphWidth/2;
        if(tmpLeft > center_horizontal)
        {
            if(fromUser == true)
            {
                final int firstLeftPixel = mLeftPixelForImageGallery;
                //mLeftPixel = (center_horizontal - mNodeMarginWidth - ((int) index * (sourceWidth + (mNodeMarginWidth * 2))));
                final int destinationPixel =  (center_horizontal - mNodeMarginWidthForImageGallery - ((int) index * (sourceWidth + (mNodeMarginWidthForImageGallery * 2))));

                mStartTimeForImageGallery = SystemClock.uptimeMillis();

                nodeProgressBarRunnableForImageGallery = new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if(isRunnableWorkingForImageGallery == false)
                            return;

                        long elapsed = SystemClock.uptimeMillis() - mStartTimeForImageGallery;
                        float change_percent = Math.min((float) elapsed / mDurationForImageGallery, 1f);
                        //float currentPixel = destinationPixel * change_percent;
                        float currentPixel = firstLeftPixel + (destinationPixel - firstLeftPixel)*change_percent;
                        mLeftPixelForImageGallery = (int)currentPixel;

                        invalidate();

                        if(isRunnableWorkingForImageGallery == false)
                            return;

                        if(mLeftPixelForImageGallery > destinationPixel)
                        {
                            if(isRunnableWorkingForImageGallery == false)
                                return;

                            NodeProgressBarHandler.postDelayed(this, 15L);
                        }
                        else
                        {
                            //finish
                            isRunnableWorkingForImageGallery = false;
                        }
                    }
                };

                isRunnableWorkingForImageGallery = true;
                NodeProgressBarHandler.postDelayed(nodeProgressBarRunnableForImageGallery, 15L);
            }
            else
            {
                mLeftPixelForImageGallery = (center_horizontal - mNodeMarginWidthForImageGallery - ((int) index * (sourceWidth + (mNodeMarginWidthForImageGallery * 2))));
                //invalidate();
            }
        }

        if(mArrays != null)
        {
            nodeImageLoadRunnableForImageGallery = new Runnable()
            {
                @Override
                public void run()
                {
                    LoadAndRecycleImageForCurrentView(mArrays);
                    invalidate();
                }
            };
            NodeProgressBarHandler.postDelayed(nodeImageLoadRunnableForImageGallery, 0);
        }

        invalidate();

        dispatchIndexChangeFromImageGallery(fromUser);
    }


    public float getBalloonIndex()
    {
        return mSelectedBalloonIndex;
    }

    public void setBalloonIndex(float index)
    {
        setBalloonIndex(index, false);
    }

    void setBalloonIndex(float index, final boolean fromUser)
    {
        if(fromUser == true)
        {
            if(isRunnableWorkingForBalloon == true)
            {
                isRunnableWorkingForBalloon = false;
                if(nodeProgressBarRunnableForBalloon != null)
                {
                    NodeProgressBarHandler.removeCallbacks(nodeProgressBarRunnableForBalloon);    //cancel previous runnable
                }
            }
        }
        else
        {
            //isRunnableWorking = false;
        }

        if(index > mNumOfBalloonNodes)
        {
            this.mSelectedBalloonIndex = mNumOfBalloonNodes;
        }
        this.mSelectedBalloonIndex = index;

        int sourceWidth = mNodeImageHeightForBalloon;
        int tmpLeft = mLeftPixelForBalloon + mNodeMarginWidthForBalloon + ((int)index * (sourceWidth + (mNodeMarginWidthForBalloon*2) ));

        int center_horizontal = mGraphWidth/2;
        if(tmpLeft > center_horizontal)
        {
            //if(fromUser == true)
            {
                final int firstLeftPixel = mLeftPixelForBalloon;
                //mLeftPixel = (center_horizontal - mNodeMarginWidth - ((int) index * (sourceWidth + (mNodeMarginWidth * 2))));
                final int destinationPixel =  (center_horizontal - mNodeMarginWidthForBalloon - ((int) index * (sourceWidth + (mNodeMarginWidthForBalloon * 2))));

                mStartTimeForBalloon = SystemClock.uptimeMillis();

                nodeProgressBarRunnableForBalloon = new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if(isRunnableWorkingForBalloon == false)
                            return;

                        long elapsed = SystemClock.uptimeMillis() - mStartTimeForBalloon;
                        float change_percent = Math.min((float) elapsed / mDurationForBalloon, 1f);
                        //float currentPixel = destinationPixel * change_percent;
                        float currentPixel = firstLeftPixel + (destinationPixel - firstLeftPixel)*change_percent;
                        mLeftPixelForBalloon = (int)currentPixel;

                        invalidate();

                        if(isRunnableWorkingForBalloon == false)
                            return;

                        if(mLeftPixelForBalloon > destinationPixel)
                        {
                            if(isRunnableWorkingForBalloon == false)
                                return;

                            NodeProgressBarHandler.postDelayed(this, 15L);
                        }
                        else
                        {
                            //finish
                            isRunnableWorkingForBalloon = false;
                        }
                    }
                };

                isRunnableWorkingForBalloon = true;
                NodeProgressBarHandler.postDelayed(nodeProgressBarRunnableForBalloon, 15L);
            }
            /*
            else
            {
                mLeftPixelForBalloon = (center_horizontal - mNodeMarginWidthForBalloon - ((int) index * (sourceWidth + (mNodeMarginWidthForBalloon * 2))));
                //invalidate();
            }
            */
        }
        invalidate();

        dispatchIndexChangeFromBalloon(fromUser);
    }

    public void setImageGalleryProperty(int properties[])
    {
        mImageGalleryProperties = properties;
    }

    public void setBalloonProperty(int properties[])
    {
        mBalloonProperties = properties;
    }

    public int [] getEventProperty()
    {
        return mBalloonProperties;
    }

    public void setmImageGalleryInfos(String filePaths[], String titles[])
    {
        mArrays = new ArrayList<ImageGalleryImageInfo>();

        for(int x = 0; x < filePaths.length; x++)
        {
            ImageGalleryImageInfo tmpInfo = new ImageGalleryImageInfo();

            tmpInfo.mFilePath = filePaths[x];
            tmpInfo.mTitles = titles[x];

            mArrays.add(tmpInfo);
        }

        if(mGraphHeight == 0)
        {
            //wait for onMeasure
        }
        else
        {
            if(mArrays != null)
            {
                nodeImageLoadRunnableForImageGallery = new Runnable()
                {
                    @Override
                    public void run()
                    {
                        LoadAndRecycleImageForCurrentView(mArrays);
                        invalidate();
                    }
                };
                NodeProgressBarHandler.postDelayed(nodeImageLoadRunnableForImageGallery, 0);
            }
        }

        /*
        mImageGalleryFilePaths = filePaths;
        mImageGalleryTitles = titles;

        if(mGraphHeight == 0)
        {
            //wait for onMeasure
        }
        else
        {
            if(mGalleryImages != null)
            {
                for(int x = 0; x < mGalleryImages.length; x++)
                {
                    if (mGalleryImages[x] != null)
                    {
                        mGalleryImages[x] = null;
                    }
                }
            }

            int oneImageGalleryNodeSize = mGraphHeight/3;

            mGalleryImages = new Bitmap[mImageGalleryFilePaths.length];

            for(int x = 0; x < mImageGalleryFilePaths.length; x++)
            {
                if(mImageGalleryFilePaths[x] != null)
                {
                    BitmapFactory.Options tmpOption = new BitmapFactory.Options();
                    tmpOption.outWidth = oneImageGalleryNodeSize;
                    tmpOption.outHeight = oneImageGalleryNodeSize;
                    tmpOption.inSampleSize = 8;
                    Bitmap tmpBitmap = BitmapFactory.decodeFile(mImageGalleryFilePaths[x], tmpOption);
                    mGalleryImages[x] = Bitmap.createScaledBitmap(tmpBitmap, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false);
                    tmpBitmap.recycle();
                    tmpBitmap = null;
                    tmpOption = null;
                    //mGalleryImages[x] = Bitmap.createScaledBitmap(tmpBitmap, oneImageGalleryNodeSize, oneImageGalleryNodeSize, false);
                    //mGalleryImages[x] = decodeSampledBitmapFromResource(mImageGalleryFilePaths[x], oneImageGalleryNodeSize, oneImageGalleryNodeSize);
                    //tmpBitmap = null;
                }
                else
                {
                    mGalleryImages[x] = null;
                }
            }
        }
        */
    }

    public void LoadAndRecycleImageForCurrentView(ArrayList<ImageGalleryImageInfo> tmpArrays)
    {
        int oneImageGalleryNodeSize = mGraphHeight/3;

        int startIndex = calculateFirstNodeIndexForImageGallery();
        int tmpEndIndex = startIndex + mMaxNumberOfNodesToBeShownForImageGallery;

        int endIndex = 0;
        if(tmpEndIndex < mNumOfImageGalleryNodes)
        {
            endIndex = tmpEndIndex;
        }
        else
        {
            endIndex = (mNumOfImageGalleryNodes-1);
            if(endIndex >  (startIndex + mMaxNumberOfNodesToBeShownForImageGallery -1))
            {
                endIndex = startIndex + mMaxNumberOfNodesToBeShownForImageGallery -1;
            }
        }

        startIndex -= EXTENDED_IMAGE_LOADING_COUNT;
        endIndex += EXTENDED_IMAGE_LOADING_COUNT;

        if(startIndex < 0)
        {
            startIndex = 0;
        }

        if(endIndex > tmpArrays.size() -1)
        {
            endIndex = tmpArrays.size() -1;
        }

        for(int x = 0; x < tmpArrays.size(); x++)
        {
            ImageGalleryImageInfo oneInfo = tmpArrays.get(x);
            if(oneInfo.mFilePath != null)
            {
                if ((x >= startIndex) && (x <= endIndex))
                {
                    if(oneInfo.mImageLoaded == false)
                    {
                        BitmapFactory.Options tmpOption = new BitmapFactory.Options();
                        tmpOption.outWidth = oneImageGalleryNodeSize;
                        tmpOption.outHeight = oneImageGalleryNodeSize;
                        tmpOption.inSampleSize = 8;
                        Bitmap tmpBitmap = BitmapFactory.decodeFile(oneInfo.mFilePath, tmpOption);
                        oneInfo.mBitmap = Bitmap.createScaledBitmap(tmpBitmap, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false);
                        tmpBitmap.recycle();
                        tmpBitmap = null;
                        tmpOption = null;
                        //mGalleryImages[x] = Bitmap.createScaledBitmap(tmpBitmap, oneImageGalleryNodeSize, oneImageGalleryNodeSize, false);
                        //mGalleryImages[x] = decodeSampledBitmapFromResource(mImageGalleryFilePaths[x], oneImageGalleryNodeSize, oneImageGalleryNodeSize);
                        //tmpBitmap = null;
                        Log.d(TAG, String.format("gallery image reloaded %d", x));
                        oneInfo.mImageLoaded = true;
                    }
                    else
                    {
                        //do nothing
                    }
                }
                else
                {
                    oneInfo.mImageLoaded = false;
                    if(oneInfo.mBitmap != null)
                    {
                        oneInfo.mBitmap.recycle();
                        oneInfo.mBitmap = null;

                        Log.d(TAG, String.format("gallery image deleted %d", x));
                    }
                }
            }
            else
            {
                oneInfo.mImageLoaded = false;
                oneInfo.mBitmap = null;
            }
            tmpArrays.set(x, oneInfo);
        }
    }

    public void blinkingRefresh()
    {
        if(balloonBlinkingRunnable != null)
        {
            NodeProgressBarHandler.removeCallbacks(balloonBlinkingRunnable);
        }

        blinkingUITime = SystemClock.uptimeMillis();

        balloonBlinkingRunnable = new Runnable()
        {
            @Override
            public void run()
            {
                long elapsed = SystemClock.uptimeMillis() - blinkingUITime;

                if(elapsed > BLINKING_TIME)
                {
                    mIsInShortBlank = false;
                    setActualImageGalleryIndex(mSelectedImageGalleryIndex, false);
                }
                else
                {
                    mIsInShortBlank = true;
                    invalidate();
                    NodeProgressBarHandler.postDelayed(this, 15L);
                }
            }
        };

        NodeProgressBarHandler.postDelayed(balloonBlinkingRunnable, 15L);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        mGraphWidth = getWidth();
        mGraphHeight = getHeight();

        if( (mGraphWidth != 0 ) && (mGraphHeight != 0))
        {
            Resources res = getResources();

            //int oneNodeSize = mGraphWidth/mNumOfNodes;
            int oneImageGalleryNodeSize;
            int oneBalloonNodeSize;

            //oneNodeSize = mGraphWidth/ (MAX_NUM_OF_EVENT_NODE_SHOWN);
            oneImageGalleryNodeSize = mGraphHeight/3;
            oneBalloonNodeSize = mGraphHeight/4;

            Bitmap tmpBitmap1 = BitmapFactory.decodeResource(res, mOnImageBarResourceId);
            Bitmap tmpBitmap2 = BitmapFactory.decodeResource(res, mOffImageBarResourceId);
            Bitmap tmpBitmap3 = BitmapFactory.decodeResource(res, mOptionalImageBarResourceId);
            Bitmap tmpBitmap4 = BitmapFactory.decodeResource(res, mOnIntroImageBarResourceId);
            Bitmap tmpBitmap5 = BitmapFactory.decodeResource(res, mOffIntroImageBarResourceId);
            Bitmap tmpBitmap6 = BitmapFactory.decodeResource(res, mOnIntroImageBarResourceId);
            Bitmap tmpBitmap7 = BitmapFactory.decodeResource(res, mOffIntroImageBarResourceId);
            Bitmap tmpBitmap8 = BitmapFactory.decodeResource(res, mPipeResourceId);
            Bitmap tmpBitmap9 = BitmapFactory.decodeResource(res, R.drawable.tgm_blank_map);
            Bitmap tmpBitmap10 = BitmapFactory.decodeResource(res, mOnMultiImageBarResourceId);
            Bitmap tmpBitmap11 = BitmapFactory.decodeResource(res, mOffMultiImageBarResourceId);

            drawables = new Bitmap[]
            {
                    Bitmap.createScaledBitmap(tmpBitmap1, oneImageGalleryNodeSize, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap2, oneImageGalleryNodeSize, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap3, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap4, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap5, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap6, oneImageGalleryNodeSize, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap7, oneImageGalleryNodeSize, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap8, 1, oneImageGalleryNodeSize/10, false),
                    Bitmap.createScaledBitmap(tmpBitmap9, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap10, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false),
                    Bitmap.createScaledBitmap(tmpBitmap11, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false)
            };

            mNodeImageWidthForImageGallery = drawables[INTRO_ON_IMAGE_INDEX_FOR_GALLERY].getWidth();
            mNodeImageHeightForImageGallery = drawables[INTRO_ON_IMAGE_INDEX_FOR_GALLERY].getHeight();
            mNodeMarginWidthForImageGallery = (int)(mNodeImageWidthForImageGallery * mNodeMarginWidthPercentForImageGallery);
            mMaxNumberOfNodesToBeShownForImageGallery = mGraphWidth/(oneImageGalleryNodeSize*2 + mNodeMarginWidthForImageGallery*2) + 2;

            mNodeImageWidthForBalloon = drawables[INTRO_ON_IMAGE_INDEX_FOR_BALLOON].getWidth();
            mNodeImageHeightForBalloon = drawables[INTRO_ON_IMAGE_INDEX_FOR_BALLOON].getHeight();
            mNodeMarginWidthForBalloon = (int)(mNodeImageWidthForBalloon * mNodeMarginWidthPercentForBalloon);
            mMaxNumberOfNodesToBeShownForBalloon = mGraphWidth/(oneBalloonNodeSize + mNodeMarginWidthForBalloon*2) + 2;

            //let's add both edge balls
            int fontSize = mGraphWidth/43;

            mPaint.setTextSize((int) (fontSize));

            mTopMarginForImageGallery = TOP_MARGIN_PERCENT_FOR_IMAGE_GALLERY * mGraphHeight;
            mCenterMarginBetweenImageGalleryAndBalloon = CENTER_MARGIN_PERCENT_BETWEEN_IMAGE_GALLERY_AND_BALLOON * mGraphHeight;
            mHeightForImageGalleryAndBalloon = HEIGHT_PERCENT_FOR_IMAGE_GALLERY_AND_BALLOON * mGraphHeight;
            mYBottomOffsetForImageGallery = mTopMarginForImageGallery + mHeightForImageGalleryAndBalloon;
            mInsidePaddingForBalloon = INSIDE_PADDING_PERCENT_FOR_BALLOON * mGraphHeight;
            mYOffsetForBalloon = mTopMarginForImageGallery + mHeightForImageGalleryAndBalloon + mCenterMarginBetweenImageGalleryAndBalloon;
            mYOffsetForSpeaker = mTopMarginForImageGallery + mHeightForImageGalleryAndBalloon + mCenterMarginBetweenImageGalleryAndBalloon + mInsidePaddingForBalloon;

            mBalloonMargin = mHeightForImageGalleryAndBalloon/2;

            /*
            if(mGalleryImages != null)
            {
                for(int x = 0; x < mGalleryImages.length; x++)
                {
                    if (mGalleryImages[x] != null)
                    {
                        mGalleryImages[x] = null;
                    }
                }
            }
            */

            if(mArrays != null)
            {
                LoadAndRecycleImageForCurrentView(mArrays);
            }

            //int oneImageGalleryNodeSize = mGraphHeight/3;
            /*
            mGalleryImages = new Bitmap[mImageGalleryFilePaths.length];

            for(int x = 0; x < mImageGalleryFilePaths.length; x++)
            {
                if(mImageGalleryFilePaths[x] != null)
                {
                    //Bitmap tmpBitmap = BitmapFactory.decodeFile(mImageGalleryFilePaths[x]);
                    //mGalleryImages[x] = Bitmap.createScaledBitmap(tmpBitmap, oneImageGalleryNodeSize, oneImageGalleryNodeSize, false);
                    //tmpBitmap = null;
                    //mGalleryImages[x] = decodeSampledBitmapFromResource(mImageGalleryFilePaths[x], oneImageGalleryNodeSize, oneImageGalleryNodeSize);

                    BitmapFactory.Options tmpOption = new BitmapFactory.Options();
                    tmpOption.outWidth = oneImageGalleryNodeSize;
                    tmpOption.outHeight = oneImageGalleryNodeSize;
                    tmpOption.inSampleSize = 8;
                    Bitmap tmpBitmap = BitmapFactory.decodeFile(mImageGalleryFilePaths[x], tmpOption);
                    mGalleryImages[x] = Bitmap.createScaledBitmap(tmpBitmap, oneImageGalleryNodeSize*2, oneImageGalleryNodeSize, false);
                    tmpBitmap.recycle();
                    tmpBitmap = null;
                    tmpOption = null;
                }
                else
                {
                    mGalleryImages[x] = null;
                }
            }
            */
        }
    }

    public void resetImageGalleryFirstLocation()
    {
        mLeftPixelForImageGallery = 0;
        invalidate();
    }

    public void resetBalloonFirstLocation()
    {
        mLeftPixelForBalloon = 0;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        double distance_from_down;

        float tmpX = event.getX();
        float tmpY = event.getY();

        int action = event.getAction();
        switch (action)
        {
            case MotionEvent.ACTION_DOWN:

                mTouchedArea = checkTouchedArea(tmpX, tmpY);

                mIsMoved = false;
                downPositionX = tmpX;
                downPositionY = tmpY;

                if(mTouchedArea == AREA_IMAGE_GALLERY)
                {
                    mStartLeftPixelForImageGallery = mLeftPixelForImageGallery;
                }
                else if(mTouchedArea == AREA_BALLOON)
                {
                    mStartLeftPixelForBalloon = mLeftPixelForBalloon;
                }

                if(mTouchViewListener != null)
                {
                    mTouchViewListener.onControlPanelClick();
                }

                break;

            case MotionEvent.ACTION_MOVE:
                distance_from_down = Math.sqrt( (downPositionX - tmpX)*(downPositionX - tmpX) );
                //일정 역치값 이상 이동했을 경우 이동으로 인정

                if(distance_from_down > MAX_MOVEMENT_DURATION)
                {
                    mIsMoved = true;

                    int tmpLeftPixel = 0;
                    int tmpStartLeftPixel = 0;
                    int tmpNodeImageWidth = 0;
                    int tmpNumOfNodes = 0;
                    int tmpNodeMarginWidth = 0;
                    if(mTouchedArea == AREA_IMAGE_GALLERY)
                    {
                        tmpLeftPixel = mLeftPixelForImageGallery;
                        tmpStartLeftPixel = mStartLeftPixelForImageGallery;
                        tmpNodeImageWidth = mNodeImageWidthForImageGallery;
                        tmpNumOfNodes = mNumOfImageGalleryNodes;
                        tmpNodeMarginWidth = mNodeMarginWidthForImageGallery;
                    }
                    else if(mTouchedArea == AREA_BALLOON)
                    {
                        tmpLeftPixel = mLeftPixelForBalloon;
                        tmpStartLeftPixel = mStartLeftPixelForBalloon;
                        tmpNodeImageWidth = mNodeImageWidthForBalloon;
                        tmpNumOfNodes = mNumOfBalloonNodes;
                        tmpNodeMarginWidth = mNodeMarginWidthForBalloon;
                    }
                    int tmpLeft = (int)(tmpX - downPositionX);
                    if(tmpLeft >= 0)
                    {
                        if(tmpLeftPixel >= 0)
                        {
                            tmpLeftPixel = 0;
                        }
                        else
                        {
                            tmpLeftPixel = tmpStartLeftPixel + tmpLeft;
                        }
                    }
                    else
                    {
                        int totalWidthOfGraph = 0;
                        int tmpTotalWidthOfGraph = 0;
                        //int nodeWidth = drawables[0].getWidth();

                        int maxLeft = 0;
                        maxLeft = -1 * ((tmpNumOfNodes * (tmpNodeImageWidth + (tmpNodeMarginWidth * 2))) - mGraphWidth);
                        //calculate max left sliding distance for this widget

                        if(tmpLeftPixel > maxLeft)
                        {
                            if(maxLeft <= tmpLeft)
                            {
                                if(tmpLeftPixel < maxLeft)
                                {
                                    tmpLeftPixel = maxLeft;
                                }
                                else
                                {
                                    tmpLeftPixel = tmpStartLeftPixel + tmpLeft;
                                }
                            }
                        }
                    }

                    if(mTouchedArea == AREA_IMAGE_GALLERY)
                    {
                        mLeftPixelForImageGallery = tmpLeftPixel;
                        //mStartLeftPixelForImageGallery = tmpStartLeftPixel;
                        //mNodeImageWidthForImageGallery = tmpNodeImageWidth;
                        //mNumOfImageGalleryNodes = tmpNumOfNodes;
                        //mNodeMarginWidthForImageGallery = tmpNodeMarginWidth;
                    }
                    else if(mTouchedArea == AREA_BALLOON)
                    {
                        mLeftPixelForBalloon = tmpLeftPixel;
                        //mStartLeftPixelForBalloon = tmpStartLeftPixel;
                        //mNodeImageWidthForBalloon = tmpNodeImageWidth;
                        //mNumOfBalloonNodes = tmpNumOfNodes;
                        //mNodeMarginWidthForBalloon = tmpNodeMarginWidth;
                    }

                    //Log.d(TAG, String.format("left : %d", mLeftPixel));
                }
                /*
                else
                {
                    mIsMoved = false;
                }
                */
                invalidate();
                break;

            case MotionEvent.ACTION_UP:
                if(mIsMoved == false)
                {
                    distance_from_down = Math.sqrt(((downPositionX - tmpX) * (downPositionX - tmpX)) + ((downPositionY - tmpY) * (downPositionY - tmpY)));

                    if(mTouchedArea == AREA_IMAGE_GALLERY)
                    {
                        //slidePosition = getRelativePositionForImageGallery(event.getX());

                        int newIndex = (int) getRelativePositionForImageGallery(event.getX());;

                        if(mImageGalleryProperties != null)
                        {
                            if (mImageGalleryProperties[newIndex] != BalloonImageGalleryBar.NODE_OPTIONAL)
                            {
                                if (newIndex != mSelectedImageGalleryIndex)
                                {
                                    setImageGalleryIndex(newIndex, true);
                                }
                            }
                            else
                            {
                                setImageGalleryIndex(newIndex, true);
                            }
                        }
                        else
                        {
                            setImageGalleryIndex(newIndex, true);
                        }
                    }
                    else if(mTouchedArea == AREA_BALLOON)
                    {
                        //slidePosition = getRelativePositionForBalloon(event.getX());

                        //int newIndex = (int) slidePosition + 1;
                        int newIndex = (int) getRelativePositionForBalloon(event.getX());

                        if(mBalloonProperties != null)
                        {
                            if (mBalloonProperties[newIndex] != BalloonImageGalleryBar.NODE_OPTIONAL)
                            {
                                if (newIndex != mSelectedBalloonIndex)
                                {
                                    setBalloonIndex(newIndex, true);
                                }
                            }
                            else
                            {
                                setBalloonIndex(newIndex, true);
                            }
                        }
                        else
                        {
                            setBalloonIndex(newIndex, true);
                        }
                    }
                }
                else
                {
                    if(mArrays != null)
                    {
                        nodeImageLoadRunnableForImageGallery = new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                LoadAndRecycleImageForCurrentView(mArrays);
                                invalidate();
                            }
                        };
                        NodeProgressBarHandler.postDelayed(nodeImageLoadRunnableForImageGallery, 0);
                    }
                }
                downPositionX = 0;
                downPositionY = 0;
                break;

            case MotionEvent.ACTION_CANCEL:
                mIsMoved = false;

                downPositionX = 0;
                downPositionY = 0;
                break;

            default:
                break;
        }

        return true;
    }

    private float getRelativePositionForImageGallery(float x)
    {
        float position = 0;

        //int nodeWidth = drawables[0].getWidth();
        int relativeStartPos = (int)x - mLeftPixelForImageGallery;

        position = relativeStartPos / (mNodeImageWidthForImageGallery + (mNodeMarginWidthForImageGallery*2) );
        // position = x / nodeWidth;

        position = Math.max(position, 0);

        return Math.min(position, mNumOfImageGalleryNodes - 1);
    }

    private int calculateFirstNodeIndexForImageGallery()
    {
        int leftNodeCount = (mLeftPixelForImageGallery / (mNodeImageWidthForImageGallery + (mNodeMarginWidthForImageGallery * 2)));

        if(leftNodeCount < 0)
        {
            leftNodeCount = leftNodeCount * -1;
        }

        return leftNodeCount;
    }

    private float getRelativePositionForBalloon(float x)
    {
        float position = 0;

        //int nodeWidth = drawables[0].getWidth();
        int relativeStartPos = (int)x - mLeftPixelForBalloon;

        position = relativeStartPos / (mNodeImageWidthForBalloon + (mNodeMarginWidthForBalloon*2) );
        // position = x / nodeWidth;

        position = Math.max(position, 0);

        return Math.min(position, mNumOfBalloonNodes - 1);
    }

    private int calculateFirstNodeIndexForBalloon()
    {
        int leftNodeCount = (mLeftPixelForBalloon / (mNodeImageWidthForBalloon + (mNodeMarginWidthForBalloon * 2)));

        if(leftNodeCount < 0)
        {
            leftNodeCount = leftNodeCount * -1;
        }

        return leftNodeCount;
    }

    /**
     * Sets the listener to be called when the rating changes.
     *
     * @param listener The listener.
     */
    public void setOnRatingBarChangeListener(OnNodeProgressBarChangeListener listener)
    {
        mOnNodeProgressBarChangeListener = listener;
    }

    /**
     * @return The listener (may be null) that is listening for rating change
     *         events.
     */
    public OnNodeProgressBarChangeListener getOnRatingBarChangeListener()
    {
        return mOnNodeProgressBarChangeListener;
    }

    void dispatchIndexChangeFromImageGallery(boolean fromUser)
    {
        if (mOnNodeProgressBarChangeListener != null)
        {
            mOnNodeProgressBarChangeListener.onNodeProgressChanged(this, AREA_IMAGE_GALLERY, (int)getImageGalleryIndex(), fromUser);
        }
    }

    void dispatchIndexChangeFromBalloon(boolean fromUser)
    {
        if (mOnNodeProgressBarChangeListener != null)
        {
            mOnNodeProgressBarChangeListener.onNodeProgressChanged(this, AREA_BALLOON, (int)getBalloonIndex(), fromUser);
        }
    }

    int checkTouchedArea(float xp, float yp)
    {
        if(yp >= mYOffsetForBalloon)
        {
            if(yp <= mGraphHeight)
            {
                return AREA_BALLOON;
            }
        }
        else if(yp <= mYBottomOffsetForImageGallery )
        {
            if(yp >= mTopMarginForImageGallery)
            {
                return AREA_IMAGE_GALLERY;
            }
        }

        return AREA_NO;
    }

    private static Bitmap decodeSampledBitmapFromResource(String resPath, int reqWidth, int reqHeight)
    {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        //BitmapFactory.decodeResource(res, resId, options);
        BitmapFactory.decodeFile(resPath, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        //return BitmapFactory.decodeResource(res, resId, options);
        return BitmapFactory.decodeFile(resPath, options);
    }

    private static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight)
    {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth)
        {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth)
            {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }


    public void setShortTouchListener(TouchViewListener tmpListener)
    {
        mTouchViewListener = tmpListener;
    }
}
