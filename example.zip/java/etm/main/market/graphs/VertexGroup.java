package etm.main.market.graphs;

import java.util.ArrayList;
import java.util.List;

import etm.main.market.vo.ServerMapSpotData;


public class VertexGroup
{
    public static final int SPOT_WEIGHT_FALSE = 0;
    public static final int SPOT_WEIGHT_TRUE = 1;

    //public static final int SPOT_RECOMMENDED_FALSE = 0;
    //public static final int SPOT_RECOMMENDED_TRUE = 1;
    public static final int NO_RECOMMENDED_ID = -1;

    private ArrayList<Edge> neighborhood;

    private ArrayList<ServerMapSpotData> spots;

    private ArrayList<Integer> spot_weights;
    //private ArrayList<Integer> spot_recommendeds;
    private int recommended_link[] = { NO_RECOMMENDED_ID, NO_RECOMMENDED_ID};

    private boolean isVisited;

    /**
     *
     * @param tmp_spots Spot list
     */
    public VertexGroup(ArrayList<ServerMapSpotData> tmp_spots)
    {
        this.spots = tmp_spots;
        this.neighborhood = new ArrayList<Edge>();

        this.spot_weights = new ArrayList<Integer>();
        for(int x = 0 ; x < spots.size(); x++)
        {
            spot_weights.add(SPOT_WEIGHT_FALSE);
        }

        /*
        this.spot_recommendeds = new ArrayList<Integer>();
        for(int x = 0 ; x < spots.size(); x++)
        {
            spot_recommendeds.add(SPOT_RECOMMENDED_FALSE);
        }
        */

        isVisited = false;
    }

    /**
     * This method adds an Edge to the incidence neighborhood of this graph iff
     * the edge is not already present.
     *
     * @param edge The edge to add
     */
    public void addNeighbor(Edge edge){
        if(this.neighborhood.contains(edge)){
            return;
        }

        this.neighborhood.add(edge);
    }


    /**
     *
     * @param other The edge for which to search
     * @return true iff other is contained in this.neighborhood
     */
    public boolean containsNeighbor(Edge other){
        return this.neighborhood.contains(other);
    }

    /**
     *
     * @param index The index of the Edge to retrieve
     * @return Edge The Edge at the specified index in this.neighborhood
     */
    public Edge getNeighbor(int index){
        return this.neighborhood.get(index);
    }


    /**
     *
     * @param index The index of the edge to remove from this.neighborhood
     * @return Edge The removed Edge
     */
    Edge removeNeighbor(int index){
        return this.neighborhood.remove(index);
    }

    /**
     *
     * @param e The Edge to remove from this.neighborhood
     */
    public void removeNeighbor(Edge e){
        this.neighborhood.remove(e);
    }


    /**
     *
     * @return int The number of neighbors of this Vertex
     */
    public int getNeighborCount(){
        return this.neighborhood.size();
    }


    /**
     *
     * @return String The label of this Vertex
     */
    public String getIndexString()
    {
        //return this.spots.get(0).getIndex();
        //return this.label;
        String returnInt = String.valueOf(this.spots.get(0).getIndex());
        return returnInt;
    }


    /**
     *
     * @return String A String representation of this Vertex
     */
    public String toString()
    {
        String returnInt = String.valueOf(this.spots.get(0).getIndex());
        return "Vertex " + returnInt;
    }

    /**
     *
     * @return The hash code of this Vertex's label
     */
    public int hashCode()
    {
        return this.getIndexString().hashCode();
    }

    /**
     *
     * @param other The object to compare
     * @return true iff other instanceof Vertex and the two Vertex objects have the same label
     */
    public boolean equals(Object other)
    {
        if(!(other instanceof VertexGroup)){
            return false;
        }

        VertexGroup v = (VertexGroup)other;
        return this.getIndexString().equals(v.getIndexString());
    }

    /**
     *
     * @return ArrayList<Edge> A copy of this.neighborhood. Modifying the returned
     * ArrayList will not affect the neighborhood of this Vertex
     */
    public ArrayList<Edge> getNeighbors()
    {
        return new ArrayList<Edge>(this.neighborhood);
    }

    public ArrayList<ServerMapSpotData> getSpots()
    {
        return spots;
    }

    public int getSpotWeightIndex()
    {
        for(int i = 0; i < spot_weights.size(); i++)
        {
            if(spot_weights.get(i) == SPOT_WEIGHT_TRUE)
            {
                return i;
            }
        }
        return -1;
    }

    /*
    public int getSpotRecommendedIndex()
    {
        for(int i = 0; i < spot_recommendeds.size(); i++)
        {
            if(spot_recommendeds.get(i) == SPOT_RECOMMENDED_TRUE)
            {
                return i;
            }
        }
        return -1;
    }
    */

    public int[] getNextRecommendedSpotId()
    {
        return recommended_link;
    }

    public void resetSpotWeight()
    {
        for(int i = 0; i < spot_weights.size(); i++)
        {
            spot_weights.set(i, SPOT_WEIGHT_FALSE);
        }
    }

    public void setSpotWeight(int index, boolean flag)
    {
        if(index < spot_weights.size())
        {
            for(int i = 0; i < spot_weights.size(); i++)
            {
                spot_weights.set(i, SPOT_WEIGHT_FALSE);
            }

            if(flag == true)
            {
                spot_weights.set(index, SPOT_WEIGHT_TRUE);
            }
            else
            {
                spot_weights.set(index, SPOT_WEIGHT_FALSE);
            }
        }
    }

    /*
    public void setSpotRecommended(int index, boolean flag)
    {
        if(index < spot_recommendeds.size())
        {
            //for(int i = 0; i < spot_recommendeds.size(); i++)
            //{
            //    spot_recommendeds.set(i, SPOT_RECOMMENDED_FALSE);
            //}

            if(flag == true)
            {
                spot_recommendeds.set(index, SPOT_RECOMMENDED_TRUE);
            }
            else
            {
                spot_recommendeds.set(index, SPOT_RECOMMENDED_FALSE);
            }
        }
    }
    */

    public void setNextRecommendedSpotId(int from_id, int to_id)
    {
        recommended_link[0] = from_id;  //current
        recommended_link[1] = to_id;    //next
    }

    public ArrayList<Integer> getSpotsWeight()
    {
        return spot_weights;
    }

    /*
    public ArrayList<Integer> getSpotsRecommended()
    {
        return spot_recommendeds;
    }
    */

    public void setVisited(boolean flag)
    {
        isVisited = flag;
    }


    public boolean isVisited()
    {
        return isVisited;
    }
}
