package etm.main.market.graphs;

/**
 * This class models an undirected Edge in the Graph implementation.
 * An Edge contains two vertices and a weight. If no weight is
 * specified, the default is a weight of 1. This is so traversing
 * edges is assumed to be of greater distance or cost than staying
 * at the given vertex.
 *
 * This class also deviates from the expectations of the Comparable interface
 * in that a return value of 0 does not indicate that this.equals(other). The
 * equals() method only compares the vertices, while the compareTo() method
 * compares the edge weights. This provides more efficient implementation for
 * checking uniqueness of edges, as well as the fact that two edges of equal weight
 * should be considered equitably in a pathfinding or spanning tree algorithm.
 *
 * @author Michael Levet
 * @date June 09, 2015
 */

public class Edge implements Comparable<Edge>
{
    public static final int WEIGHT_FALSE = 0;
    public static final int WEIGHT_TRUE = 1;

    //public static final int RECOMMENDED_FALSE = 0;
    //public static final int RECOMMENDED_TRUE = 1;

    public static final int NO_RECOMMENDED_ID = -1;

    private VertexGroup back, front;   //one, two
    private int weight;
    //private int recommended;
    private int recommended_link[] = { NO_RECOMMENDED_ID, NO_RECOMMENDED_ID};

    /**
     *
     * @param back The first vertex in the Edge
     * @param front The second vertex in the Edge
     */
    /*
    public Edge(VertexGroup back, VertexGroup front)
    {
        this(back, front, WEIGHT_FALSE, RECOMMENDED_FALSE);
    }
    */

    /**
     *
     * @param back The first vertex in the Edge
     * @param front The second vertex of the Edge
     * @param weight The weight of this Edge
     */
    public Edge(VertexGroup back, VertexGroup front, int weight, int recommended_link_from_id, int recommended_link_to_id)
    {
        //this.back = (back.getIndexString().compareTo(front.getIndexString()) <= 0) ? back : front;
        //this.front = (this.back == back) ? front : back;

        this.back = back;
        this.front = front;
        this.weight = weight;
        this.recommended_link[0] = recommended_link_from_id;
        this.recommended_link[1] = recommended_link_to_id;
        //this.recommended = recommended;
    }

    /**
     *
     * @param current
     * @return The neighbor of current along this Edge
     */
    public VertexGroup getNeighbor(VertexGroup current)
    {
        if(!(current.equals(back) || current.equals(front)))
        {
            return null;
        }

        return (current.equals(back)) ? front : back;
    }

    /**
     *
     * @return Vertex this.one
     */
    public VertexGroup getBack(){
        return this.back;
    }   //getOne

    /**
     *
     * @return Vertex this.two
     */
    public VertexGroup getFront(){      //getTwo
        return this.front;
    }   //getTwo


    /**
     *
     * @return int The weight of this Edge
     */
    public int getWeight(){
        return this.weight;
    }


    /**
     *
     * @param weight The new weight of this Edge
     */
    public void setWeight(int weight){
        this.weight = weight;
    }


    public int[] getRecommendedLink()
    {
        return recommended_link;
    }

    /**
     * Note that the compareTo() method deviates from
     * the specifications in the Comparable interface. A
     * return value of 0 does not indicate that this.equals(other).
     * The equals() method checks the Vertex endpoints, while the
     * compareTo() is used to compare Edge weights
     *
     * @param other The Edge to compare against this
     * @return int this.weight - other.weight
     */
    public int compareTo(Edge other){
        return this.weight - other.weight;
    }

    /**
     *
     * @return String A String representation of this Edge
     */
    public String toString(){
        return "({" + back + ", " + front + "}, " + weight + ")";
    }

    /**
     *
     * @return int The hash code for this Edge
     */
    public int hashCode(){
        return (back.getIndexString() + front.getIndexString()).hashCode();
    }

    /**
     *
     * @param other The Object to compare against this
     * @return ture iff other is an Edge with the same Vertices as this
     */
    public boolean equals(Object other){
        if(!(other instanceof Edge)){
            return false;
        }

        Edge e = (Edge)other;

        return e.back.equals(this.back) && e.front.equals(this.front);
    }
}
