package etm.main.market.graphs;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class GraphSearch
{
    Queue<VertexGroup> queue = new LinkedList<VertexGroup>();
    VertexGroup startVertex;
    //ArrayList<VertexGroup> neighbours;
    Graph mGraph;

    public GraphSearch(Graph tmpGraph)
    {
        mGraph = tmpGraph;
    }

    public void setGraph(Graph tmpGraph)
    {
        mGraph = tmpGraph;
    }

    public void setStartNode(VertexGroup tmpVertex)
    {
        startVertex = tmpVertex;
        queue.add(startVertex);
        startVertex.setVisited(true);
    }

    public void resetSearch()
    {
        mGraph.resetVisited();
    }

    public VertexGroup getNext()
    {
        if(!queue.isEmpty())
        {
            VertexGroup ret = null;

            ret = queue.remove();

            ArrayList<VertexGroup> neighbours = new ArrayList<VertexGroup>();
            ArrayList<Edge> edges = ret.getNeighbors();

            for(int x = 0; x < edges.size(); x++)
            {
                if(edges.get(x).getFront() != null)
                {
                    neighbours.add(edges.get(x).getFront());
                }
            }

            for (int i = 0; i < neighbours.size(); i++)
            {
                VertexGroup n = neighbours.get(i);

                if (n != null && !n.isVisited())
                {
                    queue.add(n);
                    n.setVisited(true);
                }
            }

            return ret;
        }
        else
        {
            return null;
        }
    }

}
