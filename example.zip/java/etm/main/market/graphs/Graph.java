package etm.main.market.graphs;

import android.util.Log;

import java.util.*;

/**
 * This class models a simple, undirected graph using an
 * incidence list representation. Vertices are identified
 * uniquely by their labels, and only unique vertices are allowed.
 * At most one Edge per vertex pair is allowed in this Graph.
 *
 * Note that the Graph is designed to manage the Edges. You
 * should not attempt to manually add Edges yourself.
 *
 * @author Michael Levet
 * @date June 09, 2015
 */
public class Graph
{
    private static final String TAG = Graph.class.getSimpleName();

    private HashMap<String, VertexGroup> vertices;
    private HashMap<Integer, Edge> edges;
    private HashMap<Integer, Edge> selected_edges_buffer;

    public Graph()
    {
        this.vertices = new LinkedHashMap<String, VertexGroup>();
        this.edges = new LinkedHashMap<Integer, Edge>();
        this.selected_edges_buffer = new LinkedHashMap<Integer, Edge>();
    }

    /**
     * This constructor accepts an ArrayList<Vertex> and populates
     * this.vertices. If multiple Vertex objects have the same label,
     * then the last Vertex with the given label is used.
     *
     * @param vertices The initial Vertices to populate this Graph
     */
    public Graph(ArrayList<VertexGroup> vertices)
    {
        this.vertices = new LinkedHashMap<String, VertexGroup>();
        this.edges = new LinkedHashMap<Integer, Edge>();
        this.selected_edges_buffer = new LinkedHashMap<Integer, Edge>();

        for(VertexGroup v: vertices)
        {
            this.vertices.put(v.getIndexString(), v);
        }
    }

    public void addPathToSelectedBuffer(Edge tmpEdge)
    {
        if(selected_edges_buffer != null)
        {
            VertexGroup beforeVertex = tmpEdge.getBack();
            if(beforeVertex != null)
            {
                ArrayList<Edge> tmpEdges = tmpEdge.getBack().getNeighbors();

                for(int x = 0;  x < tmpEdges.size(); x++)
                {
                    Edge oneEdge = tmpEdges.get(x);

                    if (beforeVertex == oneEdge.getFront())
                    {
                        //prev node
                    }
                    else if (beforeVertex == oneEdge.getBack())
                    {
                        if(tmpEdge != oneEdge)
                        {
                            selected_edges_buffer.remove(oneEdge.hashCode());
                        }
                    }
                }
            }
            selected_edges_buffer.put(tmpEdge.hashCode(), tmpEdge);
        }

        return ;
    }


    public void removePathToSelectedBuffer(Edge tmpEdge)
    {
        if(selected_edges_buffer != null)
        {
            selected_edges_buffer.remove(tmpEdge.hashCode());
        }

        return ;
    }

    public void readPathFromSelectedBuffer()
    {
        if(selected_edges_buffer != null)
        {
            Iterator it = selected_edges_buffer.entrySet().iterator();
            while (it.hasNext())
            {
                Map.Entry entry = (Map.Entry) it.next();

                Integer key = (Integer) entry.getKey();
                Edge value = (Edge) entry.getValue();

                VertexGroup front = value.getFront();
                VertexGroup back = value.getBack();

                if(value != null)
                {
                    if(edges != null)
                    {
                        Iterator loop_it = edges.entrySet().iterator();
                        while (loop_it.hasNext())
                        {
                            Map.Entry loop_entry = (Map.Entry) loop_it.next();

                            Integer loop_key = (Integer) loop_entry.getKey();
                            Edge loop_value = (Edge) loop_entry.getValue();


                            VertexGroup loop_front = loop_value.getFront();
                            VertexGroup loop_back = loop_value.getBack();

                            if ((loop_front == front) && (loop_back == back))
                            {
                                loop_value.setWeight(Edge.WEIGHT_TRUE);
                                edges.put(loop_value.hashCode(), loop_value);
                                break;
                            }
                        }
                    }
                }
            }
        }

        return ;
    }

    public void resetPathWeight()
    {
        if(edges != null)
        {
            Iterator it = edges.entrySet().iterator();
            while (it.hasNext())
            {
                Map.Entry entry = (Map.Entry) it.next();

                Integer key = (Integer) entry.getKey();
                Edge value = (Edge) entry.getValue();

                if(value != null)
                {
                    value.setWeight(Edge.WEIGHT_FALSE);
                }
            }
        }

        return ;
    }

    public void printPathWeight()
    {
        if(edges != null)
        {

        }
        return ;
    }

    public void clearData()
    {
        if(vertices != null)
        {
            vertices.clear();
        }

        if(edges != null)
        {
            edges.clear();
        }
    }

    public void resetVisited()
    {
        Iterator it = vertices.entrySet().iterator();
        while (it.hasNext())
        {
            Map.Entry entry = (Map.Entry) it.next();

            String key = (String) entry.getKey();
            VertexGroup value = (VertexGroup) entry.getValue();

            value.setVisited(false);
        }
    }

    /**
     * This method adds am edge between Vertices one and two
     * of weight 1, if no Edge between these Vertices already
     * exists in the Graph.
     *
     * @param back The first vertex to add
     * @param front The second vertex to add
     * @return true iff no Edge relating one and two exists in the Graph
     */
    /*
    public boolean addEdge(VertexGroup back, VertexGroup front, int recommended)
    {
        return addEdge(back, front, Edge.WEIGHT_FALSE, recommended);
        //return addEdge(back, front, Edge.WEIGHT_FALSE, Edge.RECOMMENDED_FALSE);
    }
    */

    public boolean addEdgeWithFalseWeight(VertexGroup back, VertexGroup front, int recommended_link_from_id, int recommended_link_to_id)
    {
        return addEdge(back, front, Edge.WEIGHT_FALSE, recommended_link_from_id, recommended_link_to_id);
    };
    /**
     * Accepts two vertices and a weight, and adds the edge
     * ({one, two}, weight) iff no Edge relating one and two
     * exists in the Graph.
     *
     * @param back The first Vertex of the Edge
     * @param front The second Vertex of the Edge
     * @param weight The weight of the Edge
     * @return true iff no Edge already exists in the Graph
     */
    public boolean addEdge(VertexGroup back, VertexGroup front, int weight, int recommended_link_from_id, int recommended_link_to_id)
    {
        if(back.equals(front))
        {
            return false;
        }

        //ensures the Edge is not in the Graph
        Edge e = new Edge(back, front, weight, recommended_link_from_id, recommended_link_to_id);
        if(edges.containsKey(e.hashCode()))
        {
            return false;
        }
        //and that the Edge isn't already incident to one of the vertices
        else if(back.containsNeighbor(e) || front.containsNeighbor(e))
        {
            return false;
        }

        edges.put(e.hashCode(), e);
        back.addNeighbor(e);
        front.addNeighbor(e);

        Log.d(TAG, back.getSpots().get(0).getTitle() + " --> " + front.getSpots().get(0).getTitle());

        return true;
    }

    /**
     *
     * @param e The Edge to look up
     * @return true iff this Graph contains the Edge e
     */
    public boolean containsEdge(Edge e){
        if(e.getBack() == null || e.getFront() == null){
            return false;
        }

        return this.edges.containsKey(e.hashCode());
    }


    /**
     * This method removes the specified Edge from the Graph,
     * including as each vertex's incidence neighborhood.
     *
     * @param e The Edge to remove from the Graph
     * @return Edge The Edge removed from the Graph
     */
    public Edge removeEdge(Edge e){
        e.getBack().removeNeighbor(e);
        e.getFront().removeNeighbor(e);
        return this.edges.remove(e.hashCode());
    }

    /**
     *
     * @param vertex The Vertex to look up
     * @return true iff this Graph contains vertex
     */
    public boolean containsVertex(VertexGroup vertex)
    {
        return this.vertices.get(vertex.getIndexString()) != null;
    }

    /**
     *
     * @param label The specified Vertex label
     * @return Vertex The Vertex with the specified label
     */
    public VertexGroup getVertex(String label)
    {
        return vertices.get(label);
    }

    /**
     * This method adds a Vertex to the graph. If a Vertex with the same label
     * as the parameter exists in the Graph, the existing Vertex is overwritten
     * only if overwriteExisting is true. If the existing Vertex is overwritten,
     * the Edges incident to it are all removed from the Graph.
     *
     * @param vertex
     * @param overwriteExisting
     * @return true iff vertex was added to the Graph
     */
    public boolean addVertex(VertexGroup vertex, boolean overwriteExisting){
        VertexGroup current = this.vertices.get(vertex.getIndexString());
        if(current != null){
            if(!overwriteExisting){
                return false;
            }

            while(current.getNeighborCount() > 0){
                this.removeEdge(current.getNeighbor(0));
            }
        }


        vertices.put(vertex.getIndexString(), vertex);
        return true;
    }

    /**
     *
     * @param label The label of the Vertex to remove
     * @return Vertex The removed Vertex object
     */
    public VertexGroup removeVertex(String label){
        VertexGroup v = vertices.remove(label);

        while(v.getNeighborCount() > 0)
        {
            this.removeEdge(v.getNeighbor((0)));
        }

        return v;
    }

    /**
     *
     * @return Set<String> The unique labels of the Graph's Vertex objects
     */
    public Set<String> vertexKeys(){
        return this.vertices.keySet();
    }

    /**
     *
     * @return Set<Edge> The Edges of this graph
     */
    public Set<Edge> getEdges(){
        return new HashSet<Edge>(this.edges.values());
    }


    public int getVertexsSize()
    {
        if(vertices != null)
        {
            return vertices.size();
        }
        else
        {
            return 0;
        }
    }

    public HashMap<String, VertexGroup> getVertices()
    {
        return vertices;
    }
}
