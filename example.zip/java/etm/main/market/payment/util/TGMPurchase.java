package etm.main.market.payment.util;

import android.app.Activity;

import java.util.ArrayList;
import java.util.List;

public class TGMPurchase extends cInAppBillingHelper
{
    /* base64EncodedPublicKey should be YOUR APPLICATION'S PUBLIC KEY
     * (that you got from the Google Play developer console). This is not your
     * developer public key, it's the *app-specific* public key.
     *
     * Instead of just storing the entire literal string here embedded in the
     * program,  construct the key at runtime from pieces or
     * use bit manipulation (for example, XOR with some other string) to hide
     * the actual key.  The key itself is not secret information, but we don't
     * want to make it easy for an attacker to replace the public key with one
     * of their own and then fake messages from the server.
     */
    private static final String PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlfgtIKjL/SZB4GJe7hoPJdIc01RfJwYcqMiqpxBn7t2nmpRXRVDGNWkfcqs/ImaeXJtrXKK2VdRQOhbKRCpwt9wQ0sswOHTWFAyaGRPsekRZ83WAJItwJfZvA37U4zzLOWH0Yn1q46I3HuxQIX3kBCya4CTO/mRRqizCsGsfLfSfq3gOSjkV9jnECw0R3rMvXjgzezNTN+sewxjAkL7Bm91xiYKgyhcuEeLwYXGwtnPzGkz6P/0RT7pEY09wzI6PdlIG9Tg0ZfhaeXr9vw+hNYjjL2vcscz6f/Mshyfh6CgEJ2RrL5lJwkSn0ylTmdzMYl5Z+jtQmMZ2wRrruhj0VwIDAQAB";

    public TGMPurchase(Activity _act)
    {
        super(_act, PUBLIC_KEY);
    }

    @Override
    public void addInventory()
    {

    }

}