package etm.main.market.dialog;

import android.view.View;

import java.util.ArrayList;

import etm.main.market.graphs.VertexGroup;

public interface SearchFilterListener
{
    void onButtonClickListener(View v, String food_arr_str, String trans_arr_str, String theme_arr_str, String duration_arr_str);
}