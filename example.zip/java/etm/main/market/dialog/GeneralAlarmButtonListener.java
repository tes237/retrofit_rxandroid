package etm.main.market.dialog;

import android.view.View;

public interface GeneralAlarmButtonListener
{
    void onButtonClickListener(View v, int id, int button);
}