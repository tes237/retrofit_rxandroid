package etm.main.market.dialog;

import android.view.View;

import java.util.ArrayList;

import etm.main.market.graphs.VertexGroup;

public interface GeneralOptionListener
{
    void onListClickListener(View v, int index);
}