package etm.main.market.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import etm.main.market.R;
import etm.main.market.graphs.VertexGroup;
import etm.main.market.lists.GeneralOptionListAdapter;
import etm.main.market.lists.SpotOptionListAdapter;
import etm.main.market.lists.SpotOptionListener;


public class GeneralOptionDialog extends DialogFragment implements GeneralOptionListener, View.OnClickListener
{
    GeneralOptionListAdapter mGeneralOptionListAdapter;
    ArrayList<String> mTitleArray;
    String mTitleStr = "";

    GeneralOptionListener mGeneralOptionListener;

    public GeneralOptionDialog()
    {
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        View view = inflater.inflate(R.layout.general_list_fragment, null);

        builder.setView(view);
        AlertDialog ad = builder.create();

        TextView generalDialogTitle = (TextView) view.findViewById(R.id.general_option_title);
        generalDialogTitle.setText(mTitleStr);

        ListView generalOptionList = (ListView) view.findViewById(R.id.general_option_list);
        Button generalOptionCancelButton = (Button) view.findViewById(R.id.general_option_canel_button);

        generalOptionCancelButton.setOnClickListener(this);

        mGeneralOptionListAdapter = new GeneralOptionListAdapter(getActivity(), mTitleArray, this);
        mGeneralOptionListAdapter.setListener(this);
        generalOptionList.setAdapter(mGeneralOptionListAdapter);

        return ad;
    }

    public void setTitle(String title)
    {
        mTitleStr = title;
    }
    public void setLists(ArrayList<String> titleArray)
    {
        mTitleArray = titleArray;
    }

    public void setOptionListener(GeneralOptionListener tmpListener)
    {
        mGeneralOptionListener = tmpListener;
    }

    @Override
    public void onClick(View v)
    {
        mGeneralOptionListener.onListClickListener(v, -1);

        this.dismiss();
    }

    @Override
    public void onListClickListener(View v, int index)
    {
        mGeneralOptionListener.onListClickListener(v, index);
        this.dismiss();
    }
}

