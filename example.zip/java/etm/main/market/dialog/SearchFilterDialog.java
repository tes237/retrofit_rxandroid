package etm.main.market.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;

import etm.main.market.R;
import etm.main.market.activities.CategoryListActivity;

public class SearchFilterDialog extends DialogFragment implements View.OnClickListener
{
    private Switch glutenfree, nutfree, halal, hindu, kosher, lactoovo, pureveg, vegan, jain;
    private Switch airplane, bicycle, bus, car, monorail, motorcycle, ship, subway, train;
    private Switch adventure, culture, enterinment, healing, mystery, religious, shopping, event, sports, working;
    private Switch less_3hours, less_6hours, less_1day, less_2days, less_3days, less_1week, less_10days, less_2weeks, less_3_weeks, less_1month, less_2months, less_3months, more_3months;

    private ArrayList<String> mTitleArray;
    private String mDialogTitle;
    private int mFilterType = -1;

    private SearchFilterListener mTGSearchFilterListener;

    private String []mFoodArr = null;
    private String []mTransArr = null;
    private String []mThemeArr = null;
    private String []mDurationArr = null;

    public SearchFilterDialog()
    {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View layoutView = null;
        if(mFilterType == CategoryListActivity.THEME_TYPE)
        {
            layoutView = inflater.inflate(R.layout.filter_theme_list_fragment, null);
        }
        else if(mFilterType == CategoryListActivity.TRANSPORTATION_TYPE)
        {
            layoutView = inflater.inflate(R.layout.filter_transportation_list_fragment, null);
        }
        else if(mFilterType == CategoryListActivity.SPECIAL_MEALS_TYPE)
        {
            layoutView = inflater.inflate(R.layout.filter_meal_list_fragment, null);
        }
        else// if(mFilterType == TourGuideListActivity.DURATION_TYPE)
        {
            layoutView = inflater.inflate(R.layout.filter_duration_list_fragment, null);
        }

        builder.setView(layoutView);
        AlertDialog ad = builder.create();

        TextView titleText = (TextView) layoutView.findViewById(R.id.filter_dialog_title);
        ImageButton closeButton = (ImageButton) layoutView.findViewById(R.id.filter_canel_button);
        Button okButton = (Button) layoutView.findViewById(R.id.filter_ok_button);

        ImageView titleImage = (ImageView) layoutView.findViewById(R.id.filter_title_image);

        titleText.setText(mDialogTitle);

        if(mFilterType == CategoryListActivity.THEME_TYPE)
        {
            //private Switch adventure, culture, enterinment, healing, mystery, religious, shopping, event, sports, working;
            adventure = (Switch) layoutView.findViewById(R.id.filter_adventure_switch);
            culture = (Switch) layoutView.findViewById(R.id.filter_culture_switch);
            enterinment = (Switch) layoutView.findViewById(R.id.filter_entertainment_switch);
            healing = (Switch) layoutView.findViewById(R.id.filter_healing_switch);
            mystery = (Switch) layoutView.findViewById(R.id.filter_mystery_switch);
            religious = (Switch) layoutView.findViewById(R.id.filter_religious_switch);
            shopping = (Switch) layoutView.findViewById(R.id.filter_shopping_switch);
            event = (Switch) layoutView.findViewById(R.id.filter_event_switch);
            sports = (Switch) layoutView.findViewById(R.id.filter_sports_switch);
            working = (Switch) layoutView.findViewById(R.id.filter_working_switch);

            titleImage.setImageResource(R.drawable.theme_dialog_icon);
        }
        else if(mFilterType == CategoryListActivity.TRANSPORTATION_TYPE)
        {
            //private Switch airplane, bicycle, bus, car, monorail, motorcycle, ship, subway, train;
            airplane = (Switch) layoutView.findViewById(R.id.filter_airplane_switch);
            bicycle = (Switch) layoutView.findViewById(R.id.filter_bicycle_switch);
            bus = (Switch) layoutView.findViewById(R.id.filter_bus_switch);
            car = (Switch) layoutView.findViewById(R.id.filter_car_switch);
            monorail = (Switch) layoutView.findViewById(R.id.filter_monorail_switch);
            motorcycle = (Switch) layoutView.findViewById(R.id.filter_motorcycle_switch);
            ship = (Switch) layoutView.findViewById(R.id.filter_ship_switch);
            subway = (Switch) layoutView.findViewById(R.id.filter_subway_switch);
            train = (Switch) layoutView.findViewById(R.id.filter_train_switch);

            titleImage.setImageResource(R.drawable.transportation_dialog_icon);
        }
        else if(mFilterType == CategoryListActivity.SPECIAL_MEALS_TYPE)
        {
            //private Switch glutenfree, nutfree, halal, hindu, kosher, lactoovo, pureveg, vegan, jain;
            glutenfree = (Switch) layoutView.findViewById(R.id.filter_glutenfree_switch);
            nutfree = (Switch) layoutView.findViewById(R.id.filter_nutfree_switch);
            halal = (Switch) layoutView.findViewById(R.id.filter_halal_switch);
            hindu = (Switch) layoutView.findViewById(R.id.filter_hindu_switch);
            kosher = (Switch) layoutView.findViewById(R.id.filter_kosher_switch);
            lactoovo = (Switch) layoutView.findViewById(R.id.filter_lactoovo_switch);
            pureveg = (Switch) layoutView.findViewById(R.id.filter_pureveg_switch);
            vegan = (Switch) layoutView.findViewById(R.id.filter_vegan_switch);
            jain = (Switch) layoutView.findViewById(R.id.filter_jain_switch);

            titleImage.setImageResource(R.drawable.meal_dialog_icon);
        }
        else if(mFilterType == CategoryListActivity.DURATION_TYPE)
        {
            //private Switch less_3hours, less_6hours, less_1day, less_2days, less_3days, less_1week, less_10days,
            // less_2weeks, less_3_weeks, less_1month, less_2months, less_3months, more_3months;

            less_3hours = (Switch) layoutView.findViewById(R.id.filter_less_3hours_switch);
            less_6hours = (Switch) layoutView.findViewById(R.id.filter_less_6hours_switch);
            less_1day = (Switch) layoutView.findViewById(R.id.filter_less_1day_switch);
            less_2days = (Switch) layoutView.findViewById(R.id.filter_less_2days_switch);
            less_3days = (Switch) layoutView.findViewById(R.id.filter_less_3days_switch);
            less_1week = (Switch) layoutView.findViewById(R.id.filter_less_1week_switch);
            less_10days = (Switch) layoutView.findViewById(R.id.filter_less_10days_switch);
            less_2weeks = (Switch) layoutView.findViewById(R.id.filter_less_2weeks_switch);
            less_3_weeks = (Switch) layoutView.findViewById(R.id.filter_less_3_weeks_switch);
            less_1month = (Switch) layoutView.findViewById(R.id.filter_less_1month_switch);
            less_2months = (Switch) layoutView.findViewById(R.id.filter_less_2months_switch);
            less_3months = (Switch) layoutView.findViewById(R.id.filter_less_3months_switch);
            more_3months = (Switch) layoutView.findViewById(R.id.filter_more_3months_switch);

            titleImage.setImageResource(R.drawable.duration_dialog_icon);
        }

        closeButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                getDialog().dismiss();
            }
        });

        okButton.setOnClickListener(this);

        if(mFilterType == CategoryListActivity.THEME_TYPE)
        {
            if(mThemeArr.length == 1 && mThemeArr[0].equals(""))
            {
                set_theme_checked();
            }
            else
            {
                for(int x = 0; x < mThemeArr.length ; x++)
                {
                    String tmpTheme = mThemeArr[x];
                    if ((tmpTheme != null) && ("".equals(tmpTheme) == false))
                    {
                        //private CheckBox adventure, culture, enterinment, healing, mystery, religious, shopping, event, sports, working;
                        switch(tmpTheme)
                        {
                            case "41":
                                adventure.setChecked(true);
                                break;

                            case "44":
                                culture.setChecked(true);
                                break;

                            case "43":
                                enterinment.setChecked(true);
                                break;

                            case "34":
                                healing.setChecked(true);
                                break;

                            case "39":
                                mystery.setChecked(true);
                                break;

                            case "42":
                                religious.setChecked(true);
                                break;

                            case "37":
                                shopping.setChecked(true);
                                break;

                            case "40":
                                event.setChecked(true);
                                break;

                            case "38":
                                sports.setChecked(true);
                                break;

                            case "35":
                                working.setChecked(true);
                                break;
                            default:
                                continue;
                                //break;
                        }
                    }
                }
            }
        }
        else if(mFilterType == CategoryListActivity.TRANSPORTATION_TYPE)
        {
            if(mTransArr.length == 1 && mTransArr[0].equals(""))
            {
                set_trans_checked();
            }
            else
            {
                for(int x = 0; x < mTransArr.length ; x++)
                {
                    String tmpTrans = mTransArr[x];
                    if ((tmpTrans != null) && ("".equals(tmpTrans) == false))
                    {
                        switch(tmpTrans)
                        {
                            case "30":
                                airplane.setChecked(true);
                                break;

                            case "27":
                                bicycle.setChecked(true);
                                break;

                            case "32":
                                bus.setChecked(true);
                                break;

                            case "25":
                                car.setChecked(true);
                                break;

                            case "29":
                                monorail.setChecked(true);
                                break;

                            case "26":
                                motorcycle.setChecked(true);
                                break;

                            case "28":
                                ship.setChecked(true);
                                break;

                            case "31":
                                subway.setChecked(true);
                                break;

                            case "33":
                                train.setChecked(true);
                                break;

                            default:
                                continue;
                                //break;
                        }
                    }
                }
            }
        }
        else if(mFilterType == CategoryListActivity.SPECIAL_MEALS_TYPE)
        {
            if(mFoodArr.length == 1 && mFoodArr[0].equals(""))
            {
                set_food_checked();
            }
            else
            {
                set_food_checked(); //food filter is exculsive filter, so first turns on every filters and exclude one by on

                for(int x = 0; x < mFoodArr.length ; x++)
                {
                    String tmpFood = mFoodArr[x];
                    if ((tmpFood != null) && ("".equals(tmpFood) == false))
                    {
                        switch(tmpFood)
                        {
                            case "18":
                                glutenfree.setChecked(false);
                                break;

                            case "17":
                                nutfree.setChecked(false);
                                break;

                            case "21":
                                halal.setChecked(false);
                                break;

                            case "20":
                                hindu.setChecked(false);
                                break;

                            case "19":
                                kosher.setChecked(false);
                                break;

                            case "24":
                                lactoovo.setChecked(false);
                                break;

                            case "23":
                                pureveg.setChecked(false);
                                break;

                            case "22":
                                vegan.setChecked(false);
                                break;

                            case "45":
                                jain.setChecked(false);
                                break;

                            default:
                                continue;
                                //break;
                        }
                    }
                }
            }
        }
        else if(mFilterType == CategoryListActivity.DURATION_TYPE)
        {
            if(mDurationArr.length == 1 && mDurationArr[0].equals(""))
            {
                set_duration_checked();
            }
            else
            {
                for(int x = 0; x < mDurationArr.length ; x++)
                {
                    String tmpDuration = mDurationArr[x];
                    if ((tmpDuration != null) && ("".equals(tmpDuration) == false))
                    {
                        switch (tmpDuration)
                        {
                            case "16":
                                less_3hours.setChecked(true);
                                break;

                            case "15":
                                less_6hours.setChecked(true);
                                break;

                            case "14":
                                less_1day.setChecked(true);
                                break;

                            case "13":
                                less_2days.setChecked(true);
                                break;

                            case "12":
                                less_3days.setChecked(true);
                                break;

                            case "11":
                                less_1week.setChecked(true);
                                break;

                            case "10":
                                less_10days.setChecked(true);
                                break;

                            case "9":
                                less_2weeks.setChecked(true);
                                break;

                            case "8":
                                less_3_weeks.setChecked(true);
                                break;

                            case "7":
                                less_1month.setChecked(true);
                                break;

                            case "6":
                                less_2months.setChecked(true);
                                break;

                            case "5":
                                less_3months.setChecked(true);
                                break;

                            case "4":
                                more_3months.setText(getString(R.string.more_than_3_months));
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }

        return ad;
    }

    public void setTitle(String titleStr)
    {
        mDialogTitle = titleStr;
    }

    public void setLists(ArrayList<String> titleArray)
    {
        mTitleArray = titleArray;
    }

    public void setOptionListener(SearchFilterListener tmpListener)
    {
        mTGSearchFilterListener = tmpListener;
    }

    public void setType(int type)
    {
        mFilterType = type;
    }

    public void setFilter(String foodArr, String transArr, String themeArr, String durationArr)
    {
        mFoodArr = foodArr.split(",");
        mTransArr = transArr.split(",");
        mThemeArr = themeArr.split(",");
        mDurationArr = durationArr.split(",");
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.filter_canel_button)
        {
            this.dismiss();
        }
        else if(v.getId() == R.id.filter_ok_button)
        {
            if(mTGSearchFilterListener == null)
            {
                return;
            }

            String food_filter_str = "";
            ArrayList<String> food_filter = new ArrayList<String>();
            if(mFilterType == CategoryListActivity.SPECIAL_MEALS_TYPE)
            {
                if(glutenfree.isChecked() == false)
                {
                    food_filter.add("18");
                }
                if(nutfree.isChecked() == false)
                {
                    food_filter.add("17");
                }
                if(halal.isChecked() == false)
                {
                    food_filter.add("21");
                }
                if(hindu.isChecked() == false)
                {
                    food_filter.add("20");
                }
                if(kosher.isChecked() == false)
                {
                    food_filter.add("19");
                }
                if(lactoovo.isChecked() == false)
                {
                    food_filter.add("24");
                }
                if(pureveg.isChecked() == false)
                {
                    food_filter.add("23");
                }
                if(vegan.isChecked() == false)
                {
                    food_filter.add("22");
                }
                if(jain.isChecked() == false)
                {
                    food_filter.add("45");
                }

                for(int i = 0; i < food_filter.size(); i++)
                {
                    if(food_filter_str.equals("") == false)
                    {
                        food_filter_str += ",";
                    }
                    String tmp_filter = food_filter.get(i);

                    food_filter_str += tmp_filter;
                }
            }


            String trans_filter_str = "";
            ArrayList<String> trans_filter = new ArrayList<String>();
            if(mFilterType == CategoryListActivity.TRANSPORTATION_TYPE)
            {
                if(airplane.isChecked())
                {
                    trans_filter.add("30");
                }
                if(bicycle.isChecked())
                {
                    trans_filter.add("27");
                }
                if(bus.isChecked())
                {
                    trans_filter.add("32");
                }
                if(car.isChecked())
                {
                    trans_filter.add("25");
                }
                if(monorail.isChecked())
                {
                    trans_filter.add("29");
                }
                if(motorcycle.isChecked())
                {
                    trans_filter.add("26");
                }
                if(ship.isChecked())
                {
                    trans_filter.add("28");
                }
                if(subway.isChecked())
                {
                    trans_filter.add("31");
                }
                if(train.isChecked())
                {
                    trans_filter.add("33");
                }

                for(int i = 0; i < trans_filter.size(); i++)
                {
                    if(trans_filter_str.equals("") == false)
                    {
                        trans_filter_str += ",";
                    }
                    String tmp_filter = trans_filter.get(i);

                    trans_filter_str += tmp_filter;
                }
            }

            String theme_filter_str = "";
            ArrayList<String> theme_filter = new ArrayList<String>();
            if(mFilterType == CategoryListActivity.THEME_TYPE)
            {
                if(adventure.isChecked())
                {
                    theme_filter.add("41");
                }

                if(culture.isChecked())
                {
                    theme_filter.add("44");
                }

                if(enterinment.isChecked())
                {
                    theme_filter.add("43");
                }

                if(healing.isChecked())
                {
                    theme_filter.add("34");
                }

                if(mystery.isChecked())
                {
                    theme_filter.add("39");
                }

                if(religious.isChecked())
                {
                    theme_filter.add("42");
                }

                if(shopping.isChecked())
                {
                    theme_filter.add("37");
                }

                if(event.isChecked())
                {
                    theme_filter.add("40");
                }

                if(sports.isChecked())
                {
                    theme_filter.add("38");
                }

                if(working.isChecked())
                {
                    theme_filter.add("35");
                }

                for(int i = 0; i < theme_filter.size(); i++)
                {
                    if(theme_filter_str.equals("") == false)
                    {
                        theme_filter_str += ",";
                    }
                    String tmp_filter = theme_filter.get(i);

                    theme_filter_str += tmp_filter;
                }
            }

            String duration_filter_str = "";
            ArrayList<String> duration_filter = new ArrayList<String>();
            if(mFilterType == CategoryListActivity.DURATION_TYPE)
            {
                if(less_3hours.isChecked())
                {
                    duration_filter.add("16");
                }
                if(less_6hours.isChecked())
                {
                    duration_filter.add("15");
                }
                if(less_1day.isChecked())
                {
                    duration_filter.add("14");
                }
                if(less_2days.isChecked())
                {
                    duration_filter.add("13");
                }
                if(less_3days.isChecked())
                {
                    duration_filter.add("12");
                }
                if(less_1week.isChecked())
                {
                    duration_filter.add("11");
                }
                if(less_10days.isChecked())
                {
                    duration_filter.add("10");
                }
                if(less_2weeks.isChecked())
                {
                    duration_filter.add("9");
                }
                if(less_3_weeks.isChecked())
                {
                    duration_filter.add("8");
                }
                if(less_1month.isChecked())
                {
                    duration_filter.add("7");
                }
                if(less_2months.isChecked())
                {
                    duration_filter.add("6");
                }
                if(less_3months.isChecked())
                {
                    duration_filter.add("5");
                }
                if(more_3months.isChecked())
                {
                    duration_filter.add("4");
                }

                for(int i = 0; i < duration_filter.size(); i++)
                {
                    if(duration_filter_str.equals("") == false)
                    {
                        duration_filter_str += ",";
                    }
                    String tmp_filter = duration_filter.get(i);

                    duration_filter_str += tmp_filter;
                }
            }

            mTGSearchFilterListener.onButtonClickListener(v, food_filter_str, trans_filter_str, theme_filter_str, duration_filter_str);
        }
    }

    public void set_theme_checked()
    {
        adventure.setChecked(true);
        culture.setChecked(true);
        enterinment.setChecked(true);
        healing.setChecked(true);
        mystery.setChecked(true);
        religious.setChecked(true);
        shopping.setChecked(true);
        event.setChecked(true);
        sports.setChecked(true);
        working.setChecked(true);
    }

    public void set_trans_checked()
    {
        airplane.setChecked(true);
        bicycle.setChecked(true);
        bus.setChecked(true);
        car.setChecked(true);
        monorail.setChecked(true);
        motorcycle.setChecked(true);
        ship.setChecked(true);
        subway.setChecked(true);
        train.setChecked(true);
    }

    public void set_food_checked()
    {
        glutenfree.setChecked(true);
        nutfree.setChecked(true);
        halal.setChecked(true);
        hindu.setChecked(true);
        kosher.setChecked(true);
        lactoovo.setChecked(true);
        pureveg.setChecked(true);
        vegan.setChecked(true);
        jain.setChecked(true);
    }

    public void set_duration_checked()
    {
        less_3hours.setChecked(true);
        less_6hours.setChecked(true);
        less_1day.setChecked(true);
        less_2days.setChecked(true);
        less_3days.setChecked(true);
        less_1week.setChecked(true);
        less_10days.setChecked(true);
        less_2weeks.setChecked(true);
        less_3_weeks.setChecked(true);
        less_1month.setChecked(true);
        less_2months.setChecked(true);
        less_3months.setChecked(true);
        more_3months.setChecked(true);
    }

}

