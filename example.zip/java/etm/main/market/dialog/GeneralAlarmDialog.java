package etm.main.market.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import etm.main.market.R;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class GeneralAlarmDialog extends DialogFragment implements View.OnClickListener
{
    public static final int GENERAL_TYPE_OK_ONLY = 1;
    public static final int GENERAL_TYPE_OK_CANCEL = 2;

    public static final int OK_BUTTON = 1;
    public static final int CANCEL_BUTTON = 2;

    int mGeneralId;
    String mGeneralTitleText;
    String mGeneralMessageText;

    GeneralAlarmButtonListener mGeneralAlarmButtonListener;

    public GeneralAlarmDialog()
    {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity() /*, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen*/);
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View view = inflater.inflate(R.layout.general_alarm_dialog, null);

        builder.setView(view);

        AlertDialog adialog = builder.create();

        ScalableLayout scaleable_layout = (ScalableLayout) view.findViewById(R.id.scaleable_dialog_background);
        scaleable_layout.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        //scaleable_layout.setBackgroundColor(0);

        TextView dialogTitle = (TextView) view.findViewById(R.id.general_alarm_title_text);
        dialogTitle.setText(mGeneralTitleText);

        TextView dialogMessage = (TextView) view.findViewById(R.id.general_alarm_message_text);
        dialogMessage.setText(mGeneralMessageText);

        TextView OkOnlyButton = (TextView) view.findViewById(R.id.general_ok_only_button);
        TextView OkButton = (TextView) view.findViewById(R.id.general_ok_button);
        TextView CancelButton = (TextView) view.findViewById(R.id.general_cancel_button);

        ImageView CancelImage = (ImageView) view.findViewById(R.id.general_alarm_close_image);

        OkButton.setOnClickListener(this);
        CancelButton.setOnClickListener(this);
        OkOnlyButton.setOnClickListener(this);
        CancelImage.setOnClickListener(this);

        if(mGeneralId == GENERAL_TYPE_OK_ONLY)
        {
            OkButton.setVisibility(View.GONE);
            CancelButton.setVisibility(View.GONE);
        }
        else //if(mGeneralId == GENERAL_TYPE_OK_CANCEL)
        {
            OkOnlyButton.setVisibility(View.GONE);
        }

        return adialog;
    }

    public void setId(int tmpId)
    {
        mGeneralId = tmpId;
    }

    public void setTitleText(String tmpText)
    {
        mGeneralTitleText = tmpText;
    }

    public void setMessageText(String tmpText)
    {
        mGeneralMessageText = tmpText;
    }

    public void setButtonListener(GeneralAlarmButtonListener tmpListener)
    {
        mGeneralAlarmButtonListener = tmpListener;
    }

    @Override
    public void onClick(View v)
    {
        if(mGeneralAlarmButtonListener != null)
        {
            if(v.getId() == R.id.general_ok_only_button)
            {
                mGeneralAlarmButtonListener.onButtonClickListener(v, mGeneralId, OK_BUTTON);
            }
            else if(v.getId() == R.id.general_ok_button)
            {
                mGeneralAlarmButtonListener.onButtonClickListener(v, mGeneralId, OK_BUTTON);
            }
            else if(v.getId() == R.id.general_cancel_button)
            {
                mGeneralAlarmButtonListener.onButtonClickListener(v, mGeneralId, CANCEL_BUTTON);
            }
            else if(v.getId() == R.id.general_alarm_close_image)
            {
                mGeneralAlarmButtonListener.onButtonClickListener(v, mGeneralId, CANCEL_BUTTON);
            }
        }

        this.dismiss();
    }
}

