package etm.main.market.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import etm.main.market.R;
import etm.main.market.graphs.VertexGroup;
import etm.main.market.lists.SpotOptionListAdapter;
import etm.main.market.lists.SpotOptionListener;
import etm.main.market.lists.LanguageOptionListAdapter;

public class LanguageOptionDialog extends DialogFragment implements LanguageOptionListener
{
    LanguageOptionListAdapter mTGLanguageOptionListAdapter;
    ArrayList<String> mTitleArray;
    String mDialogTitle;

    LanguageOptionListener mTGLanguageOptionListener;

    GeneralAlarmDialog mGeneralAlarmDialog = null;
    int mSelectedIndex = -1;

    public LanguageOptionDialog()
    {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View view = inflater.inflate(R.layout.language_list_fragment, null);

        builder.setView(view);
        AlertDialog ad = builder.create();

        ListView languageOptionList = (ListView) view.findViewById(R.id.language_option_list);

        TextView languageText = (TextView) view.findViewById(R.id.language_option_title);
        Button selectButton = (Button) view.findViewById(R.id.language_option_button);

        selectButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(mSelectedIndex == -1)
                {
                    showGeneralPopup(getString(R.string.error_title), getString(R.string.language_select_title));
                    return;
                }

                mTGLanguageOptionListener.onListClickListener(null, mSelectedIndex);
                getDialog().dismiss();
            }
        });

        languageText.setText(mDialogTitle);

        mTGLanguageOptionListAdapter = new LanguageOptionListAdapter(getActivity(), mTitleArray, this);
        mTGLanguageOptionListAdapter.setListener(this);
        languageOptionList.setAdapter(mTGLanguageOptionListAdapter);

        return ad;
    }

    public void setTitle(String titleStr)
    {
        mDialogTitle = titleStr;
    }

    public void setLists(ArrayList<String> titleArray)
    {
        mTitleArray = titleArray;
    }

    public void setOptionListener(LanguageOptionListener tmpListener)
    {
        mTGLanguageOptionListener = tmpListener;
    }

    @Override
    public void onListClickListener(View v, int index)
    {
        mSelectedIndex = index;
        mTGLanguageOptionListAdapter.notifyDataSetChanged();
        //mTGLanguageOptionListener.onListClickListener(v, index);
        //this.dismiss();
    }


    private void showGeneralPopup(String title, String message)
    {
        FragmentManager fm = getFragmentManager();
        if(mGeneralAlarmDialog != null)
        {
            mGeneralAlarmDialog.dismiss();
            mGeneralAlarmDialog = null;
        }
        mGeneralAlarmDialog = new GeneralAlarmDialog();
        mGeneralAlarmDialog.setTitleText(title);
        mGeneralAlarmDialog.setMessageText(message);
        mGeneralAlarmDialog.setId(GeneralAlarmDialog.GENERAL_TYPE_OK_ONLY);
        mGeneralAlarmDialog.setButtonListener(new GeneralAlarmButtonListener()
        {
            @Override
            public void onButtonClickListener(View v, int id, int button)
            {

            }
        });
        mGeneralAlarmDialog.show(fm, "tag");
        return;
    }
}

