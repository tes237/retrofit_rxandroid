package etm.main.market.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import etm.main.market.R;
import etm.main.market.common.CircleTransformation;
import etm.main.market.graphs.VertexGroup;
import etm.main.market.lists.SpotOptionListAdapter;
import etm.main.market.lists.SpotOptionListener;


public class SpotOptionDialog extends DialogFragment implements SpotOptionListener, View.OnClickListener
{
    SpotOptionListAdapter mSpotOptionListAdapter;
    ArrayList<String> mTitleArray;
    ArrayList<Integer> mRecommendationArray;
    ArrayList<String> mPathArray;
    ArrayList<VertexGroup> mVerticesArray;
    ArrayList<Integer> mSpotIndex;

    int mFromIndex;

    SpotOptionListener mSpotOptionListener;
    String mSkuStr;

    public SpotOptionDialog()
    {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View view = inflater.inflate(R.layout.spot_list_fragment, null);

        builder.setView(view);
        AlertDialog ad = builder.create();

        ListView spotOptionList = (ListView) view.findViewById(R.id.spot_option_list);
        ImageView spotOptionCancelButton = (ImageView) view.findViewById(R.id.spot_option_canel_button);
        ImageView spot_image = (ImageView) view.findViewById(R.id.spot_option_icon);

        spotOptionCancelButton.setOnClickListener(this);

        mSpotOptionListAdapter = new SpotOptionListAdapter(getActivity(), mSkuStr, mTitleArray, mRecommendationArray, mPathArray, mFromIndex, mVerticesArray, mSpotIndex, this);
        mSpotOptionListAdapter.setListener(this);
        spotOptionList.setAdapter(mSpotOptionListAdapter);

        return ad;
    }

    public void setLists(String tmpSku, ArrayList<String> titleArray, ArrayList<Integer> recommendationArray, ArrayList<String> pathArray, ArrayList<VertexGroup> verticesArray, ArrayList<Integer> spotIndexArray)
    {
        mSkuStr = tmpSku;
        mTitleArray = titleArray;
        mRecommendationArray = recommendationArray;
        mPathArray = pathArray;
        mVerticesArray = verticesArray;
        mSpotIndex = spotIndexArray;
    }

    public void setOptionListener(SpotOptionListener tmpListener)
    {
        mSpotOptionListener = tmpListener;
    }

    @Override
    public void onClick(View v)
    {
        mSpotOptionListener.onListClickListener(v, -1, -1, null, -1);

        this.dismiss();
    }

    public void setFromNode(int from_index)
    {
        this.mFromIndex = from_index;
    }

    @Override
    public void onListClickListener(View v, int index, int fromIndex, VertexGroup vertex, int spotIndex)
    {
        mSpotOptionListener.onListClickListener(v, index, fromIndex, vertex, spotIndex);
        this.dismiss();
    }
}

