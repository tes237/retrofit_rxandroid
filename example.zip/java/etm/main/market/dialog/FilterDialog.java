package etm.main.market.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;

import etm.main.market.R;
import etm.main.market.widgets.scalableLayout.ScalableLayout;

public class FilterDialog extends DialogFragment implements View.OnClickListener
{
    public static final int GENERAL_TYPE_OK_ONLY = 1;
    public static final int GENERAL_TYPE_OK_CANCEL = 2;

    public static final int OK_BUTTON = 1;
    public static final int CANCEL_BUTTON = 2;

    int mGeneralId;
    String mGeneralText;

    private CheckBox glutenfree, nutfree, halal, hindu, kosher, lactoovo, pureveg, vegan, jain;
    private CheckBox airplane, bicycle, bus, car, monorail, motorcycle, ship, subway, train;
    private CheckBox adventure, culture, enterinment, healing, mystery, religious, shopping, event, sports, working;
    private CheckBox less_3hours, less_6hours, less_1day, less_2days, less_3days, less_1week, less_10days, less_2weeks, less_3_weeks, less_1month, less_2months, less_3months, more_3months;
    private RadioButton theme_all, theme_each, trans_all, trans_each, food_all, food_each, duration_all, duration_each;

    private String []mFoodArr = null;
    private String []mTransArr = null;
    private String []mThemeArr = null;
    private String []mDurationArr = null;

    FilterButtonListener mFilterButtonListener;

    public FilterDialog()
    {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity() /*, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen*/);
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View view = inflater.inflate(R.layout.filter_dialog, null);

        builder.setView(view);

        AlertDialog adialog = builder.create();

        ScalableLayout scaleable_layout = (ScalableLayout) view.findViewById(R.id.scaleable_dialog_background);
        scaleable_layout.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        //scaleable_layout.setBackgroundColor(0);

        /*
        TextView spotOptionCancelButton = (TextView) view.findViewById(R.id.general_alarm_text);
        spotOptionCancelButton.setText(mGeneralText);
        */

        theme_all = (RadioButton) view.findViewById(R.id.theme_all);
        theme_each = (RadioButton) view.findViewById(R.id.theme_each);
        trans_all = (RadioButton) view.findViewById(R.id.trans_all);
        trans_each = (RadioButton) view.findViewById(R.id.trans_each);
        food_all = (RadioButton) view.findViewById(R.id.food_all);
        food_each = (RadioButton) view.findViewById(R.id.food_each);
        duration_all = (RadioButton) view.findViewById(R.id.duration_all);
        duration_each = (RadioButton) view.findViewById(R.id.duration_each);

        glutenfree = (CheckBox) view.findViewById(R.id.glutenfree_check);
        nutfree = (CheckBox) view.findViewById(R.id.nutfree_check);
        halal = (CheckBox) view.findViewById(R.id.halal_check);
        hindu = (CheckBox) view.findViewById(R.id.hindu_check);
        kosher = (CheckBox) view.findViewById(R.id.kosher_check);
        lactoovo = (CheckBox) view.findViewById(R.id.lactoovo_check);
        pureveg = (CheckBox) view.findViewById(R.id.pureveg_check);
        vegan = (CheckBox) view.findViewById(R.id.vegan_check);
        jain = (CheckBox) view.findViewById(R.id.jain_check);

        airplane = (CheckBox) view.findViewById(R.id.airplane_check);
        bicycle = (CheckBox) view.findViewById(R.id.bicycle_check);
        bus = (CheckBox) view.findViewById(R.id.bus_check);
        car = (CheckBox) view.findViewById(R.id.car_check);
        monorail = (CheckBox) view.findViewById(R.id.monorail_check);
        motorcycle = (CheckBox) view.findViewById(R.id.motorcycle_check);
        ship = (CheckBox) view.findViewById(R.id.ship_check);
        subway = (CheckBox) view.findViewById(R.id.subway_check);
        train = (CheckBox) view.findViewById(R.id.train_check);

        adventure = (CheckBox) view.findViewById(R.id.adventure_check);
        culture = (CheckBox) view.findViewById(R.id.culture_check);
        enterinment = (CheckBox) view.findViewById(R.id.entertainment_check);
        healing = (CheckBox) view.findViewById(R.id.healing_check);
        mystery = (CheckBox) view.findViewById(R.id.mystery_check);
        religious = (CheckBox) view.findViewById(R.id.religious_check);
        shopping = (CheckBox) view.findViewById(R.id.shopping_check);
        event = (CheckBox) view.findViewById(R.id.event_check);
        sports = (CheckBox) view.findViewById(R.id.sports_check);
        working = (CheckBox) view.findViewById(R.id.working_check);

        less_3hours = (CheckBox) view.findViewById(R.id.less_than_3_hours_check);
        less_6hours = (CheckBox) view.findViewById(R.id.less_than_6_hours);
        less_1day = (CheckBox) view.findViewById(R.id.less_than_1_day);
        less_2days = (CheckBox) view.findViewById(R.id.less_than_2_days);
        less_3days = (CheckBox) view.findViewById(R.id.less_than_3_days);
        less_1week = (CheckBox) view.findViewById(R.id.less_than_1_week);
        less_10days = (CheckBox) view.findViewById(R.id.less_than_10_days);
        less_2weeks = (CheckBox) view.findViewById(R.id.less_than_2_weeks);
        less_3_weeks = (CheckBox) view.findViewById(R.id.less_than_3_weeks);
        less_1month = (CheckBox) view.findViewById(R.id.less_than_1_month);
        less_2months = (CheckBox) view.findViewById(R.id.less_than_2_months);
        less_3months = (CheckBox) view.findViewById(R.id.less_than_3_months);
        more_3months = (CheckBox) view.findViewById(R.id.more_than_3_months);

        TextView OkOnlyButton = (TextView) view.findViewById(R.id.general_ok_only_button);
        TextView OkButton = (TextView) view.findViewById(R.id.general_ok_button);
        TextView CancelButton = (TextView) view.findViewById(R.id.general_cancel_button);

        //private String []mFoodArr = null;
        //private String []mTransArr = null;
        //private String []mThemeArr = null;
        //private String []mDurationArr = null;


        theme_all.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                theme_each.setChecked(false);
                set_theme_invisible();
            }
        });
        theme_each.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                theme_all.setChecked(false);
                set_theme_visible();
            }
        });

        trans_all.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                set_trans_invisible();
                trans_each.setChecked(false);
            }
        });
        trans_each.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                set_trans_visible();
                trans_all.setChecked(false);
            }
        });


        food_all.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                set_food_invisible();
                food_each.setChecked(false);
            }
        });
        food_each.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                set_food_visible();
                food_all.setChecked(false);
            }
        });


        duration_all.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                set_duration_invisible();
                duration_each.setChecked(false);
            }
        });
        duration_each.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                set_duration_visible();
                duration_all.setChecked(false);
            }
        });

        if(mThemeArr.length == 1 && mThemeArr[0].equals(""))
        {
            theme_all.setChecked(true);
            theme_each.setChecked(false);
            set_theme_invisible();
        }
        else
        {
            theme_all.setChecked(false);
            theme_each.setChecked(true);

            for(int x = 0; x < mThemeArr.length ; x++)
            {
                String tmpTheme = mThemeArr[x];
                if ((tmpTheme != null) && ("".equals(tmpTheme) == false))
                {
                    //private CheckBox adventure, culture, enterinment, healing, mystery, religious, shopping, event, sports, working;
                    switch(tmpTheme)
                    {
                        case "41":
                            adventure.setChecked(true);
                            break;

                        case "44":
                            culture.setChecked(true);
                            break;

                        case "43":
                            enterinment.setChecked(true);
                            break;

                        case "34":
                            healing.setChecked(true);
                            break;

                        case "39":
                            mystery.setChecked(true);
                            break;

                        case "42":
                            religious.setChecked(true);
                            break;

                        case "37":
                            shopping.setChecked(true);
                            break;

                        case "40":
                            event.setChecked(true);
                            break;

                        case "38":
                            sports.setChecked(true);
                            break;

                        case "35":
                            working.setChecked(true);
                            break;
                        default:
                            continue;
                            //break;
                    }
                }
            }
        }
        if(mTransArr.length == 1 && mTransArr[0].equals(""))
        {
            trans_all.setChecked(true);
            trans_each.setChecked(false);
            set_trans_invisible();
        }
        else
        {
            trans_all.setChecked(false);
            trans_each.setChecked(true);

            for(int x = 0; x < mTransArr.length ; x++)
            {
                String tmpTrans = mTransArr[x];
                if ((tmpTrans != null) && ("".equals(tmpTrans) == false))
                {
                    switch(tmpTrans)
                    {
                        case "30":
                            airplane.setChecked(true);
                            break;

                        case "27":
                            bicycle.setChecked(true);
                            break;

                        case "32":
                            bus.setChecked(true);
                            break;

                        case "25":
                            car.setChecked(true);
                            break;

                        case "29":
                            monorail.setChecked(true);
                            break;

                        case "26":
                            motorcycle.setChecked(true);
                            break;

                        case "28":
                            ship.setChecked(true);
                            break;

                        case "31":
                            subway.setChecked(true);
                            break;

                        case "33":
                            train.setChecked(true);
                            break;

                        default:
                            continue;
                            //break;
                    }
                }
            }
        }

        if(mFoodArr.length == 1 && mFoodArr[0].equals(""))
        {
            food_all.setChecked(true);
            food_each.setChecked(false);
            set_food_invisible();
        }
        else
        {
            food_all.setChecked(false);
            food_each.setChecked(true);

            for(int x = 0; x < mFoodArr.length ; x++)
            {
                String tmpFood = mFoodArr[x];
                if ((tmpFood != null) && ("".equals(tmpFood) == false))
                {
                    switch(tmpFood)
                    {
                        case "18":
                            glutenfree.setChecked(true);
                            break;

                        case "17":
                            nutfree.setChecked(true);
                            break;

                        case "21":
                            halal.setChecked(true);
                            break;

                        case "20":
                            hindu.setChecked(true);
                            break;

                        case "19":
                            kosher.setChecked(true);
                            break;

                        case "24":
                            lactoovo.setChecked(true);
                            break;

                        case "23":
                            pureveg.setChecked(true);
                            break;

                        case "22":
                            vegan.setChecked(true);
                            break;

                        case "45":
                            jain.setChecked(true);
                            break;

                        default:
                            continue;
                            //break;
                    }
                }
            }
        }

        if(mDurationArr.length == 1 && mDurationArr[0].equals(""))
        {
            duration_all.setChecked(true);
            duration_each.setChecked(false);
            set_duration_invisible();
        }
        else
        {
            duration_all.setChecked(false);
            duration_each.setChecked(true);

            for(int x = 0; x < mDurationArr.length ; x++)
            {
                String tmpDuration = mDurationArr[x];
                if ((tmpDuration != null) && ("".equals(tmpDuration) == false))
                {
                    switch (tmpDuration)
                    {
                        case "16":
                            less_3hours.setChecked(true);
                            break;

                        case "15":
                            less_6hours.setChecked(true);
                            break;

                        case "14":
                            less_1day.setChecked(true);
                            break;

                        case "13":
                            less_2days.setChecked(true);
                            break;

                        case "12":
                            less_3days.setChecked(true);
                            break;

                        case "11":
                            less_1week.setChecked(true);
                            break;

                        case "10":
                            less_10days.setChecked(true);
                            break;

                        case "9":
                            less_2weeks.setChecked(true);
                            break;

                        case "8":
                            less_3_weeks.setChecked(true);
                            break;

                        case "7":
                            less_1month.setChecked(true);
                            break;

                        case "6":
                            less_2months.setChecked(true);
                            break;

                        case "5":
                            less_3months.setChecked(true);
                            break;

                        case "4":
                            more_3months.setText(getString(R.string.more_than_3_months));
                            break;
                        default:
                            break;
                    }
                }
            }

        }


        OkButton.setOnClickListener(this);
        CancelButton.setOnClickListener(this);
        OkOnlyButton.setOnClickListener(this);

        if(mGeneralId == GENERAL_TYPE_OK_ONLY)
        {
            OkButton.setVisibility(View.GONE);
            CancelButton.setVisibility(View.GONE);
        }
        else //if(mGeneralId == GENERAL_TYPE_OK_CANCEL)
        {
            OkOnlyButton.setVisibility(View.GONE);
        }

        return adialog;
    }

    public void set_theme_invisible()
    {
        adventure.setVisibility(View.INVISIBLE);
        culture.setVisibility(View.INVISIBLE);
        enterinment.setVisibility(View.INVISIBLE);
        healing.setVisibility(View.INVISIBLE);
        mystery.setVisibility(View.INVISIBLE);
        religious.setVisibility(View.INVISIBLE);
        shopping.setVisibility(View.INVISIBLE);
        event.setVisibility(View.INVISIBLE);
        sports.setVisibility(View.INVISIBLE);
        working.setVisibility(View.INVISIBLE);
    }

    public void set_theme_visible()
    {
        adventure.setVisibility(View.VISIBLE);
        culture.setVisibility(View.VISIBLE);
        enterinment.setVisibility(View.VISIBLE);
        healing.setVisibility(View.VISIBLE);
        mystery.setVisibility(View.VISIBLE);
        religious.setVisibility(View.VISIBLE);
        shopping.setVisibility(View.VISIBLE);
        event.setVisibility(View.VISIBLE);
        sports.setVisibility(View.VISIBLE);
        working.setVisibility(View.VISIBLE);
    }

    public void set_trans_visible()
    {
        airplane.setVisibility(View.VISIBLE);
        bicycle.setVisibility(View.VISIBLE);
        bus.setVisibility(View.VISIBLE);
        car.setVisibility(View.VISIBLE);
        monorail.setVisibility(View.VISIBLE);
        motorcycle.setVisibility(View.VISIBLE);
        ship.setVisibility(View.VISIBLE);
        subway.setVisibility(View.VISIBLE);
        train.setVisibility(View.VISIBLE);
    }

    public void set_trans_invisible()
    {
        airplane.setVisibility(View.INVISIBLE);
        bicycle.setVisibility(View.INVISIBLE);
        bus.setVisibility(View.INVISIBLE);
        car.setVisibility(View.INVISIBLE);
        monorail.setVisibility(View.INVISIBLE);
        motorcycle.setVisibility(View.INVISIBLE);
        ship.setVisibility(View.INVISIBLE);
        subway.setVisibility(View.INVISIBLE);
        train.setVisibility(View.INVISIBLE);
    }

    public void set_food_invisible()
    {
        glutenfree.setVisibility(View.INVISIBLE);
        nutfree.setVisibility(View.INVISIBLE);
        halal.setVisibility(View.INVISIBLE);
        hindu.setVisibility(View.INVISIBLE);
        kosher.setVisibility(View.INVISIBLE);
        lactoovo.setVisibility(View.INVISIBLE);
        pureveg.setVisibility(View.INVISIBLE);
        vegan.setVisibility(View.INVISIBLE);
        jain.setVisibility(View.INVISIBLE);
    }

    public void set_food_visible()
    {
        glutenfree.setVisibility(View.VISIBLE);
        nutfree.setVisibility(View.VISIBLE);
        halal.setVisibility(View.VISIBLE);
        hindu.setVisibility(View.VISIBLE);
        kosher.setVisibility(View.VISIBLE);
        lactoovo.setVisibility(View.VISIBLE);
        pureveg.setVisibility(View.VISIBLE);
        vegan.setVisibility(View.VISIBLE);
        jain.setVisibility(View.VISIBLE);
    }

    public void set_duration_invisible()
    {
        less_3hours.setVisibility(View.INVISIBLE);
        less_6hours.setVisibility(View.INVISIBLE);
        less_1day.setVisibility(View.INVISIBLE);
        less_2days.setVisibility(View.INVISIBLE);
        less_3days.setVisibility(View.INVISIBLE);
        less_1week.setVisibility(View.INVISIBLE);
        less_10days.setVisibility(View.INVISIBLE);
        less_2weeks.setVisibility(View.INVISIBLE);
        less_3_weeks.setVisibility(View.INVISIBLE);
        less_1month.setVisibility(View.INVISIBLE);
        less_2months.setVisibility(View.INVISIBLE);
        less_3months.setVisibility(View.INVISIBLE);
        more_3months.setVisibility(View.INVISIBLE);
    }
    public void set_duration_visible()
    {
        less_3hours.setVisibility(View.VISIBLE);
        less_6hours.setVisibility(View.VISIBLE);
        less_1day.setVisibility(View.VISIBLE);
        less_2days.setVisibility(View.VISIBLE);
        less_3days.setVisibility(View.VISIBLE);
        less_1week.setVisibility(View.VISIBLE);
        less_10days.setVisibility(View.VISIBLE);
        less_2weeks.setVisibility(View.VISIBLE);
        less_3_weeks.setVisibility(View.VISIBLE);
        less_1month.setVisibility(View.VISIBLE);
        less_2months.setVisibility(View.VISIBLE);
        less_3months.setVisibility(View.VISIBLE);
        more_3months.setVisibility(View.VISIBLE);
    }

    public void setId(int tmpId)
    {
        mGeneralId = tmpId;
    }

    public void setText(String tmpText)
    {
        mGeneralText = tmpText;
    }

    public void setFilter(String foodArr, String transArr, String themeArr, String durationArr)
    {
        mFoodArr = foodArr.split(",");
        mTransArr = transArr.split(",");
        mThemeArr = themeArr.split(",");
        mDurationArr = durationArr.split(",");
    }


    public void setButtonListener(FilterButtonListener tmpListener)
    {
        mFilterButtonListener = tmpListener;
    }

    @Override
    public void onClick(View v)
    {
        if(mFilterButtonListener != null)
        {
            if(v.getId() == R.id.general_ok_only_button)
            {
                mFilterButtonListener.onButtonClickListener(v, mGeneralId, OK_BUTTON, null, null, null, null);
            }
            else if(v.getId() == R.id.general_ok_button)
            {


                ArrayList<String> food_filter = new ArrayList<String>();
                if(glutenfree.isChecked())
                {
                    food_filter.add("18");
                }
                if(nutfree.isChecked())
                {
                    food_filter.add("17");
                }
                if(halal.isChecked())
                {
                    food_filter.add("21");
                }
                if(hindu.isChecked())
                {
                    food_filter.add("20");
                }
                if(kosher.isChecked())
                {
                    food_filter.add("19");
                }
                if(lactoovo.isChecked())
                {
                    food_filter.add("24");
                }
                if(pureveg.isChecked())
                {
                    food_filter.add("23");
                }
                if(vegan.isChecked())
                {
                    food_filter.add("22");
                }
                if(jain.isChecked())
                {
                    food_filter.add("45");
                }

                ArrayList<String> trans_filter = new ArrayList<String>();
                if(airplane.isChecked())
                {
                    trans_filter.add("30");
                }
                if(bicycle.isChecked())
                {
                    trans_filter.add("27");
                }
                if(bus.isChecked())
                {
                    trans_filter.add("32");
                }
                if(car.isChecked())
                {
                    trans_filter.add("25");
                }
                if(monorail.isChecked())
                {
                    trans_filter.add("29");
                }
                if(motorcycle.isChecked())
                {
                    trans_filter.add("26");
                }
                if(ship.isChecked())
                {
                    trans_filter.add("28");
                }
                if(subway.isChecked())
                {
                    trans_filter.add("31");
                }
                if(train.isChecked())
                {
                    trans_filter.add("33");
                }

                ArrayList<String> theme_filter = new ArrayList<String>();
                if(adventure.isChecked())
                {
                    theme_filter.add("41");
                }

                if(culture.isChecked())
                {
                    theme_filter.add("44");
                }

                if(enterinment.isChecked())
                {
                    theme_filter.add("43");
                }

                if(healing.isChecked())
                {
                    theme_filter.add("34");
                }

                if(mystery.isChecked())
                {
                    theme_filter.add("39");
                }

                if(religious.isChecked())
                {
                    theme_filter.add("42");
                }

                if(shopping.isChecked())
                {
                    theme_filter.add("37");
                }

                if(event.isChecked())
                {
                    theme_filter.add("40");
                }

                if(sports.isChecked())
                {
                    theme_filter.add("38");
                }

                if(working.isChecked())
                {
                    theme_filter.add("35");
                }

                ArrayList<String> duration_filter = new ArrayList<String>();
                if(less_3hours.isChecked())
                {
                    duration_filter.add("16");
                }
                if(less_6hours.isChecked())
                {
                    duration_filter.add("15");
                }
                if(less_1day.isChecked())
                {
                    duration_filter.add("14");
                }
                if(less_2days.isChecked())
                {
                    duration_filter.add("13");
                }
                if(less_3days.isChecked())
                {
                    duration_filter.add("12");
                }
                if(less_1week.isChecked())
                {
                    duration_filter.add("11");
                }
                if(less_10days.isChecked())
                {
                    duration_filter.add("10");
                }
                if(less_2weeks.isChecked())
                {
                    duration_filter.add("9");
                }
                if(less_3_weeks.isChecked())
                {
                    duration_filter.add("8");
                }
                if(less_1month.isChecked())
                {
                    duration_filter.add("7");
                }
                if(less_2months.isChecked())
                {
                    duration_filter.add("6");
                }
                if(less_3months.isChecked())
                {
                    duration_filter.add("5");
                }
                if(more_3months.isChecked())
                {
                    duration_filter.add("4");
                }

                String food_filter_str = "";
                if(food_all.isChecked() == false)
                {
                    for(int i = 0; i < food_filter.size(); i++)
                    {
                        if(food_filter_str.equals("") == false)
                        {
                            food_filter_str += ",";
                        }
                        String tmp_filter = food_filter.get(i);

                        food_filter_str += tmp_filter;
                    }
                }

                String trans_filter_str = "";
                if(trans_all.isChecked() == false)
                {
                    for(int i = 0; i < trans_filter.size(); i++)
                    {
                        if(trans_filter_str.equals("") == false)
                        {
                            trans_filter_str += ",";
                        }
                        String tmp_filter = trans_filter.get(i);

                        trans_filter_str += tmp_filter;
                    }
                }

                String theme_filter_str = "";
                if(theme_all.isChecked() == false)
                {
                    for(int i = 0; i < theme_filter.size(); i++)
                    {
                        if(theme_filter_str.equals("") == false)
                        {
                            theme_filter_str += ",";
                        }
                        String tmp_filter = theme_filter.get(i);

                        theme_filter_str += tmp_filter;
                    }
                }

                String duration_filter_str = "";
                if(duration_all.isChecked() == false)
                {
                    for(int i = 0; i < duration_filter.size(); i++)
                    {
                        if(duration_filter_str.equals("") == false)
                        {
                            duration_filter_str += ",";
                        }
                        String tmp_filter = duration_filter.get(i);

                        duration_filter_str += tmp_filter;
                    }
                }

                mFilterButtonListener.onButtonClickListener(v, mGeneralId, OK_BUTTON, food_filter_str, trans_filter_str, theme_filter_str, duration_filter_str);
            }
            else if(v.getId() == R.id.general_cancel_button)
            {
                mFilterButtonListener.onButtonClickListener(v, mGeneralId, CANCEL_BUTTON, null, null, null, null);
            }
        }

        this.dismiss();
    }
}

