package etm.main.market.dialog;

import android.view.View;

public interface FilterButtonListener
{
    void onButtonClickListener(View v, int id, int button, String food_arr_str, String trans_arr_str, String theme_arr_str, String duration_arr_str);
}