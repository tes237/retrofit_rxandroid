package etm.main.market.pages;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import etm.main.market.R;
import etm.main.market.vo.Product;

public class LocalPagerAdapter extends PagerAdapter
{
    public static final int EVERYTHING   = 0;
    public static final int NO_PRICE = 2;

    private LayoutInflater mInflater;
    private Context mContext;
    private ArrayList<Product> mImagePathList;

    private ImageView mPhotoView;
    private TextView mTitleView;
    private TextView mPriceView;

    private int mType;

    public LocalPagerAdapter(Context c, ArrayList<Product> tmpImageList, int type)
    {
        super();
        mInflater = LayoutInflater.from(c);
        mContext = c;

        mImagePathList = tmpImageList;

        mType = type;
    }


    @Override
    public int getCount()
    {
        return mImagePathList.size();
    }


    @Override
    public float getPageWidth(int position)
    {
        //return 0.9f;

        return 1.0f;
    }


    @Override
    public Object instantiateItem(View pager, int position)
    {
        View v = null;

        v = mInflater.inflate(R.layout.page_tour_guide_info, null);

        mPhotoView = (ImageView)v.findViewById(R.id.photo_image_view);
        mTitleView = (TextView)v.findViewById(R.id.photo_title_textview);
        mPriceView = (TextView)v.findViewById(R.id.photo_price_textview);

        String imagePath = mImagePathList.get(position).getImage1();
        //Picasso.with(mContext).load(imagePath).placeholder(R.drawable.sample_photo).resize(400, 100).into(mPhotoView);
        //720, 406
        //Picasso.with(mContext).load(imagePath).placeholder(R.drawable.sample_photo).resize(360, 203).into(mPhotoView);
        Picasso.get().load(imagePath).placeholder(R.drawable.sample_photo).resize(360, 203).into(mPhotoView);
        //Picasso.with(mContext).load(imagePath).into(mPhotoView);

        mTitleView.setText(mImagePathList.get(position).getName());

        if(mType == NO_PRICE)
        {
            mPriceView.setVisibility(View.GONE);
        }
        else
        {
            mPriceView.setText(mImagePathList.get(position).getPrice());
        }

        ((ViewPager)pager).addView(v, 0);

        return v;
    }

    @Override
    public void destroyItem(View pager, int position, Object view)
    {
        ((ViewPager)pager).removeView((View)view);
    }

    @Override
    public boolean isViewFromObject(View pager, Object obj)
    {
        return pager == obj;
    }

    @Override public void restoreState(Parcelable arg0, ClassLoader arg1) {}
    @Override public Parcelable saveState() { return null; }
    @Override public void startUpdate(View arg0) {}
    @Override public void finishUpdate(View arg0) {}
}