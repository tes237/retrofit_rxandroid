package etm.main.market.pages;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import etm.main.market.R;

public class PhotoPagerAdapter extends PagerAdapter
{
    public static final int EVERYTHING   = 0;
    public static final int NO_PRICE = 2;

    private LayoutInflater mInflater;
    private Context mContext;
    private ArrayList<String> mImagePathList;

    private ImageView mPhotoView;
    private TextView mTitleView;
    private TextView mPriceView;

    public PhotoPagerAdapter(Context c, ArrayList<String> tmpImageList)
    {
        super();
        mInflater = LayoutInflater.from(c);
        mContext = c;

        mImagePathList = tmpImageList;
        //mType = type;
    }

    @Override
    public int getCount()
    {
        return mImagePathList.size();
    }


    @Override
    public float getPageWidth(int position)
    {
        //return 0.9f;
        return 1.0f;
    }

    @Override
    public Object instantiateItem(View pager, int position)
    {
        View v = null;

        v = mInflater.inflate(R.layout.page_tour_guide_photo, null);


        mPhotoView = (ImageView)v.findViewById(R.id.photo_image_view);
        //mTitleView = (TextView)v.findViewById(R.id.photo_title_textview);
        //mPriceView = (TextView)v.findViewById(R.id.photo_price_textview);

        //String imagePath = mImagePathList.get(position).getImagePath();
        String imagePath = mImagePathList.get(position);
        //Picasso.with(mContext).load(imagePath).resize(360, 203).into(mPhotoView);

        Picasso.get().load(imagePath).resize(360, 203).into(mPhotoView);

        //Picasso.with(mContext).load(imagePath).placeholder(R.drawable.sample_photo).into(mPhotoView);
        //Picasso.with(mContext).load(imagePath).into(mPhotoView);

        //mTitleView.setVisibility(View.GONE);
        //mPriceView.setVisibility(View.GONE);

        ((ViewPager)pager).addView(v, 0);

        return v;
    }

    @Override
    public void destroyItem(View pager, int position, Object view)
    {
        ((ViewPager)pager).removeView((View)view);
    }

    @Override
    public boolean isViewFromObject(View pager, Object obj)
    {
        return pager == obj;
    }

    @Override public void restoreState(Parcelable arg0, ClassLoader arg1) {}
    @Override public Parcelable saveState() { return null; }
    @Override public void startUpdate(View arg0) {}
    @Override public void finishUpdate(View arg0) {}
}