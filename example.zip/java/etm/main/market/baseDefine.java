package etm.main.market;



public interface baseDefine
{
    public static final boolean IS_DEBUG = true;

    public static final String GENERAL_APP_ID = "etm.main.market";
    public static final String GENERAL_MESSAGE_ID = "etm.main.market.message";
    public static final String GENERAL_LOCATION_DETECTION_ID = "etm.main.market.location";


    public static final String MAP_SKU = "map_sku";
    public static final String IS_TEST_MAP = "is_test_map";
    public static final String MAP_DIR = "map";
    public static final String MAP_TEST_DIR = "map_test";
    public static final String MAP_IMAGE_URL = "map_image_url";
    public static final String MAP_TITLE = "map_title";

    public static final String ROUTE_INDEX = "route_index";

    public static final int TYPE_TEST_MAP = 1;
    public static final int TYPE_PURCHASED_MAP = 0;

    //payment
    public static final int PAYMENT_FINISHED = 100;
    public static final int PAYMENT_CANCELLED= 101;
    public static final int PAYMENT_ERROR= 102;

    /////////////////////////////// JSON //////////////////////////////////

    public static final String JSON_SUCCESS = "success";
    public static final String JSON_FAIL = "fail";
    public static final String JSON_LOGOUT = "logout";

    //----------------------------- broadcast type -----------------------------//
    public static final int MY_LOCATION_CHANGED = 0;
    public static final int LOCATION_DETECTION = 1;
    public static final int NEW_MESSAGE_RECEIVED = 10;

    //----------------------------- device type -----------------------------//
    public static final String DEV_AND = "1";

    //----------------------------- etc  -----------------------------//
    public static final int LOGIN_ACTIVITY_TYPE = 3001;
    public static final int LOGIN_RESULT_SUCCESS = 1001;
    public static final int LOGIN_RESULT_CANCEL = 1002;

    public static final String DEFAULT_PAGE_ITEMS = "10";

    public static final String STORE_ENG = "1";
    public static final String STORE_KOR = "2";
    public static final String STORE_SPN = "3";
    public static final String STORE_POR = "4";
    public static final String STORE_FRN = "5";
    public static final String STORE_ITL = "6";
    public static final String STORE_RUS = "7";
    public static final String STORE_TRDCHN = "8";
    public static final String STORE_SIMCHN = "9";
    public static final String STORE_ARB = "10";
    public static final String STORE_JPN = "11";
    public static final String STORE_GER = "12";


    public static final String STORE_ENG_NAME = "English";
    public static final String STORE_KOR_NAME = "Korean";
    public static final String STORE_SPN_NAME = "Spanish";
    public static final String STORE_POR_NAME = "Portuguese";
    public static final String STORE_FRN_NAME = "French";
    public static final String STORE_ITL_NAME = "Italian";
    public static final String STORE_RUS_NAME = "Russian";
    public static final String STORE_TRDCHN_NAME = "Chinese(Traditional)";
    public static final String STORE_SIMCHN_NAME = "Chinese(Simplified)";
    public static final String STORE_ARB_NAME = "Arabic";
    public static final String STORE_JPN_NAME = "Japanese";
    public static final String STORE_GER_NAME = "German";

}
