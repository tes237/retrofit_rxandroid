package etm.main.market.etc;



public class BooleanWrapper
{
	boolean mBool = false;
	
	public BooleanWrapper(boolean tmp_bool)
	{
		mBool = tmp_bool;
	}
	
	public void setBoolean(boolean tmp_bool)
	{
		mBool = tmp_bool;
	}
	
	public boolean getBoolean()
	{
		return mBool;
	}
}