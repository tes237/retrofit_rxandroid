package etm.main.market.etc;



public class IntegerWrapper
{
	int mInteger = 0;
	
	public IntegerWrapper(int tmp_int)
	{
		mInteger = tmp_int;
	}
	
	public void setInteger(int tmp_int)
	{
		mInteger = tmp_int;
	}
	
	public int getInteger()
	{
		return mInteger;
	}
}