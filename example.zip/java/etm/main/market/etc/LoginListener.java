package etm.main.market.etc;

public interface LoginListener
{
    void onLoginSuccess();
    void onLoginCancel();
}