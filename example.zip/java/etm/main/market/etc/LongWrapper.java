package etm.main.market.etc;



public class LongWrapper
{
	long mLong = 0;
	
	public LongWrapper(long tmp_long)
	{
		mLong = tmp_long;
	}
	
	public void setLong(long tmp_long)
	{
		mLong = tmp_long;
	}
	
	public long getLong()
	{
		return mLong;
	}
}