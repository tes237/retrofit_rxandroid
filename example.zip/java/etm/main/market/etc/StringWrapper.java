package etm.main.market.etc;

public class StringWrapper
{
	String mString = "";
	
	public StringWrapper(String tmp_string)
	{
		mString = tmp_string;
	}
	
	public void setString(String tmp_string)
	{
		mString = tmp_string;
	}
	
	public String getString()
	{
		return mString;
	}
}