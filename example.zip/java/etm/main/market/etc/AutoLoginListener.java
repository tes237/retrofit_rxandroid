package etm.main.market.etc;

public interface AutoLoginListener
{
    void onAutoLoginSuccess();
    void onAutoLoginFail();
}