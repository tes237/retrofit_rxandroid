package etm.main.market.db;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import etm.main.market.BuildConfig;

public class DBAdapter
{
    private static final String TAG = "DBAdapter";
    private static final String PACKAGE_NAME = "etm.main.market";
    private static final String DB_NAME1 = "local_tourguide_info.db";

    private static String ROOT_DIR = "/data/data/" + PACKAGE_NAME + "/databases";

    private static final String TABLE_DB_VERSION = "db_version_tbl";
    private static final String TABLE_MAPS_VERSIONS = "map_versions";
    private static final String TABLE_KEY_FILE_MAP = "key_file_map";

    private static final String TABLE_TEST_MAPS_VERSIONS = "test_map_versions";
    private static final String TABLE_TEST_KEY_FILE_MAP = "test_key_file_map";

    private static final String TABLE_FRIENDS = "local_friends";
    private static final String TABLE_FRIEND_MSG = "friend_msg";
    private static final String TABLE_LAST_REQUEST_MESSAGE_TIME = "last_request_message_time";
    private static final String TABLE_STORE_LANGUAGE = "store_language";
    private static final String TABLE_SEARCH_KEYWORD = "search_keyword";
    private static final String TABLE_LOGIN_AUTH = "login_auth";
    private static final String TABLE_LOGIN_TYPE = "login_type";

    /////////////////// db version table
    public static final String VERSION = "version_val";

    /////////////////// map_versions table
    public static final String FIELD_SKU = "sku";
    public static final String VERSION_INDEX = "version_index";
    public static final String UPDATED_DATE = "updated_date";
    public static final String USER_ID = "user_id";

    /////////////////// key_file_map table
    //public static final String FIELD_SKU = "sku";
    public static final String FILE_KEY = "file_key";
    public static final String FILE_NAME = "file_name";


    /////////////////// test_map_versions table
    public static final String FIELD_MAP_ID = "id";
    //public static final String VERSION_INDEX = "version_index";
    //public static final String UPDATED_DATE = "updated_date";

    /////////////////// test_key_file_map table
    //public static final String FIELD_MAP_ID = "id";
    //public static final String FILE_KEY = "file_key";
    //public static final String FILE_NAME = "file_name";

    /////////////////// local_friends table
    public static final String FROM_ID = "from_id";
    public static final String TO_ID = "to_id";
    public static final String FROM_NAME = "from_name";
    public static final String TO_NAME = "to_name";
    public static final String LOCAL_TIME = "local_last_msg_date";
    public static final String SERVER_TIME = "server_last_msg_date";
    public static final String IS_BLOCKED = "is_blocked";
    public static final String IS_DELETED = "is_deleted";

    /////////////////// friend_msg table
    public static final String MSG = "msg";
    public static final String TIME = "time";

    /////////////////// last_request_message_time table
    public static final String LAST_TIME = "last_time";
    public static final String MY_ID = "my_id";
    public static final String FRIEND_ID = "friend_id";

    /////////////////// store language table
    public static final String LANGUAGE = "language";

    /////////////////// search table
    public static final String KEYWORD_TEXT = "search_keyword";
    public static final String SEARCH_INDEX = "search_index";

    /////////////////// login auth table
    public static final String ID_TEXT = "id_val";
    public static final String PW_TEXT = "pw_val";

    /////////////////// login type table
    public static final String SERVICE_TYPE = "service_type";
    public static final String AUTO_LOGIN_FLAG = "auto_login_flag";

    /////////////////// etc
    public static final int NO_NEW_MESSAGE = 0;
    public static final int NEW_MESSAGE_INSERTED = 1;

    private final Context mCtx;
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        private String DB_PATH = ROOT_DIR + "/";

        String dbName;
        Context context;
        File dbExistCheckFile;

        public DatabaseHelper(Context context, String dbName, CursorFactory factory, int version)
        {
            super(context, dbName, factory, version);

            this.context = context;
            this.dbName = dbName;

            dbExistCheckFile= new File(DB_PATH + dbName);
        }

        @Override
        public synchronized SQLiteDatabase getWritableDatabase()
        {
            if(!dbExistCheckFile.exists())
            {
                SQLiteDatabase db = super.getWritableDatabase();
                copyDataBase(db.getPath());
            }
            return super.getWritableDatabase();
        }

        @Override
        public synchronized SQLiteDatabase getReadableDatabase()
        {
            if(!dbExistCheckFile.exists())
            {
                SQLiteDatabase db = super.getReadableDatabase();
                copyDataBase(db.getPath());
            }
            return super.getReadableDatabase();
        }

        public void install_db()
        {
            String tmp_path = ROOT_DIR + "/" + DB_NAME1;

            if(!dbExistCheckFile.exists())
            {
                copyDataBase(tmp_path);
            }
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {

        }

        private void copyDataBase(String dbPath)
        {
            File folder = new File(ROOT_DIR);
            if (folder.exists())
            {

            }
            else
            {
                folder.mkdirs();
            }

            try
            {
                InputStream assestDB = context.getAssets().open("databases/" + dbName);

                OutputStream appDB = new FileOutputStream(dbPath, false);

                byte[] buffer = new byte[1024];
                int length;

                while ((length = assestDB.read(buffer)) > 0)
                {
                    appDB.write(buffer, 0, length);
                }

                appDB.flush();
                appDB.close();
                assestDB.close();
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public DBAdapter(Context ctx)
    {
        this.mCtx = ctx;
    }

    public void create() throws SQLiteException
    {
        if(BuildConfig.FAKE_DIR == true)
        {
            ROOT_DIR = "/mnt/sdcard/tgm";
        }

        mDbHelper = new DatabaseHelper(mCtx, DB_NAME1, null, 1);
    }

    public void install()
    {
        mDbHelper.install_db();
    }

    public void uninstall()
    {
        String tmp_path = ROOT_DIR + "/" + DB_NAME1;
        File fileDB = new File(tmp_path);
        fileDB.delete();
    }

    public void open() throws SQLiteException
    {
        SQLiteDatabase db = null;

        String tmp_path = ROOT_DIR + "/" + DB_NAME1;

        mDb = SQLiteDatabase.openDatabase(tmp_path, null, SQLiteDatabase.OPEN_READWRITE);
    }

    public void close()
    {
        if(mDbHelper != null)
        {
            mDbHelper.close();
            mDbHelper = null;
        }
    }


    public Cursor fetchAllVersions() throws SQLException
    {
        Cursor all_cursor = mDb.query(true, TABLE_MAPS_VERSIONS,
                new String[] { FIELD_SKU, VERSION_INDEX, UPDATED_DATE, USER_ID },
                null, null, null, null, null, null);

        if (all_cursor != null)
        {
            all_cursor.moveToFirst();
        }
        return all_cursor;
    }


    public Cursor fetchAllVersionsFromTestMap() throws SQLException
    {
        Cursor all_cursor = mDb.query(true, TABLE_TEST_MAPS_VERSIONS,
                new String[] { FIELD_MAP_ID, VERSION_INDEX, UPDATED_DATE, USER_ID },
                null, null, null, null, null, null);

        if (all_cursor != null)
        {
            all_cursor.moveToFirst();
        }
        return all_cursor;
    }

    public Cursor fetchAllKeyFileMap() throws SQLException
    {
        Cursor all_cursor = mDb.query(true, TABLE_KEY_FILE_MAP,
                new String[] { FIELD_SKU, FILE_KEY, FILE_NAME, USER_ID },
                null, null, null, null, null, null);

        if (all_cursor != null)
        {
            all_cursor.moveToFirst();
        }
        return all_cursor;
    }

    public Cursor fetchAllTestKeyFileMap() throws SQLException
    {
        Cursor all_cursor = mDb.query(true, TABLE_TEST_KEY_FILE_MAP,
                new String[] { FIELD_MAP_ID, FILE_KEY, FILE_NAME, USER_ID },
                null, null, null, null, null, null);

        if (all_cursor != null)
        {
            all_cursor.moveToFirst();
        }
        return all_cursor;
    }

    public void putOneVersion(String skyStr, String userIdStr, String versionIndex, String updateDate) throws SQLException
    {
        String tmpSql = "INSERT OR REPLACE INTO " + TABLE_MAPS_VERSIONS + " (" + FIELD_SKU + ", " + VERSION_INDEX + ", " + UPDATED_DATE + ", " + USER_ID + ") VALUES ('" + skyStr + "'," + versionIndex + " ," + updateDate + " ,'" + userIdStr + "');";
        mDb.execSQL(tmpSql);

    }

    public Cursor getOneVersion(String skyStr, String userIdStr) throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT " + FIELD_SKU + ", " + VERSION_INDEX + ", " + UPDATED_DATE + " FROM " + TABLE_MAPS_VERSIONS + " WHERE " + FIELD_SKU + " = '" + skyStr +"' AND " + USER_ID + " = '" + userIdStr +"' ", null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }


    public void putOneVersionForTestMap(String idStr, String versionIndex, String updateDate, String userIdStr) throws SQLException
    {
        String tmpSql = "INSERT OR REPLACE INTO " + TABLE_TEST_MAPS_VERSIONS + " (" + FIELD_MAP_ID + ", " + VERSION_INDEX + ", " + UPDATED_DATE + ", " +  USER_ID + ") VALUES ('" + idStr + "'," + versionIndex + " ," + updateDate + " , '" + userIdStr +"');";
        mDb.execSQL(tmpSql);

    }

    public void deleteOneVersionForTestMap(String idStr, String userIdStr) throws SQLException
    {
        String tmpSql = "delete FROM " + TABLE_TEST_MAPS_VERSIONS + " WHERE " + FIELD_MAP_ID + " = '" + idStr + "' AND " + USER_ID + " = '" + userIdStr +"' ";
        mDb.execSQL(tmpSql);

    }

    public Cursor getOneVersionForTestMap(String idStr, String userIdStr) throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT " + FIELD_MAP_ID + ", " + VERSION_INDEX + ", " + UPDATED_DATE + " FROM " + TABLE_TEST_MAPS_VERSIONS + " WHERE " + FIELD_MAP_ID + " = '" + idStr + "' AND " + USER_ID + " = '" + userIdStr +"' ", null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public void putOneServerFriend(long from_id, long to_id, String from_name, String to_name, String last_msg_date, long is_blocked, long is_deleted) throws SQLException
    {
        Cursor search_cursor = getOneFriend(from_id, to_id);
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_FRIENDS + " SET "
                    + FROM_ID + "='" + String.valueOf(from_id) + "', "
                    + TO_ID + "='" + String.valueOf(to_id) + "', "
                    + FROM_NAME + "='" + from_name + "', "
                    + TO_NAME + "='" + to_name + "', "
                    + SERVER_TIME + "='" + String.valueOf(last_msg_date) + "', "
                    + IS_BLOCKED + "='" + String.valueOf(is_blocked) + "', "
                    + IS_DELETED + "='" + String.valueOf(is_deleted) + "' "
                    + "WHERE " + FROM_ID + "=" + String.valueOf(from_id) + " AND " + TO_ID + "=" + String.valueOf(to_id);
            mDb.execSQL(tmpSql);
        }
        else
        {
            String tmpSql = "INSERT INTO " + TABLE_FRIENDS + " ("
                    + FROM_ID + ", " + TO_ID + ", " + FROM_NAME + ", " + TO_NAME + ", " +  SERVER_TIME + ", " + IS_BLOCKED + ", " + IS_DELETED
                    + ") VALUES ('"
                    + String.valueOf(from_id) + "', '" + String.valueOf(to_id) + "', '" + from_name + "', '" + to_name + "', '" + String.valueOf(last_msg_date) + "', '" + String.valueOf(is_blocked)+ "', '" + String.valueOf(is_deleted)
                    + "')";
            mDb.execSQL(tmpSql);
        }
        search_cursor.close();
    }


    public void putOneLocalAndServerFriend(long from_id, long to_id, String last_msg_date) throws SQLException
    {
        Cursor search_cursor = getOneFriend(from_id, to_id);
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_FRIENDS + " SET "
                    + FROM_ID + "='" + String.valueOf(from_id) + "', "
                    + TO_ID + "='" + String.valueOf(to_id) + "', "
                    + SERVER_TIME + "='" + String.valueOf(last_msg_date) + "', "
                    + LOCAL_TIME + "='" + String.valueOf(last_msg_date) + "' "
                    + "WHERE " + FROM_ID + "=" + String.valueOf(from_id) + " AND " + TO_ID + "=" + String.valueOf(to_id);
            mDb.execSQL(tmpSql);
        }
        else
        {
            String tmpSql = "INSERT INTO " + TABLE_FRIENDS + " ("
                    + FROM_ID + ", " + TO_ID + ", " +  LOCAL_TIME + ", " + SERVER_TIME
                    + ") VALUES ('"
                    + String.valueOf(from_id) + "', '" + String.valueOf(to_id) + "', '" + String.valueOf(last_msg_date) + "', '" + String.valueOf(last_msg_date)
                    + "')";
            mDb.execSQL(tmpSql);
        }
        search_cursor.close();
    }

    public Cursor getOneFriend(long from_id, long to_id) throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT "
                + FROM_ID + ", " + TO_ID + ", " + FROM_NAME + ", " + TO_NAME + ", " + LOCAL_TIME + ", " + SERVER_TIME + ", " + IS_BLOCKED + ", " + IS_DELETED
                + " FROM " + TABLE_FRIENDS + " WHERE " + FROM_ID + "='" + String.valueOf(from_id) +"' AND " + TO_ID + "='" + String.valueOf(to_id) +"' ", null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    //File key does not need user id because it can be shared by every accounts
    public Cursor getFileName(String skuStr, String keyStr, String userIdStr) throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT " + FILE_NAME  + " FROM " + TABLE_KEY_FILE_MAP + " WHERE " + FIELD_SKU + " = '" + skuStr +"' AND " + FILE_KEY + " = '" + keyStr +  "' AND " + USER_ID + " = '" + userIdStr +"' ", null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public Cursor getFileNameForTestMap(String idStr, String keyStr, String userIdStr) throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT " + FILE_NAME  + " FROM " + TABLE_TEST_KEY_FILE_MAP + " WHERE " + FIELD_MAP_ID + " = '" + idStr +"' AND " + FILE_KEY + " = '" + keyStr +  "' AND " + USER_ID + " = '" + userIdStr +"' ", null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public void updateDownloadedNewFileInfo(String skuStr, String keyStr, String fileName, String userIdStr) throws SQLException
    {
        Cursor search_cursor = getFileName(skuStr, keyStr, userIdStr);
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_KEY_FILE_MAP + " SET "
                    + FIELD_SKU + "='" + skuStr + "', "
                    + FILE_KEY + "='" + keyStr + "', "
                    + FILE_NAME + "='" + fileName + "', "
                    + USER_ID + "='" + userIdStr + "' "
                    + "WHERE " + FIELD_SKU + "='" + skuStr + "' AND " + FILE_KEY + "='" + keyStr  +  "' AND " + USER_ID + "='" + userIdStr + "'";
            mDb.execSQL(tmpSql);
        }
        else
        {
            String tmpSql = "INSERT OR REPLACE INTO " + TABLE_KEY_FILE_MAP + " (" + FIELD_SKU + ", " + FILE_KEY + ", " + FILE_NAME  + ", " + USER_ID  + ") VALUES ('" + skuStr + "', '" + keyStr + "', '" + fileName  + "', '" + userIdStr + "');";
            mDb.execSQL(tmpSql);
        }
        search_cursor.close();
    }


    public void updateDownloadedNewFileInfoForTestMap(String idStr, String keyStr, String fileName, String userIdStr) throws SQLException
    {
        Cursor search_cursor = getFileNameForTestMap(idStr, keyStr, userIdStr);
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_TEST_KEY_FILE_MAP + " SET "
                    + FIELD_MAP_ID + "='" + idStr + "', "
                    + FILE_KEY + "='" + keyStr + "', "
                    + FILE_NAME + "='" + fileName + "', "
                    + USER_ID + "='" + userIdStr + "' "
                    + "WHERE " + FIELD_MAP_ID + "='" + idStr + "' AND " + FILE_KEY + "='" + keyStr  +  "' AND " + USER_ID + "='" + userIdStr + "'";
            mDb.execSQL(tmpSql);
        }
        else
        {
            String tmpSql = "INSERT OR REPLACE INTO " + TABLE_TEST_KEY_FILE_MAP + " (" + FIELD_MAP_ID + ", " + FILE_KEY + ", " + FILE_NAME   + ", " + USER_ID  + ") VALUES ('" + idStr + "', '" + keyStr + "', '" + fileName  + "', '" + userIdStr + "');";
            mDb.execSQL(tmpSql);
        }
        search_cursor.close();
    }

    public void deleteDownloadedFileInfoForTestMap(String idStr, String userIdStr) throws SQLException
    {
        String tmpSql = "delete FROM " + TABLE_TEST_KEY_FILE_MAP + " WHERE " + FIELD_MAP_ID + " = '" + idStr + "' AND " + USER_ID + " = '" + userIdStr +"' ";
        mDb.execSQL(tmpSql);
    }


    public Cursor getLastRequestTime(String my_id, String friend_id) throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT " + LAST_TIME  + " FROM " + TABLE_LAST_REQUEST_MESSAGE_TIME + " WHERE " + MY_ID + " = '" + my_id +"' AND " + FRIEND_ID + " = '" + friend_id +"' ", null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public void putLastRequestTime(String my_id, String friend_id, String time_stamp) throws SQLException
    {
        Cursor search_cursor = getLastRequestTime(my_id, friend_id);
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_LAST_REQUEST_MESSAGE_TIME + " SET "
                    + MY_ID + "='" + my_id + "', "
                    + FRIEND_ID + "='" + friend_id + "', "
                    + LAST_TIME + "='" + time_stamp + "' "
                    + "WHERE " + MY_ID + "=" + my_id + " AND " + FRIEND_ID + "=" + friend_id;
            mDb.execSQL(tmpSql);
        }
        else
        {
            String tmpSql = "INSERT INTO " + TABLE_LAST_REQUEST_MESSAGE_TIME + " ("
                    + MY_ID + ", " + FRIEND_ID + ", "  + LAST_TIME
                    + ") VALUES ('"
                    + my_id + "', '" + friend_id + "', '" + time_stamp
                    + "')";
            mDb.execSQL(tmpSql);
        }
        search_cursor.close();
    }


    public Cursor getOneMessage(String messageFromId, String messageToId, String messageTimeStr) throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT "
                + FROM_ID + ", " + TO_ID + ", " + TIME
                + " FROM " + TABLE_FRIEND_MSG + " WHERE " + FROM_ID + "='" + messageFromId +"' AND " + TO_ID + "='" + messageToId +"' AND " + TIME + "='" + messageTimeStr +"'", null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public int putOneMessage(String messageFromId, String messageToId, String messageStr, String messageTimeStr)
    {
        Cursor search_cursor = getOneMessage(messageFromId, messageToId, messageTimeStr);
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_FRIEND_MSG + " SET "
                    + FROM_ID + "='" + messageFromId + "', "
                    + TO_ID + "='" + messageToId + "', "
                    + MSG + "='" + messageStr + "', "
                    + TIME + "='" + messageTimeStr + "' "
                    + "WHERE " + FROM_ID + "=" + messageFromId + " AND " + TO_ID + "=" + messageToId + " AND " + TIME + "=" + messageTimeStr;
            mDb.execSQL(tmpSql);
            search_cursor.close();
            return NO_NEW_MESSAGE;
        }
        else
        {
            String tmpSql = "INSERT INTO " + TABLE_FRIEND_MSG + " ("
                    + FROM_ID + ", " + TO_ID + ", " + MSG + ", " +  TIME
                    + ") VALUES ('"
                    + messageFromId + "', '" + messageToId + "', '" + messageStr + "', '" + messageTimeStr
                    + "')";
            mDb.execSQL(tmpSql);
            search_cursor.close();
            return NEW_MESSAGE_INSERTED;
        }
    }

    public Cursor fetchAllMessages(String my_id, String friend_id)
    {
        final String orderBy = " ORDER BY " + TIME + " ASC";

        Cursor search_cursor = mDb.rawQuery("SELECT "
                + FROM_ID + ", " + TO_ID + ", " + MSG + ", " + TIME +
                " FROM " + TABLE_FRIEND_MSG + " WHERE " +
                "(((" + FROM_ID + "= '" + my_id + "') AND (" + TO_ID + "= '" + friend_id + "'))" +
                "OR ((" + TO_ID + "= '" + my_id + "') AND (" + FROM_ID + "= '" + friend_id + "')))" +
                 orderBy, null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public Cursor fetchAllMessagesSinceTime(String sinceTime, String my_id, String friend_id)
    {
        final String micro_time_str = String.format("%s.000000", sinceTime);
        final String orderBy = " ORDER BY " + TIME + " ASC";

        Cursor search_cursor = mDb.rawQuery("SELECT "
                + FROM_ID + ", " + TO_ID + ", " + MSG + ", " + TIME
                + " FROM " + TABLE_FRIEND_MSG + " WHERE " +
                TIME + ">'" + micro_time_str + "' " +
                "AND" +
                "(((" + FROM_ID + "= '" + my_id + "') AND (" + TO_ID + "= '" + friend_id + "'))" +
                "OR ((" + TO_ID + "= '" + my_id + "') AND (" + FROM_ID + "= '" + friend_id + "')))" +
                orderBy, null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public Cursor fetchAllMessagesFromEveryone()
    {
        Cursor all_cursor = mDb.query(true, TABLE_FRIEND_MSG,
                new String[] { FROM_ID, TO_ID, MSG, TIME },
                null, null, null, null, TIME + " ASC", null);

        if (all_cursor != null)
        {
            all_cursor.moveToFirst();
        }
        return all_cursor;
    }

    public void deleteAllMap()
    {
        String tmpSql = "DELETE FROM " + TABLE_MAPS_VERSIONS;
        mDb.execSQL(tmpSql);

        tmpSql = "DELETE FROM " + TABLE_KEY_FILE_MAP;
        mDb.execSQL(tmpSql);
    }

    public void deleteAllTestMap()
    {
        String tmpSql = "DELETE FROM " + TABLE_TEST_MAPS_VERSIONS;
        mDb.execSQL(tmpSql);

        tmpSql = "DELETE FROM " + TABLE_TEST_KEY_FILE_MAP;
        mDb.execSQL(tmpSql);
    }

    public Cursor getDBVersion() throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT "
                + VERSION
                + " FROM " + TABLE_DB_VERSION, null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public void putDBVersion(String ver)
    {
        Cursor search_cursor = getDBVersion();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_DB_VERSION + " SET "
                    + VERSION + "='" + ver + "'";
            mDb.execSQL(tmpSql);
            search_cursor.close();
        }
        else
        {
            String tmpSql = "INSERT INTO " + TABLE_DB_VERSION + " ("
                    + VERSION
                    + ") VALUES ('"
                    + ver
                    + "')";
            mDb.execSQL(tmpSql);
            search_cursor.close();
        }
    }

    public Cursor getStoreLang() throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT "
                + LANGUAGE
                + " FROM " + TABLE_STORE_LANGUAGE, null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public void putStoreLang(String lang)
    {
        Cursor search_cursor = getStoreLang();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_STORE_LANGUAGE + " SET "
                    + LANGUAGE + "='" + lang + "'";
            mDb.execSQL(tmpSql);
            search_cursor.close();
        }
        else
        {
            String tmpSql = "INSERT INTO " + TABLE_STORE_LANGUAGE + " ("
                    + LANGUAGE
                    + ") VALUES ('"
                    + lang
                    + "')";
            mDb.execSQL(tmpSql);
            search_cursor.close();
        }
    }

    public Cursor getSearchKeyword() throws SQLException
    {
        final String orderBy = " ORDER BY " + SEARCH_INDEX + " ASC";

        Cursor search_cursor = mDb.rawQuery("SELECT "
                + KEYWORD_TEXT
                + " FROM " + TABLE_SEARCH_KEYWORD + orderBy, null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public void putSearchKeyword(ArrayList<String> keyword_list)
    {
        //public static final String KEYWORD_TEXT = "search_keyword";
        //public static final String SEARCH_INDEX = "search_index";

        String tmpSql = "delete FROM " + TABLE_SEARCH_KEYWORD;
        mDb.execSQL(tmpSql);

        for(int x = keyword_list.size()-1; x >= 0 ; x--)
        {
            tmpSql = "INSERT INTO " + TABLE_SEARCH_KEYWORD + " ("
                    + KEYWORD_TEXT + ", " + SEARCH_INDEX
                    + ") VALUES ('"
                    + keyword_list.get(x) + "', '" + String.valueOf(x)
                    + "')";
            mDb.execSQL(tmpSql);
        }
    }


    public Cursor getAutoLoginCheck() throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT "
                + ID_TEXT + ", " + PW_TEXT
                + " FROM " + TABLE_LOGIN_AUTH, null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public void deleLoginInfo()
    {
        String tmpSql = "DELETE FROM " + TABLE_LOGIN_AUTH;
        mDb.execSQL(tmpSql);
    }

    public void putLoginInfo(String idStr, String passwdStr)
    {
        //private static final String TABLE_LOGIN_AUTH = "login_auth";
        //public static final String ID_TEXT = "id_val";
        //public static final String PW_TEXT = "pw_val";

        String tmpSql = "INSERT INTO " + TABLE_LOGIN_AUTH + " ("
                + ID_TEXT + ", " + PW_TEXT
                + ") VALUES ('"
                + idStr + "', '" + passwdStr
                + "')";
        mDb.execSQL(tmpSql);
    }

    public void deleteLoginType() throws SQLException
    {
        String tmpSql = "DELETE FROM " + TABLE_LOGIN_TYPE;
        mDb.execSQL(tmpSql);
    }

    public Cursor getLoginType() throws SQLException
    {
        Cursor search_cursor = mDb.rawQuery("SELECT "
                + SERVICE_TYPE + "," + AUTO_LOGIN_FLAG
                + " FROM " + TABLE_LOGIN_TYPE, null);

        if (search_cursor != null)
        {
            search_cursor.moveToFirst();
        }
        return search_cursor;
    }

    public void putLoginType(String type, String auto_login)
    {
        Cursor search_cursor = getLoginType();
        if(search_cursor != null && search_cursor.moveToFirst())
        {
            String tmpSql = "UPDATE " + TABLE_LOGIN_TYPE + " SET "
                    + SERVICE_TYPE + "='" + type + "', "
                    + AUTO_LOGIN_FLAG + "='" + auto_login + "' ";
            mDb.execSQL(tmpSql);
            search_cursor.close();
        }
        else
        {
            String tmpSql = "INSERT INTO " + TABLE_LOGIN_TYPE + " ("
                    + SERVICE_TYPE + ", " + AUTO_LOGIN_FLAG
                    + ") VALUES ('"
                    + type + "', '" + auto_login
                    + "')";
            mDb.execSQL(tmpSql);
            search_cursor.close();
        }
    }
}
